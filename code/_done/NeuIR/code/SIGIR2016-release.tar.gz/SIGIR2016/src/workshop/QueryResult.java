package workshop;

public class QueryResult {
    private int RANK;
    private int QUERYID;
    private String DOCUMENT;
    private double SCORE;
    public QueryResult(int queryid, String document, int rank, double score){
        QUERYID = queryid;
        RANK = rank;
        SCORE = score;
        DOCUMENT = document;
    }

    public String getDocument(){
        return DOCUMENT;
    }

    public int getRank(){
        return RANK;
    }

    public double getScore(){
        return SCORE;
    }

    public int getQueryId(){
        return QUERYID;
    }

    public String objectToString(){
        return ("Document: " + DOCUMENT + ", Queryid: " + QUERYID + ", Rank: " + RANK + ", Score: " + SCORE);
    }
}
