package workshop;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class ExtractDocuments {

    TreeMap<String, TreeMap<Integer, Integer>> stats = new TreeMap<>();

    public static void main(String[] args){
        String indir = "/home/casper/research/sigir2016-workshop/sampled-docs/TREC/TREC_OFFSET30/two-layer/fixed/";
        String outdir = "/home/casper/research/sigir2016-workshop/constructed-docs/TRECFIXED/two-layer/";
        new ExtractDocuments(indir, outdir);
        //new ExtractDocuments(args[0], args[1]);
    }

    private ExtractDocuments(String indir, String outdir){
        File f = new File(indir);
        if(!f.exists()){
            System.err.println("Directory " + indir + " does not exist.");
            System.exit(-1);
        }
        f = new File(outdir);
        if(!f.exists()){
            System.err.println("Directory " + outdir + " does not exist");
            System.exit(-1);
        }

        doProcess(indir, outdir);
    }

    private void doProcess(String indir, String outdir){
        File f       = new File(indir);
        File[] files = f.listFiles();
        assert files != null;
        if(files.length == 0){
            System.err.println("Directory " + indir + " does not contain any files.");
            System.exit(-1);
        }
        System.out.println("Processing " + files.length + " files");
        for(File sample : files){

            ExtractSyntheticDocument doc = null;
            try {
                doc                                           = new ExtractSyntheticDocument(sample.getAbsolutePath());
                TreeMap<Integer, Vector<Character>> documents = doc.getDocuments();
                stats.put(sample.getName(), doc.getDocumentStatistics());

                for(Map.Entry<Integer, Vector<Character>> entry : documents.entrySet()){
                    int loc = sample.getName().indexOf('.');
                    String d2m = sample.getName().substring(0, loc);
                    String path2make = outdir+d2m+"/";
                    Path path = Paths.get(path2make);
                    Files.createDirectories(path);
                    PrintWriter pw = new PrintWriter(path2make+"document-"+entry.getKey()+".txt");
                    Vector<Character> content = entry.getValue();
                    for(Character c : content){
                        pw.print(c);
                    }
                    pw.flush();
                    pw.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
                System.err.println("There was an error processing " + sample.getAbsolutePath());
                System.exit(-1);
            }
            //System.out.println("Finished processing " + sample.getAbsolutePath());
        }
        System.out.println("Finished processed " + indir);
/*
        System.out.println("Printing document statistics");

        for(Map.Entry<String, TreeMap<Integer, Integer>> entry : stats.entrySet()){
            System.out.println("********************************************************");
            System.out.println("Printing stats for document: " + entry.getKey());
            System.out.println("Found " + entry.getValue().size() + " documents");
            for(Map.Entry<Integer, Integer> stat : entry.getValue().entrySet()){
                System.out.println(stat.getKey() + "," + stat.getValue());
            }
            System.out.println();
        }
        System.out.println("********************************************************");
*/
    }
}
