package workshop;

public class QueryResult2 {
    private int RANK;
    private int QUERYID;
    private String DOCUMENT;
    private String SCORE;
    public QueryResult2(int queryid, String document, int rank, String score){
        QUERYID = queryid;
        RANK = rank;
        SCORE = score;
        DOCUMENT = document;
    }

    public String getDocument(){
        return DOCUMENT;
    }

    public int getRank(){
        return RANK;
    }

    public String getScore(){
        return SCORE;
    }

    public int getQueryId(){
        return QUERYID;
    }

    public String objectToString(){
        return ("Document: " + DOCUMENT + ", Queryid: " + QUERYID + ", Rank: " + RANK + ", Score: " + SCORE);
    }
}
