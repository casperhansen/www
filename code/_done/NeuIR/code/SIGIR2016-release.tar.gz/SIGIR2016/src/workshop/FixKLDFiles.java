package workshop;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;
import java.util.TreeMap;

/**
 * Created by casper on 5/14/16.
 */
public class FixKLDFiles {
    TreeMap<Integer, TreeMap<String, QueryResult>> RES =  new TreeMap<>();
    public static void main(String[] args) throws IOException {
        new FixKLDFiles("/home/casper/research/sigir2016-workshop/queries/reranking/allDocs/KLD/ndcg1000-kld-doc2.txt");
    }

    public FixKLDFiles(String infile) throws IOException {
        RES = parseFile(infile);
        doPrint(infile);
    }

    private void doPrint(String infile) throws IOException {
    PrintWriter pw = new PrintWriter(infile+"-fixed");
    for(Map.Entry<Integer, TreeMap<String, QueryResult>> rerankedAlpha : RES.entrySet())

    {
        ArrayList<QueryResult> l = new ArrayList<>(rerankedAlpha.getValue().values());
        //System.out.println("Queryid: " + rerankedAlpha.getKey() + ", number of entries: " + l.size());
        Collections.sort(l, new QueryResultComparator());
        int rank = 1;
        for (QueryResult qr : l) {
            pw.println(qr.getQueryId() + " Q0 " + qr.getDocument() + " " + rank + " " + qr.getScore() + " " + "rerank");
            rank++;
        }
    }

    pw.flush();
    pw.close();
}


    private TreeMap<Integer, TreeMap<String, QueryResult>> parseFile(String infile) throws IOException {
        TreeMap<Integer, TreeMap<String, QueryResult>> RESULTS = new TreeMap<>();
        FileReader fr = new FileReader(infile);
        BufferedReader br = new BufferedReader(fr);
        String sCurrentLine;
        TreeMap<String, QueryResult> qres = new TreeMap<>(new RevCmpKey());
        sCurrentLine    = br.readLine();
        String[] parts  = sCurrentLine.split("\\s+");
        int qid         = Integer.parseInt(parts[0]);
        int prev_qid    = qid;
        String document = parts[2];
        int docrank     = Integer.parseInt(parts[3]);
        float docscore  = Math.abs(Float.parseFloat(parts[4]));

        if(!Float.isNaN(docscore)){
            qres.put(document, new QueryResult(qid, document, docrank, docscore));
        }

//        qres.put(document, new QueryResult(qid, document, docrank, docscore));

        while((sCurrentLine = br.readLine()) != null){
            parts = sCurrentLine.split("\\s+");
            qid   = Integer.parseInt(parts[0]);
            if(qid == prev_qid){
                document = parts[2];
                docrank  = Integer.parseInt(parts[3]);
                docscore = Math.abs(Float.parseFloat(parts[4]));

                if(!Float.isNaN(docscore)){
                    qres.put(document, new QueryResult(qid, document, docrank, docscore));
                }
                prev_qid = qid;
            }else{
                // We have started a new query
                RESULTS.put(prev_qid, qres);
                qres = new TreeMap<>(new RevCmpKey());

                document = parts[2];
                docrank  = Integer.parseInt(parts[3]);
                docscore = Math.abs(Float.parseFloat(parts[4]));
                if(!Float.isNaN(docscore)){
                    qres.put(document, new QueryResult(qid, document, docrank, docscore));
                }
                //qres.put(document, new QueryResult(qid, document, docrank, docscore));
                prev_qid = qid;
            }
        }
        RESULTS.put(prev_qid, qres);
        fr.close();
        br.close();
/*
        for(Map.Entry<Integer, TreeMap<String, QueryResult> > entry : RESULTS.entrySet()){
            System.out.println("Query: " + entry.getKey());
            for(Map.Entry<String, QueryResult> query : entry.getValue().entrySet()){
                System.out.println(query.getKey() + " : " + query.getValue().objectToString());
            }
        }
*/

        System.out.println("Loaded everything from " + infile);
        return RESULTS;
    }
}
