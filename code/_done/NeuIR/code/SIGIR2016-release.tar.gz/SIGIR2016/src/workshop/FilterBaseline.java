package workshop;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

/**
 * Created by casper on 5/15/16.
 */
public class FilterBaseline {
    TreeMap<Integer, TreeMap<String, QueryResult>> RESULTS = new TreeMap<>();

    int tmp[] = {303,305,308,309,310,312,314,315,316,317,320,323,325,327,328,334,338,340,342,344,348,349,356,361,368,369,379,380,381,393,394,397,398,402,405,408,409,411,418,419,424,429,430,433,442,444,448,449};

    HashSet<Integer> badQueries = new HashSet<Integer>();


    public static void main(String[] args) throws IOException {
        ///home/casper/research/sigir2016-workshop/queries/baseline-xfold-results/bpref/all
        new FilterBaseline("/home/casper/research/sigir2016-workshop/queries/baseline-xfold-results/baseline/bpref");
    }

    public FilterBaseline(String infile) throws IOException {

        for(int i : tmp){
            badQueries.add(i);
        }

        PrintWriter pw = new PrintWriter(infile+"-filtered");
        System.out.println("Bad queries: " + badQueries.size());



        FileReader fr = new FileReader(infile);
        BufferedReader br = new BufferedReader(fr);
        String sCurrentLine;
        double accsum = 0.0;
        int qcounter  = 0;
        while((sCurrentLine = br.readLine()) != null){
            String[] parts = sCurrentLine.split(",");
            int queryid = Integer.parseInt(parts[0]);
            if(!badQueries.contains(queryid)){
                accsum += Double.parseDouble(parts[1]);
                qcounter++;
                pw.println(sCurrentLine);
            }
        }
        pw.println("all," + (accsum/qcounter));
        pw.flush();
        pw.close();
    }
}
