package workshop;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

public class ParseTrecResultFile {


    public static void main(String[] args) throws IOException {
        String measure = "ndcg1000";
        String baselinefile = "/home/casper/research/sigir2016-workshop/queries/baseline-xfold-results/"+measure+"/all";
        String altfile      = "/home/casper/research/sigir2016-workshop/re-run/results/exp2/KLD-twolayer/doc2/"+measure+"/"+measure+"-kld-doc2-twolayer.txt";
        String writename    = measure+"-kld-doc2";
        new ParseTrecResultFile(baselinefile, altfile, writename);
    }

    public ParseTrecResultFile(String baselinefile, String altfile, String measure) throws IOException {
        TreeMap<Integer, TreeMap<String, QueryResult>> baseline = parseFile(baselinefile);
        TreeMap<Integer, TreeMap<String, QueryResult>> alt      = parseFile(altfile);


        double alpharange[] = {0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9};
        //double alpharange[] = {0.1};
        for(double alpha : alpharange){
            System.out.println("Starting for alpha: " + alpha);
            TreeMap<Integer, TreeMap<String, QueryResult>> alphavalres = new TreeMap<>();
            // Loop over the baseline
            for(Map.Entry<Integer, TreeMap<String, QueryResult>> baseresult : baseline.entrySet()){
                int queryid = baseresult.getKey();
                //System.out.println("Looping for query: " + queryid);
                TreeMap<String, QueryResult> baselinequery = baseresult.getValue();
                boolean found = alt.containsKey(baseresult.getKey());
                if(found){
                    // Loop over the ranked lists of the two queries
                    TreeMap<String, QueryResult> altquery = alt.get(baseresult.getKey());

                    // TreeMap to hold the reranked query
                    TreeMap<String, QueryResult> rerankedQuery = new TreeMap<>(new RevCmpKey());

                    for(Map.Entry<String, QueryResult> entry : baselinequery.entrySet()){
                        String docname = entry.getKey();
                        boolean docfound = altquery.containsKey(docname);
                        if(docfound){
                            double altscore = altquery.get(docname).getScore();
                            double rerankedscore = entry.getValue().getScore();
                            if(!Double.isNaN(altscore)) {
                                rerankedscore = (alpha * entry.getValue().getScore()) + (1.0 - alpha) * altquery.get(docname).getScore();
                            }
                            rerankedQuery.put(docname, new QueryResult(queryid,docname,0,rerankedscore));
                        }else{
                            rerankedQuery.put(docname, entry.getValue());
                        }
                    }
                    alphavalres.put(queryid,rerankedQuery);
                }else{
                    //System.err.println("Found nothing for " + baseresult.getKey() + " one of the queries for which we had no data, Inserting from baseline");
                    alphavalres.put(queryid, baselinequery);
                }
            }
            // Now we have everything for all queries for a specific alpha. Now we should print it
            System.out.println("Parsed: " + alphavalres.size() + " queries");
            PrintWriter pw = new PrintWriter("/home/casper/"+measure+"-alpha"+alpha+".txt");
            for(Map.Entry<Integer, TreeMap<String, QueryResult>> rerankedAlpha : alphavalres.entrySet()){
                ArrayList<QueryResult> l = new ArrayList<>(rerankedAlpha.getValue().values());
                //System.out.println("Queryid: " + rerankedAlpha.getKey() + ", number of entries: " + l.size());
                Collections.sort(l, new QueryResultComparator());
                int rank = 1;
                for(QueryResult qr : l){
                    pw.println(qr.getQueryId() + " Q0 " + qr.getDocument() + " " + rank + " " + qr.getScore() + " " + "rerank");
                    rank++;
                }
            }
            pw.flush();
            pw.close();
        }
    }

    private TreeMap<Integer, TreeMap<String, QueryResult>> parseFile(String infile) throws IOException {
        TreeMap<Integer, TreeMap<String, QueryResult>> RESULTS = new TreeMap<>();
        FileReader fr = new FileReader(infile);
        BufferedReader br = new BufferedReader(fr);
        String sCurrentLine;
        TreeMap<String, QueryResult> qres = new TreeMap<>(new RevCmpKey());
        sCurrentLine    = br.readLine();
        String[] parts  = sCurrentLine.split("\\s+");
        int qid         = Integer.parseInt(parts[0]);
        int prev_qid    = qid;
        String document = parts[2];
        int docrank     = Integer.parseInt(parts[3]);
        float docscore  = Float.parseFloat(parts[4]);

        qres.put(document, new QueryResult(qid, document, docrank, docscore));

        while((sCurrentLine = br.readLine()) != null){
            parts = sCurrentLine.split("\\s+");
            qid   = Integer.parseInt(parts[0]);
            if(qid == prev_qid){
                document = parts[2];
                docrank  = Integer.parseInt(parts[3]);
                docscore = Float.parseFloat(parts[4]);
                qres.put(document, new QueryResult(qid, document, docrank, docscore));
                prev_qid = qid;
            }else{
                // We have started a new query
                RESULTS.put(prev_qid, qres);
                qres = new TreeMap<>(new RevCmpKey());

                document = parts[2];
                docrank  = Integer.parseInt(parts[3]);
                docscore = Float.parseFloat(parts[4]);
                qres.put(document, new QueryResult(qid, document, docrank, docscore));
                prev_qid = qid;
            }
        }
        RESULTS.put(prev_qid, qres);
        fr.close();
        br.close();
/*
        for(Map.Entry<Integer, TreeMap<String, QueryResult> > entry : RESULTS.entrySet()){
            System.out.println("Query: " + entry.getKey());
            for(Map.Entry<String, QueryResult> query : entry.getValue().entrySet()){
                System.out.println(query.getKey() + " : " + query.getValue().objectToString());
            }
        }
*/

        System.out.println("Loaded everything from " + infile);
        return RESULTS;
    }
}

class RevCmpKey implements Comparator<String> {

    public int compare(String e1, String e2) {
        return - e1.compareTo(e2);
    }
}

class QueryResultComparator implements Comparator<QueryResult>{
    @Override
    public int compare(QueryResult q1, QueryResult q2){
        return q1.getScore() < q2.getScore() ? -1 : q1.getScore() > q2.getScore() ? 1 : 0;
    }
}