package workshop;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Vector;

public class ReverseScores {

    public static void main(String[] args) throws IOException{
        new ReverseScores();
    }

    public ReverseScores() throws IOException{
        doProcess();
    }

    private void doProcess() throws IOException{
        String filepath = "/home/casper/research/sigir2016-workshop/results/trec-vsm-nostopwords-doc1.res";
        FileReader fr = new FileReader(filepath);
        BufferedReader br = new BufferedReader(fr);
        String sCurrentLine = br.readLine();
        String[] parts = sCurrentLine.split("\\s+");
        String currentQueryId = parts[0];
        Vector<String> content = new Vector<>();
        content.add(sCurrentLine);
        System.out.println("Parsing query " + currentQueryId);
        PrintWriter pw = new PrintWriter("/home/casper/research/sigir2016-workshop/results/trec-vsm-nostopwords-doc1-reversed.res");

        while((sCurrentLine = br.readLine()) != null){
            parts = sCurrentLine.split("\\s+");
            if(parts[0].equalsIgnoreCase(currentQueryId)){
                content.add(sCurrentLine);
            }else{
                // Print in reverse order
                int rank = 1;
                for(int i = content.size()-1; i > 0; i--){
                    String[] pp = content.elementAt(i).split("\\s+");
                    pw.println(pp[0] + " " + pp[1] + " " + pp[2] + " " + rank + " " + pp[4] + " " + pp[5]);
                    rank++;
                }
                pw.flush();
                content.clear();
                content.add(sCurrentLine);
                currentQueryId = parts[0];
                System.out.println("Parsing query " + currentQueryId);
            }
        }
        // Handle last entry
        int rank = 1;
        for(int i = content.size()-1; i > 0; i--){
            String[] pp = content.elementAt(i).split("\\s+");
            pw.println(pp[0] + " " + pp[1] + " " + pp[2] + " " + rank + " " + pp[4] + " " + pp[5]);
            rank++;
        }
        pw.flush();
        pw.close();
    }
}
