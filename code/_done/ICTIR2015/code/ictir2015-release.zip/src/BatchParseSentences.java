import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.*;
import java.util.logging.*;
import java.util.logging.Formatter;

public class BatchParseSentences {
    private String filePath;
    //private String[] dirs = {"en0000/","en0001/","en0002/","en0003/","en0004/","en0005/","en0006/","en0007/","en0008/","en0009/",
    //                         "en0010/","en0011/","enwp00/","enwp01/","enwp02/","enwp03/"};
    private String[] dirs = {""};
    private final int NOF_COH_MEASURES = 15; // IF YOU ADD METRICS INCREASE THIS NUMBER CORRESPONDINGLY
    private HashMap<String, Double> WEIGHTS;
    private HashSet<String> STOPWORDS;
    private String WRITEPATH;
    private boolean projGraphLCC    = !Constants.LargestCCOnly;
    private boolean removeStopWords = Constants.RemoveStopWordSentences;   // We remove stop-word sentences full stop!
    private Auxiliary AUX;
    private String OUTDIR;
    private String SERVER;

    // Logger
    static Logger logger = Logger.getLogger("SIGIR");
    static Logger output = Logger.getLogger("OUTPUT");

    public BatchParseSentences(String filedir, String outdir, int projGraph, int projGraphType, int AGGREGATION_METHOD, String server ) throws IOException {
        /*
         * First argument is the directory of the sentence files
         * Second argument is the full path of the html file used for logging i.e. /home/cazz/log.html
         * Third argument is EITHER the path where the coherence metric result file will be written (if we use the log
         * approach), OR the directory where individual files will be written to.
         */
        SERVER = server;
        File f = new File(filedir);
        if(!f.isDirectory()){
            System.err.println(filedir + " is not a directory.");
            System.exit(-1);
        }
        filePath = filedir;

        File f1 = new File(outdir);
        if(!f1.exists()){
            f1.mkdir();
            System.out.println("Created " + outdir);
        }
        OUTDIR = outdir;
        logger.setLevel(Level.FINEST); //Log everything from finest and up
        FileHandler fileHTML = new FileHandler(outdir+"log.html");
        Formatter formatterHTML = new MyHtmlFormatter();
        fileHTML.setFormatter(formatterHTML);
        logger.addHandler(fileHTML);

        output.setLevel(Level.FINEST);
        FileHandler fileTXT = new FileHandler(outdir+"metrics.score");
        Formatter formatterTXT = new MyTXTFormatter();
        fileTXT.setFormatter(formatterTXT);
        output.addHandler(fileTXT);
        WRITEPATH = "";

        logger.log(Level.INFO, "Reading from directory " + filePath);
        logger.log(Level.INFO, "Logging all files to " + outdir);

        AUX = new Auxiliary();
        if(projGraphType == Constants.SyntacticProjection){
            try {
                System.out.println("Loading IDF weights");
                WEIGHTS = AUX.loadIdfWeights();
            } catch (IOException e) {
                logger.log(Level.SEVERE, "Could not load IDF weights");
                System.exit(-1);
            }
        }

        if(removeStopWords){
            try {
                STOPWORDS = AUX.loadStopWordList();
            }catch(IOException ioe){
                logger.log(Level.SEVERE, "Could not load stopword list");
                System.err.println("Could not load stopword list");
                System.exit(-1);
            }
        }


        runFileParser(projGraph, projGraphType, AGGREGATION_METHOD);
    }

    public void runFileParser(int projGraph, int projGraphType, int AGGREGATION_METHOD) throws IOException {
        final int N_THREADS = Runtime.getRuntime().availableProcessors()-1;
        final int BLOCKING_QUEUE_SIZE = 25;
        BlockingQueue<Runnable> blockingQueue = new ArrayBlockingQueue<Runnable>(BLOCKING_QUEUE_SIZE);
        RejectedExecutionHandler rejectedExecutionHandler = new ThreadPoolExecutor.CallerRunsPolicy();
        ThreadPoolExecutor service = new ThreadPoolExecutor(N_THREADS, N_THREADS, 1, TimeUnit.SECONDS, blockingQueue, rejectedExecutionHandler);
        ScheduledExecutorService pool = Executors.newScheduledThreadPool(1);
        service.allowCoreThreadTimeOut(true);
        logger.log(Level.CONFIG, "Using " + N_THREADS + " cores and blocking queue of " + BLOCKING_QUEUE_SIZE);
        logger.log(Level.CONFIG, "Parameters: " + Constants.getGraph(projGraph,true) + " : " +
                Constants.getProjection(projGraphType,true) + " : " +
                Constants.getLargestCC(projGraphLCC,true) + " : " +
                Constants.getStopWordsUsed(removeStopWords,true) + " : " +
                Constants.getAggregation(AGGREGATION_METHOD,true));
        if(AGGREGATION_METHOD == Constants.AGGREGATION_METHOD_AVERAGE){
            logger.log(Level.WARNING, "You are averaging with the distance function. Be careful");
        }
        // filepath is /data/local/workspace/casper_petersen/sigir2014/out/spamfree/out/enwp00/
        // We want to loop over the files in the directories therein
        long globalstart = System.currentTimeMillis();
        output.log(Level.FINEST, "#,"+(NOF_COH_MEASURES+1)); // So we have the information necessary for splitting the file
        int totalNumberOfDocs = 0;
        for(String cdir : dirs){
            long tstart    = System.currentTimeMillis();
            File dir       = new File(filePath+cdir);
            File[] content = dir.listFiles(new FilenameFilter() {
                public boolean accept(File dir, String name) {
                    return name.toLowerCase().endsWith(".sentence");
                }
            });
//            File[] content = dir.listFiles();
            if(content == null){
                logger.log(Level.SEVERE, "Could not access directory " + filePath);
                System.exit(-1);
            }
            int totaldocs  = content.length;
            if(totaldocs == 0){
               continue;
            }
            int counter    = 1;

            System.out.println("Found " + totaldocs + " documents");
            //noinspection ConstantConditions
            for(File f : content){
                if(f.isFile()){
                    String filepath = f.getAbsoluteFile().toString();
                    FileParser3 fp3 = new FileParser3(filepath,
                                projGraph,
                                projGraphType,
                                removeStopWords,
                                AGGREGATION_METHOD,
                                WEIGHTS,
                                STOPWORDS,
                                NOF_COH_MEASURES,
                                "");
                    final Future<?> ff = service.submit(fp3);
                    pool.schedule(new Runnable() {
                        @Override
                        public void run() {
                            if(!ff.isDone()){
                                ff.cancel(true);
                                System.out.println("Interrupted");
                            }
                        }
                    }, 5, TimeUnit.MINUTES);


                    if((counter%1000) == 0 || counter == totaldocs){
                        System.out.println("Submitted " + counter+"/"+totaldocs + ", Completed jobs: " + service.getCompletedTaskCount() + ", Active count: " + service.getActiveCount() + ", pool size: " + service.getPoolSize());
                    }
                    if(counter == totaldocs){
                        break;
                    }
                    counter++;
                }
            }
            long tend    = System.currentTimeMillis();
            String opt = "Finished "+cdir+" in " + ((tend-tstart)/(60*60*1000)) + " hours";
            logger.log(Level.INFO,opt);
        }
        SendMail sm = new SendMail();
        sm.doSentEmail(SERVER+" has submitted all jobs");
        service.shutdown();
        while(!service.isTerminated()){
                if(service.getQueue().size() != 0){
                    logger.log(Level.INFO, "Queue not empty. Still " + service.getQueue().size() + " jobs remaining. Waiting for 20 seconds");
                    try {
                        Thread.sleep(20000);
                    } catch (InterruptedException e) {
                    }
                }else{
                    logger.log(Level.INFO, "Queue empty! Halting service now");
                    service.shutdownNow();
                }

        };
        pool.shutdownNow();

        //noinspection StatementWithEmptyBody
        long globalend = System.currentTimeMillis();
        String opt = "Finished all threads in " + ((globalend-globalstart)/(60*60*1000)) + " hours";
        logger.log(Level.INFO,opt);
    }
}
