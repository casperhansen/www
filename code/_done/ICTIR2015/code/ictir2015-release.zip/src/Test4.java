import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.UndirectedSparseGraph;

import java.io.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Test4 {
    public static void main(String[] args) throws IOException {
        new Test4();
/*
        final Pattern p = Pattern.compile("#\\w+\\((.+)\\)");
        final Matcher matcher = p.matcher(ss[0]);
        while(matcher.find()){
            System.out.println(matcher.group(1));
        }
*/
    }
    public Test4(){
        entropy();
    }

    public TreeMap<String, Double> calcProbHist(TreeMap<Integer, String> map){
        TreeMap<String, Integer> hist = new TreeMap<String, Integer>();
        int rSum = 0;
        for(Map.Entry<Integer,String> entry : map.entrySet()){
            if(!hist.containsKey(entry.getValue())){
                hist.put(entry.getValue(), 1);
                rSum++;
            }else{
                hist.put(entry.getValue(), hist.get(entry.getValue()) + 1);
                rSum++;
            }
        }
        System.out.println(hist.toString());
        TreeMap<String, Double> probHist = new TreeMap<String, Double>();
        for(Map.Entry<String, Integer> entry : hist.entrySet()){
            probHist.put(entry.getKey(), (double)entry.getValue()/rSum);
        }
        hist = null;
        double rr = 0.0;
        for(Map.Entry<String, Double> entry : probHist.entrySet()){
            rr += entry.getValue();
        }
        //System.out.println("Total probability: " + rr);
        return probHist;
    }

    public double entropy(){
/*
        List<Entity> data = new ArrayList<Entity>();
        data.add(new Entity("V1",0,"","",0,2,"man"));
        data.add(new Entity("V2",0,"","",0,5,"newspaper"));
        data.add(new Entity("V3",0,"","",0,8,"office"));
        data.add(new Entity("V4",0,"","",0,13,"newspaper"));
        data.add(new Entity("V5",0,"","",0,16,"office"));
        data.add(new Entity("V6",0,"","",0,19,"desk"));
        data.add(new Entity("V7",0,"","",0,21,"man"));
        data.add(new Entity("V8",0,"","",0,23,"man"));
        data.add(new Entity("V9",0,"","",0,25,"habit"));
        data.add(new Entity("V10",0,"","",0,32,"man"));
        Graph<Node, Integer> graph = new UndirectedSparseGraph<Node, Integer>();
        graph.addVertex(new Node("V1",0,"","",0,2,"man"));
        graph.addVertex(new Node("V9",0,"","",0,25,"habit"));
        graph.addVertex(new Node("V2",0,"","",0,5,"newspaper"));
        graph.addVertex(new Node("V3",0,"","",0,8,"office"));
        graph.addVertex(new Node("V7",0,"","",0,21,"man"));
        graph.addVertex(new Node("V4",0,"","",0,13,"newspaper"));
        graph.addVertex(new Node("V5",0,"","",0,16,"office"));
        graph.addVertex(new Node("V6",0,"","",0,19,"desk"));
        graph.addVertex(new Node("V8",0,"","",0,23,"man"));
        graph.addVertex(new Node("V10",0,"","",0,32,"man"));
*/
/*
        List<Entity> data = new ArrayList<Entity>();
        data.add(new Entity("V1",0,"","",0,2,"S"));
        data.add(new Entity("V2",0,"","",0,4,"S"));
        data.add(new Entity("V3",0,"","",0,6,"O"));
        data.add(new Entity("V4",0,"","",0,8,"O"));
        data.add(new Entity("V5",0,"","",0,10,"O"));
        data.add(new Entity("V6",0,"","",0,12,"S"));
        data.add(new Entity("V7",0,"","",0,14,"O"));
        data.add(new Entity("V8",0,"","",0,16,"S"));
        data.add(new Entity("V9",0,"","",0,18,"S"));
        data.add(new Entity("V10",0,"","",0,20,"O"));
        data.add(new Entity("V11",0,"","",0,22,"S"));
*/
        List<Entity> data = new ArrayList<Entity>();
        data.add(new Entity("V1",0,"","",0,2,"Julian"));
        data.add(new Entity("V2",0,"","",0,4,"Thomas"));
        data.add(new Entity("V3",0,"","",0,6,"Theory"));
        data.add(new Entity("V4",0,"","",0,8,"Theory"));
        data.add(new Entity("V5",0,"","",0,10,"S"));
        data.add(new Entity("V6",0,"","",0,12,"O"));
        data.add(new Entity("V7",0,"","",0,14,"S"));
        data.add(new Entity("V8",0,"","",0,16,"S"));
        data.add(new Entity("V9",0,"","",0,18,"O"));
/*
        Graph<Node, Integer> graph = new UndirectedSparseGraph<Node, Integer>();
        graph.addVertex(new Node("V1",0,"","",0,2,"A"));
        graph.addVertex(new Node("V2",0,"","",0,4,"B"));
        graph.addVertex(new Node("V3",0,"","",0,6,"C"));
        graph.addVertex(new Node("V4",0,"","",0,8,"A"));
        graph.addVertex(new Node("V5",0,"","",0,10,"B"));
        graph.addVertex(new Node("V6",0,"","",0,12,"B"));
        graph.addVertex(new Node("V7",0,"","",0,14,"C"));


//        ArrayList<Node> list         = new ArrayList<Node>(graph.getVertices());
/*
        TreeMap<Integer, Node> t     = new TreeMap<Integer, Node>();
        for(Node e : list){
            t.put(e.getPositionInDocument(), e);
        }
*/
        TreeMap<Integer, String> tMap0 = new TreeMap<Integer, String>();
        for(Entity e : data){
            tMap0.put(e.getPositionInDocument(), e.getWord());
        }

        //0-order
        TreeMap<String, Double> order0 = calcProbHist(tMap0);
        System.out.println("order0: " + order0.toString());
        double rsum = 0.0;
        for(Map.Entry<String, Double> entry : order0.entrySet()){
            double val = entry.getValue()*(Math.log(entry.getValue())/Math.log(2.0));
            //System.out.println("Entropy for " + entry.getKey() + " = " + val);
            rsum += val;
        }
        //System.out.println("Entropy for document is: " + rsum);

        //1-order
        TreeMap<Integer, String> tMap1 = new TreeMap<Integer, String>();
        int N = data.size();
        for(int i = 0; i < N-1; i++){
            Entity e1 = data.get(i);
            Entity e2 = data.get(i+1);
            String combKey = e1.getWord()+":"+e2.getWord();
            tMap1.put(i, combKey);
        }
        TreeMap<String, Double> order1 = calcProbHist(tMap1);
        System.out.println("Order1 : " + order1.toString());

        //2-order
        TreeMap<Integer, String> tMap2 = new TreeMap<Integer, String>();
        for(int i = 0; i < N-2; i++){
            Entity e1 = data.get(i);
            Entity e2 = data.get(i+1);
            Entity e3 = data.get(i+2);
            String combKey = e1.getWord()+":"+e2.getWord()+":"+e3.getWord();
            tMap2.put(i, combKey);
        }
        TreeMap<String, Double> order2 = calcProbHist(tMap2);
        System.out.println("Order2 : " + order2.toString()+"\n");

        double total = 0.0;
        for(Map.Entry<String, Double> ord0 : order0.entrySet()){
            String key      = ord0.getKey();
            double ord0prob = ord0.getValue(); // p_i
            double ord1total = 0.0;
            for(Map.Entry<String, Double> ord1 : order1.entrySet()){ // Order-1 sum
                String[] ssplit = ord1.getKey().split(":");
                double ord1prob = ord1.getValue();
                double order2total = 0.0;
                if(key.equals(ssplit[0])){       //word j follows i
                    for(Map.Entry<String, Double> nextOrder : order2.entrySet()){// Order-2 sum
                        String[] next = nextOrder.getKey().split(":");
                        if(ssplit[1].equals(next[1])){
                            double tmp = nextOrder.getValue();
                            order2total += tmp * (Math.log(tmp)/Math.log(2));
                            System.out.println("Match: ord0key = " + key + "("+ord0prob+"), ord1key = "+ord1.getKey() + "("+ord1prob+"), ord2key = " + nextOrder.getKey() + "(" + nextOrder.getValue() +")");
                        }
                    }
                }
                ord1total += ord1prob*order2total;  // \sum_i p_i \sum_j p_ij(j)\log_2 p_ij(j)
            }
            System.out.println("After finishing order1 for " + key + ", ord1total is: " + ord1total);
            total += ord0prob*ord1total;
        }
        System.out.println("Entropy of o2-model: " + total);
        return 0.0;
    }
}
