import java.io.*;

public class IndriOutputParser {
    public static void main(String[] args) throws IOException {
        new IndriOutputParser(args);
    }

    public IndriOutputParser(String[] args) throws IOException {
	/*
	 * First argument is the IndriRunQuery output file i.e. IndriRunQuery some.queries > out.txt
	 * Second argument is the fixed out.txt file
	 */
        parseIndri(args[0], args[1]);
    }

    public void parseIndri(String r, String w) throws IOException {
        FileReader fr = new FileReader(r);
        BufferedReader br = new BufferedReader(fr);
        FileWriter fw = new FileWriter(w);
        BufferedWriter bw = new BufferedWriter(fw);
        String sCurrentLine = "";
        while((sCurrentLine = br.readLine()) != null){
            String fixed = splitAndFix(sCurrentLine);
            //bw.write(fixed);
            //bw.flush();
            //bw.newLine();
        }
        fr.close();
        br.close();
        fw.close();
        bw.close();
    }

    public String splitAndFix(String line){
        String[] ssplit = line.split("\\s");
        String path =   ssplit[2];
        int idx1 = path.lastIndexOf("/");
        int idx2 = path.lastIndexOf(".");
        String ret = "";
        try{
            ret = ssplit[0]+" "+ssplit[1]+" "+path.substring(idx1+1,idx2)+" "+ssplit[3]+" "+ssplit[4]+" "+ssplit[5];
        }catch(StringIndexOutOfBoundsException sioe){
            System.out.println(line);
        }
        return ret;
    }

}
