import org.apache.commons.collections15.Transformer;
import java.awt.*;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Vector;

public class Transformers {
    public Transformers(){}
    public Transformer<Link, String> edgeLabel = new Transformer<Link, String>() {
        public String transform(Link e) {
            return "<html><font size=5><b>"+e.getLabel()+"</b></font></html>";
        }
    };

    public Transformer<Link, Stroke> edgeStroke = new Transformer<Link, Stroke>() {
        public Stroke transform(Link s) {
            return new BasicStroke(1.0f);
        }
    };

    public Transformer<Entity, String> vertexLabelTransformer = new Transformer<Entity, String>() {
        public String transform(Entity e) {
            return "<html><font size=3><b>"+String.valueOf(e)+"</b></font></html>";
        }
    };

    public Transformer<Entity, String> vertexTransformer = new Transformer<Entity, String>() {
        public String transform(Entity e) {
            if(e.getWord().equals("<NULL>")){
               return "<html><font size=2><b>"+e.getLabel()+"</b></font></html>";
            }
            return "<html><font size=2><b>"+e.getWord()+"</b></font></html>";
        }
    };
}
