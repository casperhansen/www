import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Data {
    static Logger logger = Logger.getLogger("SIGIR");
    public static PrintWriter out = null;
    public static Data instance = null;

    private Data() throws IOException {
        super();
        logger.setLevel(Level.FINEST);
        out = new PrintWriter(new FileWriter("multithreadtextfile.txt"));
    }

    public static Data getInstance() throws IOException {
        if(instance==null){
            synchronized(Data.class){
                instance=new Data();
            }
        }
        return instance;
    }

    public void writeToFile(String str){
        synchronized(instance){
            out.println(str);
            out.flush();
        }
    }
}