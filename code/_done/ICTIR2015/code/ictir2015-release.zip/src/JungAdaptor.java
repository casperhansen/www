import edu.uci.ics.jung.algorithms.layout.CircleLayout;
import edu.uci.ics.jung.algorithms.layout.Layout;
import edu.uci.ics.jung.graph.DirectedGraph;
import edu.uci.ics.jung.visualization.BasicVisualizationServer;
import edu.uci.ics.jung.visualization.decorators.ToStringLabeller;
import edu.uci.ics.jung.visualization.renderers.Renderer;

import javax.swing.*;
import java.awt.*;

public class JungAdaptor {
/*
    public static void show(DirectedGraph g) {
        Layout layout = new CircleLayout(g);
        layout.setSize(new Dimension(600,600));
        BasicVisualizationServer vv = new BasicVisualizationServer(layout);
        vv.setPreferredSize(new Dimension(640,640)); //Sets the viewing area size
        vv.getRenderContext().setVertexLabelTransformer(new ToStringLabeller());
        vv.getRenderContext().setEdgeLabelTransformer(new ToStringLabeller());
        vv.getRenderer().getVertexLabelRenderer().setPosition(Renderer.VertexLabel.Position.CNTR);

        JFrame frame = new JFrame("Graph View");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(vv);
        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        JungTest myApp = new JungTest();
        myApp.constructGraph();
        System.out.println(myApp.g.toString());
        myApp.calcUnweightedShortestPath();
        myApp.calcWeightedShortestPath();
        myApp.calcMaxFlow();
        JCat.jtest();
    }
*/
}