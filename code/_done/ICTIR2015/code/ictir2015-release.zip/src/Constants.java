public class Constants {
    public static final int UndirectedGraph            = 0;
    public static final int DirectedGraph              = 1;
    public static final int UnweightedProjection       = 0;
    public static final int WeightedProjection         = 1;
    public static final int SyntacticProjection        = 2;
    public static boolean LargestCCOnly                = true;
    public static boolean RemoveStopWordSentences      = true;
    public static final int AGGREGATION_METHOD_MEDIAN  = 0;
    public static final int AGGREGATION_METHOD_AVERAGE = 1;
    public static final int AGGREGATION_METHOD_MODE    = 2;
    public static final String TERMS_IDF_PATH          = "C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2014\\data\\terms_idf\\old\\";
    public static final String STOPWORDLIST            = "C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2014\\data\\stop_words.txt";

    public static String getGraph(int id, boolean forlogger){
        if(forlogger){
            switch(id){
                case 0: return "UndirectedGraph";
                default: return "DirectedGraph";
            }
        }else{
            switch(id){
                case 0: return "0";
                default: return "1";
            }
        }
    }

    public static String getProjection(int id, boolean forlogger){
        if(forlogger){
            switch(id){
                case 0: return "Unweighted";
                case 1: return "Weighted";
                default: return "Syntactic";
            }
        }else{
            switch(id){
                case 0: return "0";
                case 1: return "1";
                default: return "2";
            }
        }
    }

    public static String getLargestCC(boolean b, boolean forlogger){
        if(forlogger){
            if(b){
               return "LCC";
            }else{
               return "Full";
            }
        }else{
            if(b){
                return "0";
            }else{
                return "1";
            }
        }
    }

    public static String getStopWordsUsed(boolean b, boolean forlogger){
        if(forlogger){
            if(b){
                return "WithoutStopwords";
            }else{
                return "WithStopwords";
            }
        }else{
            if(b){
                return "0";
            }else{
                return "1";
            }
        }
    }

    public static String getAggregation(int id, boolean forlogger){
        if(forlogger){
            String type;
            switch(id){
                case 0: type = "Median"; break;
                case 1: type = "Average"; break;
                default: type = "Mode";
            }
            return type;
        }else{
            String type;
            switch(id){
                case 0: type = "0"; break;
                case 1: type = "1"; break;
                default: type = "2";
            }
            return type;
        }
    }
}
