import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;

public class Prels2Qrels{
    public static void main(String[] args) throws IOException {
        if(args.length != 4){
            System.out.println("Four arguments required. " +
                    "1 - The *.prels file."+
                    "2 - The tmp qrel file resulting from processing the prel file"+
                    "3 - The path of the directory containing the *.text files that was indexed"+
                    "4 - The final qrel file resulting from removing qrels from (2) if they exist in (3) and have a val > 0");
            System.exit(-1);
        }
        new Prels2Qrels(args);
    }

    public Prels2Qrels(String[] args) throws IOException {
        doParse(args[0], args[1], args[2], args[3]);
    }

    public void doParse(String prelsfile, String qrelspath, String indexdocpath, String finalqrelsfile) throws IOException {
        FileReader fr     = new FileReader(prelsfile);
        BufferedReader br = new BufferedReader(fr);
        FileWriter fw     = new FileWriter(qrelspath);
        BufferedWriter bw = new BufferedWriter(fw);
        String sCurrentLine;
        while((sCurrentLine = br.readLine()) != null){
            String[] ssplit = sCurrentLine.split(" ");
            double qrel = Double.valueOf(ssplit[2]);
            String qrelval = "";
            if(qrel < 0){
                // Truncate to 0
                qrelval = "0";
            }else{
                qrelval = ssplit[2];
            }
            String toWrite  = ssplit[0]+" 0 "+ssplit[1]+" "+qrelval;
            bw.write(toWrite+"\n");
            bw.flush();
        }

        fr.close();
        br.close();
        fw.close();
        bw.close();

        HashSet<String> docnames = new HashSet<String>();
        File dir       = new File(indexdocpath);
        File[] content = dir.listFiles();
        int N          = content.length;
        for(File f : content){
            Path p      = Paths.get(f.getAbsoluteFile().toString());
            String name = p.getFileName().toString();
            System.out.println(name);
            docnames.add(name.substring(0,name.lastIndexOf(".")));
        }
        fr = new FileReader(qrelspath);
        br = new BufferedReader(fr);
        fw = new FileWriter(finalqrelsfile);
        bw = new BufferedWriter(fw);
        //Looper over qrels
        while((sCurrentLine = br.readLine()) != null){
            String[] ssplit = sCurrentLine.split(" ");
            String name = ssplit[2];
            // Document in qrels matches one in our collection of ~54.000 documents
            if(!docnames.contains(name)){
                // If it has a value greater than 0 we remove it to avoid biasing our results
                int val = Integer.valueOf(ssplit[3]);
                if(val <= 0){
                    bw.write(sCurrentLine+"\n");
                    bw.flush();
                }
            }else{
                bw.write(sCurrentLine+"\n");
                bw.flush();
            }
        }
        bw.flush();
        fr.close();
        br.close();
        fw.close();
        bw.close();
    }
}