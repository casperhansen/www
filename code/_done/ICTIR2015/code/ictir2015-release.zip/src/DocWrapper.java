public class DocWrapper {
    private double COH1,COH2,COH3,COH4,COH5,COH6;
    private String FILENAME;
    public DocWrapper(String filename, double coh1, double coh2, double coh3, double coh4, double coh5, double coh6){
        FILENAME = filename;
        COH1 = coh1;
        COH2 = coh2;
        COH3 = coh3;
        COH4 = coh4;
        COH5 = coh5;
        COH6 = coh6;
    }

    public String toString(){
        return FILENAME+","+COH1+","+COH2+","+COH3+","+COH4+","+COH5+","+COH6;
    }

    public String getFileName(){
        return FILENAME;
    }

    public double getCOH1(){
        return COH1;
    }

    public double getCOH2(){
        return COH2;
    }

    public double getCOH3(){
        return COH3;
    }

    public double getCOH4(){
        return COH4;
    }

    public double getCOH5(){
        return COH5;
    }

    public double getCOH6(){
        return COH6;
    }
}
