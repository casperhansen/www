import edu.uci.ics.jung.algorithms.cluster.WeakComponentClusterer;
import edu.uci.ics.jung.algorithms.filters.FilterUtils;
import edu.uci.ics.jung.algorithms.layout.*;
import edu.uci.ics.jung.graph.*;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.visualization.BasicVisualizationServer;
import edu.uci.ics.jung.visualization.control.CrossoverScalingControl;
import edu.uci.ics.jung.visualization.control.ScalingControl;
import javax.swing.*;
import java.awt.*;
import java.awt.geom.Point2D;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.Callable;
import java.util.logging.Level;
import java.util.logging.Logger;

import static java.lang.Integer.parseInt;

public class FileParser2 implements Callable<DocWrapper>{
    private String fileName;
    private String DOCNAME;
    private boolean ISCONNECTED;
    private boolean LARGESTWEAKCCONLY;
    private boolean REMOVESTOPWORDS;
    private int AGGREGATIONTYPE;
    private int GRAPHTYPE;
    private int GRAPHVIZTYPE;
    private Vector<String> content;
    private Set<Entity> SENTENCENUMBERS;
    private Set<Integer> intsentencenumbers;
    private HashMap<String,Vector<Entity>> INVINDEX;
    private DelegateForest<Entity, Link> graph;
    private Graph<Entity, Link> projectionGraph;
    private HashMap<Integer, Entity> vertexmap;
    private HashSet<String> STOPWORDS;
    private HashMap<String, Double> WEIGHTS;
    public Vector<Double> projectionEdgeWeights;
    public int MAX_SENTENCE;
    public HashMap<Entity, String> numberwordmap;
    private Auxiliary AUX;
    static Logger logger = Logger.getLogger("SIGIR");

    public FileParser2(String f, int graphtype, int graphviztype,
                      boolean largestWeakCCOnly, boolean removestopwords,
                      int aggregationtype, int threadID, HashMap<String,
            Double> weights, HashSet<String> stopwords) throws IOException {
        logger.setLevel(Level.FINEST);
        fileName          = f;
        GRAPHTYPE         = graphtype;
        GRAPHVIZTYPE      = graphviztype;
        LARGESTWEAKCCONLY = largestWeakCCOnly;
        REMOVESTOPWORDS   = removestopwords;
        AGGREGATIONTYPE   = aggregationtype;
        WEIGHTS           = weights;
        STOPWORDS         = stopwords;
        ISCONNECTED       = true;            // We assume that all graphs are connected to begin with
        projectionEdgeWeights = new Vector<Double>();
        AUX                   = new Auxiliary();

        Path p  = Paths.get(fileName);
        String dname = p.getFileName().toString();
        DOCNAME = dname.substring(0,dname.lastIndexOf("."));
    }

    public void readFile(){
        long tstart = System.currentTimeMillis();
        ValidateInputFile v = new ValidateInputFile();
        boolean isOK = v.validate(fileName);
        if(isOK){
            content = v.getContent();
        }else{
            logger.log(Level.SEVERE, "Could not parse " + fileName);
            System.err.println("Could not parse " + fileName);
            System.exit(-1);
        }
        long tend = System.currentTimeMillis();
    }
    /*
     * SENTENCENUMBERS contains the unique sentence numbers
     * words contains the unique words
     * iindex is an inverted index from words to sentences
     *
     * These sets and maps are built at runtime
     */
    public void buildInvIndex(){
        SENTENCENUMBERS = new HashSet<Entity>();
        intsentencenumbers = new HashSet<Integer>();
        INVINDEX     = new HashMap<String, Vector<Entity>>();
        HashMap<Integer, Entity> smap = new HashMap<Integer, Entity>();
        HashSet<Integer> stopwordSentences = new HashSet<Integer>();
        if(REMOVESTOPWORDS){
            for(String s : content){
                String[] ssplit = s.split(",");
                int snr         = parseInt(ssplit[0]);
                String word     = ssplit[1];
                if(REMOVESTOPWORDS && STOPWORDS.contains(word)){
                    stopwordSentences.add(snr);
                }
            }
        }
        //Auxiliary.printIntegerSet(stopwordSentences);

        for(String s : content){
            String[] ssplit = s.split(",");
            int snr         = parseInt(ssplit[0]);
            if(!stopwordSentences.contains(snr)){
                String word     = ssplit[1];
                intsentencenumbers.add(snr);
                Entity e;
                if(smap.containsKey(snr)){
                    e = smap.get(snr);
                }else{
                    String genGrammaticalRole    = ssplit[2];
                    String actualGrammaticalRole = ssplit[3];
                    int posInSentence            = Integer.valueOf(ssplit[4]);
                    int posInDoc                 = Integer.valueOf(ssplit[5]);
                    e = new Entity("V"+snr,snr,genGrammaticalRole,actualGrammaticalRole,posInSentence,posInDoc,word);
                    smap.put(snr, e);
                    SENTENCENUMBERS.add(e);
                }
                // If we have seen the word before, augment with new entity
                if(INVINDEX.containsKey(word)){
                    Vector<Entity> val = INVINDEX.get(word);
                    val.add(e);
                    INVINDEX.put(word, val);
                }else{
                    // If we have not seen the word before, create a new entry
                    Vector<Entity> val = new Vector<Entity>();
                    val.add(e);
                    INVINDEX.put(word, val);
                }
            }
        }
        //Auxiliary.printInvIndex(INVINDEX);
    }

    public void buildGraph(){
        HashMap<String, Entity> wordnumbermap  = new HashMap<String, Entity>();
        numberwordmap                          = new HashMap<Entity, String>();
        graph                                  = new DelegateForest<Entity,Link>();
        MAX_SENTENCE                           = Collections.max(intsentencenumbers);
        int sentencectr                        = MAX_SENTENCE;
        // Add sentence nodes

        for(String s : content){
            String[] ssplit = s.split(",");
            String word = ssplit[1];
            if(!wordnumbermap.containsKey(word)){
                sentencectr++;
                String genGrammaticalRole    = ssplit[2];
                String actualGrammaticalRole = ssplit[3];
                int posInSentence            = Integer.valueOf(ssplit[4]);
                int posInDoc                 = Integer.valueOf(ssplit[5]);
                Entity e                     = new Entity("V"+sentencectr,sentencectr,genGrammaticalRole,
                        actualGrammaticalRole,posInSentence,posInDoc,word);
                wordnumbermap.put(word, e);
                numberwordmap.put(e, word);
            }
        }

       /*
        * Add the edges from sentences to words
        */
        int edgecounter = 0;
        for(Map.Entry<String, Vector<Entity>> entry : INVINDEX.entrySet()){
            String word = entry.getKey();
            Vector<Entity> vx = entry.getValue();
            for(Entity j : vx){
                graph.addEdge(new Link("E"+edgecounter,1),j,wordnumbermap.get(word));
                edgecounter++;
            }
        }
    }

    public DocWrapper calcGraphMetrics(){
/*
        GraphMetrics m          = new GraphMetrics(graph,projectionGraph, AGGREGATIONTYPE, AUX);
        double driftscore       = m.driftMetric();
        double prscore          = m.pagerank(fileName);//m.PageRank(graphModel, fileName);
        double ccscore          = m.clusteringcoeff(fileName);
        double degreescore      = m.degree(0,fileName);
        double betweennessscore = m.betweenness(fileName);
        double distancescore    = m.distance(INVINDEX,fileName);
        m                       = null;
        AUX                     = null;
        return new DocWrapper(DOCNAME,prscore,ccscore,degreescore,driftscore,betweennessscore,distancescore);
*/
        return new DocWrapper(DOCNAME,0.0,0.0,0.0,0.0,0.0,0.0);
    }

    public void buildProjectionGraph(){
        switch(GRAPHVIZTYPE){
            case Constants.UnweightedProjection: unweightedProjection();
                break;
            case Constants.WeightedProjection: weightedProjection();
                break;
            case Constants.SyntacticProjection: syntaticProjection();
                break;
            default: logger.log(Level.SEVERE, "Supplied identifier to displayGraph not recognized!"); System.exit(-1);
        }
        if(LARGESTWEAKCCONLY){
            WeakComponentClusterer<Entity, Link> wcc = new WeakComponentClusterer<Entity, Link>();
            Collection<Graph<Entity,Link>> ccs = FilterUtils.createAllInducedSubgraphs(wcc.transform(projectionGraph), projectionGraph);
            if(ccs.size() == projectionGraph.getVertexCount()){
                logger.log(Level.FINE,fileName + " contains a completely disconnected graph. Metric calculations aborted.");
                ISCONNECTED = false;
                return;
            }
            Graph<Entity, Link> updatedG;

            int largestCC = 0;
            Collection<Entity> subgraph = null;
            for(Graph<Entity, Link> g : ccs){
                if(g.getVertexCount() > largestCC){
                    largestCC = g.getVertexCount();
                    subgraph = g.getVertices();
                }
            }
            updatedG = FilterUtils.createInducedSubgraph(subgraph, projectionGraph);
            projectionGraph = updatedG;
        }
    }

    public void syntaticProjection(){
        initGraph();

        HashMap<String, Vector<String>> spairsMap = new HashMap<String, Vector<String>>();
        for(Map.Entry<String, Vector<Entity>> entry : INVINDEX.entrySet()){
            String word                = entry.getKey();
            Vector<Entity> emembership = entry.getValue();
            if(emembership.size() > 1){
                int N = emembership.size();
                for(int j = 0; j < N-1; j++){
                    for(int k = j+1; k < N; k++){
                        Entity from = emembership.get(j);
                        Entity to   = emembership.get(k);
                        int fromid  = from.getID();
                        int toid    = to.getID();
                        String s = ""+fromid+":"+toid;
                        if(!spairsMap.containsKey(s)){
                            Vector<String> words = new Vector<String>();
                            words.add(word);
                            spairsMap.put(s,words);
                        }else{
                            Vector<String> ws = spairsMap.get(s);
                            ws.add(word);
                            spairsMap.put(s, ws);
                        }
                    }
                }
            }
        }
        int edgectr = 0;
        for(Map.Entry<String, Vector<String>> entry : spairsMap.entrySet()){
            String[] sents = entry.getKey().split(":");
            int from = Integer.valueOf(sents[0]);
            int to   = Integer.valueOf(sents[1]);
            Vector<String> wordsShared = entry.getValue();
            double sum = 0;
            //System.out.println("Printing words shared by vertices " + from + " and " + to);
            for(String word : wordsShared){
                double idfval = 1.0;
                if(WEIGHTS.containsKey(word)){
                    idfval = WEIGHTS.get(word);
                }
                //System.out.println(word + " : " + idfval);
                sum += idfval;
            }
            projectionEdgeWeights.add(sum);
            projectionGraph.addEdge(new Link("E"+edgectr+"W"+(int)(sum)+"ES"+wordsShared.size(),(int)(sum)),vertexmap.get(from),vertexmap.get(to));
            edgectr++;
        }
    }

    public void unweightedProjection(){
        initGraph();
        //Auxiliary.printInvIndex(INVINDEX);
        int edgecounter = 0;
        for(Map.Entry<String, Vector<Entity>> entry : INVINDEX.entrySet()){
            Vector<Entity> emembership = entry.getValue();
            if(emembership.size() > 1){
                int N = emembership.size();
                for(int j = 0; j < N-1; j++){
                    for(int k = j+1; k < N; k++){
                        Entity from = emembership.get(j);
                        Entity to   = emembership.get(k);
                        int fromid  = from.getID();
                        int toid    = to.getID();
                        projectionGraph.addEdge(new Link("E"+edgecounter+"W1", 1.0),
                                vertexmap.get(fromid),vertexmap.get(toid));
                        edgecounter++;
                    }
                }
            }
        }
    }

    public void weightedProjection(){
        initGraph();
        HashMap<String, Integer> histogram = new HashMap<String, Integer>();
        for(Map.Entry<String, Vector<Entity>> entry : INVINDEX.entrySet()){
            Vector<Entity> emembership = entry.getValue();
            if(emembership.size() > 1){
                int N = emembership.size();
                for(int j = 0; j < N-1; j++){
                    for(int k = j+1; k < N; k++){
                        Entity from = emembership.get(j);
                        Entity to   = emembership.get(k);
                        int fromid  = from.getID();
                        int toid    = to.getID();
                        String s = "";
                        s = s+fromid+":"+toid;
                        if(histogram.containsKey(s)){
                            histogram.put(s,histogram.get(s) + 1);
                        }else{
                            histogram.put(s,1);
                        }
                    }
                }
            }
        }
        int ectr = 0;
        for(Map.Entry<String, Integer> entry : histogram.entrySet()){
            //System.out.println(entry.getKey() + " = " + entry.getValue());
            String[] edges = (entry.getKey()).split(":");
            projectionGraph.addEdge(new Link("E"+ectr+"W"+entry.getValue(),entry.getValue()),
                    vertexmap.get(parseInt(edges[0])),
                    vertexmap.get(parseInt(edges[1])));
            ectr++;
        }
    }

    public void initGraph(){
        if(GRAPHTYPE == Constants.UndirectedGraph){
            projectionGraph = new UndirectedSparseGraph<Entity, Link>();
        }else{
            projectionGraph = new DirectedSparseGraph<Entity, Link>();
        }
        vertexmap = new HashMap<Integer, Entity>();

        for(Entity i : SENTENCENUMBERS){
            vertexmap.put(i.getID(),i);
            projectionGraph.addVertex(i);
        }
    }

    public DocWrapper parse() throws Exception {
        readFile();
        if(content.size() == 0){
            // No sentences. All metrics are forced to 0.0
            Thread.currentThread().isInterrupted();
            return new DocWrapper(DOCNAME,0.0,0.0,0.0,0.0,0.0,0.0);
        }
        buildInvIndex();
        if(INVINDEX.isEmpty()){
            // This is /very/ likely when removing stopwords
            Thread.currentThread().isInterrupted();
            return new DocWrapper(DOCNAME,0.0,0.0,0.0,0.0,0.0,0.0);
        }
        buildGraph();
        buildProjectionGraph();
        return new DocWrapper(DOCNAME,0.0,0.0,0.0,0.0,0.0,0.0);
    }
/*

    public void mapToGephi(ProjectController pc, GraphModel graphModel){
        // Set up statics
        boolean isDirected = (projectionGraph instanceof UndirectedSparseGraph);
        if(isDirected){
            gephiGraph = graphModel.getDirectedGraph();
        }else{
            gephiGraph = graphModel.getUndirectedGraph();
        }

        // Map nodes to Gephi format
        Collection<Entity> vertices = projectionGraph.getVertices();
        HashMap<String, Node> map = new HashMap<String, Node>();
        for(Entity e : vertices){
            Node n = graphModel.factory().newNode(e.getLabel());
            n.getNodeData().setLabel(e.getLabel());
            gephiGraph.addNode(n);
            map.put(e.getLabel(), n);
        }

        // Map edges to Gephi format
        Collection<Link> edges = projectionGraph.getEdges();
        for(Link e : edges){
            Pair<Entity> linknodes = projectionGraph.getEndpoints(e);

            gephiGraph.addEdge(graphModel.factory().newEdge(map.get(linknodes.getFirst().getLabel()),
                    map.get(linknodes.getSecond().getLabel()),
                    (float)e.getWeight(),isDirected));
        }

    }
*/
    public void displayGraph(){
        //Transformers transformers = new Transformers(projectionEdgeWeights, numberwordmap);
        Transformers transformers = new Transformers();
        TreeLayout<Entity, Link> treeLayout = new TreeLayout<Entity, Link>(graph);
        BasicVisualizationServer<Entity,Link> vv =
                new BasicVisualizationServer<Entity,Link>(treeLayout);
        vv.setPreferredSize(new Dimension(950,150)); //Sets the viewing area size
        vv.getRenderer().getVertexLabelRenderer().setPosition(edu.uci.ics.jung.visualization.renderers.Renderer.VertexLabel.Position.CNTR);
        vv.getRenderContext().setVertexLabelTransformer(transformers.vertexTransformer);
        JFrame frame = new JFrame("Bipartite graph");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        JPanel main = new JPanel();
        main.setPreferredSize(new Dimension(950,600));
        GridLayout graphLayout = new GridLayout(2,0);
        main.setLayout(graphLayout);
        JPanel bipartite = new JPanel();
        bipartite.add(vv);
        JPanel projection = new JPanel();
        CircleLayout<Entity, Link> dagLayout;
        dagLayout = new CircleLayout<Entity, Link>(projectionGraph);
        dagLayout.setSize(new Dimension(950, 375));
        BasicVisualizationServer<Entity,Link> vv_pro =
                new BasicVisualizationServer<Entity,Link>(dagLayout);
        vv_pro.setPreferredSize(new Dimension(950,450)); //Sets the viewing area size
        vv_pro.getRenderer().getVertexLabelRenderer().setPosition(edu.uci.ics.jung.visualization.renderers.Renderer.VertexLabel.Position.CNTR);
        vv_pro.getRenderContext().setVertexLabelTransformer(transformers.vertexLabelTransformer);
        vv_pro.getRenderContext().setEdgeStrokeTransformer(transformers.edgeStroke);
        vv_pro.getRenderContext().setEdgeLabelTransformer(transformers.edgeLabel);

        ScalingControl scaler = new CrossoverScalingControl();
        Point2D p = new Point2D.Double(vv_pro.getCenter().getX()+50,vv_pro.getCenter().getY()-200);
        scaler.scale(vv_pro, (float)0.7, p);
        projection.add(vv_pro);
        main.add(bipartite);
        main.add(projection);
        frame.getContentPane().add(main);
        frame.pack();
        frame.setVisible(true);
    }

    public void destroy(){
        //gephiGraph = null;
        projectionGraph = null;
        SENTENCENUMBERS = null;
        vertexmap = null;
        projectionEdgeWeights = null;
        INVINDEX = null;
        graph = null;
        numberwordmap = null;
        content = null;
        intsentencenumbers = null;
        STOPWORDS = null;
    }

    @Override
    public DocWrapper call() throws Exception {
        readFile();
        if(content.size() == 0){
            // No sentences. All metrics are forced to 0.0
            Thread.currentThread().isInterrupted();
            return new DocWrapper(DOCNAME,0.0,0.0,0.0,0.0,0.0,0.0);
        }
        buildInvIndex();
        if(INVINDEX.isEmpty()){
            // This is /very/ likely when removing stopwords
            Thread.currentThread().isInterrupted();
            return new DocWrapper(DOCNAME,0.0,0.0,0.0,0.0,0.0,0.0);
        }
        buildGraph();
        buildProjectionGraph();
        return calcGraphMetrics();
    }
}
