/*
import edu.uci.ics.jung.algorithms.layout.*;
import edu.uci.ics.jung.graph.*;
import edu.uci.ics.jung.visualization.BasicVisualizationServer;
import edu.uci.ics.jung.visualization.control.CrossoverScalingControl;
import edu.uci.ics.jung.visualization.control.ScalingControl;
import org.apache.commons.collections15.Transformer;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Point2D;
import java.io.*;
import java.util.*;

import static java.lang.Integer.*;

public class Parser {
    private DelegateForest<Integer, String> graph;
    private TreeLayout<Integer,String> treeLayout;
    private DirectedGraph<Entity, Link> projectionGraph;
    private DAGLayout<Entity, Link> dagLayout;
    private final int UNWEIGHTEDPROJECTION = 0;
    private final int WEIGHTEDPROJECTION   = 1;
    private final int SYNTACTICPROJECTION  = 2;

    public static void main(String[] args) throws IOException {
        new Parser();
    }

    public Parser() throws IOException {
        parse();
    }

    public void parse() throws IOException {
        File directory = new File("C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2014\\data\\testarticles\\parsed\\test\\");
        FileReader fr;
        BufferedReader br;
        //noinspection ConstantConditions
        for(File file : directory.listFiles()){
            final String fileName = file.getAbsoluteFile().toString();
            fr = new FileReader(fileName);
            br = new BufferedReader(fr);
            Vector<String> content = new Vector<String>();
            String sCurrentLine;
            while ((sCurrentLine = br.readLine()) != null){
                content.add(sCurrentLine);
            }
            parseDocument(content);
        }
    }
    public void parseDocument(Vector<String> v){

        Set<Integer> sentencenr = new HashSet<Integer>();
        Set<String> words = new HashSet<String>();
        HashMap<String,Vector<Integer>> iindex = new HashMap<String, Vector<Integer>>();
        for(String s : v){
            String[] ssplit = s.split(",");
            int snr = parseInt(ssplit[0]);
            String word = ssplit[1];
            //Add sentence number to set
            sentencenr.add(snr);
            //Add word to set
            words.add(word);
            //Add word to inverted index. If not previously seen a new entry is made. Otherwise the entry is updated.
            if(iindex.containsKey(word)){
                Vector<Integer> val = iindex.get(word);
                val.add(snr);
                iindex.put(word, val);
            }else{
                Vector<Integer> docs = new Vector<Integer>();
                docs.add(snr);
                iindex.put(word, docs);
            }
        }
/*
        System.out.println("Statistics:");
        System.out.println("There was: " + sentencenr.size() + " sentences");
        System.out.println("There was: " + wordcounter + " words");
        System.out.println("There was: " + words.size() + " unique words");
        printInvIndex(iindex);
        showGraph(sentencenr,iindex, v);
    }

    public void showGraph(Set<Integer> sentencenr, HashMap<String,Vector<Integer>> iindex, Vector<String> v){
        graph                                        = new DelegateForest<Integer,String>();
        final int maxsentence                        = Collections.max(sentencenr);
        int sentencectr                              = maxsentence;
        HashMap<String, Integer> wordnumbermap       = new HashMap<String, Integer>();
        final HashMap<Integer, String> numberwordmap = new HashMap<Integer, String>();
        Integer[] arlist                             = sentencenr.toArray(new Integer[sentencenr.size()]);
        int arlist_ctr                               = 0;
        System.out.println(arlist.length);
        for(String s : v){
            String[] ssplit = s.split(",");
            String word = ssplit[1];
            graph.addVertex(arlist[arlist_ctr]); // Adds the sentence nodes
            if(!wordnumbermap.containsKey(word)){
                sentencectr++;
                wordnumbermap.put(word, sentencectr);
                numberwordmap.put(sentencectr, word);
                graph.addVertex(sentencectr); // Add the word nodes
            }
        }
        for(Map.Entry<String, Vector<Integer>> entry : iindex.entrySet()){
            String word = entry.getKey();
            Vector<Integer> vx = entry.getValue();
            for(Integer j : vx){
                graph.addEdge("E"+j+""+wordnumbermap.get(word),j,wordnumbermap.get(word));
            }
        }


        projectionGraph = UnweightedProjection(iindex, sentencenr);
        //projectionGraph = WeightedProjection(iindex, sentencenr);
        //projectionGraph = syntaticWeightedProjection(iindex, sentencenr);

        treeLayout = new TreeLayout<Integer,String>(graph);
        BasicVisualizationServer<Integer,String> vv =
                new BasicVisualizationServer<Integer,String>(treeLayout);
        vv.setPreferredSize(new Dimension(950,150)); //Sets the viewing area size
        vv.getRenderer().getVertexLabelRenderer().setPosition(edu.uci.ics.jung.visualization.renderers.Renderer.VertexLabel.Position.CNTR);
        vv.getRenderContext().setVertexLabelTransformer(new Transformer<Integer, String>() {
            public String transform(Integer e) {
                if(e > maxsentence){
                    return "<html><font size=2><b>"+numberwordmap.get(e)+"</b></font></html>";
                }
                return "<html><font size=2><b>"+"S"+String.valueOf(e)+"</b></font></html>";
            }
        });
        JFrame frame = new JFrame("Bipartite graph");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        JPanel main = new JPanel();
        main.setPreferredSize(new Dimension(950,600));
        GridLayout graphLayout = new GridLayout(2,0);
        main.setLayout(graphLayout);
        JPanel bipartite = new JPanel();
        bipartite.add(vv);
        JPanel projection = new JPanel();
        dagLayout = new DAGLayout<Entity, Link>(projectionGraph);
        dagLayout.setForceMultiplier(100);
        dagLayout.setSize(new Dimension(950,375));

        BasicVisualizationServer<Entity,Link> vv_pro =
                new BasicVisualizationServer<Entity,Link>(dagLayout);
        vv_pro.setPreferredSize(new Dimension(950,450)); //Sets the viewing area size
        vv_pro.getRenderer().getVertexLabelRenderer().setPosition(edu.uci.ics.jung.visualization.renderers.Renderer.VertexLabel.Position.CNTR);
        vv_pro.getRenderContext().setVertexLabelTransformer(new Transformer<Entity, String>() {
            public String transform(Entity e) {
                return "<html><font size=5><b>"+"S"+String.valueOf(e)+"</b></font></html>";
            }
        });

        vv_pro.getRenderContext().setEdgeLabelTransformer(new Transformer<Link, String>() {
            public String transform(Link e) {
                return "<html><font size=4><b>"+e.label+"</b></font></html>";
            }
        });

        ScalingControl scaler = new CrossoverScalingControl();
        Point2D p = new Point2D.Double(vv_pro.getCenter().getX()+50,vv_pro.getCenter().getY()-200);
        scaler.scale(vv_pro, (float)0.7, p);
        projection.add(vv_pro);
        main.add(bipartite);
        main.add(projection);
        frame.getContentPane().add(main);
        frame.pack();
        frame.setVisible(true);
    }

    public void syntaticWeightedProjection(HashMap<String, Vector<Integer>> v, Set<Integer> sentenceids){
        projectionGraph = new DirectedSparseGraph<Entity, Link>();
        HashMap<Integer, Entity> vmap = new HashMap<Integer, Entity>();
        for(Integer i : sentenceids){
            Entity e = new Entity(""+i,i);
            vmap.put(i,e);
            projectionGraph.addVertex(e);

        }
        HashMap<String, Vector<String>> spairsMap = new HashMap<String, Vector<String>>();
        for(Map.Entry<String, Vector<Integer>> entry : v.entrySet()){
            String word = entry.getKey();
            Vector<Integer> entitymembership = entry.getValue();
            Set<Integer> unique = new HashSet<Integer>();
            unique.addAll(entitymembership);
            Integer[] sentencelist = unique.toArray(new Integer[unique.size()]);
            if(sentencelist.length > 1){
                int N = sentencelist.length;
                for(int i = 0; i < N-1; i++){
                    for(int j = i+1; j < N; j++){
                        String key = ""+sentencelist[i]+":"+sentencelist[j];
                        if(!spairsMap.containsKey(key)){
                            Vector<String> words = new Vector<String>();
                            words.add(word);
                            spairsMap.put(key,words);
                            //System.out.println("Added key: " + key);
                        }else{
                            Vector<String> ws = spairsMap.get(key);
                            //System.out.println("Syntatic: " + key + ", " + ws.size());
                            ws.add(word);
                            spairsMap.put(key, ws);
                        }
                    }
                }
            }
        }
        int edgectr = 0;
        for(Map.Entry<String, Vector<String>> entry : spairsMap.entrySet()){
            String[] sents = entry.getKey().split(":");
            int from = Integer.valueOf(sents[0]);
            int to   = Integer.valueOf(sents[1]);
            //Get the IDFs of the words (here assuming two)
            double dummyIDFA = 1.0;
            double dummyIDFB = 1000.0;
            projectionGraph.addEdge(new Link("E"+edgectr+(dummyIDFA+dummyIDFB)),vmap.get(from),vmap.get(to));
        }
/*
        for(Map.Entry<String, Vector<String>> entry : spairsMap.entrySet()){
            String sentences  = entry.getKey();
            Vector<String> vs = entry.getValue();
            String b = "";
            for(String s : vs){
                b = b+s+";";
            }
            System.out.println(sentences + " - " + b);
        }

    }

    public DirectedSparseGraph<Entity, Link> UnweightedProjection(HashMap<String, Vector<Integer>> v, Set<Integer> sentenceids){
        DirectedSparseGraph<Entity, Link> projectionGraph = new DirectedSparseGraph<Entity, Link>();
        HashMap<Integer, Entity> vertexmap = new HashMap<Integer, Entity>();
        for(Integer i : sentenceids){
            Entity e = new Entity(""+i,i);
            vertexmap.put(i,e);
            projectionGraph.addVertex(e);

        }
        int edgecounter = 0;
        for(Map.Entry<String, Vector<Integer>> entry : v.entrySet()){
            Vector<Integer> entitymembership = entry.getValue();
            Set<Integer> unique = new HashSet<Integer>();
            unique.addAll(entitymembership);
            if(unique.size() > 1){
               Integer[] sentencelist = unique.toArray(new Integer[unique.size()]);
               int N = sentencelist.length;
               // Notice that this just goes 1 -> 2, 2 -> 3, 3 -> 4 despite 1 shares with 3 and 4 as well.
               /*
               for(int j = 0; j < N-1; j++){
                   projectionGraph.addEdge("E"+edgecounter,sentencelist[j], sentencelist[j+1]);
                   System.out.println("E"+edgecounter + ", " +sentencelist[j] + ", " + sentencelist[j+1]);
                   edgecounter++;
               }

                for(int j = 0; j < N-1; j++){
                    for(int k = j+1; k < N; k++){
                        //projectionGraph.addEdge("E"+edgecounter,sentencelist[j],sentencelist[k]);
                        projectionGraph.addEdge(new Link("E"+edgecounter+"W1"),
                                                vertexmap.get(sentencelist[j]),
                                                vertexmap.get(sentencelist[k]));
                        //System.out.println("E"+edgecounter + ", " +sentencelist[j] + ", " + sentencelist[k]);
                        edgecounter++;
                    }
                }
            }
        }
        return projectionGraph;
        //System.out.println(projectionGraph.toString());
    }

    public void printInvIndex(HashMap<String, Vector<Integer>> v){
        for (Map.Entry<String, Vector<Integer>> stringVectorEntry : v.entrySet()) {
            Map.Entry pairs = (Map.Entry) stringVectorEntry;
            String word = (String) pairs.getKey();
            //noinspection unchecked
            Vector<Integer> vals = (Vector<Integer>) pairs.getValue();
            String s = "";
            for (Integer i : vals) {
                s = s.concat(i + ";");
            }
            System.out.println(word + ", index: " + s);
        }
    }
*/
/*
    public void printHashMap(HashMap<String, Integer> v){
        for (Map.Entry<String, Integer> stringVectorEntry : v.entrySet()) {
            Map.Entry pairs = (Map.Entry) stringVectorEntry;
            String word = (String) pairs.getKey();
            int vals = (Integer)pairs.getValue();
            System.out.println(word + ", nr: " + vals);
        }
    }

}*/