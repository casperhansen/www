public class Link {
    private String label;
    private double WEIGHT;

    public Link(String label, double weight) {
        this.label = label;
        this.WEIGHT = weight;
    }

    @Override
    public String toString() {
        return label;
    }

    public String getLabel(){
        return label;
    }

    public double getWeight(){
        return WEIGHT;
    }

    public void setWeight(double w){
        this.WEIGHT = w;
    }
}