/*
import edu.uci.ics.jung.graph.DirectedGraph;
import edu.uci.ics.jung.graph.DirectedSparseGraph;
import java.util.*;

public class UnweightedProjection {
    public UnweightedProjection(){}

    public DirectedGraph<Entity, Link> getUnweightedProjection(HashMap<String, Vector<Integer>> invIndex, Set<Integer> sentenceids){
        DirectedGraph<Entity, Link> projectionGraph = new DirectedSparseGraph<Entity, Link>();
        HashMap<Integer, Entity> vertexmap = new HashMap<Integer, Entity>();
        for(Integer i : sentenceids){
            Entity e = new Entity(""+i,i);
            vertexmap.put(i,e);
            projectionGraph.addVertex(e);

        }
        int edgecounter = 0;
        for(Map.Entry<String, Vector<Integer>> entry : invIndex.entrySet()){
            Vector<Integer> entitymembership = entry.getValue();
            Set<Integer> unique = new HashSet<Integer>();
            unique.addAll(entitymembership);
            if(unique.size() > 1){
                Integer[] sentencelist = unique.toArray(new Integer[unique.size()]);
                int N = sentencelist.length;
                for(int j = 0; j < N-1; j++){
                    for(int k = j+1; k < N; k++){
                        projectionGraph.addEdge(new Link("E"+edgecounter+"W1"),
                                vertexmap.get(sentencelist[j]),
                                vertexmap.get(sentencelist[k]));
                        edgecounter++;
                    }
                }
            }
        }
      return projectionGraph;
    }
}
 */