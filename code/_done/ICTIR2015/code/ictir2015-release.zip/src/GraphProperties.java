import java.util.Vector;

public class GraphProperties {
    private Vector<Double> values;
    public GraphProperties(double[] vals){

    }
}
