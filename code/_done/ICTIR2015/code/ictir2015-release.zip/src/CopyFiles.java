import java.io.*;
import java.util.HashSet;

public class CopyFiles {
    private HashSet<String> s =  new HashSet<String>();
    private HashSet<String> p =  new HashSet<String>();
    String writefile = "/data/local/workspace/casper_petersen/sigir2014/copyenwp01.sh";
    String parsed   = "/data/local/workspace/casper_petersen/sigir2014/out/spamfree/out/enwp01/";
    String original = "/data/local/workspace/casper_petersen/sigir2014/out/spamfree/tmp/enwp01/";
    String[] outs = {"/data/local/workspace/casper_petersen/sigir2014/out/spamfree/out/tmp/one/",
                     "/data/local/workspace/casper_petersen/sigir2014/out/spamfree/out/tmp/two/",
                     "/data/local/workspace/casper_petersen/sigir2014/out/spamfree/out/tmp/three/"};
    public static void main(String[] args) throws IOException, InterruptedException{
        new CopyFiles();
    }

    public CopyFiles() throws IOException, InterruptedException {
        loadFiles();
        doParse();
    }

    public void loadFiles(){
        File f = new File(original);
        File[] fs = f.listFiles();
        int N     = fs.length;
        System.out.println("Found " + N + " files.");
        for(File f1 : fs){
            String str = f1.getName();
            String writeFile = str.substring(0,str.lastIndexOf('.'));
            s.add(writeFile);

        }
        System.out.println("Finished loading original file names");

        File f1    = new File(parsed);
        File[] fs1 = f1.listFiles();
        int N1     = fs1.length;
        System.out.println("Found " + N1 + " files.");
        for(File f11 : fs1){
            String str = f11.getName();
            String writeFile = str.substring(0,str.lastIndexOf('.'));
            p.add(writeFile);
        }
        System.out.println("Finished loading parsed file names");

    }

    public void doParse() throws FileNotFoundException {
        PrintWriter pw = new PrintWriter(writefile);
        int counter = 0;
        for(String str : s){
            if(!p.contains(str)){
                if(counter >= 0 && counter < 150000){
                    pw.println("cp /data/local/workspace/casper_petersen/sigir2014/out/spamfree/tmp/enwp01/" + str+".text" + " " +outs[0]+";");
                    pw.flush();
                }
                if(counter >= 150000 && counter < 350000){
                    pw.println("cp /data/local/workspace/casper_petersen/sigir2014/out/spamfree/tmp/enwp01/" + str+".text" + " " +outs[1]+";");
                    pw.flush();
                }
                if(counter >=350000){
                    pw.println("cp /data/local/workspace/casper_petersen/sigir2014/out/spamfree/tmp/enwp01/" + str+".text" + " " +outs[2]+";");
                    pw.flush();
                }
                counter++;
            }
        }
        pw.close();
    }
}
