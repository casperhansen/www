import java.io.FileInputStream;
import java.io.IOException;
import java.util.logging.*;

public class LoggerTest {
    private static FileHandler fileHTML;
    private static Formatter formatterHTML;
    static Logger logger = Logger.getLogger("ROFL");

    public static void main(String[] args) {
        logger.setLevel(Level.FINE);
        //adding custom handler
        try {
            fileHTML = new FileHandler(args[0]);
            formatterHTML = new MyHtmlFormatter();
            fileHTML.setFormatter(formatterHTML);
            logger.addHandler(fileHTML);

            for(int i=0; i<10; i++){
                //logging messages
                //logger.log(Level.INFO, ";Msg:"+i);
            }
            logger.log(Level.CONFIG, "Config data");
            for(int j = 0; j < 10; j++){
                //new CallMe(j);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}