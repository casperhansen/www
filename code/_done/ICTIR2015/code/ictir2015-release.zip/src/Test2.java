import edu.uci.ics.jung.algorithms.layout.CircleLayout;
import edu.uci.ics.jung.algorithms.layout.Layout;
import edu.uci.ics.jung.algorithms.scoring.PageRank;
import edu.uci.ics.jung.graph.UndirectedGraph;
import edu.uci.ics.jung.graph.UndirectedSparseGraph;
import edu.uci.ics.jung.visualization.BasicVisualizationServer;
import org.apache.commons.collections15.Transformer;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Vector;


public class Test2 {
    public static void main(String[] args) throws IOException {
        new Test2();
    }

    public Test2(int a) throws IOException{
    }

    public Test2() throws IOException{
        String file = "C:\\Casper\\enwp00.txt";
        File f = new File(file);
        System.out.println(f.getName());
    }

}
