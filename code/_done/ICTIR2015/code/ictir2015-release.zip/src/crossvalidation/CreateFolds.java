package crossvalidation;

/**
 * Creates and write k-fold cross validation files for SINGLE parameter tuning.
 *
 * For a parameter P in range [X;Y] : Y > X
 */

import java.io.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CreateFolds {
    private int NOFFOLDS   = 0;
    private int NOFQUERIES = 0;
//    private int[] MU_RANGE = {10,20,30,40,50};

    private String[] MU_RANGE = {"00100", "00500", "00800", "01000", "02000", "03000", "04000", "05000", "08000", "10000"};
/*
            {"00050","00150","00250","00350","00450","00550","00650","00750","00850","00950","01050","01150","01250",
            "01350","01450","01550","01650","01750","01850","01950","02050","02150","02250","02350","02450","02550","02650","02750",
            "02850","02950","03050","03150","03250","03350","03450","03550","03650","03750","03850","03950","04050","04150","04250",
            "04350","04450","04550","04650","04750","04850","04950","05050","05150","05250","05350","05450","05550","05650","05750",
            "05850","05950","06050","06150","06250","06350","06450","06550","06650","06750","06850","06950","07050","07150","07250",
            "07350","07450","07550","07650","07750","07850","07950","08050","08150","08250","08350","08450","08550","08650","08750",
            "08850","08950","09050","09150","09250","09350","09450","09550","09650","09750","09850","09950","10000"};
*/
    private HashMap<Integer, String> QUERYMAP;
/*
    public static void main(String[] args){
        /*
         * 1 - Number of folds
         * 2 - Number of queries in total
         * 3 - Original TREC query file to split into folds
         * 4 - Outputdir for files. Each fold get a seperate directory containing a training dir, a test dir, and a result dir

        if(args.length != 4){
              System.err.println("Four arguments must be supplied. The number of folds and the number of queries in total");
              System.exit(-1);
        }

        new CreateFolds(args[0], args[1], args[2], args[3]);
    }
*/

    public CreateFolds(){};

    public void createKFolds(int numberfolds, int numberqueries, String queryfile, String foldsdir){
        try{
            NOFFOLDS = numberfolds;//Integer.parseInt(numberfolds);
            NOFQUERIES = numberqueries;//Integer.parseInt(numberqueries);
        }catch(NumberFormatException nfe){
            System.err.println("Could not parse arguments #1 or #2 as integers");
            System.exit(-1);
        }
        loadAndProcessQueryFile(queryfile);
        createValidationFolds(foldsdir);
    }
  /*
   * We assume that there are more queries than the number of folds.
   */
    public void createValidationFolds(String foldsdir){
        // Setup directory structure
        File savedir = new File(foldsdir);
        if(!savedir.exists()){
            savedir.mkdir();
        }
        String delim = File.separator;
/*
        if(isWindows()){
           delim = "\\";
        }else{
           delim = "/";
        }
*/
       /*
        * Create     output dir strings
        */
        String[] dirfolds = new String[NOFFOLDS];
        for(int i = 0; i < NOFFOLDS; i++){
            dirfolds[i] = savedir+delim+"fold"+i+delim;
        }

       /*
        * Create output dirs
        */
        for(int i = 0; i < NOFFOLDS; i++){
            File f = new File(dirfolds[i]);
            if(!f.exists()){
                f.mkdir();
            }
        }

       /*
        * Create fold dirs
        */
        String[] traindirfolds = new String[NOFFOLDS];
        String[] testdirfolds  = new String[NOFFOLDS];
        for(int i = 0; i < NOFFOLDS; i++){
            traindirfolds[i] = dirfolds[i]+"train"+delim;
            testdirfolds[i]  = dirfolds[i]+"test"+delim;
        }

        for(int i = 0; i < NOFFOLDS; i++){
            File train = new File(traindirfolds[i]);
            if(!train.exists()){
                train.mkdir();
            }
            File test = new File(testdirfolds[i]);
            if(!test.exists()){
                test.mkdir();
            }
        }

        int queriesprfold;
        int leftover = 0;
        boolean hadleftover = false;
        if((NOFQUERIES % NOFFOLDS) == 0){ //Perfect split. This /should/ always be the case
            queriesprfold = NOFQUERIES/NOFFOLDS;
        }else{
           leftover = NOFQUERIES % NOFFOLDS;
           queriesprfold = (NOFQUERIES - leftover)/NOFFOLDS;
           hadleftover = true;
        }
        // Initialize queryids
        List<Integer> queryids = new ArrayList<Integer>(QUERYMAP.keySet());
        Collections.shuffle(queryids); // Generate random permutation of the queryids
        HashMap<Integer,Vector<Integer>> folds = new HashMap<Integer, Vector<Integer>>();
        for(int i = 0; i < NOFFOLDS; i++){
            Vector<Integer> queriesinfold = new Vector<Integer>();
            for(int j = 0; j < queriesprfold; j++){
                queriesinfold.add(queryids.get(i*queriesprfold+j));
            }
            folds.put(i, queriesinfold);
        }
        if(hadleftover){
            //Distribute evenly over folds (starting backwards)
            for(int j = leftover; j > 0; j--){
                Vector<Integer> qids = folds.get(j);
                qids.add(queryids.get(NOFQUERIES-j));
                folds.put(j, qids);
            }
        }
        String[] result = generateTxtFolds(folds);
/*
        for(Map.Entry<Integer, Vector<Integer>> entry : folds.entrySet()){
            System.out.println("Fold: " + entry.getKey() + " - " + entry.getValue().toString());
        }
*/
        //Now that they are split, we can begin circulating them
        List<Integer> ary = new ArrayList<Integer>();
        for(int i = 0; i < NOFFOLDS; i++){
            ary.add(i+1);
        }
        int trainfolds     = NOFFOLDS-1;
        int missingNumber  = ((trainfolds+1)*(trainfolds+2))/2;
        CombinationIterator<Integer> ci = new CombinationIterator<Integer>(ary, trainfolds);
        int foldcounter = 0;
        while(ci.hasNext()){
            List<Integer> fold = ci.next();
            int testfold = missingNumber-sum(fold);
            for (String aMU_RANGE : MU_RANGE) {
//                System.out.println("Trainset: " + trainout+"train-mu"+MU_RANGE[i]+"-fold"+foldcounter+".txt");
                PrintWriter pw = null;
                try {
                    pw = new PrintWriter(traindirfolds[foldcounter] + "train-mu-" + aMU_RANGE + "-fold-" + foldcounter + ".txt");
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                assert pw != null;
                pw.println(printHeader());
                pw.flush();
                pw.println("<rule>method:dirichlet,mu:" + Integer.valueOf(aMU_RANGE) + "</rule>");
                pw.flush();
                for (Integer j : fold) {
                    pw.println(result[j - 1]);
                    pw.flush();
                }
                pw.println("</parameter>");
                pw.flush();
                pw.close();
            }
            // Write the test set
            //System.out.println("Testset: " + testout+"test-fold"+foldcounter+".txt");
            PrintWriter pw = null;
            try {
                pw = new PrintWriter(testdirfolds[foldcounter]+"test-fold-"+foldcounter+".txt");
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            assert pw != null;
            pw.println(printHeader()); pw.flush();
            pw.println(result[testfold-1]); pw.flush();
            pw.println("</parameter>"); pw.flush();
            pw.flush();
            pw.close();
            foldcounter++;
        }
    }

    public Integer sum(List<Integer> list) {
        Integer sum= 0;
        for (Integer i:list)
            sum = sum + i;
        return sum;
    }
  /*
   * Prints all queries for a fold as text once, so we save iterations later
   */
    public String[] generateTxtFolds(HashMap<Integer,Vector<Integer>> folds){
        String[] result = new String[folds.size()];
        // Contains key = foldnumber, value = queryids
        for(Map.Entry<Integer, Vector<Integer>> entry : folds.entrySet()){
            Vector<Integer> foldids = entry.getValue();
            String fold = "";
            int N = foldids.size();
            for(int i = 0; i < N-1; i++){
                fold = fold.concat(QUERYMAP.get(foldids.get(i))+"\n");
            }
            fold = fold.concat(QUERYMAP.get(foldids.get(N-1)));
            result[entry.getKey()] = fold;
        }
        return result;
    }

    public void loadAndProcessQueryFile(String queryfilepath){
        Pattern p = Pattern.compile("<query>\\s*<number>\\s*(\\d+).+"); // Looking for query number
        FileReader fr = null;
        try {
            fr = new FileReader(queryfilepath);
        } catch (FileNotFoundException e) {
            System.err.println("Could not open file at " + queryfilepath);
            System.exit(-1);
        }
        BufferedReader br = new BufferedReader(fr);
        QUERYMAP = new HashMap<Integer, String>();
        String sCurrentLine = "";
        try{
            while((sCurrentLine = br.readLine()) != null){
                    Matcher m = p.matcher(sCurrentLine);
                    if(m.find()){ // Found match
                        QUERYMAP.put(Integer.parseInt(m.group(1)), sCurrentLine);
                    }
            }
        }catch(IOException ioe){
            System.err.println("Could not read line after " + sCurrentLine);
            System.exit(-1);
        }finally {
            try {
                fr.close();
                br.close();
            } catch (IOException e) {
                System.err.println("Could not close readers");
                System.exit(-1);
            }
        }
    }

    public String printHeader(){
        return "<parameter>\n" +
                "<index>/data/local/workspace/casper_petersen/sigir2014/index90</index>\n" +
                "<runID>13112013</runID>\n" +
                "<trecFormat>true</trecFormat>\n" +
                "<count>1000</count>";
    }

    public boolean isWindows(){
        String osname = System.getProperty("os.name").toLowerCase();
        return osname.startsWith("windows");
    }
}
