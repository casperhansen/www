package crossvalidation;

import java.util.ArrayList;

public class FoldSplit {
    private int[] TRAINFOLDS;
    private int TESTFOLD;

    public FoldSplit(int[] trainfolds, int testfold){
        this.TRAINFOLDS = trainfolds;
        this.TESTFOLD   = testfold;
    }

    public int[] getTrainFolds(){
        return TRAINFOLDS;
    }

    public int getTestFold(){
        return TESTFOLD;
    }
}
