import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Formatter;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class MyLogger {
    private static FileHandler fileHTML;
    private static Formatter formatterHTML;

    public static void setup(String htmlLogPath) throws IOException {
        Logger logger = Logger.getLogger("SIGIR");

        logger.setLevel(Level.FINEST);
        fileHTML = new FileHandler(htmlLogPath);

        // Create HTML Formatter
        formatterHTML = new MyHtmlFormatter();
        fileHTML.setFormatter(formatterHTML);
        logger.addHandler(fileHTML);
    }
}
