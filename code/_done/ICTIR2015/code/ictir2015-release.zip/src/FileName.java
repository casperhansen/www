public class FileName {
    private String FILENAME;
    public FileName(String s){
         FILENAME = s;
    }

   public String getFileName(){
       return FILENAME;
   }
}
