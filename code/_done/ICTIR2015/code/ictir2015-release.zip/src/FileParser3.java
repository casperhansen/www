/*
*
*
*
*
*
* CHANGELOG:
* 22-11-2013: Added: numberwordmap.put(i, i.getLabel()) to initgraph;
*
*/

import edu.uci.ics.jung.algorithms.layout.*;
import edu.uci.ics.jung.graph.*;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.visualization.BasicVisualizationServer;
import edu.uci.ics.jung.visualization.control.CrossoverScalingControl;
import edu.uci.ics.jung.visualization.control.ScalingControl;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Point2D;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.List;
import java.util.Timer;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FileParser3 implements Runnable{
    private String fileName;
    private String DOCNAME;
    private boolean REMOVESTOPWORDS;
    private int AGGREGATIONTYPE;
    private int GRAPHTYPE;
    private int GRAPHVIZTYPE;
    private Vector<String> content;
    private HashMap<Integer, Entity> PARENTS;
    private HashMap<String,Vector<Entity>> INVINDEX;
    private DelegateForest<Entity, Link> graph;
    private HashSet<Integer> entitylist;
    private Graph<Entity, Link> projectionGraph;
    private HashSet<String> STOPWORDS;
    private HashMap<String, Double> WEIGHTS;
    private String FILEPATH;
    public int MAX_SENTENCE;
    private int NOF_COH_MEASURES;
    private double MAX_IDF_NORMALIZER = 0.0;
    public HashMap<Entity, String> numberwordmap;
    private Auxiliary AUX;
    static Logger logger = Logger.getLogger("SIGIR");
    static Logger output = Logger.getLogger("OUTPUT");

    public FileParser3(String f, int graphtype, int graphviztype,
                       boolean removestopwords,
                       int aggregationtype,
                       HashMap<String,Double> weights,
                       HashSet<String> stopwords,
                       final int nof_coh_measures,
                       String fpath) throws IOException {
        logger.setLevel(Level.FINEST);
        fileName              = f;
        GRAPHTYPE             = graphtype;
        GRAPHVIZTYPE          = graphviztype;
        REMOVESTOPWORDS       = removestopwords;
        AGGREGATIONTYPE       = aggregationtype;
        WEIGHTS               = weights;
        STOPWORDS             = stopwords;
        NOF_COH_MEASURES      = nof_coh_measures;
        FILEPATH              = fpath;
        AUX                   = new Auxiliary();

        Path p  = Paths.get(fileName);
        String dname = p.getFileName().toString();
        DOCNAME = dname.substring(0,dname.lastIndexOf("."));
    }

    public void readFile(){
        ValidateInputFile v = new ValidateInputFile();
        boolean isOK = v.validate(fileName);
        if(isOK){
            content = v.getContent();
        }else{
            logger.log(Level.SEVERE, "Could not parse " + fileName);
            System.err.println("Could not parse " + fileName);
            System.exit(-1);
        }
    }

    public void buildInvIndex(){
        INVINDEX           = new HashMap<String, Vector<Entity>>();
        HashSet<Integer> stopwordSentences = new HashSet<Integer>();
        if(REMOVESTOPWORDS){
            for(String s : content){
                String[] ssplit = s.split(",");
                int snr         = Integer.parseInt(ssplit[0]);
                String word     = ssplit[1];
                if(REMOVESTOPWORDS && STOPWORDS.contains(word)){
                    stopwordSentences.add(snr);
                }
            }
        }
        //Auxiliary.printIntegerSet(stopwordSentences);
        int vcounter    = 1;
        entitylist = new HashSet<Integer>();
        for(String s : content){
            //System.out.println(s);
            String[] ssplit = s.split(",");
            int snr         = Integer.parseInt(ssplit[0]);
            if(!stopwordSentences.contains(snr)){
                String word     = ssplit[1];
                String genGrammaticalRole    = ssplit[2];
                String actualGrammaticalRole = ssplit[3];
                int posInSentence            = Integer.valueOf(ssplit[4]);
                int posInDoc                 = Integer.valueOf(ssplit[5]);
                Entity e = new Entity("V"+vcounter++,snr,genGrammaticalRole,actualGrammaticalRole,posInSentence,posInDoc,word);
                //System.out.println("BuildIndex: Added entity: " + e.toString2());
                entitylist.add(e.getID());

                // If we have seen the word before, augment with new entity
                if(INVINDEX.containsKey(word)){
                    Vector<Entity> val = INVINDEX.get(word);
                    val.add(e);
                    INVINDEX.put(word, val);
                }else{
                    // If we have not seen the word before, create a new entry
                    Vector<Entity> val = new Vector<Entity>();
                    val.add(e);
                    INVINDEX.put(word, val);
                }
            }
        }
        MAX_SENTENCE = vcounter;
//        AUX.printTable(INVINDEX);
    }

    public void buildGraph2(){
        graph                 = new DelegateForest<Entity,Link>();
/*
        HashSet<Integer> sids = new HashSet<Integer>();
        for(Entity e : entitylist){
            sids.add(e.getID());
        }
*/
        //How many sentence nodes is needed?
        Vector<Integer> sortedsids = new Vector<Integer>();
        sortedsids.addAll(entitylist);
        Collections.sort(sortedsids);

       /*
        * Add the parents to the graph. The parents have no word as they are only parents with no information.
        * Each parent is added with its sentence number, and an ID that identifies them. These ID
        */
        PARENTS = new HashMap<Integer, Entity>();
        for (Integer sortedsid : sortedsids) {
            Entity e = new Entity("S" + sortedsid, MAX_SENTENCE + sortedsid, "", "", 0, 0, "<NULL>");
            PARENTS.put(sortedsid, e);
            graph.addVertex(e);
        }
       /*
        * With the parents added, add the children
        */
        int edgecounter = 1;
        for(Map.Entry<String, Vector<Entity>> entry : INVINDEX.entrySet()){
            Vector<Entity> vs = entry.getValue();
            for(Entity e : vs){
                int parent = e.getID();
               /* Strictly speaking the 1 should be either 1 or the IDF weight.
                * - Get e's IDF weight and use that if its a syntactic projection.
                *   This is important if the IDFs are to be used in the metrics not operating on the proejctions
                */
                graph.addEdge(new Link("E"+edgecounter,1),PARENTS.get(parent), e);
                edgecounter++;
            }
        }
    }

    public ProcessedFileResult calcGraphMetrics(){
        GraphMetrics m            = new GraphMetrics(graph, projectionGraph, AGGREGATIONTYPE, AUX, PARENTS);
        if(MAX_IDF_NORMALIZER == 0.0){
           MAX_IDF_NORMALIZER = 1.0; // Could happen, but very unlikely
        }
        double prscore            = m.pagerank(MAX_IDF_NORMALIZER); // Must normalize as the framework requires it.
        double ccscore            = m.clusteringcoeff();
        double degreescore        = m.degree(0);
        double betweennessscore   = m.betweenness();
        double driftscore         = m.driftMetric();
        double distancescore      = m.distance(INVINDEX);
        double adjBinTopicflow    = m.adjbinarytopicflow(INVINDEX);
        double adjWTopicflow      = m.adjWeightedTopicFlow(INVINDEX);
        double adjPosTopicFlow    = m.adjPositionalTopicFlow(INVINDEX);
        double nonAdjBinTopicFlow = m.nonAdjBinaryTopicFlow(INVINDEX);
        double nonAdjWTopicFlow   = m.nonAdjWeightedTopicFlow(INVINDEX);
        double nonAdjPosTopicFlow = m.nonAdjPositionalTopicFlow(INVINDEX);
        Collection<Entity> cc     = graph.getVertices();
        TreeMap<Integer, Entity> tmap = new TreeMap<Integer, Entity>();
        for(Entity e : cc){
            tmap.put(e.getPositionInDocument(), e);
        }
        List<Entity> list         = new ArrayList<Entity>(tmap.values());
        double entropy0           = m.entropy(list, 0);
        double entropy1           = m.entropy(list, 1);
        double entropy2           = m.entropy(list, 2);
        AUX                       = null;
        return new ProcessedFileResult(DOCNAME,NOF_COH_MEASURES,prscore,ccscore,degreescore,betweennessscore,driftscore,distancescore,adjBinTopicflow,
                adjWTopicflow,adjPosTopicFlow,nonAdjBinTopicFlow,nonAdjWTopicFlow,nonAdjPosTopicFlow, entropy0, entropy1, entropy2);
    }

    public void buildProjectionGraph(){
        switch(GRAPHVIZTYPE){
            case Constants.UnweightedProjection: unweightedProjection2();
                break;
            case Constants.WeightedProjection: weightedProjection2();
                break;
            case Constants.SyntacticProjection: syntaticProjection2();
                break;
            default: logger.log(Level.SEVERE, "Supplied identifier to displayGraph not recognized!"); System.exit(-1);
        }
/*
        if(LARGESTWEAKCCONLY){
            WeakComponentClusterer<Entity, Link> wcc = new WeakComponentClusterer<Entity, Link>();
            Collection<Graph<Entity,Link>> ccs = FilterUtils.createAllInducedSubgraphs(wcc.transform(projectionGraph), projectionGraph);
            if(ccs.size() == projectionGraph.getVertexCount()){
                logger.log(Level.FINE,fileName + " contains a completely d" +
                        "isconnected graph. Metric calculations aborted.");
                ISCONNECTED = false;
                return;
            }
            Graph<Entity, Link> updatedG;

            int largestCC = 0;
            Collection<Entity> subgraph = null;
            for(Graph<Entity, Link> g : ccs){
                if(g.getVertexCount() > largestCC){
                    largestCC = g.getVertexCount();
                    subgraph = g.getVertices();
                }
            }
            updatedG = FilterUtils.createInducedSubgraph(subgraph, projectionGraph);
            projectionGraph = updatedG;
        }
*/
    }

    public void syntaticProjection2(){
        initGraph2();
        HashMap<String, Vector<String>> spairsMap = new HashMap<String, Vector<String>>();
        for(Map.Entry<String, Vector<Entity>> entry : INVINDEX.entrySet()){
            String word                = entry.getKey();
            Vector<Entity> emembership = entry.getValue();
            if(emembership.size() > 1){
                int N = emembership.size();
                for(int j = 0; j < N-1; j++){
                    int fromid = emembership.get(j).getID();
                    for(int k = j+1; k < N; k++){
                        int toid   = emembership.get(k).getID();
                        String s = ""+fromid+":"+toid;
                        if(!spairsMap.containsKey(s)){
                            Vector<String> words = new Vector<String>();
                            words.add(word);
                            spairsMap.put(s,words);
                        }else{
                            Vector<String> ws = spairsMap.get(s);
                            ws.add(word);
                            spairsMap.put(s, ws);
                        }
                    }
                }
            }
        }
       /*
        * spairsMap contains:
        * 1:2, <summer, goat, share>
        * where the key is the concatenation of the sentence nodes in the projection graph, and the val is a vector
        * of words they share
        */

        int edgectr = 0;
        for(Map.Entry<String, Vector<String>> entry : spairsMap.entrySet()){
            String[] sents = entry.getKey().split(":");
            int from = Integer.valueOf(sents[0]);
            int to   = Integer.valueOf(sents[1]);
            Vector<String> wordsShared = entry.getValue();
            double sum = 0;
            // Get the IDF weights for the words shared and sum them. This is
            for(String word : wordsShared){
                double idfval = 1.0;
                if(WEIGHTS.containsKey(word)){
                    idfval = WEIGHTS.get(word);
                }
                sum += idfval;
            }
            if(sum > MAX_IDF_NORMALIZER){
               MAX_IDF_NORMALIZER = sum;
            }
            // Use summed weights as weights for projection graph edges and for visualization
            projectionGraph.addEdge(new Link("E"+edgectr+"W"+(int)(sum)+"ES"+wordsShared.size(),(int)(sum)),
                    PARENTS.get(from),PARENTS.get(to));
            edgectr++;
        }
    }

    public void unweightedProjection2(){
        // Initialize projectiongraph
        initGraph2();
        HashSet<String> keysSeens = new HashSet<String>();
        int edgecounter = 0;
        for(Map.Entry<String, Vector<Entity>> entry : INVINDEX.entrySet()){
            // Use the name of the first word to get the vertices it belongs to.
            Vector<Entity> v = entry.getValue();
            Collections.sort(v);
            int N = v.size();
            // Only add edges between sentence nodes if the word exist in at least entities
            if(N > 1){
                for(int i = 0; i < N-1; i++){
                    Entity e1 = PARENTS.get(v.get(i).getID());   // Get parent of first entity
                    for(int j = i+1; j < N; j++){
                        Entity e2 = PARENTS.get(v.get(j).getID()); // Get parent of second entity
                        //If the parents of the entities are different we add an edge. To avoid adding multiple edges
                        // we screen for that (though JUNG takes care of that we make it explicit)
                        if(e2.getID() != e1.getID() && !keysSeens.contains(""+e1.getID()+":"+e2.getID())){
                           keysSeens.add(e1.getID()+":"+e2.getID());
                           projectionGraph.addEdge(new Link("E"+edgecounter,1),e1,e2);
                           edgecounter++;
                        }
                    }
                }
            }
        }
        MAX_IDF_NORMALIZER = (double)projectionGraph.getEdgeCount();
        //AUX.printHashMapSingle(PARENTS);
    }

    public void weightedProjection2(){
        // Initiate projectiongraph
        int total_weight = 0;
        initGraph2();
        HashMap<String, Integer> histogram = new HashMap<String, Integer>();
        for(Map.Entry<String, Vector<Entity>> entry : INVINDEX.entrySet()){
            Vector<Entity> emembership = entry.getValue();
            if(emembership.size() > 1){
                int N = emembership.size();
                for(int j = 0; j < N-1; j++){
                    int from = emembership.get(j).getID();
                    for(int k = j+1; k < N; k++){
                        int to   = emembership.get(k).getID();
                        String s = "";
                        s = s+from+":"+to;
                        if(histogram.containsKey(s)){
                            histogram.put(s,histogram.get(s) + 1);
                        }else{
                            histogram.put(s,1);
                        }
                        total_weight++;
                    }
                }
            }
        }
       /*Histogram contains .e.g:
        * 1:2, 5
        * 2:3, 2
        * 2:5, 1
        * and so on. The key is the concatenation of the parents ID.
        */
        MAX_IDF_NORMALIZER = (double)total_weight;
        int ectr = 0;
        for(Map.Entry<String, Integer> entry : histogram.entrySet()){
            String[] edges = (entry.getKey()).split(":");
            Entity from = PARENTS.get(Integer.valueOf(edges[0]));
            Entity to   = PARENTS.get(Integer.valueOf(edges[1]));
            projectionGraph.addEdge(new Link("E"+ectr+"W"+entry.getValue(),entry.getValue()),
                    from, to);
            ectr++;
        }

    }

   /*
    * initGraph2() initiates the projection graph by adding the sentence nodes.
    */
    public void initGraph2(){
        if(GRAPHTYPE == Constants.UndirectedGraph){
            projectionGraph = new UndirectedSparseGraph<Entity, Link>();
        }else{
            projectionGraph = new DirectedSparseGraph<Entity, Link>();
        }
        for(Map.Entry<Integer, Entity> p : PARENTS.entrySet()){
            projectionGraph.addVertex(p.getValue());
        }

    }

    public void displayGraph(){
        Transformers transformers = new Transformers();
        TreeLayout<Entity, Link> treeLayout = new TreeLayout<Entity, Link>(graph);
        BasicVisualizationServer<Entity,Link> vv =
                new BasicVisualizationServer<Entity,Link>(treeLayout);
        vv.setPreferredSize(new Dimension(950,150)); //Sets the viewing area size
        vv.getRenderer().getVertexLabelRenderer().setPosition(edu.uci.ics.jung.visualization.renderers.Renderer.VertexLabel.Position.CNTR);
        vv.getRenderContext().setVertexLabelTransformer(transformers.vertexTransformer);
        JFrame frame = new JFrame("Bipartite graph");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        JPanel main = new JPanel();
        main.setPreferredSize(new Dimension(950,600));
        GridLayout graphLayout = new GridLayout(2,0);
        main.setLayout(graphLayout);
        JPanel bipartite = new JPanel();
        bipartite.add(vv);
        JPanel projection = new JPanel();
        CircleLayout<Entity, Link> dagLayout;
        dagLayout = new CircleLayout<Entity, Link>(projectionGraph);
        dagLayout.setSize(new Dimension(950, 375));
        BasicVisualizationServer<Entity,Link> vv_pro =
                new BasicVisualizationServer<Entity,Link>(dagLayout);
        vv_pro.setPreferredSize(new Dimension(950,450)); //Sets the viewing area size
        vv_pro.getRenderer().getVertexLabelRenderer().setPosition(edu.uci.ics.jung.visualization.renderers.Renderer.VertexLabel.Position.CNTR);
        vv_pro.getRenderContext().setVertexLabelTransformer(transformers.vertexLabelTransformer);
        vv_pro.getRenderContext().setEdgeStrokeTransformer(transformers.edgeStroke);
        vv_pro.getRenderContext().setEdgeLabelTransformer(transformers.edgeLabel);
        ScalingControl scaler = new CrossoverScalingControl();
        Point2D p = new Point2D.Double(vv_pro.getCenter().getX()+50,vv_pro.getCenter().getY()-200);
        scaler.scale(vv_pro, (float)0.7, p);
        projection.add(vv_pro);
        main.add(bipartite);
        main.add(projection);
        frame.getContentPane().add(main);
        frame.pack();
        frame.setVisible(true);
    }

    public void destroy(){
        projectionGraph = null;
        INVINDEX = null;
        graph = null;
        numberwordmap = null;
        content = null;
        STOPWORDS = null;
    }

    @Override
    public void run() {
        readFile();
        if(content.size() == 0){
            // No sentences. All metrics are forced to 0.0
            //Thread.currentThread().isInterrupted();
            //writeFile(fileName, new ProcessedFileResult(fileName,NOF_COH_MEASURES));
            ProcessedFileResult pr = new ProcessedFileResult(DOCNAME,NOF_COH_MEASURES);
            output.log(Level.FINEST,pr.toString());
            Thread.currentThread().interrupt();
            return;
        }
        buildInvIndex();
        if(INVINDEX.isEmpty()){
            // This is /very/ likely when removing stopwords and the sentences to which they belong
            //Thread.currentThread().isInterrupted();
            //writeFile(fileName, new ProcessedFileResult(fileName,NOF_COH_MEASURES));
            ProcessedFileResult pr = new ProcessedFileResult(DOCNAME,NOF_COH_MEASURES);
            output.log(Level.FINEST,pr.toString());
            Thread.currentThread().interrupt();
            return;
        }
        buildGraph2();
        buildProjectionGraph();
        //displayGraph();
        ProcessedFileResult dw = calcGraphMetrics();
        if(FILEPATH.equals("")){ // Not pretty but it will get the job done
            output.log(Level.FINEST, dw.toString());
        }else{
            writeFile(DOCNAME, dw);
        }
//        System.out.println(dw.toString());
        destroy();
    }

    public void writeFile(String filename, ProcessedFileResult dw) {
        String fileExt = ".docscore";
        PrintWriter pw;
        try {
            pw = new PrintWriter(FILEPATH+DOCNAME+fileExt);
        } catch (FileNotFoundException e) {
            logger.log(Level.SEVERE,"Could not create output file: " + FILEPATH+filename+fileExt);
            Thread.currentThread().isInterrupted();
            return;
        }
        pw.println(dw.toString());
        pw.close();
    }
}
