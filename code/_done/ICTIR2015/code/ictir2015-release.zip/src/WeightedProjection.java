/*
import edu.uci.ics.jung.graph.DirectedGraph;
import edu.uci.ics.jung.graph.DirectedSparseGraph;
import java.util.*;
import static java.lang.Integer.parseInt;

public class WeightedProjection {
    public WeightedProjection(){

    }

    public DirectedGraph<Entity, Link> getWeightedProjection(HashMap<String, Vector<Integer>> v, Set<Integer> sentenceids){
        DirectedGraph<Entity, Link> projectionGraph = new DirectedSparseGraph<Entity, Link>();
        HashMap<Integer, Entity> vertexmap = new HashMap<Integer, Entity>();
        for(Integer i : sentenceids){
            Entity e = new Entity(""+i,i);
            vertexmap.put(i,e);
            projectionGraph.addVertex(e);

        }
        HashMap<String, Integer> histogram = new HashMap<String, Integer>();
        for(Map.Entry<String, Vector<Integer>> entry : v.entrySet()){
            Vector<Integer> entitymembership = entry.getValue();
            Set<Integer> unique = new HashSet<Integer>();
            unique.addAll(entitymembership);
            if(unique.size() > 1){
                Integer[] sentencelist = unique.toArray(new Integer[unique.size()]);
                int N = sentencelist.length;
                for(int j = 0; j < N-1; j++){
                    for(int k = j+1; k < N; k++){
                        String s = "";
                        s = s+sentencelist[j]+":"+sentencelist[k];
                        if(histogram.containsKey(s)){
                            histogram.put(s,histogram.get(s) + 1);
                        }else{
                            histogram.put(s,1);
                        }
                    }
                }
            }
        }
        int ectr = 0;
        for(Map.Entry<String, Integer> entry : histogram.entrySet()){
            System.out.println(entry.getKey() + " = " + entry.getValue());
            String[] edges = (entry.getKey()).split(":");
            projectionGraph.addEdge(new Link("E"+ectr+"W"+entry.getValue()), vertexmap.get(parseInt(edges[0])), vertexmap.get(parseInt(edges[1])));
            ectr++;
        }
        return projectionGraph;
    }
}
*/