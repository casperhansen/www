import edu.uci.ics.jung.algorithms.scoring.PageRank;
import edu.uci.ics.jung.algorithms.shortestpath.DijkstraShortestPath;
import edu.uci.ics.jung.graph.UndirectedGraph;
import edu.uci.ics.jung.graph.UndirectedSparseGraph;
import org.apache.commons.collections15.Transformer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.util.logging.Logger;

public class Test{
    public static void main(String[] args) throws IOException {
        new Test();
    }

    public Test() throws IOException{
        String path = "C:\\Casper\\enwp01.files.txt";
        List<Integer> ss = new ArrayList<Integer>();
        FileReader fr = new FileReader(path);
        BufferedReader br = new BufferedReader(fr);
        br.readLine();
        String sCurrentLine;
        int max = 0;
        String filename = "";
        while((sCurrentLine = br.readLine()) != null){
               String[] s = sCurrentLine.split("\\s+");
               int val = Integer.parseInt(s[4]);
               if(val > max){
                   max = val;
                   filename = s[8];
               }
               ss.add(val);
        }
        System.out.println("Max val was: " + max + " in file: " + filename);
        fr.close();
        br.close();
        Collections.sort(ss);
        int N = ss.size();
        for(int i = N; i > N-10; i--){
            System.out.println(ss.get(i-1));
        }
/*
        String path = "C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2014\\data\\qrels\\all_webtrack_qrels_filtered.qrels";
        FileReader fr = new FileReader(path);
        BufferedReader br = new BufferedReader(fr);
        String sCurrentLine;
        int lines = 0;
        HashSet<String> names = new HashSet<String>();
        while((sCurrentLine = br.readLine()) != null){
               lines++;
               String[] ss = sCurrentLine.split(" ");
               names.add(ss[2]);
        }
        fr.close();
        br.close();
        System.out.println("From " + lines + " qrels, there were " + names.size() + " different documents");
        ProcessedFileResult pr = new ProcessedFileResult("HEJ",0.0,0.0,0.0,10.2,29.9,0.0);
        System.out.println(pr.toString());
                */
    }
}