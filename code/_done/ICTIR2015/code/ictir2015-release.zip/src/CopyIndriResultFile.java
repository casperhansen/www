import java.io.*;
import java.util.HashSet;

public class CopyIndriResultFile {
    String dir;
    private HashSet<String> s =  new HashSet<String>();
    String path = "/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/";
    public static void main(String[] args) throws IOException, InterruptedException{
        new CopyIndriResultFile(args);
    }

    public CopyIndriResultFile(String[] args) throws IOException, InterruptedException {
        int N = args.length-1;
        dir = args[N];
        for(int i = 0; i < N-1; i++){
            doParse(args[i]);
        }
    }

    public void doParse(String in) throws IOException, InterruptedException {
        FileReader fr = new FileReader(in);
        BufferedReader br = new BufferedReader(fr);
        String sCurrentLine;
        Process p;
        while((sCurrentLine = br.readLine()) != null){
            String[] ssplit  = sCurrentLine.split("\\s+");
            int idx1         = ssplit[2].lastIndexOf("/");
            String substring = ssplit[2].substring(0, idx1-1);
            idx1             = substring.lastIndexOf("/");
            String str       = ssplit[2].substring(idx1+1,ssplit[2].length());
            String command = "cp"+" "+str+" "+dir;

            System.out.println(command);
            //p = Runtime.getRuntime().exec(command);
            //p.waitFor();
        }
    }
}
