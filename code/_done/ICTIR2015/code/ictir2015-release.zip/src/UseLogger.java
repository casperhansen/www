import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UseLogger {
    // Always use the classname, this way you can refactor
    private final static Logger LOGGER = Logger.getLogger("SIGIR");

    public void doSomeThingAndLog() {
        LOGGER.setLevel(Level.FINE);
        for(int i=0; i<1000; i++){
            LOGGER.log(Level.SEVERE, "Msg"+i);
        }
        for(int j = 0; j < 5; j++){
            //new CallMe(j);
        }
    }

    public static void main(String[] args) {
        UseLogger tester = new UseLogger();
        try {
            MyLogger.setup("C:\\Casper\\log.html");
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Problems with creating the log files");
        }
        tester.doSomeThingAndLog();
    }
}
