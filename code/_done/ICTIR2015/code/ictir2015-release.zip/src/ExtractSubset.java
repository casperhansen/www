import java.io.*;
import java.util.HashMap;

/**
 * This file extract files from a directory specified in an input list.
 * Specifically, this file was created to copy files from /data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/enxxzzyy/
 * based on the qrels given in a files provided to the program. The file must be in TREC qrel format.
 */
public class ExtractSubset {

    private HashMap<String, String> dirs = new HashMap<String, String>();


    public static void main(String[] args) throws IOException {
        assert args.length == 2;
        // First argument is the file containing the qrels which names the clueweb09 files we are interested.
        // Second argument COULD BE the path to the dirs containing the clueweb09 files.
        // Third argument is the directory to which files should be copied
        new ExtractSubset(args[0], args[1], args[2]);
    }

    public ExtractSubset(String qrelfile, String copytodirpath, String copyfile) throws IOException {
        dirs.put("en0000","/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/en000/");
        dirs.put("en0001","/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/en001/");
        dirs.put("en0002","/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/en002/");
        dirs.put("en0003","/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/en003/");
        dirs.put("en0004","/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/en004/");
        dirs.put("en0005","/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/en005/");
        dirs.put("en0006","/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/en006/");
        dirs.put("en0007","/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/en007/");
        dirs.put("en0008","/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/en008/");
        dirs.put("en0009","/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/en009/");
        dirs.put("en0010","/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/en010/");
        dirs.put("en0011","/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/en011/");
        dirs.put("enwp00","/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/enwp00/");
        dirs.put("enwp01","/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/enwp01/");
        dirs.put("enwp02","/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/enwp02/");
        dirs.put("enwp03","/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/enwp03/");

        doFilter(qrelfile, copytodirpath, copyfile);
    }

    public void doFilter(String in, String copydir, String copyfile) throws IOException {
        FileReader fr = new FileReader(in);
        BufferedReader br =  new BufferedReader(fr);
        String sCurrentLine;
        FileWriter fw = new FileWriter(copydir+copyfile);
        BufferedWriter bw = new BufferedWriter(fw);
        while((sCurrentLine = br.readLine()) != null){
               String[] tmp       = sCurrentLine.split(" ");
               String name        = tmp[2];
               String[] nameparts = name.split("-");
               String key         = nameparts[1];
               if(!dirs.containsKey(key)){
                    System.err.println("Dirs do not contain a match for " + key + " for line " + sCurrentLine);
                    System.exit(-1);
               }else{
                    String path = dirs.get(key);
                    bw.write("cp " + path+name+".text "+ copydir+name+".text\n");
                    bw.flush();
               }
        }
        bw.flush();
        fw.close();
        bw.close();
        fr.close();
        br.close();
    }
}
