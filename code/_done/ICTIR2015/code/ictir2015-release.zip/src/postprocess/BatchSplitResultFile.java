package postprocess;

import java.io.File;
import java.io.IOException;
import java.util.Date;

public class BatchSplitResultFile {
    public static void main(String[] args) throws IOException {
        new BatchSplitResultFile();
    }

    public BatchSplitResultFile() throws IOException {
        doSplit();
    }

    public void doSplit() throws IOException {
       /*
        * (1) - The location of the index
        */
        String indexpath = "/data/local/workspace/casper_petersen/sigir2014/index90/";
       /*
        * (2) - Where are the original files stored?
        */
        String textpath = "/data/local/workspace/casper_petersen/sigir2014/out/spamfree/out/";
       /*
        * (3) - ocal path to dir containing dirs containing metric.scores
        */
        //String dir      = "C:/Casper/confs/in/";
        String dir      = "C:/Casper/Universitet/PhD/Articles/2013/SIGIR2014/data/testarticles/rmfiles/parsed/";
       /*
        * Path where the splitted files will be places
        */
        //String priorloc = "C:/Casper/confs/out/";
        String priorloc = "C:/Casper/Universitet/PhD/Articles/2013/SIGIR2014/data/testarticles/rmfiles/parsed/";
       /*
        * Location of the queries to use
        */
        String qfile    = "C:/Casper/Universitet/PhD/Articles/2013/SIGIR2014/data/webtrackqueries/200webtrack.queries";
        File f = new File(dir);
        String[] fs = f.list();
        int COH = 0;
        for(String s : fs){
            String newdir = dir+s+File.separator;
            String currentfile = newdir+"metrics.score";
            System.out.println(currentfile);
            String priordir = newdir+"priors"+File.separator;
            File pdir = new File(priordir);
            if(!pdir.exists()){
                pdir.mkdirs();
            }
            System.out.println("Created prior dir at " + priordir);
            String resdir = newdir+"results"+File.separator;
            File rdir = new File(resdir);
            if(!rdir.exists()){
                rdir.mkdirs();
            }
            System.out.println("Created result dir at " + rdir);
            String splitdir = newdir+"split"+File.separator;
            File sdir = new File(splitdir);
            if(!sdir.exists()){
                sdir.mkdirs();
            }
            System.out.println("Created split dir at " + splitdir);
            String queriesdir = newdir+"queries"+File.separator;
            File qdir = new File(queriesdir);
            if(!qdir.exists()){
                qdir.mkdirs();
            }
            System.out.println("Created query dir at " + queriesdir);
            Date d = new Date(System.currentTimeMillis());
            System.out.println(d + " - Started processing of " + currentfile);
            new SplitResultFile2(currentfile,splitdir,textpath,s,priordir,priorloc,qfile,queriesdir,COH,indexpath);
            COH++;
            System.out.println("Finished splitting " + currentfile);
        }
    }
}
