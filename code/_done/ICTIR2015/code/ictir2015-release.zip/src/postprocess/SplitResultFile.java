package postprocess;
import au.com.bytecode.opencsv.CSVReader;
import crossvalidation.CreateFolds;

import java.io.*;
import java.util.Date;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SplitResultFile {
    //static Logger logger = Logger.getLogger("SIGIR");
/*
    public static void main(String[] args) throws IOException {
       /*
        * First argument is the output file from ParseSentences
        * Second argument is the location where the splitted files should be placed
        * Third argument is the path to where the original (now indexed) files are stored on either local or remote server
        * Fourth argument is the configurationID (so the priors are named differently)
        *
        * PLEASE OBSERVE. RIGHT NOW IT ONLY PROCESSES THE ENTROPY MEASURE i.e the last three measures!
        * SEARCH FOR INDEX_LOW and INDEX_HIGH
        */
    public SplitResultFile(String infile, String outputdir, String textpath,
                           String conf, String priordir, String priorloc,
                           String qfile, String qdir, int NUMDIRS, String indexpath) throws IOException {
        doProcess(infile, outputdir, textpath, conf, priordir, priorloc, qfile, qdir, NUMDIRS, indexpath);
    }

    public void doProcess(String infile, String outputdir, String textpath,
                          String conf, String priordir, String priorloc,
                          String qfile, String qdir, int NUMDIRS, String indexpath) throws IOException {
        CSVReader reader = new CSVReader(new FileReader(infile));
        String[] lineparts = reader.readNext(); // First line is #,X where X is the number of fields
        int numscores = Integer.parseInt(lineparts[1]);
        PrintWriter[] writers = new PrintWriter[numscores];
        for(int j = 0; j < numscores-1; j++){
            writers[j] = new PrintWriter(outputdir+"coh"+j+".txt");
        }
        double[] sumscores = new double[numscores];
        int INDEX_LOW = 13;  // Entropy 0 -- Entropy 1 is at field 14
        int INDEX_HIGH = 15; // Entropy 2
        while((lineparts = reader.readNext()) != null){
              // A line looks like: clueweb09-enYYXX-ZZ-XXXXX, <score1>,<score2>,...,<scoreN>
              for(int i = INDEX_LOW; i < lineparts.length; i++){   //lineparts length = 16
                  sumscores[i-1] += Double.valueOf(lineparts[i]);
              }
        }
        Date d = new Date(System.currentTimeMillis());
        System.out.println(d + " - Completed summing of score");
        //for(int j = 0; j < sumscores.length-1; j++){  // -1 as the first is the documentname
            //System.out.println("Total score for coh"+j+": " + sumscores[j]);
        //}

        reader.close();

        reader = new CSVReader(new FileReader(infile));
        lineparts = reader.readNext(); // Discard
        lineparts = null;
        double[] total_score = new double[numscores];
        for(int k = 0; k < total_score.length; k++){
            total_score[k] = 0;
        }
        while((lineparts = reader.readNext()) != null){
            String filename = lineparts[0];
            for(int i = INDEX_LOW; i < lineparts.length; i++){
                double score   = Double.valueOf(lineparts[i]);
                if(score == 0.0 || Double.isNaN(score) || Double.isInfinite(score)){
                    score = Double.MIN_VALUE;
                    total_score[i] += score;
                }else{
                    score = score/sumscores[i-1];
                    total_score[i] += score;
                }
                double logprob = Math.log(score);
                // Must incorporate the fact that files are split into various dirs.
                // Force it to / as it will run on linux systems
                String[] fileparts = filename.split("-");
                writers[i-1].println(textpath+fileparts[1]+"/"+filename + ".text " + logprob);
                writers[i-1].flush();
            }
        }
        d = new Date(System.currentTimeMillis());
        System.out.print(d + " - Created all split files");
        for(int j = 0; j < numscores-1; j++){
            writers[j].close();
        }
        reader.close();
/*
        for(int i = 0; i < total_score.length; i++){
            System.out.println("Total probability of " + i + " was: " + total_score[i]);
        }
*/
        // Create prior files
        for(int j = INDEX_LOW; j < numscores; j++){ // was j < numscores - 1
            if(NUMDIRS < 10){
                createPriorFile(priordir,conf+"coh"+j, indexpath, priorloc+"conf"+0+NUMDIRS+"\\split\\coh"+j+".txt");
            }else{
                createPriorFile(priordir,conf+"coh"+j, indexpath, priorloc+"conf"+NUMDIRS+"\\split\\coh"+j+".txt");
            }
        }
        // Create queries
        for(int k = INDEX_LOW; k < numscores; k++){ // was k < numscores - 1
            createQueryPriorFile(qfile,conf+"coh"+k,qdir+"coh"+k+".queries",qdir);
        }
        d = new Date(System.currentTimeMillis());
        System.out.print(d + " - Created prior files");
    }

    public void createPriorFile(String wheretosave, String priorname, String textpath, String priorloc) throws FileNotFoundException {
        PrintWriter p = new PrintWriter(wheretosave+priorname+".prior");
        p.println("<parameters>");
        p.println("<index>"+textpath+"</index>");
        p.println("<name>"+priorname.toLowerCase()+"</name>");
        p.println("<input>"+priorloc+"</input>");
        p.println("<memory>500M</memory>");
        p.println("</parameters>");
        p.flush();
        p.close();
    }

    public void createQueryPriorFile(String queryfile, String priorname, String outfile, String qdir) throws IOException {
        FileReader fr = new FileReader(queryfile);
        BufferedReader br = new BufferedReader(fr);
        FileWriter fw = new FileWriter(outfile);
        BufferedWriter bw = new BufferedWriter(fw);
        String sCurrentLine;
        final Pattern p1 = Pattern.compile("(.+<text>\\s*)#combine\\((.+)\\)(\\s*</text>.+)");
        Matcher m1;
        while((sCurrentLine = br.readLine()) != null){
            m1 = p1.matcher(sCurrentLine);
            m1.find();
            try{
                String begin = m1.group(1);
                String query = m1.group(2);
                String endl  = m1.group(3);
                String priorquery = "#combine(#prior("+priorname+") "+query+") ";
                //System.out.println(begin+priorquery+endl);
                bw.write(begin+priorquery+endl+"\n");
                bw.flush();
            }catch(IllegalStateException ise){
                bw.write(sCurrentLine+"\n");
                bw.flush();
            }
        }
        bw.flush();
        fr.close();
        br.close();
        fw.close();
        bw.close();

        CreateFolds cf = new CreateFolds();
        cf.createKFolds(3,200,outfile,qdir);
    }
}
