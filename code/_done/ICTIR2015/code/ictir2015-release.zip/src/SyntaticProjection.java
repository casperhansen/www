/*
import edu.uci.ics.jung.graph.DirectedGraph;
import edu.uci.ics.jung.graph.DirectedSparseGraph;

import java.util.*;

public class SyntaticProjection {
    private HashMap<String, Vector<Integer>> INVINDEX;
    private Set<Integer> SENTENCEIDS;

    public SyntaticProjection(HashMap<String, Vector<Integer>> invIndex, Set<Integer> sentenceids){
        INVINDEX = invIndex;
        SENTENCEIDS = sentenceids;
    }

    public DirectedGraph<Entity, Link> getSyntaticProjection(){
        DirectedGraph<Entity, Link> projectionGraph = new DirectedSparseGraph<Entity, Link>();
        HashMap<Integer, Entity> vmap = new HashMap<Integer, Entity>();
        for(Integer i : SENTENCEIDS){
            Entity e = new Entity(""+i,i);
            vmap.put(i,e);
            projectionGraph.addVertex(e);

        }
        HashMap<String, Vector<String>> spairsMap = new HashMap<String, Vector<String>>();
        for(Map.Entry<String, Vector<Integer>> entry : INVINDEX.entrySet()){
            String word = entry.getKey();
            Vector<Integer> entitymembership = entry.getValue();
            Set<Integer> unique = new HashSet<Integer>();
            unique.addAll(entitymembership);
            Integer[] sentencelist = unique.toArray(new Integer[unique.size()]);
            if(sentencelist.length > 1){
                int N = sentencelist.length;
                for(int i = 0; i < N-1; i++){
                    for(int j = i+1; j < N; j++){
                        String key = ""+sentencelist[i]+":"+sentencelist[j];
                        if(!spairsMap.containsKey(key)){
                            Vector<String> words = new Vector<String>();
                            words.add(word);
                            spairsMap.put(key,words);
                        }else{
                            Vector<String> ws = spairsMap.get(key);
                            ws.add(word);
                            spairsMap.put(key, ws);
                        }
                    }
                }
            }
        }
        int edgectr = 0;
        for(Map.Entry<String, Vector<String>> entry : spairsMap.entrySet()){
            String[] sents = entry.getKey().split(":");
            int from = Integer.valueOf(sents[0]);
            int to   = Integer.valueOf(sents[1]);
            //Get the IDFs of the words (here assuming two)
            double dummyIDFA = 1.0;
            double dummyIDFB = 1000.0;
            projectionGraph.addEdge(new Link("E"+edgectr+(dummyIDFA+dummyIDFB)),vmap.get(from),vmap.get(to));
        }
      return projectionGraph;
    }
}
*/