import java.io.*;
import java.util.HashSet;
import java.util.Random;

public class SelectRandomSample {
    private String[] paths = {
            "/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/en0000/",
            "/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/en0001/",
            "/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/en0002/",
            "/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/en0003/",
            "/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/en0004/",
            "/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/en0005/",
            "/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/en0006/",
            "/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/en0007/",
            "/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/en0008/",
            "/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/en0009/",
            "/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/en0010/",
            "/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/en0011/",
            "/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/enwp00/",
            "/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/enwp01/",
            "/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/enwp02/",
            "/data/local/workspace/casper_petersen/sigir2014/out/spamfree/in/enwp03/"};
    String destdir = "/data/local/workspace/casper_petersen/sigir2014/EXP_LARGE_MILLION_QUERY/text/";
    private String toWrite = "/data/local/workspace/casper_petersen/sigir2014/EXP_LARGE_MILLION_QUERY/randomselect_exp_copy.sh";
    private HashSet<String> existingFiles = new HashSet<String>();

    public static void main(String[] args) throws IOException{
        new SelectRandomSample();
    }

    public SelectRandomSample() throws IOException{
        doRandomSelection();
    }

    public void doRandomSelection() throws IOException{
        int TOTAL_FILES = 50000;
        int TOTAL_DIRS = paths.length;
        int RANDOM_FILES_PR_DIR = (int)TOTAL_FILES/TOTAL_DIRS;
        FileWriter fw = new FileWriter(toWrite);
        BufferedWriter bw = new BufferedWriter(fw);
        for(String s : paths){
            int nof_random_files = 0;
            Random random = new Random();
            File f = new File(s);
            File[] fs = f.listFiles();
            while(nof_random_files <= RANDOM_FILES_PR_DIR){
                File cf = fs[random.nextInt(fs.length)];
                bw.write("cp " + cf.getAbsoluteFile().toString() + " " + destdir+cf.getName()+"\n");
                nof_random_files++;
            }
        }
        System.out.println("Finished all dirs");
    }

    private void loadExisitingFiles() throws IOException {
        String p = "/data/local/workspace/casper_petersen/sigir2014/retexp_small/data/scrambled/";
        File dir = new File(p);
        File[] content = dir.listFiles();
        for(File c : content){
            existingFiles.add(c.getName());
        }
    }
}
