package Powerlaw;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

public class iSearch {
    public static void main(String[] args) throws IOException {
        new iSearch();
    }

    public iSearch() throws IOException {
        doParse();
    }

    public void doParse() throws IOException {
        String fileloc = "C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2014\\data\\powerlaw\\isearch\\iSearch-direct-citations.txt";
        FileReader fr = new FileReader(fileloc);
        BufferedReader br = new BufferedReader(fr);
        String sCurrentLine;
        HashMap<String, Integer> histogram = new HashMap<String, Integer>();
        while((sCurrentLine = br.readLine()) != null){
              String[] ssplit = sCurrentLine.split(",");
              String citedDoc = ssplit[1];
              citedDoc = citedDoc.replace("\"","");
              if(!histogram.containsKey(citedDoc)){
                  histogram.put(citedDoc,1);
              }else{
                  histogram.put(citedDoc, histogram.get(citedDoc)+1);
              }
        }
        fr.close();
        br.close();
        PrintWriter pw = new PrintWriter("C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2014\\data\\powerlaw\\isearch\\iSearch-direct-histogram.txt");
        int docid = 0;
        for (Map.Entry<String, Integer> pairs : histogram.entrySet()) {
             String doc = pairs.getKey();
             int count  = pairs.getValue();
             pw.println(count);
             docid++;
        }
        pw.close();
    }

}
