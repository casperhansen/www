package Powerlaw;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class Excite{
    public static void main(String[] args) throws IOException {
        new Excite(args[0], args[1]);
    }

    public Excite(String in, String out) throws IOException {
    doParse(in, out);
    }

    public void doParse(String in, String out) throws IOException {
        FileReader fr = new FileReader(in);
        BufferedReader br = new BufferedReader(fr);
        PrintWriter pw = new PrintWriter(out);
        String sCurrentLine;
        while((sCurrentLine = br.readLine()) != null){
               String[] s = sCurrentLine.split("\\t");
               try{
                   String query = s[3];
                   String[] querylength = query.split("\\s");
                   pw.println(querylength.length);
                   pw.flush();
               }catch(IndexOutOfBoundsException ioe){
                    //System.out.println(sCurrentLine); Query of length 0
               }
        }
        br.close();
        fr.close();
        pw.close();
    }


}