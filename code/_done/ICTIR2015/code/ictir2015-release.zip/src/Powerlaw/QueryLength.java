package Powerlaw;

import java.io.*;

/**
 * Distribution for the million query tracks from 07 through 09
 */
public class QueryLength {
    public static void main(String[] args) throws IOException {
        /*
         * First argument is the directory containing the millionquery files.
         * Second argument is the parsed file containing just the number of terms pr query.
         */
        new QueryLength(args[0], args[1]);
    }

    public QueryLength(String in, String out) throws IOException {
        doParse(in, out);
    }

    public void doParse(String in, String out) throws IOException {
        File check = new File(in);
        if(!check.isDirectory()){
            System.err.println("First argument must be where the million query track files resides");
            System.exit(-1);
        }
        File[] files = check.listFiles();
        PrintWriter pw = new PrintWriter(out);
        assert files != null;
        for(File f : files){
            String filepath = f.getAbsoluteFile().toString();
            FileReader fr = new FileReader(filepath);
            BufferedReader br = new BufferedReader(fr);
            String sCurrentLine;
            while((sCurrentLine = br.readLine()) != null){
                   String[] splitted = sCurrentLine.split(":"); // 07 and 08 has one ":". 09 has two.
                   int N = splitted.length;
                   String query;
                   if(N == 2){
                      query = splitted[1];
                   }else{
                      query = splitted[2];
                   }
                   String[] querysize = query.split(" ");
                   pw.println(querysize.length);
            }
        }
        pw.close();
    }
}
