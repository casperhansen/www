package Powerlaw;

import java.io.*;
import java.nio.charset.Charset;
import java.util.zip.GZIPInputStream;

public class SyntacticNGrams {
    public static void main(String[] args) throws IOException {
        /*
         * First argument is the directory containing the gz files (http://commondatastorage.googleapis.com/books/syntactic-ngrams/index.html)
         * Second argument is the file containing the counts of syntactic ngrams.
         */
        new SyntacticNGrams(args[0], args[1]);
    }

    public SyntacticNGrams(String indir, String outfile) throws IOException {
        doParse(indir, outfile);
    }

    public void doParse(String indir, String outfile) throws IOException {
        File dir = new File(indir);
        if(!dir.isDirectory()){
            System.err.println("First argument must be a directory containing the gz files");
            System.exit(-1);
        }
        File[] dircontent = dir.listFiles();
        assert dircontent != null;
        int N             = dircontent.length;
        int filecounter   = 0;
        PrintWriter pw = new PrintWriter(outfile);
        for(File f : dircontent){
            String filepath = f.getAbsoluteFile().toString();
            InputStream fileStream = new FileInputStream(filepath);
            InputStream gzipStream = new GZIPInputStream(fileStream);
            Reader decoder = new InputStreamReader(gzipStream, Charset.defaultCharset());
            BufferedReader buffered = new BufferedReader(decoder);
            String sCurrentLine;
            while((sCurrentLine = buffered.readLine()) != null){
                   String[] parts = sCurrentLine.split("\\t");
                   if(parts[2].equals("1055305466")){
                      System.out.println("Filepath: " + filepath + ", Line: " + sCurrentLine);
                   }
                   pw.println(parts[2]); // Format is "org.\t"org./FW/nn/0\t15\t2003,5\t2005,4\t2006,4\t2007,2
            }
            buffered.close();
            decoder.close();
            gzipStream.close();
            fileStream.close();
            System.out.println("Completed "+ filecounter + " of " + N);
            filecounter++;
        }
        pw.close();
        //1055305466
    }
}
