package Powerlaw;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class Clueweb09 {
    public static void main(String[] args) throws IOException {
        new Clueweb09("C:\\Users\\casper\\Downloads\\ClueWeb09-B-PRranked\\ClueWeb09-B-PRranked.txt");
    }

    public Clueweb09(String arg) throws IOException {
        doParse(arg);
    }

    public void doParse(String arg) throws IOException {
        FileReader fr = new FileReader(arg);
        BufferedReader br = new BufferedReader(fr);
        PrintWriter pw = new PrintWriter("C:\\Users\\casper\\Downloads\\ClueWeb09-B-PRranked\\ClueWeb09-B-PRranked-stripped.txt");
        String sCurrentLine;
        int counter = 0;
        while((sCurrentLine = br.readLine()) != null){
               String[] ss = sCurrentLine.split("\\s+");
               int val = (int)(Double.parseDouble(ss[1]) * 100);
               pw.println(""+val); pw.flush();
        }
        System.out.println("There was: " + counter + " lines");
        fr.close();
        br.close();
        pw.close();
    }

}
