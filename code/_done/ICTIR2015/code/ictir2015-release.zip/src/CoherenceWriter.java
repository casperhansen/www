import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CoherenceWriter {
    private FileWriter fw = null;
    private BufferedWriter bw = null;
    static Logger logger = Logger.getLogger("SIGIR");

    public CoherenceWriter(String writefile){
        super();
        logger.setLevel(Level.FINEST);
        try{
            fw = new FileWriter(writefile);
            bw = new BufferedWriter(fw);
        }catch(IOException ioe){
            logger.log(Level.SEVERE, "Could not open file to write coherence metrics: " + writefile);
        }
    }

    public void writeToFile(String str) {
        try {
            bw.write(str+"\n");
            bw.flush();
        } catch (IOException e) {
            logger.log(Level.WARNING, "Could not write string to file: " + str);
        }
    }

    public void closeWriter() throws IOException {
        bw.flush();
        fw.close();
        bw.close();
    }
}