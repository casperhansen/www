import java.io.*;
import java.util.HashSet;

public class RemoveQrelsForNonExistingDocs {
    public static void main(String[] args) throws IOException{
        // First argument is the qrels file given in TREC format.
        // Second argument is the filtered output file.
        new RemoveQrelsForNonExistingDocs(args[0], args[1]);
    }

    public RemoveQrelsForNonExistingDocs(String in, String out) throws IOException{
        doFilter(in, out);
    }

    public void doFilter(String in, String out) throws IOException {
        FileReader fr = new FileReader(in);
        BufferedReader br = new BufferedReader(fr);
        FileWriter fw = new FileWriter(out);
        BufferedWriter bw = new BufferedWriter(fw);
        String sCurrentLine;
        while((sCurrentLine = br.readLine()) != null){
                //116 0 clueweb09-enwp01-08-20960 0 is an example line
                String[] ssplit   = sCurrentLine.split(" ");
                String[] docparts = ssplit[2].split("-");ssplit = null;
                String s = docparts[1].substring(2, docparts[1].length());
                try{
                    int val  = Integer.parseInt(s);
                    if(val <= 11){
                       bw.write(sCurrentLine+"\n");
                       bw.flush();
                    }
                }catch(NumberFormatException nfe){
                    System.out.println(s);
                    bw.write(sCurrentLine+"\n");
                    bw.flush();
                }
        }
        bw.flush();
        fw.close();
        bw.close();
        fr.close();
        br.close();

    }

}
