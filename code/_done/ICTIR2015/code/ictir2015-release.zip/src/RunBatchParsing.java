import java.io.File;
import java.io.IOException;

public class RunBatchParsing {
    public static void main(String[] args) throws IOException {
        new RunBatchParsing(args);
    }

    public RunBatchParsing(String[] args) throws IOException {
        batchrun(args);
    }

    public void batchrun(String[] args) throws IOException {
        String filedir = args[0];//"C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2014\\data\\testarticles\\tmp\\";
        String outdir  = args[1];//"C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2014\\data\\retrievalexp\\output\\conf";
        String server  = args[2];
        int confcounter = 1;
        if(args.length != 3){
            System.err.println("Three arguments must be supplied");
            System.exit(-1);
        }
        // directed/undirected
        // unweighted/weighted/syntactic
        // mean/median/mode
        //BatchParseSentences bps = new BatchParseSentences(filedir,outdir+confcounter+ File.separator,0,0,0);
        BatchParseSentences bps = new BatchParseSentences(filedir,outdir+confcounter+ File.separator,0,0,1,server);
        //BatchParseSentences bps = new BatchParseSentences(filedir,outdir+confcounter+ File.separator,0,0,2);
        //BatchParseSentences bps = new BatchParseSentences(filedir,outdir+confcounter+ File.separator,0,1,0);
        //BatchParseSentences bps = new BatchParseSentences(filedir,outdir+confcounter+ File.separator,0,1,1);
        //BatchParseSentences bps = new BatchParseSentences(filedir,outdir+confcounter+ File.separator,0,1,2);
        //BatchParseSentences bps = new BatchParseSentences(filedir,outdir+confcounter+ File.separator,0,2,0);
        //BatchParseSentences bps = new BatchParseSentences(filedir,outdir+confcounter+ File.separator,0,2,1);
        //BatchParseSentences bps = new BatchParseSentences(filedir,outdir+confcounter+ File.separator,0,2,2);
        //BatchParseSentences bps = new BatchParseSentences(filedir,outdir+confcounter+ File.separator,1,0,0);
        //BatchParseSentences bps = new BatchParseSentences(filedir,outdir+confcounter+ File.separator,1,0,1);
        //BatchParseSentences bps = new BatchParseSentences(filedir,outdir+confcounter+ File.separator,1,0,2);
        //BatchParseSentences bps = new BatchParseSentences(filedir,outdir+confcounter+ File.separator,1,1,0);
        //BatchParseSentences bps = new BatchParseSentences(filedir,outdir+confcounter+ File.separator,1,1,1);
        //BatchParseSentences bps = new BatchParseSentences(filedir,outdir+confcounter+ File.separator,1,1,2);
        //BatchParseSentences bps = new BatchParseSentences(filedir,outdir+confcounter+ File.separator,1,2,0);
        //BatchParseSentences bps = new BatchParseSentences(filedir,outdir+confcounter+ File.separator,1,2,1);
        //BatchParseSentences bps = new BatchParseSentences(filedir,outdir+confcounter+ File.separator,1,2,2);
    }
}
