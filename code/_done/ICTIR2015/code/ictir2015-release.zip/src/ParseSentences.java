import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.*;
import java.util.logging.*;
import java.util.logging.Formatter;

public class ParseSentences {
    private String filePath;
    private final int NOF_COH_MEASURES = 13; // IF YOU ADD METRICS INCREASE THIS NUMBER CORRESPONDINGLY
    private HashMap<String, Double> WEIGHTS;
    private HashSet<String> STOPWORDS;
    private String WRITEPATH;

   /*
    * *******************************************************************************************************
    * CHANGE THESE SETTINGS FOR EXPERIMENTATION
    * *******************************************************************************************************
    */
    private int projGraph           = Constants.UndirectedGraph;
    private int projGraphType       = Constants.UnweightedProjection;
    private boolean projGraphLCC    = !Constants.LargestCCOnly;
    private boolean removeStopWords = Constants.RemoveStopWordSentences;   // We remove stop-word sentences full stop!
    private int AGGREGATION_METHOD  = Constants.AGGREGATION_METHOD_MEDIAN;
    private Auxiliary AUX;

    // Logger
    static Logger logger = Logger.getLogger("SIGIR");
    static Logger output = Logger.getLogger("OUTPUT");

    public static void main(String[] args) throws IOException {
         new ParseSentences(args);
    }

    public ParseSentences(String... arguments) throws IOException {
        if(!(arguments.length == 2)){
            System.err.println("At least two arguments must be supplied. Location of the files, and where to store the output (log file and metrics)");
            System.exit(-1);
        }
        /*
         * First argument is the directory of the sentence files
         * Second argument is the full path of the html file used for logging i.e. /home/cazz/log.html
         * Third argument is EITHER the path where the coherence metric result file will be written (if we use the log
         * approach), OR the directory where individual files will be written to.
         */

        File f = new File(arguments[0]);
        if(!f.isDirectory()){
            System.err.println(arguments[0] + " is not a directory.");
            System.exit(-1);
        }
        filePath = arguments[0];

        File f1 = new File(arguments[1]);
        if(!f1.exists()){
            f1.mkdir();
            System.out.println("Created " + arguments[1]);
        }
        String storagedir = arguments[1];
        logger.setLevel(Level.FINEST); //Log everything from finest and up
        FileHandler fileHTML = new FileHandler(storagedir+"log.html");
        Formatter formatterHTML = new MyHtmlFormatter();
        fileHTML.setFormatter(formatterHTML);
        logger.addHandler(fileHTML);

        output.setLevel(Level.FINEST);
        FileHandler fileTXT = new FileHandler(storagedir+"metrics.score");
        Formatter formatterTXT = new MyTXTFormatter();
        fileTXT.setFormatter(formatterTXT);
        output.addHandler(fileTXT);
        WRITEPATH = "";

        logger.log(Level.INFO, "Reading from directory " + filePath);
        logger.log(Level.INFO, "Logging all files to " + arguments[1]);

        AUX = new Auxiliary();
        if(projGraphType == Constants.SyntacticProjection){
            try {
                System.out.println("Loading IDF weights");
                WEIGHTS = AUX.loadIdfWeights();
            } catch (IOException e) {
                logger.log(Level.SEVERE, "Could not load IDF weights");
                System.exit(-1);
            }
        }

        if(removeStopWords){
            try {
                STOPWORDS = AUX.loadStopWordList();
            }catch(IOException ioe){
                logger.log(Level.SEVERE, "Could not load stopword list");
                System.err.println("Could not load stopword list");
                System.exit(-1);
            }
        }


        runFileParser();
    }

    public void runFileParser() throws IOException {
        final int N_THREADS = 2;//Runtime.getRuntime().availableProcessors()-2;
        final int BLOCKING_QUEUE_SIZE = 100;
        BlockingQueue<Runnable> blockingQueue = new ArrayBlockingQueue<Runnable>(BLOCKING_QUEUE_SIZE);
        RejectedExecutionHandler rejectedExecutionHandler = new ThreadPoolExecutor.CallerRunsPolicy();
        ThreadPoolExecutor service = new ThreadPoolExecutor(N_THREADS, N_THREADS, 0L, TimeUnit.MILLISECONDS, blockingQueue, rejectedExecutionHandler);

        logger.log(Level.CONFIG, "Using " + N_THREADS + " cores and blocking queue of " + BLOCKING_QUEUE_SIZE);
        logger.log(Level.CONFIG, "Parameters: " + Constants.getGraph(projGraph,true) + " : " +
                Constants.getProjection(projGraphType,true) + " : " +
                Constants.getLargestCC(projGraphLCC,true) + " : " +
                Constants.getStopWordsUsed(removeStopWords,true) + " : " +
                Constants.getAggregation(AGGREGATION_METHOD,true));
        if(AGGREGATION_METHOD == Constants.AGGREGATION_METHOD_AVERAGE){
            logger.log(Level.WARNING, "You are averaging with the distance function. Be careful");
        }

        File dir       = new File(filePath);
        File[] content = dir.listFiles();
        if(content == null){
           logger.log(Level.SEVERE, "Could not access directory " + filePath);
           System.exit(-1);
        }
        int totaldocs  = content.length;
        int counter    = 1;
        output.log(Level.FINEST, "#,"+(NOF_COH_MEASURES+1)); // So we have the information necessary for splitting the file
        System.out.println("Found " + totaldocs + " documents");
        long tstart    = System.currentTimeMillis();
        //noinspection ConstantConditions
        for(File f : content){

            String filepath = f.getAbsoluteFile().toString();
            try {
                service.submit(new FileParser3(filepath,
                                               projGraph,
                                               projGraphType,
                                               removeStopWords,
                                               AGGREGATION_METHOD,
                                               WEIGHTS,
                                               STOPWORDS,
                                               NOF_COH_MEASURES,
                                               WRITEPATH)); // Placeholder for faster version. Dont forget to turn off the logging!

            } catch (IOException e) {
                logger.log(Level.SEVERE, "Could not submit job from file " + filepath);
            }
            if((counter%100) == 0){
                System.out.println("Submitted " + counter+"/"+totaldocs);
            }
            if(counter >= 50600 && counter <= 50700){
                System.out.println(filepath);
            }

            counter++;
        }
        service.shutdown();

        //noinspection StatementWithEmptyBody
        while (!service.isTerminated()) {
            //Could be that once a thread gets into heap space problems and IOE's it never terminates per say hence this never gets called
        }
        long tend = System.currentTimeMillis();
        String opt = "Finished all threads in " + ((tend-tstart)/(1000)) + " minutes";
        logger.log(Level.INFO,opt);
    }
}
