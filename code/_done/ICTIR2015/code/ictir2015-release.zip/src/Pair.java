public class Pair {

    private int left;
    private int right;

    public Pair(int left, int right) {
        this.left = left;
        this.right = right;
    }

    public int getLeft() { return left; }
    public int getRight() { return right; }
    public void incrementLeft(int amount){this.left+=amount;}
    public void incrementRight(int amount){this.right+=amount;}
}