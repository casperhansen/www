import edu.uci.ics.jung.graph.Graph;

import java.io.*;
import java.util.*;

public class Auxiliary {

    public <T,S> void printMap(HashMap<T,S> map){
        for(Map.Entry<T,S> entry : map.entrySet()){
            System.out.println("first: " + entry.getKey() + " - second: " + entry.getValue());
        }
    }

    public void printHashMapRev(HashMap<Entity, String> v){
        for (Map.Entry<Entity, String> stringVectorEntry : v.entrySet()) {
            Map.Entry pairs = (Map.Entry) stringVectorEntry;
            Entity e = (Entity) pairs.getKey();
            String vals = (String)pairs.getValue();
            System.out.println(e.getLabel() + ", nr: " + vals);
        }
    }

    public <T> void printTreeMap(TreeMap<T,Entity> tMap){
         for(Map.Entry<T,Entity> entry : tMap.entrySet()){
             System.out.println("key: " + entry.getKey() + " - val: " + entry.getValue().getLabel());
         }
    }

    public <T> void printHashMapSingle(HashMap<T,Entity> map){
        for (Map.Entry<T, Entity> entry : map.entrySet()) {
            T key = (T) entry.getKey();
            Entity val = entry.getValue();
            System.out.println("key: " + key + ", val: " + val.getLabel());
        }
    }

    public <T> void printHashSet(HashSet<T> myset){
        for(T t : myset){
            System.out.println(t);
        }
    }

    public <T> void printTable(HashMap<String,Vector<T>> map){
        for(Map.Entry<String, Vector<T>> entry : map.entrySet()){
            String key = entry.getKey();
            Vector<T> vals = entry.getValue();
            String s = "";
            for(T t : vals){
                s = s.concat(t + ";");
            }
            System.out.println("key: "+key + ", val: " + s);
        }
    }

    public void printIndex(HashMap<Entity, Vector<String>> index){
        for(Map.Entry<Entity, Vector<String>> entry : index.entrySet()){
            System.out.print(entry.getKey().getID() + ": ");
            for(String s : entry.getValue()){
                System.out.print(s + ",");
            }
            System.out.println();
        }
    }

    public HashMap<String, Double> loadIdfWeights() throws IOException {
        File dir = new File(Constants.TERMS_IDF_PATH);
        HashMap<String, Double> weights = new HashMap<String, Double>();
        //noinspection ConstantConditions
        for(File f : dir.listFiles()){
            String filename = f.getAbsoluteFile().toString();
            FileReader fr = new FileReader(filename);
            BufferedReader br = new BufferedReader(fr);
            String sCurrentLine;
            while((sCurrentLine = br.readLine()) != null){
                  int lastIndex = sCurrentLine.lastIndexOf(" ");
                  String term = sCurrentLine.substring(0,lastIndex);
                  double value = Double.valueOf(sCurrentLine.substring(lastIndex+1,sCurrentLine.length()));
                  weights.put(term, value);
            }
            fr.close();
            br.close();
        }
        return weights;
    }

    public HashSet<String> loadStopWordList() throws IOException{
        HashSet<String> stopwords = new HashSet<String>();
        FileReader fr = new FileReader(Constants.STOPWORDLIST);
        BufferedReader br = new BufferedReader(fr);
        String sCurrentLine;
        while((sCurrentLine = br.readLine()) != null){
               stopwords.add(sCurrentLine);
        }
        fr.close();
        br.close();

        return stopwords;
    }

    public double median(List<Double> entries){
        int index;
        Collections.sort(entries);
        int length = entries.size();
        switch(length){
            case 1:  index = 0;
                     break;
            default: if((length%2) == 0){
                        int indexLow  = (int)(length/2);
                        int indexHigh = (int)((length/2) + 1);
                        index         = (int)((indexLow + indexHigh)/2);
                     }else{
                        index = (int)((length+1)/2);
                     }
        }
        try{
            double result = entries.get(index);
            entries = null;
            return ((double)result);
        }catch(IndexOutOfBoundsException ioe){
            System.out.println("Found index: " + index);
//            System.out.println("File: " + filename);
            System.out.println(entries.toString());
            System.exit(-1);
        }
        return 0.0;
    }

    public double mode(List<Double> ary) {
        Map<Double, Integer> m = new HashMap<Double, Integer>();
        for (Double a : ary) {
            Integer freq = m.get(a);
            m.put(a, (freq == null) ? 1 : freq + 1);
        }
        int max = -1;
        double mostFrequent = -1.0;
        for (Map.Entry<Double, Integer> e : m.entrySet()) {
            if (e.getValue() > max) {
                mostFrequent = e.getKey();
                max = e.getValue();
            }
        }
        m = null;
        return mostFrequent;
    }

    public <T> int intersection(Vector<T> list1, Vector<T> list2) {
        List<T> list = new ArrayList<T>();

        for (T t : list1) {
            if(list2.contains(t)) {
                list.add(t);
            }
        }
        return list.size();
    }

    public <T> int intersectList(List<T> list1, List<T> list2) {
        List<T> list = new ArrayList<T>();

        for (T t : list1) {
            if(list2.contains(t)) {
                list.add(t);
            }
        }
        return list.size();
    }

    public <T> int union(Vector<T> list1, Vector<T> list2) {
        Set<T> set = new HashSet<T>();

        set.addAll(list1);
        set.addAll(list2);

        return set.size();
    }

    public <T> int union(List<T> list1, List<T> list2) {
        Set<T> set = new HashSet<T>();
        set.addAll(list1);
        set.addAll(list2);
        //System.out.println("union(List<T> list1, List<T> list2: " + set.toString());
        //return new ArrayList<T>(set).size();
        return set.size();
    }

    public <T> List<T> unionList(List<T> list1, List<T> list2) {
        Set<T> set = new HashSet<T>();

        set.addAll(list1);
        set.addAll(list2);

        return new ArrayList<T>(set);
    }

    public Assembler getDocLocsAndMap(Graph<Entity,Link> GRAPH, HashMap<Integer,Entity> PARENTS, Entity sentence_current, Entity sentence_next){
        Collection<Entity> curSucc  = GRAPH.getNeighbors(PARENTS.get(sentence_current.getID()));
        Collection<Entity> nextSucc = GRAPH.getNeighbors(PARENTS.get(sentence_next.getID()));
        HashSet<Entity> hs = new HashSet<Entity>();
        hs.addAll(curSucc); hs.addAll(nextSucc);
        HashMap<String, Vector<Integer>> map = new HashMap<String, Vector<Integer>>();
        Vector<Integer> docLocs = new Vector<Integer>();
        for(Entity e : hs){
            docLocs.add(e.getPositionInDocument());
            if(!map.containsKey(e.getWord())){
                Vector<Integer> v = new Vector<Integer>();
                v.add(e.getPositionInDocument());
                map.put(e.getWord(), v);
            }else{
                Vector<Integer> v = map.get(e.getWord());
                v.add(e.getPositionInDocument());
                map.put(e.getWord(), v);
            }
        }
        hs = null; curSucc = null; nextSucc = null;
        return new Assembler(map, docLocs);
    }

    public TreeMap<String, Double> calcProbHist(TreeMap<Integer, String> map){
        TreeMap<String, Integer> hist = new TreeMap<String, Integer>();
        int rSum = 0;
        for(Map.Entry<Integer,String> entry : map.entrySet()){
            if(!hist.containsKey(entry.getValue())){
               hist.put(entry.getValue(), 1);
               rSum++;
            }else{
               hist.put(entry.getValue(), hist.get(entry.getValue()) + 1);
               rSum++;
            }
        }
        TreeMap<String, Double> probHist = new TreeMap<String, Double>();
        for(Map.Entry<String, Integer> entry : hist.entrySet()){
            probHist.put(entry.getKey(), (double)entry.getValue()/rSum);
        }
        hist = null;
        return probHist;
    }
}
