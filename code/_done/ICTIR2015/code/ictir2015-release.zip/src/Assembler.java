import java.util.HashMap;
import java.util.Vector;

public class Assembler{
    Vector<Integer> DOCLOCS;
    HashMap<String, Vector<Integer>> MAP;
    public Assembler(HashMap<String, Vector<Integer>> map, Vector<Integer> doclocs){
        DOCLOCS = doclocs;
        MAP = map;
    }

    public HashMap<String, Vector<Integer>> getMap(){
        return MAP;
    }
    public Vector<Integer> getDocLocs(){
        return DOCLOCS;
    }
}