import edu.uci.ics.jung.algorithms.importance.BetweennessCentrality;
import edu.uci.ics.jung.algorithms.metrics.Metrics;
import edu.uci.ics.jung.algorithms.scoring.PageRank;
import edu.uci.ics.jung.graph.DirectedSparseGraph;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.UndirectedSparseGraph;
import edu.uci.ics.jung.graph.util.*;
import edu.uci.ics.jung.graph.util.Pair;
import org.apache.commons.collections15.Transformer;

import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GraphMetrics {
    private Graph<Entity, Link> GRAPH;
    private Graph<Entity, Link> PROJGRAPH;
    private Collection<Entity> vertices;
    private Auxiliary AUX;
    private int AGGTYPE;
    private HashMap<Integer,Entity> PARENTNODES;
    static Logger logger = Logger.getLogger("SIGIR");

    public GraphMetrics(Graph<Entity,Link> g, Graph<Entity, Link> projg,
                        int aggtype, Auxiliary aux, HashMap<Integer, Entity> parents){
            GRAPH         = g;
            PROJGRAPH     = projg;
            vertices      = projg.getVertices();
            AGGTYPE       = aggtype;
            AUX           = aux;
            PARENTNODES   = parents;
            logger.setLevel(Level.FINEST);
    }
   /*
    * Depends only on graph-structure. Works.
    */
    public double degree(int direction){
        ArrayList<Double> indegreeList = new ArrayList<Double>();
        ArrayList<Double> outdegreeList = new ArrayList<Double>();
        int indegree     = 0;
        int outdegree    = 0;

        for(Entity id : vertices){
            double indeg  = (double)PROJGRAPH.inDegree(id);
            double outdeg = (double)PROJGRAPH.outDegree(id);
            indegreeList.add(indeg);
            outdegreeList.add(outdeg);
            indegree += indeg;
            outdegree += outdeg;
        }
        if(direction == 0){
            return aggregateAndReturn(indegreeList, indegree);
        }else{
            return aggregateAndReturn(outdegreeList, outdegree);
        }
    }
   /*
    * Depends only on graph-structure. Works.
    */
    public double betweenness(){
        BetweennessCentrality<Entity, Link> ranker = new BetweennessCentrality<Entity,Link>(PROJGRAPH);
        ranker.evaluate();
        List<Double> betweennessScores = ranker.getRankScores(vertices.size());
        double bscore   = 0.0;
        for(Double d : betweennessScores){
            bscore += d;
        }
        ranker = null;
        return aggregateAndReturn(betweennessScores, bscore);
    }

   /*
    * Depends only on graph-structure. Works.
    */
    public double clusteringcoeff(){
        Map<Entity, Double> clusteringCoefficients = Metrics.clusteringCoefficients(PROJGRAPH);
        ArrayList<Double> clusteringcoeffList = new ArrayList<Double>();
        double ccs = 0.0;
        for (Entity key: clusteringCoefficients.keySet()) {
            double val = clusteringCoefficients.get(key);
            ccs += val;
            clusteringcoeffList.add(val);
        }
        clusteringCoefficients = null;
        return aggregateAndReturn(clusteringcoeffList, ccs);
    }

    public double driftMetric(){
        int topicalflow  = 0;
        TreeMap<Integer, Entity> sortedMap = new TreeMap<Integer, Entity>();
        for(Entity e : vertices){ // vertices are the projectiongraphs vertices
            sortedMap.put(e.getID(), e);
        }
        //sortedMap contains the parentsID and a sentence (the getLabel());
        for(Map.Entry<Integer, Entity> m : sortedMap.entrySet()){
            // If vertex i and i + 1 exist
            if(sortedMap.containsKey(m.getKey() + 1)){
                // Does there exist an edge between them?
                Link link = PROJGRAPH.findEdge(sortedMap.get(m.getKey()), sortedMap.get(m.getKey()+1));
                if(!(link == null)){
                   // An edge exist
                   topicalflow++;
                }
            }
        }
        sortedMap = null;
        //Return the ratio of topical flow links to the total number of possible links
        int denom = (PROJGRAPH.getVertexCount()-1);
        int num   = topicalflow;
        if(denom > 0){
           return((double)num / (double)denom);
        }
        return 0.0;
    }

    public double distance(HashMap<String, Vector<Entity>> invIndex){
        ArrayList<Double> distances = new ArrayList<Double>();
        double totaldistance        = 0.0;
        for(Map.Entry<String, Vector<Entity>> entry : invIndex.entrySet()){
            int N = entry.getValue().size();
            if(N > 1){
               // Word is shared by more than a single entity
               Vector<Entity> vals = entry.getValue();
               for(int i = 0; i < N-1; i++){
                   Entity from = vals.get(i);
                   for(int j = i+1; j < N; j++){
                       Entity to   = vals.get(j);
                       if(from.hasDifferentParent(to)){  // Need to check that entities do not share parent
                            double eDist = (double)Math.abs(from.getPositionInDocument() - to.getPositionInDocument());
/*
                            System.out.println("Entity " + from.getLabel() +" (word: " + from.getWord()+") at position " + from.getPositionInDocument()+
                                                " shares with Entity " + to.getLabel() + " (word: " + to.getWord() + ") at position " + to.getPositionInDocument());
*/
                            distances.add(eDist);
                            totaldistance += eDist;
                       }
                   }
               }
            }
        }
        return aggregateAndReturn(distances, totaldistance);
    }
   /*
    * Depends only on graph-structure. Works.
    */
    public double pagerank(final double IDFnormalizer){
        Collection<Entity> col = PROJGRAPH.getVertices();
       /*
        * PageRank is not defined for undirected graphs. Hence the calculations are very much off for these graphs.
        * To counter that, we replace each undirected edge between E1 and E2 with a directed edge from E1 to E2 and with
        * another directed edge from E2 to E1. Both edges are given the same weight. Isolated nodes are added last to
        * ensure the graph remains unchanged.
        */
        if(PROJGRAPH instanceof UndirectedSparseGraph){
            Graph<Entity, Link> g = null;
            HashSet<Entity> entitiesSeen = new HashSet<Entity>();

            g = new DirectedSparseGraph<Entity, Link>();
            Collection<Link> lCol = PROJGRAPH.getEdges();
            for(Link l : lCol){
                Pair<Entity> p = ((UndirectedSparseGraph) PROJGRAPH).getEndpoints(l);
                if(!entitiesSeen.contains(p.getFirst())){
                    entitiesSeen.add(p.getFirst());
                    g.addVertex(p.getFirst());
                }
                if(!entitiesSeen.contains(p.getSecond())){
                    entitiesSeen.add(p.getSecond());
                    g.addVertex(p.getSecond());
                }
                Link l1 = new Link(l.getLabel()+"D1", l.getWeight());
                Link l2 = new Link(l.getLabel()+"D2", l.getWeight());
                g.addEdge(l1,p.getFirst(),p.getSecond());
                g.addEdge(l2,p.getSecond(), p.getFirst());
            }
            for(Entity e : col){
                if(!entitiesSeen.contains(e)){
                    g.addVertex(e); // Add isolated vertices
                }
            }
            PROJGRAPH = g;
        }

       /*
        * The weights of the out-going edges for each vertex correspond to probabilities for the random walker. As such
        * they must sum to 1. (This is from the JUNG documentation). Hence we loop over the out-going edges of each vertex
        * and normalize them accordingly.
        */
        for(Entity e : col){
            Collection<Link> linkcol = PROJGRAPH.getOutEdges(e);
            if(linkcol.size() == 0){
               // If there are not out-edges we do not need to normalize any weights
            }else{
                double rsum  = 0.0;
                Vector<Double> lk = new Vector<Double>();
                for(Link l : linkcol){
                    rsum += l.getWeight();
                    lk.add(l.getWeight());
                }
                int ctr = 0;
                for(Link l : linkcol){
                    l.setWeight(lk.get(ctr)/rsum);
                    //System.out.println("Link: " + l.getLabel() + " set to weight " + l.getWeight());
                    ctr++;
                }
            }
        }

       /*
        * Notice that
        */
        Transformer<Link, Double> prTransformer = new Transformer<Link, Double>() {
            public Double transform(Link link){
                return (link.getWeight());
            }
        };
        ArrayList<Double> prscores = new ArrayList<Double>();
        PageRank<Entity, Link> prRanker = new PageRank<Entity, Link>(PROJGRAPH, 0.15);
        prRanker.setEdgeWeights(prTransformer);
        //prRanker.setTolerance(0.001);
        //prRanker.setMaxIterations(3000);
        prRanker.acceptDisconnectedGraph(true);
        prRanker.evaluate();
        double prScore = 0.0;
        for(Entity i : vertices){
            prscores.add(prRanker.getVertexScore(i));
            //System.out.println("Entity: " + i.toString() + " - val: " + prRanker.getVertexScore(i));
            prScore += prRanker.getVertexScore(i);
        }
        //System.out.println(PROJGRAPH.toString());
        prRanker = null;
/*
        for(Double score : prscores){
            System.out.println("Val: " + score);
        }
*/
        //System.out.println(prScore);
        return aggregateAndReturn(prscores, prScore);
    }

   /*
    * Pitfall: the method uses the first shared entity as a measure since it is binary. In the test-sentence that means
    * that office will be used as measure when in fact newspaper would also have worked.
    */
    public double adjbinarytopicflow(HashMap<String, Vector<Entity>> invIndex){
        HashMap<String, Double> pairsmatch = new HashMap<String, Double>();
        Vector<Entity> es;
        double rSum = 0.0;
        for(Map.Entry<String, Vector<Entity>> entry : invIndex.entrySet()){
            es = entry.getValue();
            int essize = es.size();
            if(essize > 1){
               Collections.sort(es);
               for(int i = 0; i < essize-1; i++){
                   Entity sentence_current = es.get(i);
                   for(int j =  i+1; j < essize; j++){
                       Entity sentence_next    = es.get(j);
                       String key = sentence_current.getID()+":"+sentence_next.getID();
                       // If the sentence number is current+1 and we have not seen this pair before we update their value
                       if(sentence_next.isSuccessor(sentence_current) && !pairsmatch.containsKey(key)){
                              //Next sentence in sequence is the successor. They share the entity in the entry
                                double val = (1.0 / getNofUniqueSharedEntities(sentence_current, sentence_next, false));
                                rSum += val;
                                pairsmatch.put(key, val);
                       }
                   }
               }
            }
            //es.clear();
        }
        // Some additional processing to sum the results and the aggregation
        List<Double> list = new ArrayList<Double>(pairsmatch.values());
        return aggregateAndReturn(list, rSum);
    }

    public double adjWeightedTopicFlow(HashMap<String, Vector<Entity>> invIndex){
        HashMap<String, Double> pairsmatch           = new HashMap<String, Double>();
        Vector<Entity> es;
        for(Map.Entry<String, Vector<Entity>> entry : invIndex.entrySet()){
            es = entry.getValue();
            int essize = es.size();
            if(essize > 1){
                Collections.sort(es);
                for(int i = 0; i < essize-1; i++){ // -1 as we only consider adjacent sentences
                    Entity sentence_current = es.get(i);
                    for(int j = i+1; j < essize; j++){
                        Entity sentence_next = es.get(j);
                        String key = sentence_current.getID()+":"+sentence_next.getID();
                        // If the sentence number is current+1 and we have not seen this pair before we update their value
                        if(sentence_next.isSuccessor(sentence_current)){
                            if(pairsmatch.containsKey(key)){
                               pairsmatch.put(key, pairsmatch.get(key) + 1.0);
                            }else{
                               pairsmatch.put(key,1.0);
                            }
                        }
                    }
                }
            }
        }
        //AUX.printMap(pairsmatch);
        double rSum = 0.0;
        List<Double> list = new ArrayList<Double>();
        for(Map.Entry<String, Double> entry : pairsmatch.entrySet()){
            String[] ssplit = entry.getKey().split(":");
            //Normalize by the sum of the number of entities between the keys
            double nom        = entry.getValue();
            double normfactor = getNofUniqueSharedEntities(PARENTNODES.get(Integer.valueOf(ssplit[0])),
                                                           PARENTNODES.get(Integer.valueOf(ssplit[1])),
                                                           true);
            double val = nom/normfactor;
            rSum += val;
            list.add(val);
        }
        return aggregateAndReturn(list, rSum);
    }

    public double adjPositionalTopicFlow(HashMap<String, Vector<Entity>> invIndex){
        Vector<Entity> es;
        HashSet<String> keysSeen = new HashSet<String>();
        List<Double> results     = new ArrayList<Double>();
        double rSum              = 0.0;
        for(Map.Entry<String, Vector<Entity>> entry : invIndex.entrySet()){
            es         = entry.getValue();
            int essize = es.size();
            if(essize > 1){
                Collections.sort(es);
                for(int i = 0; i < essize-1; i++){ // -1 as we only consider adjacent sentences
                    Entity sentence_current = es.get(i);
                    for(int j = i+1; j<essize; j++){
                        Entity sentence_next    = es.get(j);
                        String key = sentence_current.getID()+":"+sentence_next.getID();
                        // If the sentence number is current+1 and we have not seen this pair before we update their value
                        if(sentence_next.isSuccessor(sentence_current) && !keysSeen.contains(key)){
                            // Now that we know the sentences are adjacent. We need to work on the entities they share
                            keysSeen.add(key);
                            Assembler a = AUX.getDocLocsAndMap(GRAPH, PARENTNODES, sentence_current, sentence_next);
                            double sumdistances = 0.0;
                            int denomcounter    = 0;
                            for(Map.Entry<String, Vector<Integer>> e : a.getMap().entrySet()){
                                Vector<Integer> v = e.getValue();
                                if(v.size() > 1){
                                    sumdistances += (double)(Math.abs(v.get(0) - v.get(1))-1); // -1 to match christinas example
                                    denomcounter++;
                                }
                            }
                            double nom = sumdistances/(double)denomcounter;
                            double denom = Math.abs((double)Collections.max(a.getDocLocs()) - (double)Collections.min(a.getDocLocs()));
                            double val = nom/denom;
                            results.add(val);
                            rSum += val;
//                            System.out.println("Expression: (" + sumdistances+"/"+denomcounter + ")/"+denom + " -!- result: " + (nom/denom));
                        }
                    }
                }
            }
        }
        return aggregateAndReturn(results, rSum);
    }


    public double nonAdjBinaryTopicFlow(HashMap<String, Vector<Entity>> invIndex){
        HashMap<String, Double> pairs = new HashMap<String, Double>();
        HashSet<String> keysSeen      = new HashSet<String>();
        double rSum                   = 0.0;
        Vector<Entity> es;
        for(Map.Entry<String, Vector<Entity>> entry : invIndex.entrySet()){
            es = entry.getValue();
            int essize = es.size();
            if(essize > 1){
                Collections.sort(es); // No need to sort if not needed
                for(int i = 0; i < essize-1; i++){ // -1 as we only consider adjacent sentences
                    Entity e1 = es.get(i);
                    for(int j = i+1; j < essize; j++){
                        Entity e2 = es.get(j);
                        String key = e1.getID()+":"+e2.getID();
                        if(!keysSeen.contains(key) && e1.hasDifferentParent(e2)){
                           keysSeen.add(key);
                           double val = 1.0/getNofUniqueSharedEntities(e1,e2,false);
                           pairs.put(key, val);
                           rSum += val;
                        }
                    }
                }
            }
        }
        // Some additional processing to sum the results and the aggregation
        List<Double> list = new ArrayList<Double>(pairs.values());
        return aggregateAndReturn(list, rSum);
    }

    public double nonAdjWeightedTopicFlow(HashMap<String, Vector<Entity>> invIndex){
        HashMap<String, Double> histogram = new HashMap<String, Double>();
        Vector<Entity> es;
        for(Map.Entry<String, Vector<Entity>> entry : invIndex.entrySet()){
            es = entry.getValue();
            int numElem = es.size();
            if(numElem > 1){
               // Word is shared between N > 1 entity
                Collections.sort(es);
                for(int i = 0; i < numElem-1; i++){ // -1 as we only consider adjacent sentences
                    Entity e1 = es.get(i);
                    for(int j = i+1; j < numElem; j++){
                        Entity e2 = es.get(j);
                        if(e1.hasDifferentParent(e2)){
                            String key = e1.getID()+":"+e2.getID();
                            if(histogram.containsKey(key)){
                                histogram.put(key, histogram.get(key) + 1.0);
                            }else{
                                histogram.put(key,1.0);
                            }
                        }
                    }
                }
            }
        }
        double rSum = 0.0;
        List<Double> list = new ArrayList<Double>();
        for(Map.Entry<String, Double> entry : histogram.entrySet()){
            String[] ssplit = entry.getKey().split(":");
            //Normalize by the sum of the number of entities between the keys
            double nom        = entry.getValue();
            double normfactor = getNofUniqueSharedEntities( PARENTNODES.get(Integer.valueOf(ssplit[0])),
                                                            PARENTNODES.get(Integer.valueOf(ssplit[1])),
                                                            true);
            double val = nom/normfactor;
            rSum += val;
            list.add(val);
        }
        return aggregateAndReturn(list, rSum);
    }
   /*
    * As this measure considers both adjacent and non-adjacent sentences it is a global measure.
    */
    public double nonAdjPositionalTopicFlow(HashMap<String, Vector<Entity>> invIndex){
        Vector<Entity> es;
        List<Double> list = new ArrayList<Double>();
        int totalShared   = 0;
        double rSum       = 0.0;
        double minLoc     = 1000000.0;
        double maxLoc     = -1.0;
        for(Map.Entry<String, Vector<Entity>> entry : invIndex.entrySet()){
            es = entry.getValue();
            int essize = es.size();
            if(essize > 1){
                //We know the word is shared
                Collections.sort(es);
                for(int i = 0; i < essize-1; i++){ // -1 as we only consider adjacent sentences
                    Entity e1 = es.get(i);
                    for(int j = i+1; j < essize; j++){
                        Entity e2 = es.get(j);
                        /* As we work between sentences, a word appearing one or more times in one sentence:
                            1,man,s,nsubj,2,2,0.0          <-----
                            1,newspaper,o,dobj,5,5,0.0
                            1,office,o,pobj,8,8,0.0
                            1,man,s,nsubj,9,10,0.0         <-----
                            2,newspaper,o,pobj,5,13,0.0
                            2,office,o,dobj,8,16,0.0
                            2,desk,o,pobj,11,19,0.0
                            2,man,s,nsubj,13,21,0.0
                            3,man,o,nsubj,3,23,0.0
                            3,habit,o,pobj,5,25,0.0
                            6,man,s,nsubj,1,32,0.0

                            that the distance between the word in the same sentence is not included. This is what
                            hasDifferentParent check for.
                        */
                        if(e1.hasDifferentParent(e2)){
                            totalShared++;
                            double pose1 = (double)e1.getPositionInDocument();
                            double pose2 = (double)e2.getPositionInDocument();
                            double distance = Math.abs(pose1-pose2);
                            list.add(distance);
                            rSum += distance;

                            if(pose1 < minLoc){
                               minLoc = pose1;
                            }
                            if(pose1 > maxLoc){
                               maxLoc = pose1;
                            }

                            if(pose2 < minLoc){
                               minLoc = pose2;
                            }
                            if(pose2 > maxLoc){
                               maxLoc = pose2;
                            }
                        }
                    }
                }
            }else{
                Entity e = entry.getValue().get(0);
                if(e.getPositionInDocument() < minLoc){
                    minLoc = e.getPositionInDocument();
                }
                if(e.getPositionInDocument() > maxLoc){
                    maxLoc = e.getPositionInDocument();
                }
            }
        }
//        System.out.println("rSum: " + rSum + ", totalshared: " + totalShared + ", maxLoc: " + maxLoc + ", minLoc: " + minLoc);
        if(totalShared != 0){
            if(AGGTYPE == Constants.AGGREGATION_METHOD_AVERAGE){
                //if there are no shared entities (especially true for small documents with many stopwords) total shared equals 0 giving NaN
                return ((rSum/(double)totalShared)/Math.abs(maxLoc - minLoc));
            }else{
                return aggregateAndReturn(list,rSum);
            }
        }else{
            return 0.0;
        }
    }
/*
 * Calculates the entropy of the entities of a document by a n-order Markov process
 */
    public double entropy(List<Entity> data, int order){
        double total = 0.0;
        switch(order){
            case 0: total = zeroOrderEntropy(data);
                    break;
            case 1: total = firstOrderEntropy(data);
                    break;
            case 2: total = secondOrderEntropy(data);
                    break;
            default: break;
        }
        return total;
    }

    private double zeroOrderEntropy(List<Entity> data){
        TreeMap<Integer, String> tMap0 = new TreeMap<Integer, String>();
        for(Entity e : data){
            tMap0.put(e.getPositionInDocument(), e.getWord());
        }
        TreeMap<String, Double> order0 = AUX.calcProbHist(tMap0);
        double total = 0.0;
        for(Map.Entry<String, Double> ord0 : order0.entrySet()){ // Order-0 sum
            total += (ord0.getValue() * (Math.log(ord0.getValue())/Math.log(2)));
        }
        return total;
    }

    private double firstOrderEntropy(List<Entity> data){
        TreeMap<Integer, String> tMap0 = new TreeMap<Integer, String>();
        for(Entity e : data){
            tMap0.put(e.getPositionInDocument(), e.getWord());
        }

        //0-order
        TreeMap<String, Double> order0 = AUX.calcProbHist(tMap0);

        //1-order
        TreeMap<Integer, String> tMap1 = new TreeMap<Integer, String>();
        int N = data.size();
        for(int i = 0; i < N-1; i++){
            Entity e1 = data.get(i);
            Entity e2 = data.get(i+1);
            String combKey = e1.getWord()+":"+e2.getWord();
            tMap1.put(i, combKey);
        }
        if(tMap1.isEmpty()){
           // Check if there is anything to calculate. If not return NaN indicating that this was not feasible
           return Double.parseDouble("NaN");
        }

        TreeMap<String, Double> order1 = AUX.calcProbHist(tMap1);

        double entropyo1 = 0.0;
        for(Map.Entry<String, Double> ord0 : order0.entrySet()){
            String key = ord0.getKey();
            double val = ord0.getValue();                                           // p_i
            double total = 0.0;
            for(Map.Entry<String, Double> ord1 : order1.entrySet()){
                String[] ssplit = ord1.getKey().split(":");
                double ord1prob = 0.0;
                if(key.equals(ssplit[0])){
                    double tmp = ord1.getValue();                                   // p_ij
                    ord1prob = tmp * (Math.log(tmp)/Math.log(2));                   // Entropy for p_ij
                }
                total += ord1prob; // \sum_j p_ij(j)\log_2 p_ij(j)
            }
            double state = val*total; // \sum_i p_i \sum_j p_ij(j)\log_2 p_ij(j)
            entropyo1 += state;
        }
        return entropyo1;
    }

    private double secondOrderEntropy(List<Entity> data){
        TreeMap<Integer, String> tMap0 = new TreeMap<Integer, String>();
        for(Entity e : data){
            tMap0.put(e.getPositionInDocument(), e.getWord());
        }
        int N = data.size();

        //0-order
        TreeMap<String, Double> order0 = AUX.calcProbHist(tMap0);

        //1-order
        TreeMap<Integer, String> tMap1 = new TreeMap<Integer, String>();
        for(int i = 0; i < N-1; i++){
            Entity e1 = data.get(i);
            Entity e2 = data.get(i+1);
            String combKey = e1.getWord()+":"+e2.getWord();
            tMap1.put(i, combKey);
        }
        if(tMap1.isEmpty()){
            // Check if there is anything to calculate. If not return NaN indicating that this was not feasible
            return Double.parseDouble("NaN");
        }

        TreeMap<String, Double> order1 = AUX.calcProbHist(tMap1);

        //2-order
        TreeMap<Integer, String> tMap2 = new TreeMap<Integer, String>();
        for(int i = 0; i < N-2; i++){
            Entity e1 = data.get(i);
            Entity e2 = data.get(i+1);
            Entity e3 = data.get(i+2);
            String combKey = e1.getWord()+":"+e2.getWord()+":"+e3.getWord();
            tMap2.put(i, combKey);
        }
        if(tMap2.isEmpty()){
            return Double.parseDouble("NaN"); // Cannot calculate second-order on something which has no second order
        }

        TreeMap<String, Double> order2 = AUX.calcProbHist(tMap2);

        /*
         * Formula is: \sum_{i} p_i \sum_{j} p_{i}(j) \sum_{k}p_{i,j}(k) \log_2 p_{i,j}(k)
         */
        double total = 0.0;
        for(Map.Entry<String, Double> ord0 : order0.entrySet()){
            String key       = ord0.getKey();   // i (the entity name whatever it may be)
            double ord0prob  = ord0.getValue(); // p_i
            double ord1total = 0.0;
            for(Map.Entry<String, Double> ord1 : order1.entrySet()){ // Order-1 sum
                String[] ssplit = ord1.getKey().split(":");
                double ord1prob = ord1.getValue();
                double order2total = 0.0;
                if(key.equals(ssplit[0])){       //word j follows i i.e. a, a:e (since a matches both, e follows a)
                    for(Map.Entry<String, Double> ord2 : order2.entrySet()){// Order-2 sum
                        String[] next = ord2.getKey().split(":");
                        if(ssplit[1].equals(next[1])){ //a, a:e, a:e:f (a matches, e matches, so whatever comes after matches)
                            double tmp = ord2.getValue();
                            order2total += (tmp * (Math.log(tmp)/Math.log(2))); // p_{i,j}(k) \log_2 p_{i,j}(k)
                        }
                    }
                }
                ord1total += ord1prob*order2total;  // \sum_{j} p_{i}(j) \sum_{k}p_{i,j}(k) \log_2 p_{i,j}(k)
            }
            total += ord0prob*ord1total; // \sum_{i} p_i \sum_{j} p_{i}(j) \sum_{k}p_{i,j}(k) \log_2 p_{i,j}(k)
        }
        return total;
    }

    public double getNofUniqueSharedEntities(Entity e1, Entity e2, boolean isParents){
        Collection<Entity> parent1;
        Collection<Entity> parent2;
        if(!isParents){
            parent1 = GRAPH.getNeighbors(PARENTNODES.get(e1.getID()));
            parent2 = GRAPH.getNeighbors(PARENTNODES.get(e2.getID()));
        }else{
            parent1 = GRAPH.getNeighbors(e1);
            parent2 = GRAPH.getNeighbors(e2);
        }
        HashSet<String> shared = new HashSet<String>();
        for(Entity e : parent1){
            shared.add(e.getWord());
        }
        for(Entity e : parent2){
            shared.add(e.getWord());
        }
        parent1 = null; parent2 = null;
        return (double)shared.size();
    }

    public double aggregateAndReturn(List<Double> list, double rSum){
        double result = 0.0;
        if(!list.isEmpty()){
            switch(AGGTYPE){
                case Constants.AGGREGATION_METHOD_AVERAGE:
                    result = (rSum/((double)list.size()));
                    break;
                case Constants.AGGREGATION_METHOD_MEDIAN:
                    result = AUX.median(list);
                    break;
                case Constants.AGGREGATION_METHOD_MODE:
                    result = AUX.mode(list);
                    break;
                default: logger.log(Level.WARNING, "Unknown aggregation method");
            }
        }
        list = null;
        return result;
    }

}
