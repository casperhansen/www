public class ProjectionLink {
    private String LABEL;
    private int WEIGHT;

    public ProjectionLink(String label, int weight) {
        this.LABEL = label;
        this.WEIGHT = weight;
    }

    @Override
    public String toString() {
        return this.LABEL;
    }

    public String getLabel(){
        return this.LABEL;
    }

    public int getEdgeWeight(){
        return this.WEIGHT;
    }
}