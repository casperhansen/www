import java.util.Vector;

public class ProcessedFileResult {
    Vector<Double> scores = new Vector<Double>();
    private String FILENAME;
    private int SCORES_SIZE;
    public ProcessedFileResult(String filename, final int NOF_COH_MEASURES, double... args){
        FILENAME = filename;
        if(args.length == 0){
            for(int i = 0; i < NOF_COH_MEASURES; i++){
                scores.add(0.0);
            }
            SCORES_SIZE = scores.size();
        }else{
            for(double d : args){
                scores.add(d);
            }
            SCORES_SIZE = scores.size();
        }
    }

    public String toString(){
        String s = "";
        for(int i = 0; i < scores.size()-1; i++){
            s = s+scores.get(i)+",";
        }
        s = s+scores.get(scores.size()-1);
        return (FILENAME+","+s);
    }

    public String getFileName(){
        return FILENAME;
    }

    public double getCohMeasure(int index){
        if(index >= 0 && index <= scores.size()-1){
           return scores.get(index);
        }
        System.err.println("Cannot get cohere measure for index " + index);
        return 0.0;
    }

    public int getScoreSize(){
        return SCORES_SIZE;
    }
}
