import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Random;

public class RandomSelect {
    public static void main(String[] args){
        new RandomSelect();
    }

    public RandomSelect(){
        doSelectCopy();
    }

    public void doSelectCopy(){
        String sourcedir = "C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2014\\data\\ret_exp\\text\\original\\";
        String targetdir = "C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2014\\data\\ret_exp\\text\\scrambled\\";

        int N = 200;
        Random random = new Random();
        File f = new File(sourcedir);
        File[] fs = f.listFiles();
        int TOTAL_FILES = f.listFiles().length;
        int counter = 0;
        for(int i = 0; i < N; i++){
            int rand = random.nextInt(TOTAL_FILES);
            File current = fs[rand];
            String sourcefullpath = current.getAbsoluteFile().toString();
            Path p  = Paths.get(sourcefullpath);
            String dname = p.getFileName().toString();
            String targetfile = targetdir+dname;

            try{
                Files.copy(Paths.get(sourcefullpath), Paths.get(targetfile), StandardCopyOption.REPLACE_EXISTING);
            }catch(IOException ioe){
                System.err.println("Could not copy");
            }

            //System.out.println("Copy: " + sourcefullpath + " : To: " + targetfile);
        }



    }

}
