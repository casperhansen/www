import java.io.*;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ValidateInputFile {
    private Vector<String> content = new Vector<String>();
    static Logger logger = Logger.getLogger("SIGIR");
    public ValidateInputFile(){}

    public boolean validate(String filename) {
        logger.setLevel(Level.FINEST);
        if(!content.isEmpty()){
            content.clear();
        }
        boolean success = true;
        FileReader fw = null;
        try {
            fw = new FileReader(filename);
        } catch (FileNotFoundException e) {
            System.err.println("Could not open " + filename);
            System.exit(-1);
        }
        BufferedReader br = new BufferedReader(fw);
        String sCurrentLine;
        int LINE_LENGTH = 7;
        try {
            while((sCurrentLine = br.readLine()) != null){
                String[] linesplit = sCurrentLine.split(",");
                if(linesplit.length != LINE_LENGTH){
                    File f = new File(filename);
                    logger.log(Level.FINE, "Parse error: " + f.getName() + " - ignoring line: " + sCurrentLine);
                }else{
                    content.add(sCurrentLine);
                }
            }
        } catch (IOException e) {
          logger.log(Level.SEVERE, "Could not read from: " + filename + ". Exiting...");
          System.exit(-1);
        }
        try{
            fw.close();
            br.close();
        }catch(IOException ioe){
            logger.log(Level.SEVERE, " Could not close readers. Exiting....");
            System.exit(-1);
        }
        fw = null;
        br = null;
        return success;
    }

    public Vector<String> getContent(){
        return content;
    }
}