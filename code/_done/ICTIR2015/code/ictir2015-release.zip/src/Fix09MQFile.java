import java.io.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Fix09MQFile {
    public static void main(String[] args) throws IOException {
        assert args.length == 3;
        new Fix09MQFile(args[0], args[1], args[2]);
    }

    public Fix09MQFile(String queryfile, String priorname, String outfile) throws IOException {
        FileReader fr = new FileReader(queryfile);
        BufferedReader br = new BufferedReader(fr);
        FileWriter fw = new FileWriter(outfile);
        BufferedWriter bw = new BufferedWriter(fw);
        String sCurrentLine;
        final Pattern p1 = Pattern.compile("(.+<text>\\s*)#combine\\((.+)\\)(\\s*</text>.+)");
        Matcher m1;
        while((sCurrentLine = br.readLine()) != null){
            m1 = p1.matcher(sCurrentLine);
            m1.find();
            try{
                String begin = m1.group(1);
                String query = m1.group(2);
                String endl  = m1.group(3);
                String priorquery = "#combine(#prior("+priorname+") "+query+") ";
                //System.out.println(begin+priorquery+endl);
                bw.write(begin+priorquery+endl+"\n");
                bw.flush();
            }catch(IllegalStateException ise){
                bw.write(sCurrentLine+"\n");
                bw.flush();
            }
        }
        bw.flush();
        fr.close();
        br.close();
        fw.close();
        bw.close();
    }
}
