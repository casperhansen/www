import java.io.*;

public class ReadFromFile {
    public static void main(String[] args) throws IOException {
        new ReadFromFile();
    }

    public ReadFromFile() throws IOException {
        doParse();
    }

    public void doParse() throws IOException {
        String path = "C:\\Casper\\Universitet\\PhD\\Articles\\2013\\JGS+RR\\data\\security-sipscan\\sipscan.release_dataset";
        FileReader fr = new FileReader(path);
        BufferedReader br = new BufferedReader(fr);
        FileWriter fw = new FileWriter("C:\\Casper\\Universitet\\PhD\\Articles\\2013\\JGS+RR\\data\\security-sipscan\\sipscan.small.last");
        BufferedWriter bw = new BufferedWriter(fw);
        String sCurrentLine;
        int linectr = 0;
        while((sCurrentLine = br.readLine()) != null){
               if(linectr > 20250000){
                   bw.write(sCurrentLine);
                   bw.newLine();
               }
               linectr++;
        }
        bw.flush();
        fw.close();
        bw.close();
        fr.close();
        br.close();
    }
}
