import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Vector;

public class SentenceFileObject {
    public SentenceFileObject(){}

    public Vector<String> read(String FILEPATH){
        Vector<String> FILESENTENCES = new Vector<String>();
        BufferedReader br = null;
        try {
            String sCurrentLine;
            br = new BufferedReader(new FileReader(FILEPATH));
            while ((sCurrentLine = br.readLine()) != null) {
                FILESENTENCES.add(sCurrentLine);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (br != null)br.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        return FILESENTENCES;
    }
}
