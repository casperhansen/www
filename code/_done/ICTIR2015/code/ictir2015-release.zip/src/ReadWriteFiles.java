import java.io.*;

public class ReadWriteFiles {
    public static void main(String[] args) throws IOException {
        /*
         * Args[0] is the directory containing the files i.e. enwp01/ where there is a lot of files and only a portion of them.
         * Args[1] is the directory where the copied files should be put
         * Args[2] is the name of the file containing the copy commands.
         */
        new ReadWriteFiles(args[0], args[1], args[2]);
    }

    public ReadWriteFiles(String fromdir, String todir, String filename) throws IOException {
        doCopy(fromdir, todir, filename);
    }

    public void doCopy(String fromdir, String todir, String file) throws IOException {
        File dir = new File(fromdir);
        File[] dircontent = dir.listFiles();
        int N             = dircontent.length;
        int startNr       = 0;
        PrintWriter pw    = new PrintWriter(file);
        for(int i = startNr; i < N; i++){
            String fileName = dircontent[i].getAbsoluteFile().toString();
            String fwrite = fileName.substring(fileName.lastIndexOf("\\")+1, fileName.lastIndexOf("."));
            String writeto = todir+fwrite+".sentence";
            pw.println("cp " + fileName + " " + writeto + ";");
            pw.flush();
        }
        pw.close();
    }

}
