import edu.uci.ics.jung.graph.DirectedSparseGraph;
import edu.uci.ics.jung.graph.UndirectedSparseGraph;
import java.awt.*;
import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Vector;

public class Test3 {
    public static void main(String[] args){
        new Test3();
    }

    public Test3(){
        String xchromosome = "GATCATTGATATGTTGCTAGAACTATGAGTGTTAAAGGTGCTTGTGGTGAGTTATCAGACAGAAACGCAGAAGATGTTATTGGAAGCTTGAGGAAAAGTGATCCTGGATTTACAGTGCCAAGAATTGGCCTGTATTGTGTTCTCAATGTTTTTGAGGAAGGTAGAAACTGTAAGTGATGA";
        HashMap<Character, Integer> uniqueChars = new HashMap<Character, Integer>();
        for(int i = 0; i < xchromosome.length(); i++){
            if(!uniqueChars.containsKey(xchromosome.charAt(i))){
                uniqueChars.put(xchromosome.charAt(i), 1);
            }else{
                uniqueChars.put(xchromosome.charAt(i), uniqueChars.get(xchromosome.charAt(i)) + 1);
            }
        }
        System.out.println(uniqueChars);

        HashMap<String, Integer> bigrams = new HashMap<String, Integer>();
        for(int i = 0; i < xchromosome.length()-1; i++){
            String key = xchromosome.charAt(i) + "" + xchromosome.charAt(i+1);
            if(!bigrams.containsKey(key)){
                bigrams.put(key, 1);
            }else{
                bigrams.put(key, bigrams.get(key)+1);
            }
        }
        System.out.println(bigrams);

        for(Map.Entry<Character,Integer> entry : uniqueChars.entrySet()){
            String current = entry.getKey().toString();
            Vector<Integer> v = new Vector<Integer>();
            for(Map.Entry<String,Integer> bigram : bigrams.entrySet()){

                if(bigram.getKey().charAt(0) == current.charAt(0)){
                   v.add(bigram.getValue());
                }
            }
            double norm = 0.0;
            for(Integer i : v){
                norm += i;
            }
            Vector<Double> v2 = new Vector<Double>();
            for(Integer i : v){
                v2.add((double)i/norm);
            }
            System.out.println(current + ": "+entry.getValue() + "* SUM" + v.toString() + " = " + v2.toString());
        }
    }
/*
    public void doExp(){
        ProjectController pc = Lookup.getDefault().lookup(ProjectController.class);
        pc.newProject();
        Workspace workspace = pc.getCurrentWorkspace();

        AttributeModel attributeModel = Lookup.getDefault().lookup(AttributeController.class).getModel();
        GraphModel graphModel = Lookup.getDefault().lookup(GraphController.class).getModel();
        ImportController importController = Lookup.getDefault().lookup(ImportController.class);
        //Import file
        Container container;
        try {
            //File file = new File(getClass().getResource("/org/gephi/toolkit/demos/resources/polblogs.gml").toURI());

            File file = new File("C:\\Casper\\karate.gml");
            container = importController.importFile(file);
            container.getLoader().setEdgeDefault(EdgeDefault.UNDIRECTED);   //Force DIRECTED
        } catch (Exception ex) {
            ex.printStackTrace();
            return;
        }
        importController.process(container, new DefaultProcessor(), workspace);

        DirectedGraph graph = graphModel.getDirectedGraph();
        System.out.println("Nodes: " + graph.getNodeCount());
        System.out.println("Edges: " + graph.getEdgeCount());
        UndirectedGraph graphVisible = graphModel.getUndirectedGraphVisible();
        PageRank pr = new PageRank();
        pr.setEpsilon(0.001);
        pr.setDirected(false);
        pr.setUseEdgeWeight(true);
        pr.execute(graphModel,attributeModel);

        Node[] nodes = graphVisible.getNodes().toArray();
        for(Node n : nodes){
            System.out.println(n.getNodeData().getAttributes().getValue("pagerank"));
        }
    }
*/
}
