import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class BaselineLogProb {
    public static void main(String[] args) throws FileNotFoundException {
        new BaselineLogProb();
    }

    public BaselineLogProb() throws FileNotFoundException {
        doCreate();
    }

    public void doCreate() throws FileNotFoundException {
        String files   = "C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2014\\data\\retrievalexp\\text\\";
        File dir       = new File(files);
        File[] content = dir.listFiles();
        int N          = content.length;
        double uprob   = Math.log(1.0/(double)N);
        PrintWriter pw = new PrintWriter("C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2014\\data\\retrievalexp\\baselinelogprob.txt");
        for(File f : content){
            pw.println("/data/local/workspace/casper_petersen/sigir2014/retrievalexp/text/"+f.getName() + " " + uprob);
        }
        pw.close();
    }
}
