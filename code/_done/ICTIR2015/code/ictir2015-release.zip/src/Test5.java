import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.regex.Pattern;

public class Test5 {
    public static void main(String[] args) throws IOException {
            new Test5();
    }

    public Test5() throws IOException {
        doFilter();
    }

    public void doFilter() throws IOException {
        String qrelpath = "C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2014\\data\\retrievalexp\\qrels\\50webtrack.qrels";
        String newqrels = "C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2014\\data\\retrievalexp\\qrels\\50webtrack-fixed.qrels";
        String datapath = "C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2014\\data\\retrievalexp\\text\\";

        HashSet<String> docnames = new HashSet<String>();
        File dir       = new File(datapath);
        File[] content = dir.listFiles();
        for(File f : content){
            Path p      = Paths.get(f.getAbsoluteFile().toString());
            String name = p.getFileName().toString();
            docnames.add(name.substring(0,name.lastIndexOf(".")));
        }

        FileReader fr = new FileReader(qrelpath);
        BufferedReader br = new BufferedReader(fr);
        FileWriter fw = new FileWriter(newqrels);
        BufferedWriter bw = new BufferedWriter(fw);

        String sCurrentLine;
        while((sCurrentLine = br.readLine()) != null){
               String[] ss = sCurrentLine.split(" ");
               String name = ss[2];
               if(!docnames.contains(name)){
                   int val = Integer.valueOf(ss[3]);
                   if(val <= 0){
                       bw.write(sCurrentLine+"\n");
                       bw.flush();
                   }
               }else{
                   bw.write(sCurrentLine+"\n");
                   bw.flush();
               }
        }
        bw.flush();
        fw.close();
        bw.close();
        fr.close();
        br.close();
    }

}
