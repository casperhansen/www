import java.util.Comparator;

public class Node implements Comparable<Node>{
    private String LABEL;
    private int IDENTIFIER;
    private String GENERAL_GRAMMATICAL_ROLE;
    private String ACTUAL_GRAMMATICAL_ROLE;
    private int POS_IN_SENTENCE;
    private int POS_IN_DOC;
    private String WORD;

    // ID is WILDELY misleading. It is actually the id of the parent node in the bipartite graph
    public Node(String label, int id, String genrole, String actualrole, int sentencepos, int docpos, String word) {
        this.LABEL                    = label;
        this.IDENTIFIER               = id;
        this.GENERAL_GRAMMATICAL_ROLE = genrole;
        this.ACTUAL_GRAMMATICAL_ROLE  = actualrole;
        this.POS_IN_SENTENCE          = sentencepos;
        this.POS_IN_DOC               = docpos;
        this.WORD                     = word;
    }

    public String toString() {
        return LABEL;
    }

    public int getID(){
        return IDENTIFIER;
    }

    public String getLabel(){
        return LABEL;
    }

    public String getGeneralGrammaticalRole(){
        return GENERAL_GRAMMATICAL_ROLE;
    }

    public String getActualGrammaticalRole(){
        return ACTUAL_GRAMMATICAL_ROLE;
    }

    public int getPositionInSentence(){
        return POS_IN_SENTENCE;
    }

    public int getPositionInDocument(){
        return POS_IN_DOC;
    }

    public boolean isSuccessor(Entity e){
        return (this.IDENTIFIER - e.getID()) == 1;
    }

    public boolean hasDifferentParent(Entity e){
        return (this.IDENTIFIER != e.getID());
    }

    public String getWord(){
        return WORD;
    }

    @Override
    public int compareTo(Node o) {
        return (this.getPositionInDocument() >= o.getPositionInDocument()) ? 1 : 0;
    }
}