import java.io.*;
import java.util.HashSet;

/**
 * This class creates a single metric score file from several fragments caused by incorrect shutdown or idle hanging threads.
 */
public class AssembleMetricScores {
    HashSet<String> docs = new HashSet<String>();
    public static void main(String[] args) throws IOException {
        new AssembleMetricScores(args[0], args[1]);
        /*
         * args[0] is the directory that contains the fragmented metric.score files e.g. /home/cazz/dir/
         * args[2] is the file that will assemble all the fragments e.g. /hom/cazz/dir/complete-metric.score
         */
    }

    public AssembleMetricScores(String indir, String outfile) throws IOException {
         doParse(indir, outfile);
    }

    public void doParse(String indir, String outfile) throws IOException {
         File dir = new File(indir);
         File[] content = dir.listFiles(new FilenameFilter() {
             public boolean accept(File dir, String name) {
                 return name.toLowerCase().endsWith(".score");
             }
         });
         int N = content.length;
         System.out.println("Found " + N + " fragmented metric.score files");
         PrintWriter pw = new PrintWriter(outfile);
         boolean isFirst = true;
         int counter = 0;
         for(File f : content){
             System.out.println("Processing " + f.getName());
             FileReader fr = new FileReader(indir+f.getName());
             BufferedReader br = new BufferedReader(fr);
             String sCurrentLine = br.readLine(); // Will be #,16
             if(isFirst){
                 pw.println(sCurrentLine); pw.flush();
                 isFirst = false;
             }
             while((sCurrentLine = br.readLine()) != null){
                 String[] s = sCurrentLine.split(",");
                 if(!docs.contains(s[0])){ // s[0] is the name
                     docs.add(s[0]);
                     pw.println(sCurrentLine); pw.flush();
                     counter++;
                 }
             }
             fr.close();
             br.close();
             System.out.println("Completed processing of " + f.getName() + " total: " + counter + " files");
         }
         pw.close();
    }
}
