import java.util.Vector;
import java.util.concurrent.Callable;

public class CallMe implements Runnable{
    private String fileName;
    private Vector<String> content;
    public CallMe(String filename){
        fileName = filename;
    }

    public void readFile2(){
        long tstart = System.currentTimeMillis();
        ValidateInputFile v = new ValidateInputFile();
        boolean isOK = v.validate(fileName);
        if(isOK){
            content = v.getContent();
        }else{
            System.err.println("Could not parse " + fileName);
            System.exit(-1);
        }
        long tend = System.currentTimeMillis();
    }

    @Override
    public void run() {
        readFile2();
    }
}




    /*
    public double pathlengths(Collection<Entity> vertices){
        Transformer<Entity, Double> vertexPathLengths = DistanceStatistics.averageDistances(GRAPH);
        double globalAvgPathLength = 0.0;
        double connAvgPathLength   = 0.0;
        int connectedVertices      = 0;
        for(Entity e : vertices){
            if(!Double.isNaN(vertexPathLengths.transform(e))){
                connAvgPathLength += vertexPathLengths.transform(e);
                connectedVertices += 1;
            }
            globalAvgPathLength += vertexPathLengths.transform(e);
        }
        //Make dependent on whether the full graph is wanted or just the largest CC
        return globalAvgPathLength/vertices.size();
    }

    public void HITS(Collection<Entity> vertices){
        Transformer<Link, Double> HITStransformer = new Transformer<Link, Double>() {
            public Double transform(Link link){
                return (double)link.getWeight();
            }
        };
        HITS<Entity, Link> HITSranker = new HITS<Entity,Link>(GRAPH, HITStransformer, 0.25);
        HITSranker.acceptDisconnectedGraph(true);
        HITSranker.evaluate();
        //System.out.println("Printing HITS scores");
        for(Entity e : vertices){
            HITS.Scores s = HITSranker.getVertexScore(e);
            double authority = s.authority;
            double hubs      = s.hub;
            //System.out.println(e.getLabel() + " : " + authority + " : " + hubs);
        }
    }

    public double density(){
        int num_edges    = GRAPH.getEdgeCount();
        int num_vertices = GRAPH.getVertexCount();
//        System.out.println("num_edges: " + num_edges + " : num_vertices: " + num_vertices);
        if(num_vertices > 1){
            return ((2*(double)num_edges)/((double)num_vertices*((double)num_vertices - 1)));
        }
        return 0.0;
    }

    public double closeness(){
        DistanceCentralityScorer<Entity, Link> dcs = new DistanceCentralityScorer<Entity, Link>(GRAPH,true);
        double centrality = 0.0;
        double connCentrality = 0.0;
        double connCentralityVtx = 0.0;
        for(Entity e : vertices){
            if(!Double.isNaN(dcs.getVertexScore(e))){
                connCentrality += dcs.getVertexScore(e);
                connCentralityVtx++;
            }
            centrality += dcs.getVertexScore(e);
        }
        return centrality/vertices.size();
    }

    /*
     * Pagerank can ONLY operate with normalized values.
     */
/*
    public double pagerank(Collection<Entity> vertices){
        Transformer<Link, Double> prTransformer = new Transformer<Link, Double>() {
            public Double transform(Link link){
                return (link.getWeight()/TOTAL_DOCUMENTS);
            }
        };
        PageRank<Entity, Link> prRanker = new PageRank<Entity, Link>(GRAPH, 0.15);
        prRanker.setEdgeWeights(prTransformer);
        prRanker.setTolerance(0.001);
        prRanker.setMaxIterations(3000);
        prRanker.acceptDisconnectedGraph(true);
        prRanker.evaluate();
        double prScore = 0.0;
        for(Entity i : vertices){
            //System.out.println(prRanker.getVertexScore(i));
            prScore += prRanker.getVertexScore(i);
        }
        return prScore/vertices.size();
    }
*/