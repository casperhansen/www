import java.io.*;

public class MillionQuery2Trec{

    public static void main(String[] args) throws IOException {
        if(args.length != 3){
            System.out.println("Three arguments required. "+
                    "- First is the million query topic file."+
                    "- Second is the name of the TREC file resulting from processing the million query file" +
                    "- Third is the location of the index"+
                    " Default: top 500 results are returned using standard LM values and dirichlet smoothing");
            System.exit(-1);
        }
        new MillionQuery2Trec(args);
    }

    public MillionQuery2Trec(String[] args) throws IOException {
        doParse(args[0], args[1], args[2]);
    }

    public void doParse(String prelsfile, String qrelspath, String index) throws IOException {
        FileReader fr     = new FileReader(prelsfile);
        BufferedReader br = new BufferedReader(fr);
        FileWriter fw     = new FileWriter(qrelspath);
        BufferedWriter bw = new BufferedWriter(fw);
        String sCurrentLine;
        bw.write("<parameters>"+"\n");
        bw.write("<index>" + index + "</index>" + "\n");
        bw.write("<runID>200916102013</runID>\n");
        bw.write("<trecFormat>true</trecFormat>\n");
        bw.write("<count>500</count>\n");
        bw.write("<rule>method:dirichlet</rule>\n");
        while((sCurrentLine = br.readLine()) != null){
            String[] ssplit = sCurrentLine.split(":");
            String toWrite  = "<query> <number>"+ssplit[0]+"</number> <text> #combine(#prior(topicalflow01large)"+ssplit[2]+")</text> </query>\n";
            bw.write(toWrite);
            bw.flush();
        }
        bw.write("</parameters>");
        bw.flush();
        fr.close();
        br.close();
        fw.close();
        bw.close();
    }

}