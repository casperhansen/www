import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Set;

import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.ling.HasWord;
import edu.stanford.nlp.process.CoreLabelTokenFactory;
import edu.stanford.nlp.process.DocumentPreprocessor;
import edu.stanford.nlp.process.PTBTokenizer;

public class DocToSentences {
    Statics stats = new Statics();
    Set<String> chars = stats.getCharDelim();

    public DocToSentences(){}

    public String[] textToSenteces(String arg){
        DocumentPreprocessor dp = new DocumentPreprocessor(arg);
        String[] res = new String[5];
        for (List<HasWord> sentence : dp) {
            reconstructSentences(sentence);
        }
        return res;
    }

    public void reconstructSentences(List<HasWord> sentence){
        String str = "";
        for(HasWord s : sentence){
            if(chars.contains(s.word())){
                str = str+s.word();
            }else{
                str = str+" "+s.word();
            }
        }
        System.out.println(str.trim());
    }
}