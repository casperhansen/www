import edu.stanford.nlp.io.IOUtils;
import edu.stanford.nlp.ling.CoreAnnotations;
import edu.stanford.nlp.ling.HasWord;
import edu.stanford.nlp.pipeline.Annotation;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import edu.stanford.nlp.process.DocumentPreprocessor;
import edu.stanford.nlp.trees.*;
import edu.stanford.nlp.util.CoreMap;

import java.util.*;

public class ProcessDocument {
    private StanfordCoreNLP PIPELINE;
    private Statics stats = new Statics();
    private Set<String> chars = stats.getCharDelim();
    private HashSet<String> nlconstructs = new HashSet<String>();
    private final String DOBJ = "dobj";
    private final String IOBJ = "iobj";
    private final String NSUBJ = "nsubj";
    private final String NSUBJPASS = "nsubjpass";
    private final String XSUBJ = "xsubj";
    private final String POBJ = "pobj";
    public static void main(String[] args){
        Properties props = new Properties();
        props.put("annotators", "tokenize, ssplit, pos, lemma, ner, parse");
        StanfordCoreNLP pipeline = new StanfordCoreNLP(props);
        new ProcessDocument(pipeline);
    }

    public ProcessDocument(StanfordCoreNLP pipeline){
        PIPELINE = pipeline;
        nlconstructs.add(DOBJ);
        nlconstructs.add(IOBJ);
        nlconstructs.add(NSUBJ);
        nlconstructs.add(NSUBJPASS);
        nlconstructs.add(XSUBJ);
        nlconstructs.add(POBJ);
        doProcess("C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2014\\data\\article-docs\\doc8.txt");
    }

    public void doProcess(String text){
        Vector<String> docsentences = DocToSentences(text);
        int sentencecounter = 0;
        int wordcounter = 0;
        int wordinsentencecounter;
        for(String docsentence : docsentences){
            System.out.println(docsentence);
            sentencecounter++;
            Annotation annotation;
            annotation = new Annotation(docsentence);
            PIPELINE.annotate(annotation);

            List<CoreMap> sentences = annotation.get(CoreAnnotations.SentencesAnnotation.class);
            if (sentences != null && sentences.size() > 0) {
                CoreMap sentence                = sentences.get(0);
                Tree tree                       = sentence.get(TreeCoreAnnotations.TreeAnnotation.class);
                TreebankLanguagePack tlp        = new PennTreebankLanguagePack();
                GrammaticalStructureFactory gsf = tlp.grammaticalStructureFactory();
                GrammaticalStructure gs         = gsf.newGrammaticalStructure(tree);
                Collection<TypedDependency> td  = gs.typedDependenciesCollapsed();

                Object[] list = td.toArray();
                wordinsentencecounter = 0;
                for (Object object : list) {
                    TypedDependency typedDependency = (TypedDependency) object;
                    System.out.println("Depdency Name: "+typedDependency.dep().nodeString()+ " :: "+ "Node: "+typedDependency.reln());
                    /*
                    typedDependency = (TypedDependency) object;
                    String tDep = typedDependency.reln().toString();
                    wordcounter++;
                    wordinsentencecounter++;

                    if(nlconstructs.contains(tDep)){
                        String grole = "";
                        if(tDep.equalsIgnoreCase(DOBJ)){
                           grole = "o";
                        }
                        if(tDep.equalsIgnoreCase(IOBJ)){
                            grole = "o";
                        }
                        if(tDep.equalsIgnoreCase(NSUBJ)){
                            grole = "s";
                        }
                        if(tDep.equalsIgnoreCase(NSUBJPASS)){
                            grole = "s";
                        }
                        if(tDep.equalsIgnoreCase(XSUBJ)){
                            grole = "s";
                        }
                        if(tDep.equalsIgnoreCase(POBJ)){
                            grole = "o";
                        }
                        SentenceAnnotation sa = new SentenceAnnotation("a",sentencecounter,typedDependency.dep().nodeString(),grole,typedDependency.reln().toString(), wordinsentencecounter, wordcounter, 0.25);
                        System.out.println(sa.toString());
                        //System.out.println("("+sentencecounter+"/"+(wordcounter) + "/" + wordinsentencecounter +") " + "Depdency Name: " + typedDependency.dep().nodeString() + " :: " + "Node: " + typedDependency.reln());
                    }
                                            */
                }
            }else{

            }
          System.out.println("\n");
        }
    }

    private Vector<String> DocToSentences(String doc){
       Vector<String> sentences = new Vector<String>();
       DocumentPreprocessor dp = new DocumentPreprocessor(doc);
       for (List<HasWord> sentence : dp) {
            sentences.add(reconstructSentences(sentence));
       }
       return sentences;
    }

    public String reconstructSentences(List<HasWord> sentence){
        String str = "";
        for(HasWord s : sentence){
            if(chars.contains(s.word())){
                str = str+s.word();
            }else{
                str = str+" "+s.word();
            }
        }
        return str.trim();
    }
}
