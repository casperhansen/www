import edu.stanford.nlp.ling.HasWord;
import edu.stanford.nlp.parser.lexparser.LexicalizedParser;
import edu.stanford.nlp.process.DocumentPreprocessor;
import edu.stanford.nlp.trees.*;

import java.io.*;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Vector;

public class ParseDocuments {
    private String PATH_OF_DOCS;
    private String WRITE_PATH;
    private LexicalizedParser LP;
    private GrammaticalStructureFactory GSF;
    private HashSet<GrammaticalRelation> ACCEPTED_GRAMMATICAL_ROLES = new HashSet<GrammaticalRelation>();

    public static void main(String[] args) throws IOException {
        if(args.length > 2 | args.length < 2){
           System.err.println("Wrong number (" + args.length + ") of arguments.");
           System.exit(-1);
        }
        File f = new File(args[0]);
        if(!f.exists()){
           System.err.println(args[0] + " does not exist");
           System.exit(-1);
        }
        if(!f.isDirectory()){
            System.err.println(args[0] + " is not a directory");
            System.exit(-1);
        }

        File theDir = new File(args[1]);

        // if the directory does not exist, create it
        if (!theDir.exists()) {
            System.out.println("Creating directory: " + args[1]);
            boolean result = theDir.mkdir();
            if(result) {
                System.out.println(args[1] + " created successfully");
            }
        }else{
            System.err.println("Directory " + args[1] + " exists. Aborting...");
            System.exit(-1);
        }

        new ParseDocuments(args);
    }

    public ParseDocuments(String[] input) throws IOException {
        PATH_OF_DOCS = input[0];
        WRITE_PATH   = input[1];
        if(!PATH_OF_DOCS.endsWith("/")){
            PATH_OF_DOCS = PATH_OF_DOCS + "/";
        }
        // Set-up necessary components
        LP = LexicalizedParser.loadModel("edu/stanford/nlp/models/lexparser/englishPCFG.ser.gz");
        TreebankLanguagePack TLP = new PennTreebankLanguagePack();
        GSF = TLP.grammaticalStructureFactory();
        ACCEPTED_GRAMMATICAL_ROLES.add(EnglishGrammaticalRelations.DIRECT_OBJECT);
        ACCEPTED_GRAMMATICAL_ROLES.add(EnglishGrammaticalRelations.INDIRECT_OBJECT);
        ACCEPTED_GRAMMATICAL_ROLES.add(EnglishGrammaticalRelations.PREPOSITIONAL_OBJECT);
        ACCEPTED_GRAMMATICAL_ROLES.add(EnglishGrammaticalRelations.NOMINAL_SUBJECT);
        ACCEPTED_GRAMMATICAL_ROLES.add(EnglishGrammaticalRelations.NOMINAL_PASSIVE_SUBJECT);
        ACCEPTED_GRAMMATICAL_ROLES.add(EnglishGrammaticalRelations.CONTROLLING_SUBJECT);
        processDirectory();
    }

    public void processDirectory() throws IOException {
        File folder = new File(PATH_OF_DOCS);
        File[] listOfFiles = folder.listFiles();
        assert listOfFiles != null;

        // Iterate over all files in the directory
        int docCounter = 0;
        for (File listOfFile : listOfFiles) {
            String filePath;
            String fileName = listOfFile.getName();
                filePath = listOfFile.getAbsoluteFile().toString();
                // Only the spam-free files are interesting
                if (filePath.endsWith(".text")) {
                    docCounter++;
                    int sentenceCounter = 0;
                    int posInDocCounter = 0;
                    Vector<SentenceAnnotation> annotations = new Vector<SentenceAnnotation>();
                    for (List<HasWord> sentence : new DocumentPreprocessor(filePath)) {
                        int posInSentenceCounter = 0;
                        sentenceCounter++;
                        Tree parse = LP.apply(sentence);
                        GrammaticalStructure gs = GSF.newGrammaticalStructure(parse);
                        Collection<TypedDependency> tdl = gs.typedDependenciesCCprocessed(true);
                        for (TypedDependency td : tdl) {
                            posInSentenceCounter++;
                            posInDocCounter++;
                            if(ACCEPTED_GRAMMATICAL_ROLES.contains(td.reln())){
                               String generalRole;
                               if(td.reln().equals(EnglishGrammaticalRelations.NOMINAL_SUBJECT) ||
                                  td.reln().equals(EnglishGrammaticalRelations.NOMINAL_PASSIVE_SUBJECT) ||
                                  td.reln().equals(EnglishGrammaticalRelations.CONTROLLING_SUBJECT)){
                                        generalRole = "s";
                               }else{
                                   generalRole = "o";
                               }
                                SentenceAnnotation sa = new SentenceAnnotation(
                                        sentenceCounter,td.dep().nodeString(),generalRole,td.reln().toString(),
                                        posInSentenceCounter, posInDocCounter, docCounter, 1);
                                annotations.add(sa);
                            }
                        }
                    }
                    // Write annotations to file
                    String writeFile    = fileName.substring(0,fileName.lastIndexOf('.'));
                    String sentFileName = WRITE_PATH + writeFile + ".sentences";
                    File file           = new File(sentFileName);
                    FileWriter fw       = new FileWriter(file);
                    BufferedWriter bw   = new BufferedWriter(fw);
                    for(SentenceAnnotation s : annotations){
                        bw.write(s.toString());
                        bw.flush();
                        bw.newLine();
                    }
                    bw.close();
                    fw.close();
                }
            }
    }
}
