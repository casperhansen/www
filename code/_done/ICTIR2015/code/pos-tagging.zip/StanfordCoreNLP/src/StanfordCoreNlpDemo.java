import java.io.*;
import java.util.*;

import edu.stanford.nlp.io.*;
import edu.stanford.nlp.ling.*;
import edu.stanford.nlp.pipeline.*;
import edu.stanford.nlp.trees.*;
import edu.stanford.nlp.util.*;

public class StanfordCoreNlpDemo {

    public static void main(String[] args) throws IOException {
/*
        PrintWriter out;
        if (args.length > 1) {
            out = new PrintWriter(args[1]);
        } else {
            out = new PrintWriter(System.out);
        }
        PrintWriter xmlOut = null;
        if (args.length > 2) {
            xmlOut = new PrintWriter(args[2]);
        }
*/
        Properties props = new Properties();
        props.put("annotators", "tokenize, ssplit, pos, lemma, ner, parse");
        StanfordCoreNLP pipeline = new StanfordCoreNLP(props);


        String[] files = {"C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2014\\data\\article-docs\\doc8.txt"};
/*
                ,
                          "C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2014\\data\\article-docs\\doc2.txt",
                          "C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2014\\data\\article-docs\\doc3.txt"};
*/

        //PrintWriter out = new PrintWriter(System.out);
        for (String file : files) {
            Annotation annotation;
            annotation = new Annotation(IOUtils.slurpFileNoExceptions(file));
            pipeline.annotate(annotation);

            List<CoreMap> sentences = annotation.get(CoreAnnotations.SentencesAnnotation.class);
            if (sentences != null && sentences.size() > 0) {
                CoreMap sentence = sentences.get(0);
                Tree tree = sentence.get(TreeCoreAnnotations.TreeAnnotation.class);
                // Get dependency tree
                TreebankLanguagePack tlp = new PennTreebankLanguagePack();
                GrammaticalStructureFactory gsf = tlp.grammaticalStructureFactory();
                GrammaticalStructure gs = gsf.newGrammaticalStructure(tree);
                Collection<TypedDependency> td = gs.typedDependencies();
                //System.out.println(td);

                Object[] list = td.toArray();
                //System.out.println(list.length);
                TypedDependency typedDependency;
                for (Object object : list) {
                    typedDependency = (TypedDependency) object;
                    System.out.println("Depdency Name: " + typedDependency.dep().nodeString() + " :: " + "Node: " + typedDependency.reln());
                }

            }
        }
        //out.close();
    }
}
