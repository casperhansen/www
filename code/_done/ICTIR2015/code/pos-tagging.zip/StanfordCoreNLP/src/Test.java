import edu.stanford.nlp.io.IOUtils;
import edu.stanford.nlp.ling.CoreAnnotations;
import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.ling.HasWord;
import edu.stanford.nlp.ling.IndexedWord;
import edu.stanford.nlp.pipeline.Annotation;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import edu.stanford.nlp.process.DocumentPreprocessor;
import edu.stanford.nlp.semgraph.SemanticGraph;
import edu.stanford.nlp.semgraph.SemanticGraphCoreAnnotations;
import edu.stanford.nlp.trees.*;
import edu.stanford.nlp.util.CoreMap;

import java.util.*;

public class Test {
    public static void main(String[] args){
        Properties props = new Properties();
        props.put("annotators", "tokenize, ssplit, pos, lemma, ner, parse");
        StanfordCoreNLP pipeline = new StanfordCoreNLP(props);
        String text ="The ordering of the dependency is such that the head is listed first (in the example, the head is throw), and the dependent is listed second. These dependency relations come in two forms: a fixed number of predefined relations, and a much larger number (hundreds) of prepositional relations.";
        Annotation annotation = new Annotation(text);
        pipeline.annotate(annotation);

        List<CoreMap> sentences = annotation.get(CoreAnnotations.SentencesAnnotation.class);
        CoreMap t = sentences.get(1);
        Tree tt = t.get(TreeCoreAnnotations.TreeAnnotation.class);
        TreebankLanguagePack tlp = new PennTreebankLanguagePack();
        GrammaticalStructureFactory gsf = tlp.grammaticalStructureFactory();
        GrammaticalStructure gs = gsf.newGrammaticalStructure(tt);
        Collection<TypedDependency> tdl = gs.typedDependenciesCCprocessed(true);
        for (TypedDependency td : tdl) {
            if (td.reln().equals(EnglishGrammaticalRelations.NOMINAL_SUBJECT)) {
                System.out.println("Nominal Subj relation: " + td);
            }
        }


    }
}
