import java.util.HashSet;
import java.util.Set;

public class Statics {
    Set<String> implodeChars = new HashSet<String>();

    public Statics(){
        implodeChars.add(",");
        implodeChars.add(".");
        implodeChars.add("'s");
    }

    public Set<String> getCharDelim(){
        return implodeChars;

    }
}
