
public class SentenceAnnotation {

    private String _documentname;
    private int _current_sentence;
    private String _term;
    private String _subobjrole;
    private String _actualrole;
    private int _termlocinsentence;
    private int _termlocindoc;
    private int _docno;
    private int _termidf;

    public SentenceAnnotation(int current_sentence, String term, String subobjrole,
                              String actualrole,  int termlocinsentence, int termlocindoc, int docno, int termidf){
        this._current_sentence = current_sentence;
        this._term = term;
        this._subobjrole = subobjrole;
        this._actualrole = actualrole;
        this._termlocinsentence = termlocinsentence;
        this._termlocindoc = termlocindoc;
        this._termidf = termidf;
        this._docno = docno;

    }


    public String toString(){
        String csent       = Integer.toString(_current_sentence);
        String termlocsent = Integer.toString(_termlocinsentence);
        String termlocdoc  = Integer.toString(_termlocindoc);
        String docno       = Integer.toString(_docno);
        String tidf        = Integer.toString(_termidf);

        return (csent + "," + _term + "," + _subobjrole + "," + _actualrole + "," +
                termlocsent   + "," + termlocdoc + "," + "," + docno + "," + tidf);
    }

}
