import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.AffineTransform;
import java.io.IOException;
import java.util.Iterator;
import java.util.Vector;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;

public class GlassGamePane extends JPanel implements MouseListener, ActionListener {
    private JPopupMenu snippet;
    private Vector<Vertex> v;
    private final int docInfoViewWidth = 220;
    private final int docInfoViewHeight = 170;
    private Font f = new Font("Verdana", Font.PLAIN, 10);
    private Font fat = new Font("Verdana", Font.BOLD, 10);
    private Border b = BorderFactory.createMatteBorder(0, 0, 1, 0, Color.darkGray);
    private Border empty = new EmptyBorder(0, 0, 5, 0);
    private CompoundBorder border = new CompoundBorder(b, empty);

    public GlassGamePane(Vector<Vertex> vertices) {
        this.v = vertices;
        createGlassPane();
    }

    private void createGlassPane() {
        //setLayout(new BorderLayout());
        setLayout(null);
        //add(new DocumentNode(250,250));
        createComponents();


        Iterator it = v.iterator();
        while(it.hasNext()){
            Vertex v = (Vertex)it.next();
            JButton jb2 = new JButton();
            ImageIcon icon = createImageIcon("blue-icon.jpg", "");
            jb2.setIcon(icon);
            jb2.setBorderPainted(false);
            jb2.setContentAreaFilled(false);
            jb2.setFocusPainted(false);
            jb2.setOpaque(false);
            add(jb2);
            jb2.setSize(icon.getIconWidth(),icon.getIconHeight());
            jb2.setLocation((int)v.getNodex(), (int)v.getNodey());
            //System.out.println(v.getNodex() + ", " + v.getNodey() + ", (int x) " + (int)v.getNodex() + ", (int y) " + (int)v.getNodey());
            Border emptyBorder = BorderFactory.createEmptyBorder();
            jb2.setBorder(emptyBorder);
            jb2.addMouseListener(this);
            jb2.addActionListener(this);
            jb2.setActionCommand("HEJ");
        }
    }

    private void createComponents() {
        //setLayout(new BorderLayout());
    }

    @Override
    public void mouseClicked(MouseEvent me) {
        System.out.println(me.getX() + ", " + me.getY());
    }

    @Override
    public void mousePressed(MouseEvent me) {
        //Toolkit.getDefaultToolkit().beep();
    }

    @Override
    public void mouseReleased(MouseEvent me) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        System.out.println(e.getX() + ", " + e.getY());
        snippet = new JPopupMenu();
        snippet.setOpaque(false);
        snippet.setPreferredSize(new Dimension(docInfoViewWidth,docInfoViewHeight));
        JPanel docInfo = new JPanel();
        docInfo.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        JLabel docInfoText = new JLabel("<html>Official Splinter Cell Blacklist website. Unleash the power of the most lethal agent to ever exist. You are Sam Fisher, and you've been given the ultimate freedom</html>");
        docInfoText.setFont(f);
        docInfoText.setPreferredSize(new Dimension(100, docInfoViewHeight));
        docInfoText.setBorder(border);

        c.weightx = 1.0;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(0,10,5,10);
        c.gridx = 0;
        c.gridy = 0;
        docInfo.add(docInfoText,c);

        JLabel itemAbove = new JLabel("Rank: 4, Document: 98");
        itemAbove.setFont(f);
        JLabel itemCurrent = new JLabel("Rank 19, Document: 2");
        itemCurrent.setFont(fat);
        JLabel itemBelow = new JLabel("Rank 8, Document 41");
        itemBelow.setFont(f);
        itemBelow.setBorder(border);

        c.weightx = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(0,10,0,10);
        c.gridx = 0;
        c.gridy = 1;
        docInfo.add(itemAbove,c);
        c.insets = new Insets(2,10,0,10);
        c.gridx = 0;
        c.gridy = 2;
        docInfo.add(itemCurrent,c);
        c.gridx = 0;
        c.gridy = 3;
        docInfo.add(itemBelow,c);

        JButton accept = new JButton("Relevant");
        accept.setFont(f);
        accept.setActionCommand("Relevance");
        accept.setPreferredSize(new Dimension(30,docInfoViewHeight/4));
        c.weightx = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        //         t,l,b,h
        c.insets = new Insets(5,20,0,20);
        c.gridx = 0;
        c.gridy = 4;
        docInfo.add(accept, c);

        snippet.add(docInfo);
        snippet.setOpaque(false);
        snippet.show(this, e.getX(),e.getY());
    }

    @Override
    public void mouseExited(MouseEvent me) {
    }

    public ImageIcon createImageIcon(String path,
                                        String description) {
        java.net.URL imgURL = this.getClass().getResource(path);
        if (imgURL != null) {
            return new ImageIcon(imgURL, description);
        } else {
            System.err.println("Couldn't find file: " + path);
            return null;
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }
}