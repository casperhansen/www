import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Point2D;
import java.io.*;
import java.util.*;
import javax.swing.*;
import java.awt.Robot;
import edu.uci.ics.jung.algorithms.layout.GraphElementAccessor;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.visualization.control.CrossoverScalingControl;
import edu.uci.ics.jung.visualization.control.ScalingControl;
import edu.uci.ics.jung.visualization.picking.PickedState;
import edu.uci.ics.jung.algorithms.layout.FRLayout;
import edu.uci.ics.jung.visualization.VisualizationViewer;


public class GraphView extends JPanel implements MouseListener, ActionListener, ItemListener {
    /*
     * Variables w. initialization
     */
    //private BuildGraph bg                       = new BuildGraph();
    private VisualizationStatics vs             = new VisualizationStatics();
    private Dimension viewArea                  = new Dimension(1300, 1000);
    private Map<String, MyNode> relevantNodes   = new HashMap<String, MyNode>();
    private Map<Integer, MyNode> nodesMap       = new HashMap<Integer, MyNode>();
    private Set<MyNode> seedVertices            = new HashSet<MyNode>();
    private Set<MyNode> visitedVertices         = new HashSet<MyNode>();
    private Vector<Integer> nodesVisisted       = new Vector<Integer>();
    private Map<Integer, Long> nodesTimeSpent   = new HashMap<Integer, Long>();
    private Map<String, String> snippetMap      = new HashMap<String, String>();
    private Map<Integer, String> rankMap        = new HashMap<Integer, String>();
    private Map<String, Integer> rankMapRev     = new HashMap<String, Integer>();
    private Set<String> queryTerms              = new HashSet<String>();
    private String[] cluewebfilenames           = new String[20];
    /*
     * Variables for the graph
     */
    private QueryObject queryObject;
    private VisualizationViewer<MyNode,MyEdge> panel;
    private FRLayout<MyNode,MyEdge> layout;
    private MyNode currentNodeSelected;
    private PickedState<MyNode> pickedState;
    private Map<MyNode,Color> nodeColors;
    private Map<Integer, String> NIDCLUEWEB;
    private Map<String, Vector<Integer>> NODEOUTLINKS;
    private BuildGraph BG;
   /*
    * Variables for SWING
    */
    private Long timeStarted;
    private Long timeEnded;
    private DefaultListModel listModel;
    private JList list;
    private JPopupMenu infoPanel;
    private HelpPanel helpPanel;
    private JPanel empty;
    private JPanel buttonContainer;
    private JScrollPane listScrollPane;
    private String COLLECTION;
    private String QUERY;
    private String WEB_PATH;
    private String SNIPPET_PATH;
    private String RANK_PATH;
    private String QUERYNUMBER;
    private Robot robot;

    public GraphView() throws IOException {

        helpPanel = new HelpPanel();
    }

    public void createButtonContainer(){
        buttonContainer = new JPanel();
        JButton relevant = new JButton("Relevant");
        relevant.setActionCommand("Relevant");
        relevant.addActionListener(this);
        JButton notRelevant = new JButton("Not Relevant");
        notRelevant.addActionListener(this);
        notRelevant.setActionCommand("NotRelevant");
        relevant.setPreferredSize(new Dimension(115, 25));
        notRelevant.setPreferredSize(new Dimension(115, 25));
        relevant.setFont(vs.getNormalFont());
        notRelevant.setFont(vs.getNormalFont());
        buttonContainer.add(relevant, BoxLayout.X_AXIS);
        buttonContainer.add(notRelevant, BoxLayout.X_AXIS);
    }

    public void createEmptySpace(){
        empty = new JPanel();
        empty.setPreferredSize(new Dimension(vs.getPopupWidth()/10,vs.getPopupHeight()));
        empty.setOpaque(false);
        empty.setBorder(BorderFactory.createEmptyBorder());
        empty.setBackground(new Color(0,0,0,0));
    }

    public void setRanks() throws IOException {
        listModel = new DefaultListModel();
        //System.out.println(RANK_PATH);
        BufferedReader br = new BufferedReader(new FileReader(RANK_PATH));
        String currentLine;
        int rank = 1;
        while((currentLine = br.readLine()) != null){
            listModel.addElement("Rank: " + rank + ", Documentname: " + currentLine);
            cluewebfilenames[rank-1] = currentLine;
            rankMap.put(rank,currentLine);
            rank++;
        }
        list = new JList(listModel);
        list.setFont(vs.getNormalFont());
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setVisibleRowCount(4);
        list.setCellRenderer(new MyListRenderer());
        list.setEnabled(false);
        listScrollPane = new JScrollPane(list,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        listScrollPane.setMinimumSize(new Dimension(vs.getPopUpSnippetWidth(),vs.getPopupHeight()-30));
    }


    public GraphView(QueryObject qo,Map<String, Vector<Integer>> nodeoutlinks, Map<Integer, String> nidclueweb, BuildGraph bg) throws IOException {
        this.queryObject  = qo;
        this.helpPanel    = new HelpPanel();
        this.COLLECTION   = qo.getCollection();
        this.WEB_PATH     = qo.getWebgraphPath();
        this.SNIPPET_PATH = qo.getSnippetpath();
        this.RANK_PATH    = qo.getRankPath();
        this.QUERY        = qo.getQuery();
        this.QUERYNUMBER  = qo.getQueryNumber();
        String[] qt       = QUERY.split(" ");
        for (String q : qt){
            queryTerms.add(q);
        }
        //, Map<Integer, String> nidclueweb,Map<String, Vector<Integer>> nodeoutlinks
        this.NIDCLUEWEB   = nidclueweb;
        this.NODEOUTLINKS = nodeoutlinks;
        this.BG           = bg;
        try {
            robot = new Robot();
        } catch (AWTException e) {
            e.printStackTrace();
        }
        setRanks();
        //buildGraphLocal();
        createEmptySpace();
        createButtonContainer();
        loadSnippets();
    }

    public void loadSnippets(){
        File folder = new File(SNIPPET_PATH);
        File[] listOfFiles = folder.listFiles();
        assert listOfFiles != null;
        for (File f : listOfFiles) {
            if (f.isFile()) {
                String cluewebfilepath = SNIPPET_PATH+f.getName();
                BufferedReader br = null;
                try {
                    String sCurrentLine;
                    br = new BufferedReader(new FileReader(cluewebfilepath));
                    while((sCurrentLine = br.readLine()) != null) {
                           //Trim extension
                           String cluwebname = (f.getName()).substring(0, (f.getName()).lastIndexOf("."));
                           snippetMap.put(cluwebname, sCurrentLine);
                    }
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                    System.err.println("GraphView:loadSnippets(): Error reading file " + cluewebfilepath);
                }
            }
        }
   }

    public VisualizationViewer<MyNode,MyEdge> getViz(){
        buildGraph();
        ScalingControl scaler = new CrossoverScalingControl();
        Point2D p = new Point2D.Double(0 + panel.getCenter().getX(),panel.getCenter().getY() - 450.0);
        scaler.scale(panel, (float)0.66, p);
        return panel;
    }

    @Override
    public void mouseClicked(MouseEvent e){
        GraphElementAccessor<MyNode,MyEdge> pickSupport = panel.getPickSupport();
        final MyNode station = pickSupport.getVertex(panel.getGraphLayout(), e.getX(), e.getY());
        if(station != null){
            Graph<MyNode, MyEdge> h = panel.getGraphLayout().getGraph();

            //System.out.println("In degree: " + h.inDegree(station) + ", out degree: " + h.outDegree(station));

            nodesVisisted.add(station.getID());
            nodesMap.put(station.getID(), station);
            timeStarted = System.currentTimeMillis();
            Point p     = checkBounds(e.getX(), e.getY());
            showPopupMenu((int)p.getX(),(int)p.getY());

            visitedVertices.add(station);
        }
    }

    public void showPopupMenu(int corX, int corY){
        // Create JPanel
        infoPanel = new JPopupMenu();
        infoPanel.setOpaque(false);
        infoPanel.setBorder(vs.getFullEmptyBorder());
        infoPanel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        infoPanel.setPreferredSize(new Dimension(vs.getPopupWidth(), vs.getPopupHeight()));
        // We have a 3-split pane
        JPanel snippet = new JPanel();
        snippet.setLayout(new GridBagLayout());
        GridBagConstraints cc = new GridBagConstraints();
        JLabel heading = new JLabel("Document snippet:");
        heading.setBorder(vs.getLowerMatteBorder());
        heading.setPreferredSize(new Dimension(vs.getPopUpSnippetWidth(), 20));
        heading.setFont(vs.getBoldFont());
        cc.anchor  = GridBagConstraints.NORTH;
        cc.gridx   = 0;
        cc.gridy   = 0;
        cc.weightx = 1;
        cc.weighty = 1;
        cc.fill    = GridBagConstraints.HORIZONTAL;
        cc.insets  = new Insets(2,2,2,2);
        snippet.add(heading, cc);

        //JLabel textsnippet = new JLabel("<html>\"Macbeth, upon hearing that Macduff has fled to England, determines to kill Macduff's family. He justifies himself by saying that from now on he will follow his first impulse, because if he had followed his first impulse, Macduff would already be dead.\"</html>");
        //System.out.println(currentNodeSelected.getID());
        //System.out.println("Clueweb filename: " + rankMap.get(currentNodeSelected.getID()));
        //System.out.println(snippetMap.get(rankMap.get(currentNodeSelected.getID())));
        /*
         * Begin untested code (waiting for snippets)
         */

         String currentNodeSnippet = snippetMap.get(rankMap.get(currentNodeSelected.getID()));
         //System.out.println(currentNodeSnippet);
         JLabel textsnippet = new JLabel("<html>"+highLightQueryWords(currentNodeSnippet, queryTerms)+"</html>"); // case sensitivity in method
        //JLabel textsnippet = new JLabel("<html>"+currentNodeSnippet+"</html>"); // case sensitivity in method

        textsnippet.setFont(vs.getItalicFont());
        textsnippet.setHorizontalAlignment(SwingConstants.LEFT);
        snippet.setPreferredSize(new Dimension(vs.getPopUpSnippetWidth(), vs.getPopupHeight()));
        snippet.setBorder(vs.getFullMatteBorder());
        snippet.setOpaque(true);

        cc.gridx = 0;
        cc.gridy = 1;
        cc.weightx = 1.0;
        cc.weighty = 1.0;
        cc.fill = GridBagConstraints.HORIZONTAL;
        cc.insets = new Insets(5,5,5,5);
        snippet.add(textsnippet,cc);

        //buttonContainer.add(fill)
        cc.gridx = 0;
        cc.gridy = 2;
        cc.weighty = 1;
        cc.anchor = GridBagConstraints.PAGE_END;
        //buttonContainer.add(fill);
        snippet.add(buttonContainer,cc);

        c.weightx = 1;
        c.weighty = 1;
        c.gridx = 0;
        c.gridy = 0;
        infoPanel.add(snippet, c);

        c.gridx = 1;
        c.weightx = 1;
        infoPanel.add(empty,c);

        JPanel listRank = new JPanel();
        listRank.setLayout(new GridBagLayout());
        GridBagConstraints lc = new GridBagConstraints();
        listRank.setPreferredSize(new Dimension(vs.getPopUpSnippetWidth(),vs.getPopupHeight()));
        JLabel rankheading = new JLabel("Ranking:");
        rankheading.setBorder(vs.getLowerMatteBorder());
        rankheading.setPreferredSize(new Dimension(vs.getPopUpSnippetWidth(), 20));
        rankheading.setFont(vs.getBoldFont());

        lc.anchor = GridBagConstraints.NORTH;
        lc.gridx = 0;
        lc.gridy = 0;
        lc.weightx = 1;
        lc.weighty = 1;
        lc.fill = GridBagConstraints.HORIZONTAL;
        lc.insets = new Insets(5,5,5,5);
        listRank.add(rankheading,lc);

        list.setSelectedIndex(currentNodeSelected.getID()-1);
        lc.insets = new Insets(5,5,5,5);
        lc.gridx = 0;
        lc.gridy = 1;
        lc.weighty = 1;
        lc.anchor = GridBagConstraints.PAGE_START;
        lc.fill = GridBagConstraints.VERTICAL;
        listRank.add(listScrollPane,lc);
        listRank.setOpaque(true);
        listRank.setBorder(vs.getFullMatteBorder());

        infoPanel.add(listRank, c);
        infoPanel.show(panel,corX-(vs.getPopupWidth()/2), corY);
        infoPanel.revalidate();
        infoPanel.repaint();
        infoPanel.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String action = e.getActionCommand();

        if(action.equalsIgnoreCase("Relevant")){
            timeEnded = System.currentTimeMillis();
            updateTimeSpent();
            pickedState.pick(currentNodeSelected, true);
            relevantNodes.put(currentNodeSelected.getLabel(), currentNodeSelected);
            seedVertices.add(currentNodeSelected);
            infoPanel.setVisible(false);
            System.gc();
        }
        if(action.equalsIgnoreCase("NotRelevant")){
            timeEnded = System.currentTimeMillis();
            updateTimeSpent();
            if(relevantNodes.containsKey(currentNodeSelected.getLabel())){
                relevantNodes.remove(currentNodeSelected.getLabel());
                seedVertices.remove(currentNodeSelected);
            }
            infoPanel.setVisible(false);
            System.gc();
        }

        if(action.equalsIgnoreCase("Help")){
            JOptionPane.showConfirmDialog(null,
                    helpPanel.getHelp(),
                    "Help",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE);
        }

        robot.mousePress(InputEvent.BUTTON1_MASK);
    }

    public void buildGraph(){
        BG.createGraph(cluewebfilenames, NIDCLUEWEB, NODEOUTLINKS);
        nodeColors = BG.getNodeColors();
        BG.setGraphLayout(BG.getGraph(),viewArea,this,this);
        panel = BG.getPanel();
        this.layout = BG.getLayout();
        pickedState = BG.getPickedState();
        visitedVertices = BG.getVisitedVertices();
        seedVertices = BG.getSeedVertices();
    }

    @Override
    public void mousePressed(MouseEvent e) {
        //System.out.println("x: " + e.getX() + ", y: " + e.getY());
    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
    @Override
    public void itemStateChanged(ItemEvent e) {
        Object subject = e.getItem();
        if (subject instanceof MyNode) {
            MyNode vertex = (MyNode) subject;
            if (pickedState.isPicked(vertex)) {
                currentNodeSelected = vertex;
            }
        }
    }

    private class MyListRenderer extends DefaultListCellRenderer {
        public Component getListCellRendererComponent( JList list,
                                                       Object value, int index, boolean isSelected,
                                                       boolean cellHasFocus ) {
            Component c = super.getListCellRendererComponent( list, value, index,
                    isSelected, cellHasFocus );
            c.setEnabled(currentNodeSelected.getID() == index+1);
            c.setFont(c.getFont().deriveFont(Font.BOLD));
            return c;
        }
    }

    public String highLightQueryWords(String text, Set<String> terms){
        try{
            String[] words         = text.split(" ");
            String highlightedText = "";
            for(String word : words){
                String s = "";
                if(terms.contains(word)){
                    s = "<b>"+word+"</b>";
                }else{
                    s = word;
                }
                highlightedText = highlightedText+s+" ";
            }
            return highlightedText;
        }catch(NullPointerException npe){
           return "No snippet available";
        }
    }

    public Point checkBounds(int x, int y){
        int lowx = x-(vs.getPopupWidth()/2);
        if(lowx < 30){
            int newx = (lowx+Math.abs(vs.getPopupWidth()/2 - lowx)+50);
            //System.out.println("X: Falling outside! x: " + x + ", y: " + y + ", popupwidth/2: " + vs.getPopupWidth()/2 + ", low: " + lowx + ", newx: " + newx);
            x = newx;
        }
        //System.out.println(vs.getScreenYSize());
        int lowy = y+(vs.getPopupHeight());
        if(lowy > (vs.getScreenYSize()-50)){
            //System.out.println("Y: Falling outside! x: " + x + ", y: " + y + ", popupheight: " + vs.getPopupHeight() + ", low: " + lowy);
            y = (y-vs.getPopupHeight());
        }
        return (new Point(x,y));
    }

    public Map<String, MyNode> getRelevantNodes(){
        return relevantNodes;
    }

    public Vector<Integer> getNodesVisisted(){
        return nodesVisisted;
    }

    public Map<Integer, Long> getNodesTimeSpent(){
        return nodesTimeSpent;
    }

    public Graph<MyNode,MyEdge> getGraph(){
        return panel.getGraphLayout().getGraph();
    }

    public void updateTimeSpent(){
        long diff = (timeEnded-timeStarted);
        if(nodesTimeSpent.containsKey(currentNodeSelected.getID())){
            nodesTimeSpent.put(currentNodeSelected.getID(), nodesTimeSpent.get(currentNodeSelected.getID()) + diff);
        }else{
            nodesTimeSpent.put(currentNodeSelected.getID(), diff);
        }
    }

    public Map<Integer, MyNode> getNodesMap(){
        return nodesMap;
    }

    public QueryObject getQueryObject(){
        return queryObject;
    }
}