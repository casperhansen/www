/*
 * CardLayoutDemo.java
 *
 */

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.*;

public class AnnotationInterface extends JFrame implements MouseListener, ActionListener {
    private final String FILE_PATH                    = "C:/Casper/Universitet/PhD/Articles/2013/SIGIR2013/workshop/Data/";
    private BuildGraph bg                             = new BuildGraph();
    private Random randomGenerator                    = new Random();
    private VisualizationStatics vs                   = new VisualizationStatics();
    private int selectedQueryID                       = -1;
    private Map<Integer, Object> queryVisMap          = new HashMap<Integer, Object>();
    private Set<Integer> queriesDone                  = new HashSet<Integer>();
    private SaveAnnotation sa                         = new SaveAnnotation();
    private Map<Integer, String> nidclueweb           = new HashMap<Integer, String>();
    private Map<String, Vector<Integer>> nodeoutlinks = new HashMap<String, Vector<Integer>>();
    private Set<String> BAD_SNIPPETS                 = new HashSet<String>();
    private final int UIA = 0;
    private final int UIB = 1;
    private int UI_SELECTED;
    private String ANNOTATION_PATH;
    private JPanel cards;
    private QuerySelector qs;
    private HelpPanel helpPanel;

    public void addComponentToPane(Container pane) throws IOException {
        BAD_SNIPPETS.add("dog clean up bags");
        BAD_SNIPPETS.add("figs");
        BAD_SNIPPETS.add("unc");
        BAD_SNIPPETS.add("appraisals");
        BAD_SNIPPETS.add("dog heat");
        BAD_SNIPPETS.add("hoboken");
        BAD_SNIPPETS.add("kcs");
        BAD_SNIPPETS.add("michworks");
        BAD_SNIPPETS.add("yahoo");
        BAD_SNIPPETS.add("pvc");
        BAD_SNIPPETS.add("worm");
//        setPath();
        loadGraphFile();
        //helpPanel = new HelpPanel();
        JFrame frame = new JFrame("AnnotationRelevanceGraph");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        pane.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        LoadMenu lm = new LoadMenu(vs.getScreenXSize(),20,this);
        JMenuBar menuBar = lm.getMenuBar();
        c.gridx = 0;
        c.gridy = 0;
        c.fill = GridBagConstraints.VERTICAL;
        pane.add(menuBar,c);

        c.gridy = 1;
        qs = new QuerySelector(vs.getScreenYSize(),20,FILE_PATH);
        JPanel querySelector = qs.buildQuerySelectionBar(this);
        selectedQueryID = 0;
        //queriesDone.add(selectedQueryID);
        //System.out.println("There are " + qs.getQueryCount() + " queries");
        pane.add(querySelector,c);
        c.gridy = 2;
        //Create the "cards".
        cards = new JPanel(new CardLayout());
        cards.setPreferredSize(new Dimension(vs.getScreenXSize(), vs.getScreenYSize()-65));

        // Add a dummy panel to act as blank when applet opens
        JPanel blank = new JPanel();
        cards.add(blank, Integer.toString(qs.getQueryCount()));
        pane.add(cards, c);
        CardLayout cl = (CardLayout)(cards.getLayout());
        cl.show(cards, Integer.toString(qs.getQueryCount()));
    }

    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event dispatch thread.
     */
    private static void createAndShowGUI() throws IOException {
        //Create and set up the window.
        //JFrameTypeLocking frame = new JFrameTypeLocking("AnnotationInterface");
        JFrame frame = new JFrame("AnnotationInterface");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setUndecorated(true);
        frame.setResizable(false);
        frame.validate();

        //Create and set up the content pane.
        AnnotationInterface demo = new AnnotationInterface();
        demo.addComponentToPane(frame.getContentPane());

        //Display the window.
        frame.pack();
        frame.setVisible(true);
        GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().setFullScreenWindow(frame);
        //frame.lockLocation();
    }

    public static void main(String[] args) {
        /* Use an appropriate Look and Feel */
        try {
            //UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
            UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
        } catch (UnsupportedLookAndFeelException ex) {
            ex.printStackTrace();
        } catch (IllegalAccessException ex) {
            ex.printStackTrace();
        } catch (InstantiationException ex) {
            ex.printStackTrace();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
        /* Turn off metal's use of bold fonts */
        UIManager.put("swing.boldMetal", Boolean.FALSE);

        //Schedule a job for the event dispatch thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    createAndShowGUI();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String action = e.getActionCommand();

        if(action.equalsIgnoreCase("reload")){

            if(!queriesLeft()){
                JOptionPane.showMessageDialog(null,
                        "There are not more queries\nThank you for your help!",
                        "No queries left",
                        JOptionPane.INFORMATION_MESSAGE);
                System.exit(1);
            }

            int qcount = qs.getQueryCount();
            int randomInt = (randomGenerator.nextInt(qcount));

            String q = (qs.getQueries().get(randomInt));
            QueryObject qo = (qs.getQueryPaths()).get(q);
/*
            if(queriesDone.contains(randomInt)){
                while(true){
                    randomInt = (randomGenerator.nextInt(qcount));
                    if(!queriesDone.contains(randomInt)){
                            qs.setJTextFieldText((qs.getQueries()).get(randomInt));
                            break;
                    }
                }
            }else{
                     qs.setJTextFieldText((qs.getQueries()).get(randomInt));
            }
*/
            if(BAD_SNIPPETS.contains(qo.getQuery().toLowerCase())){
              if(!queriesDone.contains(randomInt)){
                  queriesDone.add(randomInt);
              }
            }
            if(queriesDone.contains(randomInt)){
                while(true){
                    randomInt = (randomGenerator.nextInt(qcount));
                    q = (qs.getQueries().get(randomInt));
                    qo = (qs.getQueryPaths()).get(q);
                    if(!queriesDone.contains(randomInt) && !BAD_SNIPPETS.contains(qo.getQuery().toLowerCase())){
                        qs.setJTextFieldText((qs.getQueries()).get(randomInt));
                        break;
                    }
                }
            }else{
                  qs.setJTextFieldText((qs.getQueries()).get(randomInt));
            }
            selectedQueryID = randomInt;
            //queriesDone.add(selectedQueryID);
        }

        if(action.equalsIgnoreCase("accept")){
            // Get the selectedQueryID
            // Use to index the list of strings corresponding to the layouts of the different graph.
            // cl.show(cards, CARDSINDEX[selectedQueryID]);
/*
            CardLayout cl = (CardLayout)(cards.getLayout());
            cl.show(cards, Integer.toString(selectedQueryID));
*/
            /*
             * Begin changes made on 30-05-2012
             */
            String q = (qs.getQueries().get(selectedQueryID));
            QueryObject qo = (qs.getQueryPaths()).get(q);
            //System.out.println("Query: " + q + " - collection: " + qo.getCollection() + ", webpath: " +
            //        qo.getWebgraphPath() + ", snippet: " + qo.getSnippetpath() + ",  rankpath: " + qo.getRankPath() +
            //        ", queryNumber: " + qo.getQueryNumber());


            // Generate random number between 0 and 1
            JPanel card      = new JPanel();
            int randomInt = randomGenerator.nextInt(2);
            //int randomInt = UIA;
            if(randomInt == UIA){
                UI_SELECTED = UIA;
                ListView cardE = null;
                try {
                    //cardE = new ListView(qo,nidclueweb,nodeoutlinks);
                    cardE = new ListView(qo,nodeoutlinks,nidclueweb,bg);
                    queryVisMap.put(selectedQueryID,cardE);
                    card.add(cardE.getPane());
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }else{
                UI_SELECTED = UIB;
                GraphView cardE = null;
                try {
                    //cardE = new GraphView(qo,nidclueweb,nodeoutlinks);
                    cardE = new GraphView(qo,nodeoutlinks,nidclueweb,bg);
                    queryVisMap.put(selectedQueryID,cardE);
                    card.add(cardE.getViz());
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
            cards.add(card, Integer.toString(selectedQueryID));
            CardLayout cc = (CardLayout)(cards.getLayout());
            cc.show(cards, Integer.toString(selectedQueryID));
            qs.disableSearch();
            qs.disableReload();
            qs.enableDone();
        }

        if(action.equalsIgnoreCase("Help")){
            //System.out.println("Help");

            JOptionPane.showConfirmDialog(null,
                    helpPanel.getHelp(),
                    "Help",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE);
        }

        if (action.equalsIgnoreCase("done")){
//            sa.saveAnnotations(ANNOTATION_PATH, queryVisMap, selectedQueryID, UI_SELECTED);
            qs.enableSearch();
            qs.enableReload();
            qs.disableDone();

            // Reset visualization
            CardLayout cl = (CardLayout)(cards.getLayout());
            cl.show(cards, Integer.toString(qs.getQueryCount()));

            // Fake a click on the reload button to reload new query
            qs.clickDone();
        }

        if(action.equalsIgnoreCase("exit")){
            System.exit(0);
        }
    }

    public void setPath(){
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Select directory for saving user annotations");
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        chooser.setDragEnabled(false);
        int option = chooser.showSaveDialog(null);
        if (option == JFileChooser.APPROVE_OPTION) {
            ANNOTATION_PATH = chooser.getSelectedFile().getPath();
        }else{
            JOptionPane.showMessageDialog(chooser,
                    "A directory must be selected",
                    "Directory select error",
                    JOptionPane.ERROR_MESSAGE);
            setPath();
        }
    }

    public void loadGraphFile(){
        // nodeoutlink = map
        // nidclueweb = nodeidToDocNo
        BufferedReader br = null;
        try {
            String sCurrentLine;
            br = new BufferedReader(new FileReader(FILE_PATH+"webgraph/docno.docid.outlinks.sed"));
            while((sCurrentLine = br.readLine()) != null) {
                String[] split = sCurrentLine.split(" ");
                nidclueweb.put(Integer.parseInt(split[1]), split[0]);
                Vector<Integer> v = new Vector<Integer>();
                for(int j = 2; j < split.length; j++){
                    v.add(Integer.parseInt(split[j]));
                }
                nodeoutlinks.put(split[0], v);
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
//        System.out.println("Loaded all webgraph info");
    }

    public boolean queriesLeft(){
        return (queriesDone.size() != qs.getQueryCount());
    }

    static class JFrameTypeLocking extends JFrame {
        Point locked=null;
        public JFrameTypeLocking(String string) {
            super(string);
            super.addComponentListener(new ComponentAdapter(){
                public void componentMoved(ComponentEvent e) {
                    if (locked!=null) JFrameTypeLocking.this.setLocation(locked);
                }});
        }
        public void lockLocation() {
            locked=super.getLocation();
        }
    }

}