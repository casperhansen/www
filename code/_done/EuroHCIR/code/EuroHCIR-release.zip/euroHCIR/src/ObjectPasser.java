import edu.uci.ics.jung.visualization.picking.PickedState;

import java.util.Map;
import java.util.Set;

public class ObjectPasser {
    private PickedState<MyNode> pickedNodes;
    private Map<String, MyNode> rNodes;
    private Set<MyNode> seedV;
    private MyNode cNode;

    public ObjectPasser(){

    }

    public void setPickedState(PickedState<MyNode> p){
        this.pickedNodes = p;
    }

    public PickedState<MyNode> getPickedState(){
        return pickedNodes;
    }

    public void setRelevantNodes(Map<String, MyNode> relevantNodes){
        this.rNodes = relevantNodes;
    }

    public Map<String, MyNode> getRelevantNodes(){
        return rNodes;
    }

    public void  setSeedVertices(Set<MyNode> seedVertices){
        this.seedV = seedVertices;
    }

    public Set<MyNode> getSeedVertices(){
        return seedV;
    }

    public void setCurrentNodeSelected(MyNode currentNode){
        this.cNode = currentNode;
    }

    public MyNode getCurrentNodeSelected(){
        return cNode;
    }

}
