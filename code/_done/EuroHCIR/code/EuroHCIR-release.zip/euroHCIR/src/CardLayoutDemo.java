/*
 * CardLayoutDemo.java
 *
 */

import java.awt.*;
import java.awt.event.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import javax.swing.*;

public class CardLayoutDemo extends JFrame implements MouseListener, ActionListener {
    private final String FILE_PATH         = "C:/Casper/Universitet/PhD/Articles/2013/SIGIR2013/workshop/Data/";
    private Random randomGenerator         = new Random();
    private VisualizationStatics vs        = new VisualizationStatics();
    private int selectedQueryID            = -1;
    private Map<Integer, Exp2> queryVisMap = new HashMap<Integer, Exp2>();
    private Set<Integer> queriesDone       = new HashSet<Integer>();
    private SaveAnnotation sa                   = new SaveAnnotation();
    private String ANNOTATION_PATH;
    private JPanel cards;
    private QuerySelector qs;
    private HelpPanel helpPanel;

    public void addComponentToPane(Container pane) throws IOException {
        setPath();
        helpPanel = new HelpPanel();
        JFrame frame = new JFrame("AnnotationRelevanceGraph");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        pane.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        LoadMenu lm = new LoadMenu(vs.getScreenXSize(),20,this);
        JMenuBar menuBar = lm.getMenuBar();
        c.gridx = 0;
        c.gridy = 0;
        c.fill = GridBagConstraints.VERTICAL;
        pane.add(menuBar,c);

        c.gridy = 1;
        qs = new QuerySelector(vs.getScreenYSize(),20,FILE_PATH);
        JPanel querySelector = qs.buildQuerySelectionBar(this);
        selectedQueryID = 0;
        queriesDone.add(selectedQueryID);
        System.out.println("There are " + qs.getQueryCount() + " queries");
        pane.add(querySelector,c);
        c.gridy = 2;
        //Create the "cards".
        cards = new JPanel(new CardLayout());
        cards.setPreferredSize(new Dimension(vs.getScreenXSize(), vs.getScreenYSize()-65));
/*
        for(int i = 0; i < qs.getQueryCount(); i++){
            JPanel card = new JPanel();
            Exp cardE   = new Exp();
            queryVisMap.put(i,cardE);
            card.add(cardE.getViz());
            cards.add(card, Integer.toString(i));
        }
*/
        // Add a dummy panel to act as blank when applet opens
        JPanel blank = new JPanel();
        cards.add(blank, Integer.toString(qs.getQueryCount()));
        pane.add(cards, c);
        CardLayout cl = (CardLayout)(cards.getLayout());
        cl.show(cards, Integer.toString(qs.getQueryCount()));
    }

    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event dispatch thread.
     */
    private static void createAndShowGUI() throws IOException {
        //Create and set up the window.
        JFrame frame = new JFrame("CardLayoutDemo");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        //Create and set up the content pane.
        CardLayoutDemo demo = new CardLayoutDemo();
        demo.addComponentToPane(frame.getContentPane());

        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        /* Use an appropriate Look and Feel */
        try {
            //UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
            UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
        } catch (UnsupportedLookAndFeelException ex) {
            ex.printStackTrace();
        } catch (IllegalAccessException ex) {
            ex.printStackTrace();
        } catch (InstantiationException ex) {
            ex.printStackTrace();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
        /* Turn off metal's use of bold fonts */
        UIManager.put("swing.boldMetal", Boolean.FALSE);

        //Schedule a job for the event dispatch thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    createAndShowGUI();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String action = e.getActionCommand();

        if(action.equalsIgnoreCase("reload")){

            if(!queriesLeft()){
                JOptionPane.showMessageDialog(null,
                        "There are not more queries\nThank you for your help!",
                        "No queries left",
                        JOptionPane.INFORMATION_MESSAGE);
            }

            int qcount = qs.getQueryCount();
            int randomInt = (randomGenerator.nextInt(qcount));

            if(queriesDone.contains(randomInt)){
                while(true){
                    randomInt = (randomGenerator.nextInt(qcount));
                    if(!queriesDone.contains(randomInt)){
                        qs.setJTextFieldText((qs.getQueries()).get(randomInt));
                        break;
                    }
                }
            }else{
                qs.setJTextFieldText((qs.getQueries()).get(randomInt));
/*
                if(randomInt != selectedQueryID){
                    qs.setJTextFieldText((qs.getQueries()).get(randomInt));
                }else{
                    while(true){
                        randomInt = (randomGenerator.nextInt(qcount));
                        if(randomInt != selectedQueryID){
                            qs.setJTextFieldText((qs.getQueries()).get(randomInt));
                            break;
                        }
                    }
                }
*/
            }
            selectedQueryID = randomInt;
            queriesDone.add(selectedQueryID);
        }

        if(action.equalsIgnoreCase("accept")){
            // Get the selectedQueryID
            // Use to index the list of strings corresponding to the layouts of the different graph.
            // cl.show(cards, CARDSINDEX[selectedQueryID]);
/*
            CardLayout cl = (CardLayout)(cards.getLayout());
            cl.show(cards, Integer.toString(selectedQueryID));
*/
            /*
             * Begin changes made on 30-05-2012
             */
            String q = (qs.getQueries().get(selectedQueryID));
            System.out.println(q);
            QueryObject qo = (qs.getQueryPaths()).get(q);
            System.out.println("Query: " + q + " - collection: " + qo.getCollection() + ", webpath: " +
            qo.getWebgraphPath() + ", snippet: " + qo.getSnippetpath() + ",  rankpath: " + qo.getRankPath());
            /*
             * Pass the QueryObject to the Exp and in there, construct the graph and add snippets. Add the Exp
             * to the card layout and show it.
             */

            JPanel card = new JPanel();
            Exp2 cardE   = null;
            try {
                cardE = new Exp2(qo);
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            queryVisMap.put(selectedQueryID,cardE);
            card.add(cardE.getViz());
            cards.add(card, Integer.toString(selectedQueryID));
            CardLayout cc = (CardLayout)(cards.getLayout());
            cc.show(cards, Integer.toString(selectedQueryID));
            qs.disableSearch();
            qs.disableReload();
            qs.enableDone();
        }

        if(action.equalsIgnoreCase("Help")){
            System.out.println("Help");

            JOptionPane.showConfirmDialog(null,
                    helpPanel.getHelp(),
                    "Help",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE);
        }

        if (action.equalsIgnoreCase("done")){
            //sa.saveAnnotationsWebgraph(ANNOTATION_PATH, queryVisMap, selectedQueryID);
            qs.enableSearch();
            qs.enableReload();
            qs.disableDone();

            // Reset visualization
            CardLayout cl = (CardLayout)(cards.getLayout());
            cl.show(cards, Integer.toString(qs.getQueryCount()));

            // Fake a click on the reload button to reload new query
            qs.clickDone();
        }
    }

    public void setPath(){
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Select directory for saving user annotations");
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        chooser.setDragEnabled(false);
        int option = chooser.showSaveDialog(null);
        if (option == JFileChooser.APPROVE_OPTION) {
            ANNOTATION_PATH = chooser.getSelectedFile().getPath();
        }else{
            JOptionPane.showMessageDialog(chooser,
                    "A directory must be selected",
                    "Directory select error",
                    JOptionPane.ERROR_MESSAGE);
            setPath();
        }
    }

    public boolean queriesLeft(){
        return (queriesDone.size() != qs.getQueryCount());
    }
}