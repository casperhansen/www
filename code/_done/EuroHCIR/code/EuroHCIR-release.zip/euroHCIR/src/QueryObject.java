import java.io.*;
import java.util.HashMap;

public class QueryObject {
    private String webgraphpath;
    private String snippetpath;
    private String rankpath;
    private String col;
    private String query;
    private HashMap<Integer, String> map = new HashMap<Integer, String>();
    private String queryNumber;

    public QueryObject(String collection, String pathToQueryWebgraph, String pathToSnippet,
                       String rankpath, String query, String queryNumber){
        this.col = collection;
        this.webgraphpath = pathToQueryWebgraph;
        this.snippetpath = pathToSnippet;
        this.rankpath = rankpath;
        this.query    = query;
        this.queryNumber = queryNumber;
    }

    public String getWebgraphPath(){
        return webgraphpath;
    }

    public String getSnippetpath(){
        return snippetpath;
    }

    public String getCollection(){
        return col;
    }

    public String getRankPath(){
        return rankpath;
    }

    public String getQuery(){
        return query;
    }

    public HashMap<Integer, String> getMap(){
        return map;
    }

    public String getQueryNumber(){
        return queryNumber;
    }
}
