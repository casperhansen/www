import edu.uci.ics.jung.graph.Graph;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class SaveAnnotation {

    public SaveAnnotation(){
    }

    public void saveAnnotations(String ANNOTATION_PATH, Map<Integer, Object> queryVisMap, int selectedQueryID, int UI_SELECTED){
        // Get the visualization according to the query
        if(UI_SELECTED == 0){ //baseline is chosen
            ListView current                    = (ListView)queryVisMap.get(selectedQueryID);
            QueryObject qo                      = current.getQueryObject();
            Set<Integer> indexesRelevant        = current.getRelevantIndexes();
            Map<Integer, Long> indexesTimeSpent = current.getIndexesTimeSpent();
            Vector<Integer> indexesVisisted     = current.getIndexesVisisted();
            Graph<MyNode, MyEdge> g             = current.getGraph();
            Map<Integer,MyNode> tmp             = current.getNodesMap();
            String sep = "";
            if(ANNOTATION_PATH.contains("/")){
                sep = "/";
            }else{
                sep = "\\";
            }
            try {
                FileWriter fw     = new FileWriter(ANNOTATION_PATH+sep+"baseline.query."+String.valueOf(selectedQueryID)+".stat");
                BufferedWriter bw = new BufferedWriter(fw);

                bw.write(qo.getCollection());
                bw.newLine();
                bw.flush();
                bw.write(qo.getQuery());
                bw.newLine();
                bw.flush();
                bw.write(qo.getQueryNumber());
                bw.newLine();
                bw.flush();
                bw.write(qo.getWebgraphPath());
                bw.newLine();
                bw.flush();
                bw.write(qo.getSnippetpath());
                bw.newLine();
                bw.flush();
                bw.write(qo.getRankPath());
                bw.newLine();
                bw.flush();
                bw.write("# User interface");
                bw.newLine();
                bw.flush();
                bw.write(Integer.toString(UI_SELECTED));
                bw.newLine();
                bw.flush();
                bw.write("# Relevant indexes");
                bw.newLine();
                bw.flush();

                for (Integer anIndexesRelevant : indexesRelevant) {
                    bw.write(String.valueOf(anIndexesRelevant+1));
                    bw.newLine();
                    bw.flush();
                }
                bw.write("# Time spent (id, timespent (ms))");
                bw.newLine();
                bw.flush();
                for (Map.Entry<Integer, Long> stringMyNodeEntry : indexesTimeSpent.entrySet()) {
                    Map.Entry pairs = (Map.Entry) stringMyNodeEntry;
                    Integer key     = (Integer)pairs.getKey();
                    Long value      = (Long)pairs.getValue();
                    bw.write(String.valueOf(key+1) + "," + String.valueOf(value.floatValue()));
                    bw.newLine();
                    bw.flush();
                }
                bw.write("# Indexes visited in order");
                bw.newLine();
                bw.flush();

                //Map<Integer,MyNode> tmp = current.getNodesMap();
                for (Integer nodeid : indexesVisisted) {
                    MyNode t = tmp.get(nodeid);
                    int indegree = g.inDegree(t);
                    int outdegree = g.outDegree(t);
                    bw.write(String.valueOf(nodeid+1)+","+String.valueOf(indegree)+","+String.valueOf(outdegree));
                    bw.newLine();
                    bw.flush();
                }
                bw.close();

            } catch (IOException e) {
                e.printStackTrace();
                System.err.println("There was a problem writing the file of user annotation");
            }
        }else{
            GraphView current                 = (GraphView) queryVisMap.get(selectedQueryID);
            QueryObject qo                    = current.getQueryObject();
            Map<String, MyNode> relevantNodes = current.getRelevantNodes();
            Map<Integer, Long> nodesTimeSpent = current.getNodesTimeSpent();
            Vector<Integer> nodesVisisted     = current.getNodesVisisted();
            Graph<MyNode, MyEdge> g           = current.getGraph();
            Map<Integer,MyNode> tmp           = current.getNodesMap();
            String sep = "";
            if(ANNOTATION_PATH.contains("/")){
                sep = "/";
            }else{
                sep = "\\";
            }
            try {
                FileWriter fw     = new FileWriter(ANNOTATION_PATH+sep+"webgraph.query."+String.valueOf(selectedQueryID)+".stat");
                BufferedWriter bw = new BufferedWriter(fw);

                bw.write(qo.getCollection());
                bw.newLine();
                bw.flush();
                bw.write(qo.getQuery());
                bw.newLine();
                bw.flush();
                bw.write(qo.getQueryNumber());
                bw.newLine();
                bw.flush();
                bw.write(qo.getWebgraphPath());
                bw.newLine();
                bw.flush();
                bw.write(qo.getSnippetpath());
                bw.newLine();
                bw.flush();
                bw.write(qo.getRankPath());
                bw.newLine();
                bw.flush();
                bw.write("# User interface");
                bw.newLine();
                bw.flush();
                bw.write(Integer.toString(UI_SELECTED));
                bw.newLine();
                bw.flush();
                // Relevant nodes are written first
                bw.write("# Relevant nodes");
                bw.newLine();
                bw.flush();
                for (Map.Entry<String, MyNode> stringMyNodeEntry : relevantNodes.entrySet()) {
                    Map.Entry pairs = (Map.Entry) stringMyNodeEntry;
                    MyNode m = (MyNode)pairs.getValue();
                    bw.write(String.valueOf(m.getID()));
                    bw.newLine();
                    bw.flush();
                }
                bw.write("# Time spent at each node (nodeid, timespent (ms))");
                bw.newLine();
                bw.flush();
                for (Map.Entry<Integer, Long> stringMyNodeEntry : nodesTimeSpent.entrySet()) {
                    Map.Entry pairs = (Map.Entry) stringMyNodeEntry;
                    Integer key     = (Integer)pairs.getKey();
                    Long value      = (Long)pairs.getValue();
                    bw.write(String.valueOf(key) + "," + String.valueOf(value.floatValue()));
                    bw.newLine();
                    bw.flush();
                }
                bw.write("# Nodes visited in order");
                bw.newLine();
                bw.flush();
                for (Integer nodeid : nodesVisisted) {
                    MyNode t = tmp.get(nodeid);
                    int indegree = g.inDegree(t);
                    int outdegree = g.outDegree(t);
                    bw.write(String.valueOf(nodeid)+","+String.valueOf(indegree)+","+String.valueOf(outdegree));
                    bw.newLine();
                    bw.flush();
                }
                bw.close();

            } catch (IOException e) {
                e.printStackTrace();
                System.err.println("There was a problem writing the file of user annotation");
            }
        }
    }
}
