import edu.uci.ics.jung.algorithms.layout.FRLayout;
import edu.uci.ics.jung.algorithms.scoring.DegreeScorer;
import edu.uci.ics.jung.algorithms.scoring.util.VertexScoreTransformer;
import edu.uci.ics.jung.graph.DirectedSparseGraph;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.visualization.VisualizationViewer;
import edu.uci.ics.jung.visualization.control.CrossoverScalingControl;
import edu.uci.ics.jung.visualization.control.ScalingControl;
import org.apache.commons.collections15.Transformer;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class Test3 extends JFrame{
    private Map<Integer, String> nodeidToDocNo = new HashMap<Integer, String>();
    private Map<String, Vector<Integer>> map   = new HashMap<String, Vector<Integer>>();
    private Map<Integer, MyNode> rankToNode    = new HashMap<Integer, MyNode>();
    private Map<String, Integer> cluewebs      = new HashMap<String, Integer>();
    private String[] names = new String[20];

    public static void main(String[] args){
        new Test3(args);
    }

    public Test3(String[] arg){
        BufferedReader br = null;
        int rank = 1;
        try {
            String sCurrentLine;
            br = new BufferedReader(new FileReader(arg[1]));
            while((sCurrentLine = br.readLine()) != null) {
                   rankToNode.put(rank, new MyNode(String.valueOf(rank),rank));
                   cluewebs.put(sCurrentLine,rank);
                   names[rank-1] = sCurrentLine;
                   rank++;
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }



        BufferedReader br2 = null;
        try {
            String sCurrentLine;
            br2 = new BufferedReader(new FileReader(arg[0]));
            while((sCurrentLine = br2.readLine()) != null) {
                String[] split = sCurrentLine.split(" ");
                nodeidToDocNo.put(Integer.parseInt(split[1]), split[0]);
                Vector<Integer> v = new Vector<Integer>();
                for(int j = 2; j < split.length; j++){
                    v.add(Integer.parseInt(split[j]));
                }
                map.put(split[0], v);
            }
            br2.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        findMatches();
    }

    public void findMatches(){
        Graph<MyNode,MyEdge> g = new DirectedSparseGraph<MyNode,MyEdge>();
        //g.addEdge(new MyEdge("e1"), n1, n2);
        //We enter with a list of some kind containing the clueweb names. Call this cluewebs. Loop over them.
        int edgenr = 1;
        for(int j = 0; j < names.length; j++) {
            String clueweb = names[j];
             //With the current look up in map.
            if(map.containsKey(clueweb)){
               // We know the node exist. But does it have any outlinks?
               Vector<Integer> outlinks = map.get(clueweb);
               if(!outlinks.isEmpty()){
                   boolean edgewascreated = false;
                   //System.out.println("Node " + clueweb +" in list. Have outlinks. Looping.");
                   for (int entry : outlinks){
                         // Attempt ot find the key in the pl lookup table to get the mapping.
                         if(nodeidToDocNo.containsKey(entry)){
                            //System.out.println("Node " + clueweb +" has mapping.");
                            String match = nodeidToDocNo.get(entry);
                            //If the key exists, fetch it. Now we need to know if that key exist in the original list.
                            if(Arrays.asList(names).contains(match)){
                                System.out.println("Node " + clueweb +" contains outlink " +match+" also in initial set.");
                                int rankorg = cluewebs.get(clueweb);
                                int rankmatch = cluewebs.get(match);
                                g.addEdge(new MyEdge("e"+edgenr),rankToNode.get(rankorg),rankToNode.get(rankmatch));
                                edgewascreated = true;
                               // We are happy. We lookup clueweb and match in a docno-to-rank-map and write it.
                            }
                         }
                    }
                    if(!edgewascreated){
                        int index = cluewebs.get(clueweb);
                        //g.addVertex(rankToNode.get(index));
                    }
               }else{
                  //The node exists but has no outlinks. Create it anyway
                  //System.out.println("Node " + clueweb +"  in list but no outlinks. Creating.");
                  int index = cluewebs.get(clueweb);
                   //g.addVertex(rankToNode.get(index));
               }
            }else{
                int index = cluewebs.get(clueweb);
                //g.addVertex(rankToNode.get(index));
               // So the node in the list is one of those we could not find. We make a node nevertheless.
               //System.out.println("Node " + clueweb +" not in list. Creating.");
            }
        }
      visualization(g);
    }

    public void visualization(Graph<MyNode, MyEdge> graph){
        //Graph<MyNode,MyEdge> graph = createGraph();
        Dimension viewArea = new Dimension(700,700);
        int graphVertexCount = graph.getVertexCount();
        //StaticLayout<MyNode, MyEdge> layout = new StaticLayout<MyNode, MyEdge>(g, locationTransformer);
        FRLayout<MyNode,MyEdge> layout = new FRLayout<MyNode,MyEdge>(graph, viewArea);
        VisualizationViewer<MyNode, MyEdge> panel = new VisualizationViewer<MyNode, MyEdge>(layout, viewArea);
        panel.setPreferredSize(viewArea);
        panel.setMinimumSize(viewArea);
        panel.getRenderContext().setVertexLabelTransformer(new Transformer<MyNode, String>() {
            public String transform(MyNode e) {
                return "<html><font size=6><b>" + e.getLabel() + "</b></font></html>";
            }
        });
        panel.getRenderer().getVertexLabelRenderer().setPosition(edu.uci.ics.jung.visualization.renderers.Renderer.VertexLabel.Position.CNTR);
        DegreeScorer<MyNode> degree = new DegreeScorer<MyNode>(graph);
        Transformer<MyNode, Integer> degrees = new VertexScoreTransformer<MyNode, Integer>(degree);
        VertexShapeSizeAspect<MyNode, MyEdge> vssa = new VertexShapeSizeAspect<MyNode, MyEdge>(graph, degrees);
        vssa.setScaling(true);
        panel.getRenderContext().setVertexShapeTransformer(vssa);
        ScalingControl scaler = new CrossoverScalingControl();
        scaler.scale(panel, (float) 0.8, panel.getCenter());

        JFrame frame = new JFrame("AnnotationInterface");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        //Create and set up the content pane.
        Container c = frame.getContentPane();
        c.add(panel);

        //Display the window.
        frame.pack();
        frame.setVisible(true);

    }
}