import edu.uci.ics.jung.visualization.picking.PickedInfo;
import org.apache.commons.collections15.Transformer;

import java.awt.*;
import java.util.Map;
import java.util.Set;

public class SeedFillColor<MyNode> implements Transformer<MyNode,Paint> {
    private final Color softred                 = new Color(238,221,130);
    private final Color softgreen               = new Color(152,251,152);
    private final Color softblue                = new Color(224,255,255);
    protected PickedInfo<MyNode> pi;
    protected final static float dark_value = 0.8f;
    protected final static float light_value = 0.2f;
    protected boolean seed_coloring;
    private Map<MyNode,Color> nodeColors;
    private Set<MyNode> seedVertices;
    private Set<MyNode> visitedVertices;

    public SeedFillColor(PickedInfo<MyNode> pi, Map<MyNode, Color> nColors, Set<MyNode> seed, Set<MyNode> v)
    {
        this.pi = pi;
        this.nodeColors = nColors;
        this.seedVertices = seed;
        this.visitedVertices = v;
        seed_coloring = false;
    }

    public void setSeedColoring(boolean b)
    {
        this.seed_coloring = b;
    }

    public Paint transform(MyNode v) {
        Color alpha = nodeColors.get(v);
        if (pi.isPicked(v)) {
            if(alpha == softred)
                return softblue;
            else{
                return softred;
            }
        }
        else {
            if(seedVertices.contains(v))
                return softblue;
            else{
                if(visitedVertices.contains(v)){
                    return softgreen;
                }
                return softred;
            }
        }
    }
}