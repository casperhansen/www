import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Random;

public class QuerySelector extends JPanel implements KeyListener {
    private int panelWidth;
    private int panelHeight;
    private String[] qfiles;
    private String[] dirnames = {"trec2011","trec2012","wt09","wt10"};
    private JButton reload;
    private JButton accept;
    private JButton done;
    private String filetopdir;
    private Font normal = new Font("Verdana", Font.PLAIN, 10);
    private HashMap<Integer, String> queries = new HashMap<Integer, String>();
    private HashMap<String, QueryObject> queryList = new HashMap<String, QueryObject>();
    public JTextField jtf;
    private int QUERYCOUNT;

    public QuerySelector(int width, int height, String mainFileDir){
        panelWidth = width;
        panelHeight = height;
        filetopdir = mainFileDir;
        String[] query_files = { mainFileDir + "queries/"+dirnames[0]+"/queries.txt",
                                 mainFileDir + "queries/"+dirnames[1]+"/queries.txt",
                                 mainFileDir + "queries/"+dirnames[2]+"/queries.txt",
                                 mainFileDir + "queries/"+dirnames[3]+"/queries.txt"};
        for (String query_file : query_files) {
            File f = new File(query_file);
            if(!f.exists()){
                System.err.println("The supplied path for queryfile locations does not contain all query files.");
                System.exit(-1);
            }
        }
        qfiles = query_files;

        try {
            //readQueries2();
            loadQueries();
        } catch (IOException e) {
            System.err.println("Could not execute readQueries() - Check path!");
        }
    }

    public JPanel buildQuerySelectionBar(ActionListener al){
        JPanel container = new JPanel();
        container.setSize(new Dimension(panelWidth,panelHeight));
        container.setLayout(new GridBagLayout());
        container.setBackground(Color.WHITE);
        GridBagConstraints c = new GridBagConstraints();
        jtf = new JTextField();
        jtf.setPreferredSize(new Dimension((int)(panelWidth/3.3), panelHeight));
        String query = queries.get(0);
        jtf.setText(query);
        jtf.setEnabled(false);
        jtf.setFont(normal);

        // Reload button
        reload = new JButton("I dont get it");
        reload.setActionCommand("reload");
        reload.setPreferredSize(new Dimension((int)(panelWidth/7.5), panelHeight));
        reload.addActionListener(al);
        reload.setFont(normal);
        reload.setFocusPainted(false);

        // Accept button
        accept = new JButton("Search");
        accept.setActionCommand("accept");
        accept.setPreferredSize(new Dimension(panelWidth/8,panelHeight));
        accept.addActionListener(al);
        accept.requestFocusInWindow();
        accept.setFont(normal);
        accept.setFocusPainted(false);
        accept.addKeyListener(this);

        // Print relevant nodes
        done = new JButton("Done");
        done.setActionCommand("done");
        done.setPreferredSize(new Dimension(panelWidth/8,panelHeight));
        done.addActionListener(al);
        done.requestFocusInWindow();
        done.setFont(normal);
        done.setFocusPainted(false);

        c.gridx = 0;
        c.gridy = 0;
        container.add(jtf,c);
        c.gridx = 1;
        container.add(accept,c);
        c.gridx = 2;
        container.add(reload,c);
        c.gridx = 3;
        container.add(done,c);
        return container;
    }

    public HashMap<Integer, String> getQueries(){
        return queries;
    }

    public HashMap<String, QueryObject> getQueryPaths(){
        return queryList;
    }

    public void readQueries() throws IOException {
        BufferedReader br;
        String sCurrentLine;
        br = new BufferedReader(new FileReader("C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2013\\workshop\\Data\\queries\\all.queries.unnumbered.txt"));
        //br = new BufferedReader(new FileReader("C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2013\\workshop\\Data\\queries\\queries.test.indri"));
        int linenr = 1;
        int low = 0;
        while ((sCurrentLine = br.readLine()) != null) {
            String[] ar = sCurrentLine.split(":");
            int foo = Integer.parseInt(ar[0]);
            if(linenr == 1){
               low = foo;
               linenr++;
            }
            foo = foo - low;
            System.out.println(foo);
            queries.put(foo, ar[1]);
            QUERYCOUNT++;
        }
        br.close();
    }

    public void readQueries2() throws IOException {
        BufferedReader br;
        String sCurrentLine;
        br = new BufferedReader(new FileReader("C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2013\\workshop\\Data\\queries\\all.queries.unnumbered.txt"));
        //br = new BufferedReader(new FileReader("C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2013\\workshop\\Data\\queries\\queries.test.indri"));
        int linenr = 0;
        while ((sCurrentLine = br.readLine()) != null) {
            queries.put(linenr, sCurrentLine);
            QUERYCOUNT++;
            linenr++;
        }
        br.close();
    }


    public void loadQueries() throws IOException{
        int linenr = 0;
        for(int i = 0; i < dirnames.length; i++){
            BufferedReader br = new BufferedReader(new FileReader(filetopdir+"/queries/"+dirnames[i]+"/queries.txt"));
            String currentLine;
            int id = 0;
            int rankcounter = 0;
            while((currentLine = br.readLine()) != null){
                   String[] ar = currentLine.split(":");
                   queries.put(linenr, ar[1]);
                   String webpath     = filetopdir+"webgraph/"+dirnames[i]+"/webgraph.txt."+id; // Path to graph
                   String snippetpath = filetopdir+"snippetclean/"+dirnames[i]+"/"+ar[1]+"/";            // Path to snippets
                   String rankpath    = filetopdir+"ranks/"+dirnames[i]+"/standard.28052013.res"+rankcounter; // Path to ranks
                   //String docsForQuery = filetopdir+"docsprquery/"+dirnames[i]+"/"+ar[1]+".docs"; //
                   queryList.put(ar[1], new QueryObject(dirnames[i], webpath, snippetpath, rankpath, ar[1], ar[0]));
                   id++;
                   rankcounter++;
                   QUERYCOUNT++;
                   linenr++;
            }
            br.close();
        }

    }

    public void setJTextFieldText(String text){
       jtf.setText(text);
       this.repaint();
    }

    public int getQueryCount(){
        return QUERYCOUNT;
    }

    public void enableSearch(){
        accept.setEnabled(true);
    }

    public void disableSearch(){
        accept.setEnabled(false);
    }

    public void enableReload(){
        reload.setEnabled(true);
    }

    public void disableReload(){
        reload.setEnabled(false);
    }

    public void enableDone(){
        done.setEnabled(true);
    }

    public void disableDone(){
        done.setEnabled(false);
    }

    public void clickDone(){
        reload.doClick();
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

    }

    @Override
    public void keyReleased(KeyEvent e) {
        if(e.getKeyCode() == KeyEvent.VK_ENTER){

        }
    }
}
