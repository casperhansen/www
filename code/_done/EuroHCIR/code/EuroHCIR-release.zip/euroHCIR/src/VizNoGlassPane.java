import java.awt.*;
import java.awt.event.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

import edu.uci.ics.jung.algorithms.layout.GraphElementAccessor;
import edu.uci.ics.jung.algorithms.scoring.DegreeScorer;
import edu.uci.ics.jung.algorithms.scoring.util.VertexScoreTransformer;
import edu.uci.ics.jung.visualization.control.CrossoverScalingControl;
import edu.uci.ics.jung.visualization.control.ModalGraphMouse;
import edu.uci.ics.jung.visualization.control.ScalingControl;
import edu.uci.ics.jung.visualization.picking.PickedState;
import edu.uci.ics.jung.visualization.renderers.Renderer;
import org.apache.commons.collections15.Transformer;
import edu.uci.ics.jung.algorithms.layout.FRLayout;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.UndirectedSparseGraph;
import edu.uci.ics.jung.visualization.VisualizationViewer;
import edu.uci.ics.jung.visualization.control.DefaultModalGraphMouse;

public class VizNoGlassPane extends JFrame implements MouseListener, ActionListener, ItemListener {
    private final String FILE_PATH = "C:/Casper/Universitet/PhD/Articles/2013/SIGIR2013/workshop/Data/";
    private Random randomGenerator = new Random();
    private final Color softred                 = new Color(238,221,130);
    private BuildGraph bg = new BuildGraph();
    private VisualizationViewer<MyNode,MyEdge> panel;
    private FRLayout<MyNode,MyEdge> layout;
    private JPanel querySelector;
    private Graph<MyNode,MyEdge> graph;
    private MyNode currentNodeSelected;
    private PickedState<MyNode> pickedState;
    private HelpPanel helpPanel;
    private QuerySelector qs;
    private final int FONT_SIZE                 = 11;
    private Map<String, MyNode> relevantNodes   = new HashMap<String, MyNode>();
    private Set<MyNode> seedVertices            = new HashSet<MyNode>();
    private Set<MyNode> visitedVertices         = new HashSet<MyNode>();
    private Font normal                         = new Font("Verdana", Font.PLAIN, FONT_SIZE);
    private Font italic                         = new Font("Verdana", Font.ITALIC, FONT_SIZE);
    private Font bold                           = new Font("Verdana", Font.BOLD, FONT_SIZE);
    private Border lowerMatteBorder             = BorderFactory.createMatteBorder(0, 0, 1, 0, Color.darkGray);
    private Border fullMatteBorder              = BorderFactory.createMatteBorder(1, 1, 1, 1, Color.darkGray);
    private Border fullEmptyBorder              = new EmptyBorder(0, 0, 0, 0);
    private Map<MyNode,Color> nodeColors;

    public static void main(String[] args) throws IOException {
        new VizNoGlassPane();
    }

    public VizNoGlassPane() throws IOException {
        //init();
        JFrame frame = new JFrame("AnnotationRelevanceGraph");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        Container contentPane = frame.getContentPane();
        contentPane.setBackground(Color.WHITE);
        contentPane.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        // Construct the helpPanel
        helpPanel = new HelpPanel();
        // Set up first menu
        LoadMenu lm = new LoadMenu(800,20,this);
        JMenuBar menuBar = lm.getMenuBar();
        //JMenuBar menuBar = buildMenu(800,20,this);
        c.gridx = 0;
        c.gridy = 0;
        contentPane.add(menuBar,c);
        c.gridy = 1;
        qs = new QuerySelector(800,20,FILE_PATH);
        querySelector = qs.buildQuerySelectionBar(this);
        contentPane.add(querySelector,c);
        c.gridy = 2;
/*
        graph = new UndirectedSparseGraph<MyNode,MyEdge>();
        layout = new FRLayout<MyNode,MyEdge>(graph, new Dimension(800,800));
        panel = new VisualizationViewer<MyNode,MyEdge>(layout, new Dimension(800,800));
*/
        buildGraph();
        contentPane.add(panel,c);
        //panel.setVisible(false);
        ScalingControl scaler = new CrossoverScalingControl();
        scaler.scale(panel, (float)0.50, panel.getCenter());
        frame.pack();
        frame.setVisible(true);
    }

    public void init() throws IOException {
/*
        layout = new FRLayout<MyNode,MyEdge>(graph, viewArea);
        panel = new VisualizationViewer<MyNode,MyEdge>(layout, viewArea);
        panel.setBackground(Color.WHITE);
        panel.addMouseListener(this);
        DefaultModalGraphMouse<MyNode,MyEdge> gm = new DefaultModalGraphMouse<MyNode,MyEdge>();
        gm.setMode(ModalGraphMouse.Mode.PICKING);
        panel.setGraphMouse(gm);
        Transformer<MyNode, String> pointedNodeNote = new Transformer<MyNode, String>() {
            @Override
            public String transform(MyNode n) {
                return "Document " + n.getLabel();
            }
        };
        panel.setVertexToolTipTransformer(pointedNodeNote);
        DegreeScorer<MyNode> degree = new DegreeScorer<MyNode>(graph);
        Transformer<MyNode, Integer> degrees = new VertexScoreTransformer<MyNode, Integer>(degree);
        VertexShapeSizeAspect<MyNode, MyEdge> vssa = new VertexShapeSizeAspect<MyNode, MyEdge>(graph, degrees);
        panel.getRenderContext().setVertexShapeTransformer(vssa);
        panel.getRenderContext().setVertexLabelTransformer(new Transformer<MyNode, String>() {
            public String transform(MyNode e) {
                return "<html><font size=8><b>"+e.getLabel()+"</b></font></html>";
            }
        });
        panel.getRenderer().getVertexLabelRenderer().setPosition(Renderer.VertexLabel.Position.CNTR);
        vssa.setScaling(true);
        pickedState = panel.getPickedVertexState();
        pickedState.addItemListener(this);
        SeedFillColor<MyNode> seedFillColor = new SeedFillColor<MyNode>(pickedState, nodeColors, seedVertices, visitedVertices);
        panel.getRenderContext().setVertexFillPaintTransformer(seedFillColor);

        JFrame frame = new JFrame("AnnotationRelevanceGraph");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        Container contentPane = frame.getContentPane();
        contentPane.setBackground(Color.WHITE);
        contentPane.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        // Construct the helpPanel
        helpPanel = new HelpPanel();
        // Set up first menu
        LoadMenu lm = new LoadMenu(800,20,this);
        JMenuBar menuBar = lm.getMenuBar();
        //JMenuBar menuBar = buildMenu(800,20,this);
        c.gridx = 0;
        c.gridy = 0;
        contentPane.add(menuBar,c);
        c.gridy = 1;
        qs = new QuerySelector(800,20);
        JPanel querySelector = qs.buildQuerySelectionBar(this);
        contentPane.add(querySelector,c);
        c.gridy = 2;
        contentPane.add(panel,c);
        //panel.setVisible(false);
        ScalingControl scaler = new CrossoverScalingControl();
        scaler.scale(panel, (float)0.50, panel.getCenter());
        frame.pack();
        frame.setVisible(true);
*/
    }

    @Override
    public void mouseClicked(MouseEvent e){
        GraphElementAccessor<MyNode,MyEdge> pickSupport = panel.getPickSupport();
        final MyNode station = pickSupport.getVertex(panel.getGraphLayout(), e.getX(), e.getY());
        if(station != null){
           showPopupMenu(e.getX(), e.getY());
           visitedVertices.add(station);
        }
    }

    public void showPopupMenu(int corX, int corY){
        int infoPanelWidth = 480;
        int infoPanelHeight = 190;
        // Create JPanel
        JPopupMenu infoPanel = new JPopupMenu();
        infoPanel.setOpaque(false);
        infoPanel.setBorder(fullEmptyBorder);
        infoPanel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        infoPanel.setPreferredSize(new Dimension(infoPanelWidth, infoPanelHeight));
        // We have a 3-split pane
        JPanel snippet = new JPanel();
        snippet.setLayout(new GridBagLayout());
        GridBagConstraints cc = new GridBagConstraints();
        JLabel heading = new JLabel("Document snippet:");
        heading.setBorder(lowerMatteBorder);
        heading.setPreferredSize(new Dimension(225, 20));
        heading.setFont(bold);

        cc.gridx = 0;
        cc.gridy = 0;
        cc.weightx = 1;
        cc.weighty = 1;
        cc.fill = GridBagConstraints.HORIZONTAL;
        cc.insets = new Insets(5,5,5,5);
        snippet.add(heading, cc);

        JLabel info = new JLabel("<html>\"Macbeth, upon hearing that Macduff has fled to England, determines to kill Macduff's family. He justifies himself by saying that from now on he will follow his first impulse, because if he had followed his first impulse, Macduff would already be dead.\"</html>");
        info.setFont(italic);
        info.setVerticalAlignment(SwingConstants.TOP);
        info.setHorizontalAlignment(SwingConstants.LEFT);
        //info.setBorder(fullBorder);
        snippet.setPreferredSize(new Dimension(245, infoPanelHeight));
        snippet.setBorder(fullMatteBorder);
        snippet.setOpaque(true);
        cc.gridx = 0;
        cc.gridy = 1;
        cc.weightx = 1;
        cc.weighty = 1;
        cc.fill = GridBagConstraints.HORIZONTAL;
        cc.insets = new Insets(5,5,5,5);
        snippet.add(info,cc);


        JPanel buttonContainer = new JPanel();
        JButton relevant = new JButton("Relevant");
        relevant.setActionCommand("Relevant");
        relevant.addActionListener(this);
        JButton notRelevant = new JButton("Not Relevant");
        notRelevant.addActionListener(this);
        notRelevant.setActionCommand("NotRelevant");
        relevant.setPreferredSize(new Dimension(110, 25));
        notRelevant.setPreferredSize(new Dimension(110, 25));
        relevant.setFont(normal);
        notRelevant.setFont(normal);
        //relevance.setVerticalAlignment(SwingConstants.BOTTOM);

        //buttonContainer.add(fill)
        cc.gridx = 0;
        cc.gridy = 2;
        cc.weighty = 1;
        cc.anchor = GridBagConstraints.PAGE_END;
        buttonContainer.add(relevant, BoxLayout.X_AXIS);
        buttonContainer.add(notRelevant, BoxLayout.X_AXIS);
        //buttonContainer.add(fill);
        snippet.add(buttonContainer,cc);

        c.weightx = 1;
        c.weighty = 1;
        c.gridx = 0;
        c.gridy = 0;
        infoPanel.add(snippet, c);

        JPanel empty = new JPanel();
        empty.setPreferredSize(new Dimension(75,infoPanelHeight));
        empty.setOpaque(false); // added by OP
        empty.setBorder(BorderFactory.createEmptyBorder());
        empty.setBackground(new Color(0,0,0,0));
        c.gridx = 1;
        c.weightx = 1;
        infoPanel.add(empty,c);

        JPanel listRank = new JPanel();
        listRank.setLayout(new GridBagLayout());
        GridBagConstraints lc = new GridBagConstraints();
        listRank.setPreferredSize(new Dimension(150,infoPanelHeight));
        JLabel rankheading = new JLabel("Ranking:");
        rankheading.setBorder(lowerMatteBorder);
        rankheading.setPreferredSize(new Dimension(150, 20));
        rankheading.setFont(bold);

        lc.anchor = GridBagConstraints.NORTH;
        lc.gridx = 0;
        lc.gridy = 0;
        lc.weightx = 1;
        lc.weighty = 1;
        lc.fill = GridBagConstraints.HORIZONTAL;
        lc.insets = new Insets(5,5,5,5);
        listRank.add(rankheading,lc);

        DefaultListModel listModel = new DefaultListModel();
        //Create the list and put it in a scroll pane.
        listModel.addElement("Rank: 4, Doc: 98");
        listModel.addElement("Rank: 5, Doc: 71");
        listModel.addElement("Rank: 6, Doc: 103");
        listModel.addElement("Rank: 7, Doc: 13");
        listModel.addElement("Rank: 6, Doc: 83");
        listModel.addElement("Rank: 9, Doc: 6");
        listModel.addElement("Rank: 10, Doc: 187");
        listModel.addElement("Rank: 11, Doc: 63");
        listModel.addElement("Rank: 12, Doc: 77");
        listModel.addElement("Rank: 13, Doc: 16");
        listModel.addElement("Rank: 14, Doc: 34");
        JList list = new JList(listModel);
        list.setFont(normal);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setSelectedIndex(3);
        list.setVisibleRowCount(4);
        list.addMouseListener(this);
        JScrollPane listScrollPane = new JScrollPane(list,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        listScrollPane.setMinimumSize(new Dimension(130,infoPanelHeight-30));
        lc.insets = new Insets(5,5,5,5);
        lc.gridx = 0;
        lc.gridy = 1;
        lc.weighty = 1;
        lc.anchor = GridBagConstraints.PAGE_START;
        lc.fill = GridBagConstraints.VERTICAL;
        listRank.add(listScrollPane,lc);
        listRank.setOpaque(true);
        listRank.setBorder(fullMatteBorder);

        infoPanel.add(listRank, c);
        infoPanel.show(panel, corX-(int)(infoPanelWidth/1.66), corY-infoPanelHeight);
        infoPanel.revalidate();
        infoPanel.repaint();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String action = e.getActionCommand();
        if(action.equalsIgnoreCase("Relevant")){
            pickedState.pick(currentNodeSelected, true);
            relevantNodes.put(currentNodeSelected.getLabel(), currentNodeSelected);
            seedVertices.add(currentNodeSelected);
        }
        if(action.equalsIgnoreCase("NotRelevant")){
            if(relevantNodes.containsKey(currentNodeSelected.getLabel())){
               relevantNodes.remove(currentNodeSelected.getLabel());
               seedVertices.remove(currentNodeSelected);
            }
        }

        if(action.equalsIgnoreCase("Save")){
            JFileChooser c = new JFileChooser();
            int rVal = c.showSaveDialog(this);
            if (rVal == JFileChooser.APPROVE_OPTION) {
                if(!relevantNodes.isEmpty()){
                    String path   = c.getSelectedFile().getPath();
                    path          = path.replace("\\", "/");
                    File file     = new File(path);
                    FileWriter fw;
                    try {
                        fw = new FileWriter(file.getAbsoluteFile());
                        BufferedWriter bw = new BufferedWriter(fw);
                        for (Map.Entry<String, MyNode> stringMyNodeEntry : relevantNodes.entrySet()) {
                            Map.Entry pairs = (Map.Entry) stringMyNodeEntry;
                            MyNode m = (MyNode)pairs.getValue();
                            bw.write(m.getLabel());
                            bw.newLine();
                            bw.flush();
                        }
                        bw.close();
                        fw.close();
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                }
                else{
                    c.cancelSelection();
                    JOptionPane.showConfirmDialog(null,
                            "No nodes have been selected as being relevant",
                            "Help",
                            JOptionPane.OK_CANCEL_OPTION,
                            JOptionPane.PLAIN_MESSAGE);

                }
            }
            if (rVal == JFileChooser.CANCEL_OPTION) {
            }
        }
        if(action.equalsIgnoreCase("Help")){
            JOptionPane.showConfirmDialog(null,
                    helpPanel.getHelp(),
                    "Help",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE);
        }

        if(action.equalsIgnoreCase("reload")){
            int qcount = qs.getQueryCount();
            int randomInt = (randomGenerator.nextInt(qcount)) + 100;
            if((qs.getQueries()).containsKey(randomInt))
                qs.setJTextFieldText((qs.getQueries()).get(randomInt));
            else{
                int rInt = (randomGenerator.nextInt(qcount)) + 100;
                qs.setJTextFieldText((qs.getQueries()).get(rInt));
            }
        }
        if(action.equalsIgnoreCase("accept")){
            System.out.println("Accepting");
            updateGraph();
        }
    }

    public void updateGraph(){
                this.remove(querySelector);
        this.add(new JButton("HEJHEJHEJ"));
        this.validate();
        this.repaint();
    }

    public void buildGraph(){
        Dimension viewArea = new Dimension(800, 800);
        //graph = createGraph();
        //bg.createGraph(20); // this should be a
        nodeColors = bg.getNodeColors();
        bg.setGraphLayout(bg.getGraph(),viewArea,this,this);
        panel = bg.getPanel();
        layout = bg.getLayout();
        pickedState = bg.getPickedState();
        visitedVertices = bg.getVisitedVertices();
        seedVertices = bg.getSeedVertices();
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
    @Override
    public void itemStateChanged(ItemEvent e) {
           Object subject = e.getItem();
           if (subject instanceof MyNode) {
               MyNode vertex = (MyNode) subject;
               if (pickedState.isPicked(vertex)) {
                   currentNodeSelected = vertex;
               }
          }
    }
}
