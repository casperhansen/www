import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;

public class HelpPanel extends JPanel {
    JPanel help = new JPanel();
    private BufferedImage notVisited;
    private BufferedImage visited;
    private BufferedImage relevant;
    private final int FONT_SIZE = 9;
    private Font normal = new Font("Verdana", Font.PLAIN, FONT_SIZE);

    private void loadImages() throws IOException {
        InputStream imageStreamRed = this.getClass().getResourceAsStream("images/redvertex.PNG");
        notVisited = ImageIO.read(imageStreamRed);
        InputStream imageStreamGreen = this.getClass().getResourceAsStream("images/greenvertex.PNG");
        visited = ImageIO.read(imageStreamGreen);
        InputStream imageStreamPurple = this.getClass().getResourceAsStream("images/purplevertex.PNG");
        relevant = ImageIO.read(imageStreamPurple);
    }

    public HelpPanel() throws IOException {
        loadImages();
        help.setPreferredSize(new Dimension(200,240));
        help.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.insets = new Insets(2,2,2,2);
        JLabel labelNotVisited = new JLabel(new ImageIcon(notVisited));
        help.add(labelNotVisited,c);
        c.anchor = GridBagConstraints.WEST;
        JLabel descriptionNotVisited = new JLabel("<html>The vertex have not been visited</html>");
        descriptionNotVisited.setHorizontalAlignment(SwingConstants.RIGHT);
        descriptionNotVisited.setFont(normal);
        c.gridx = 1;
        help.add(descriptionNotVisited,c);
        c.gridy = 1;
        c.gridx = 0;
        JLabel labelVisited = new JLabel(new ImageIcon(visited));
        help.add(labelVisited,c);
        c.gridx = 1;
        JLabel descriptionVisited = new JLabel("<html>The vertex have been visited</html>");
        descriptionVisited.setHorizontalAlignment(SwingConstants.RIGHT);
        descriptionVisited.setFont(normal);
        help.add(descriptionVisited,c);
        c.gridx = 0;
        c.gridy = 2;
        JLabel labelRelevant = new JLabel(new ImageIcon(relevant));
        help.add(labelRelevant,c);
        c.gridx = 1;
        JLabel descriptionRelevant = new JLabel("<html>The vertex has been deemed relevant</html>");
        descriptionRelevant.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        descriptionRelevant.setFont(normal);
        help.add(descriptionRelevant,c);
        c.gridx = 0;
        c.gridy = 3;
        c.gridwidth = 2;
        c.anchor = GridBagConstraints.CENTER;
        JLabel description = new JLabel();
        description.setFont(normal);
        description.setPreferredSize(new Dimension(200,140));
        description.setText(getHelpDescription());
        help.add(description,c);
    }

    private String getHelpDescription(){
        return "<html>Each vertex is a document. Upon clicking on a vertex, a snippet of the document represtend by the vertex" +
                " will be presented on the left side of the vertex and the documents location in the retrieved list on the right." +
                " If you think this document is relevant, press the \"Relevant\" button. IF you change your mind about the vertex" +
                " being relevant, simply click the vertex again and press the \"Not Relevant\" button.</html>";
    }

    public JPanel getHelp(){
        return help;
    }
}
