import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Ellipse2D;
import java.util.Iterator;
import java.util.Vector;
import javax.swing.*;

public class GlassGamePane2 extends JPanel implements MouseListener {

    private JPanel statusPanel;
    private JLabel healthLabel;
    private JPanel header;
    private Vector<Vertex> v;

    public GlassGamePane2(Vector<Vertex> vertices) {
        this.v = vertices;
        createGlassPane();
    }

    private void createGlassPane() {
        setLayout(null);
        createComponents();
        //add(header, BorderLayout.NORTH);
        //statusPanel.add(healthLabel);
        //add(statusPanel, BorderLayout.NORTH);
        addMouseListener(this);
    }

    private void createComponents() {
        header = new JPanel();
        JLabel left = new JLabel("Select query", SwingConstants.RIGHT);
        left.setPreferredSize(new Dimension(325,30));
        JComboBox queryDropDown = new JComboBox();
        queryDropDown.setPreferredSize(new Dimension(150, 20));
        queryDropDown.addItem("Query 1");
        queryDropDown.addItem("Query 2");
        queryDropDown.addItem("Query 3");
        queryDropDown.addItem("Query 4");
        queryDropDown.addItem("Query 5");
        queryDropDown.addItem("Query 6");
        queryDropDown.addItem("Query 7");

        JLabel right = new JLabel();
        right.setPreferredSize(new Dimension(325,30));
        header.add(left);
        header.add(queryDropDown);
        header.add(right);

        //statusPanel = new JPanel(new GridLayout(2, 6));
        //healthLabel = new JLabel("Player Health:");
        //healthLabel.setForeground(Color.RED);
        //healthLabel.setBackground(Color.BLUE);

    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D ourGraphics = (Graphics2D) g;
        ourGraphics.setColor(Color.BLACK);

        ourGraphics.translate(245, 267);
        ourGraphics.scale(0.4,0.4);

        Iterator it = v.iterator();
        while(it.hasNext()){
            Vertex n = (Vertex)it.next();
            Ellipse2D oval = new Ellipse2D.Double(n.getNodex(), n.getNodey(),25.0, 25.0);
            ourGraphics.fill(oval);
        }


/*
        //g.setColor(Color.red);
        //Draw an oval in the panel  
        //g.drawOval(10, 10, getWidth() - 20, getHeight() - 20);
*/
        /*
        Iterator it = v.iterator();
        while(it.hasNext()){
            Vertex n = (Vertex)it.next();
            ourGraphics.fillOval((int)(n.getNodex()), (int)(n.getNodey()), 25, 25);
        }
*/
    }

    @Override
    public void mouseClicked(MouseEvent me) {

    }

    @Override
    public void mousePressed(MouseEvent me) {

    }

    @Override
    public void mouseReleased(MouseEvent me) {
    }

    @Override
    public void mouseEntered(MouseEvent me) {
    }

    @Override
    public void mouseExited(MouseEvent me) {
    }
}