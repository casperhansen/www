public class DocumentsAssessed {
    private int document;
    private String query;

    public DocumentsAssessed(int doc, String q){
        this.document = doc;
        this.query = q;
    }

    public int getDocument(){
        return document;
    }

    public String getQuery(){
        return query;
    }
}
