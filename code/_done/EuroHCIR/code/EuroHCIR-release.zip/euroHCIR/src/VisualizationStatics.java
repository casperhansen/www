import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionListener;

public class VisualizationStatics {
    private final int FONT_SIZE                 = 10;
    private Font normal                         = new Font("Verdana", Font.PLAIN, FONT_SIZE);
    private Font italic                         = new Font("Verdana", Font.ITALIC, FONT_SIZE);
    private Font bold                           = new Font("Verdana", Font.BOLD, FONT_SIZE);
    private Border lowerMatteBorder             = BorderFactory.createMatteBorder(0, 0, 1, 0, Color.darkGray);
    private Border fullMatteBorder              = BorderFactory.createMatteBorder(1, 1, 1, 1, Color.darkGray);
    private Border fullEmptyBorder              = new EmptyBorder(0, 0, 0, 0);
    private int screenXSize;
    private int screenYSize;
    private int POPUP_WIDTH                     = 1000; // was 1000
    private int POPUP_HEIGHT                    = 360;  // was 360
    private int POPUP_SNIPPET_WIDTH             = (int)(POPUP_WIDTH/2.5);

    public VisualizationStatics(){
        Toolkit tk = Toolkit.getDefaultToolkit();
        screenXSize = ((int) tk.getScreenSize().getWidth());
        screenYSize = ((int) tk.getScreenSize().getHeight());
    }

    public int getPopUpSnippetWidth(){
        return POPUP_SNIPPET_WIDTH;
    }

    public int getPopupWidth(){
       return POPUP_WIDTH;
    }

    public int getPopupHeight(){
        return POPUP_HEIGHT;
    }

    public int getScreenXSize(){
        return screenXSize;
    }

    public int getScreenYSize(){
        return screenYSize;
    }

    public Font getNormalFont(){
        return normal;
    }

    public Font getItalicFont(){
        return italic;
    }

    public Font getBoldFont(){
        return bold;
    }

    public Border getLowerMatteBorder(){
        return lowerMatteBorder;
    }

    public Border getFullMatteBorder(){
        return fullMatteBorder;
    }

    public Border getFullEmptyBorder(){
        return fullEmptyBorder;
    }

    public JPanel createEmptySpace(){
        JPanel empty = new JPanel();
        empty.setPreferredSize(new Dimension(getPopupWidth()/10,getPopupHeight()));
        empty.setOpaque(false);
        empty.setBorder(BorderFactory.createEmptyBorder());
        empty.setBackground(new Color(0,0,0,0));
        return empty;
    }

    public JPanel createButtonContainer(ActionListener al){
        JPanel buttonContainer = new JPanel();
        JButton relevant = new JButton("Relevant");
        relevant.setActionCommand("Relevant");
        relevant.addActionListener(al);
        JButton notRelevant = new JButton("Not Relevant");
        notRelevant.addActionListener(al);
        notRelevant.setActionCommand("NotRelevant");
        relevant.setPreferredSize(new Dimension(115, 25));
        notRelevant.setPreferredSize(new Dimension(115, 25));
        relevant.setFont(getNormalFont());
        notRelevant.setFont(getNormalFont());
        buttonContainer.add(relevant, BoxLayout.X_AXIS);
        buttonContainer.add(notRelevant, BoxLayout.X_AXIS);
        return buttonContainer;
    }

    public JLabel createHeading(String text){
        JLabel rankheading = new JLabel(text);
        rankheading.setBorder(getLowerMatteBorder());
        rankheading.setPreferredSize(new Dimension(getPopUpSnippetWidth(), 20));
        rankheading.setFont(getBoldFont());
        return rankheading;
    }
}
