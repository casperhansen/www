import javax.swing.*;
import java.awt.Graphics;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class MyNode extends JPanel{
    private String label;
    private int identifier;

      public MyNode(String label, int id) {
            this.label = label;
            this.identifier = id;
      }

        @Override
        public String toString() {
            return label;
        }

        public int getID(){
            return identifier;
        }
        public String getLabel(){
            return label;
        }
}