import edu.uci.ics.jung.visualization.picking.PickedState;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;
import java.util.Set;

public class ButtonListener extends JPanel implements ActionListener {
    private HelpPanel hpanel;
    private PickedState<MyNode> pickedNodes;
    private Map<String, MyNode> rNodes;
    private Set<MyNode> seedV;
    private MyNode cNode;
    private ObjectPasser op;
    public ButtonListener(HelpPanel p, ObjectPasser opasser){
      this.hpanel = p;
      this.op = opasser;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String action = e.getActionCommand();


    }

    public void setOp(ObjectPasser o){
        this.op = o;
    }
}
