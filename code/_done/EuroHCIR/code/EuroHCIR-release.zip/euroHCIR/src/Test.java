import edu.uci.ics.jung.graph.DirectedSparseGraph;
import edu.uci.ics.jung.graph.Graph;

import javax.swing.*;
import javax.swing.UIManager.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class Test implements ActionListener {
    private Font normal = new Font("Verdana", Font.PLAIN, 10);
    private HashMap<Integer, String> queries = new HashMap<Integer, String>();
    Random randomGenerator = new Random();
    private JTextField jtf;
    private int QUERYCOUNT;

    public static void createGraph() throws IOException {
        Graph<MyNode,MyEdge> g = new DirectedSparseGraph<MyNode,MyEdge>();
        BufferedReader br;
        String sCurrentLine;
        br = new BufferedReader(new FileReader("C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2013\\workshop\\Data\\test.edgelist.txt"));
        int id = 1;
        HashMap<Integer, Integer> nodeMap = new HashMap<Integer, Integer>();
        while((sCurrentLine = br.readLine()) != null){
            String[] ar  = sCurrentLine.split(" ");
            int from     = Integer.parseInt(ar[0]);
            if(!nodeMap.containsKey(from)){
                nodeMap.put(from, id);
                id++;
            }
        }
        br.close();
        br = new BufferedReader(new FileReader("C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2013\\workshop\\Data\\test.edgelist.txt"));
        String currentLine;
        id = 1;
        while((currentLine=br.readLine()) != null){
            String[] ar  = currentLine.split(" ");
            /* Need to decipher between what we can add edges to and isolated vertices
             * If we have a to and from vertex
             */
            if(ar.length == 2){
                int from     = nodeMap.get(Integer.parseInt(ar[0]));
                int to       = nodeMap.get(Integer.parseInt(ar[1]));
                MyNode f     = new MyNode(Integer.toString(from), from);
                MyNode t     = new MyNode(Integer.toString(to), to);
                g.addEdge(new MyEdge("e"+Integer.toString(id)), f, t);
                id++;
            }else{
                /*
                 * We have just an isolated node
                 */
                int from     = nodeMap.get(Integer.parseInt(ar[0]));
                g.addVertex(new MyNode(Integer.toString(from), from));
            }
        }
        br.close();

        Iterator it = nodeMap.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pairs = (Map.Entry)it.next();
            System.out.println(pairs.getKey() + " = " + pairs.getValue());
            it.remove(); // avoids a ConcurrentModificationException
        }
/*
               String[] ar  = sCurrentLine.split(" ");
               MyNode f     = new MyNode(ar[0], Integer.parseInt(ar[0]));
               MyNode t     = new MyNode(ar[1], Integer.parseInt(ar[1]));
               nodeColors.put(f, softred);
               nodeColors.put(t, softred); // We risk overwrite but this is just initialization so no diff.
               g.addEdge(new MyEdge("e"+Integer.toString(id)), f, t);
               id++;
*/



    }

    public static void main(String[] args) throws FileNotFoundException {
        Random randomGenerator = new Random();
        for(int i = 0; i < 100; i++){
            int randomInt = randomGenerator.nextInt(2);
            System.out.println(randomInt);
        }
        /*
           String test = "this is a test to see if things get highlighted";
           String[] terms = {"test", "things", "highlighted"};
           for (String term : terms) {
                test = test.replaceAll(term, "<b>"+term+"</b>");
           }
           System.out.println(test);
        */
    }

    public Test(){
        try {
            readQueries();
        } catch (IOException e) {
            e.printStackTrace();
        }
        JFrame frame = new JFrame("querytest");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(new Dimension(400,30));
        Container contentPane = frame.getContentPane();

        JPanel container = new JPanel();
        container.setSize(new Dimension(400,30));
        container.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        jtf = new JTextField();
        Dimension JTEXTFIELD_DIM = new Dimension(200, 30);
        jtf.setPreferredSize(JTEXTFIELD_DIM);
        int randomInt = (randomGenerator.nextInt(QUERYCOUNT)) + 100;
        String query = queries.get(randomInt);
        jtf.setText(query);
        jtf.setEnabled(false);
        jtf.setFont(normal);

        // Reload button
        JButton reload = new JButton("New query");
        reload.setActionCommand("reload");
        reload.setPreferredSize(new Dimension(100, 30));
        reload.addActionListener(this);
        reload.setFont(normal);

        // Accept button
        JButton accept = new JButton("Load query");
        accept.setActionCommand("accept");
        accept.setPreferredSize(new Dimension(100,30));
        accept.addActionListener(this);
        accept.requestFocusInWindow();
        accept.setFont(normal);

        c.gridx = 0;
        c.gridy = 0;
        container.add(jtf,c);
        c.gridx = 1;
        container.add(accept,c);
        c.gridx = 2;
        container.add(reload,c);
        contentPane.add(container);
        frame.getRootPane().setDefaultButton(accept);
        frame.pack();
        frame.setVisible(true);
    }


    public void readQueries() throws IOException {
        BufferedReader br = null;
        String sCurrentLine;
        br = new BufferedReader(new FileReader("C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2013\\workshop\\Data\\queries\\all.queries.txt"));
        while ((sCurrentLine = br.readLine()) != null) {
            String[] ar = sCurrentLine.split(":");
            int foo = Integer.parseInt(ar[0]);
            queries.put(foo, ar[1]);
            QUERYCOUNT++;
        }
        br.close();
    }

    public HashMap<Integer, String> getQueries(){
        return queries;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String action = e.getActionCommand();
        if(action.equalsIgnoreCase("reload")){
            int randomInt = (randomGenerator.nextInt(QUERYCOUNT)) + 100;
            if(queries.containsKey(randomInt))
                jtf.setText(queries.get(randomInt));
            else{
                int rInt = (randomGenerator.nextInt(QUERYCOUNT)) + 100;
                jtf.setText(queries.get(rInt));
            }
        }
        if(action.equalsIgnoreCase("accept")){
           System.out.println("Accepted!");
        }
    }
}