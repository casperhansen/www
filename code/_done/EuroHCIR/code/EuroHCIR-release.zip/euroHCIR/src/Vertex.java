/**
 * Created with IntelliJ IDEA.
 * User: casper
 * Date: 18-05-13
 * Time: 00:11
 * To change this template use File | Settings | File Templates.
 */
public class Vertex {
    private int nodeid;
    private String nodelabel;
    private double nodex;
    private double nodey;

    public Vertex(int id, String label, double x, double y){
        this.nodeid = id;
        this.nodelabel = label;
        this.nodex = x;
        this.nodey = y;
    }

    public int getNodeid(){
        return nodeid;
    }

    public String getNodelabel(){
        return nodelabel;
    }

    public double getNodex(){
        return nodex;
    }

    public double getNodey(){
        return nodey;
    }

}
