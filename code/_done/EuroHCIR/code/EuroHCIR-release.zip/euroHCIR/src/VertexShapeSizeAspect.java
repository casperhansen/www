import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.visualization.decorators.AbstractVertexShapeTransformer;
import org.apache.commons.collections15.Transformer;

import java.awt.*;

public class VertexShapeSizeAspect<MyNode,MyEdge>
        extends AbstractVertexShapeTransformer<MyNode>
        implements Transformer<MyNode,Shape> {

    protected boolean stretch = false;
    protected boolean scale = false;
    protected boolean funny_shapes = false;
    protected Transformer<MyNode,Integer> degrees;
    protected Graph<MyNode,MyEdge> graph;

    public VertexShapeSizeAspect(Graph<MyNode,MyEdge> graphIn, Transformer<MyNode,Integer> dgs)
    {
        this.graph = graphIn;
        this.degrees = dgs;
        setSizeTransformer(new Transformer<MyNode,Integer>() {

            public Integer transform(MyNode v) {
                if (scale)
                    return (degrees.transform(v) * 8) + 20; // was + 10
                else
                    return 50;

            }});
        setAspectRatioTransformer(new Transformer<MyNode,Float>() {

            public Float transform(MyNode v) {
                if (stretch) {
                    return (float)(graph.inDegree(v) + 1) /
                            (graph.outDegree(v) + 1);
                } else {
                    return 1.0f;
                }
            }});
    }

    public void setStretching(boolean stretch)
    {
        this.stretch = stretch;
    }

    public void setScaling(boolean scale)
    {
        this.scale = scale;
    }

    public void useFunnyShapes(boolean use)
    {
        this.funny_shapes = use;
    }

    public Shape transform(MyNode v)
    {
        if (funny_shapes)
        {
            if (graph.degree(v) < 5)
            {
                int sides = Math.max(graph.degree(v), 3);
                return factory.getRegularPolygon(v, sides);
            }
            else
                return factory.getRegularStar(v, graph.degree(v));
        }
        else
            return factory.getEllipse(v);
    }
}