import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import javax.swing.*;
import java.awt.Robot;
import edu.uci.ics.jung.algorithms.layout.GraphElementAccessor;
import edu.uci.ics.jung.visualization.control.CrossoverScalingControl;
import edu.uci.ics.jung.visualization.control.ScalingControl;
import edu.uci.ics.jung.visualization.picking.PickedState;
import edu.uci.ics.jung.algorithms.layout.FRLayout;
import edu.uci.ics.jung.visualization.VisualizationViewer;


public class Exp2 extends JPanel implements MouseListener, ActionListener, ItemListener {
   /*
    * Variables w. initialization
    */
    private BuildGraph bg                       = new BuildGraph();
    private VisualizationStatics vs             = new VisualizationStatics();
    private Dimension viewArea                  = new Dimension(1300, 1000);
    private Map<String, MyNode> relevantNodes   = new HashMap<String, MyNode>();
    private Set<MyNode> seedVertices            = new HashSet<MyNode>();
    private Set<MyNode> visitedVertices         = new HashSet<MyNode>();
    private Vector<Integer> nodesVisisted       = new Vector<Integer>();
    private Map<Integer, Long> nodesTimeSpent   = new HashMap<Integer, Long>();
   /*
    * Variables for the graph
    */
    private VisualizationViewer<MyNode,MyEdge> panel;
    private FRLayout<MyNode,MyEdge> layout;
    private MyNode currentNodeSelected;
    private PickedState<MyNode> pickedState;
    private Map<MyNode,Color> nodeColors;
   /*
    * Variables for SWING
    */
    private Long timeStarted;
    private Long timeEnded;
    private String[] queryTerms;
    private DefaultListModel listModel;
    private JList list;
    private JPopupMenu infoPanel;
    private HelpPanel helpPanel;
    private JButton dummy = new JButton();
    private JPanel empty;
    private JPanel buttonContainer;
    private JScrollPane listScrollPane;
    private String[] snippets;
    private String COLLECTION;
    private String QUERY;
    private String WEB_PATH;
    private String SNIPPET_PATH;
    private String RANK_PATH;
    private Robot robot;

    public Exp2() throws IOException {

        helpPanel = new HelpPanel();
    }

    public void setSnippets() throws IOException{
        snippets = new String[20];
        BufferedReader br = new BufferedReader(new FileReader(SNIPPET_PATH));
        String currentLine;
        int id = 0;
        while((currentLine = br.readLine()) != null){
            snippets[id] = currentLine;
            id++;
        }
    }

    public void createButtonContainer(){
        buttonContainer = new JPanel();
        JButton relevant = new JButton("Relevant");
        relevant.setActionCommand("Relevant");
        relevant.addActionListener(this);
        JButton notRelevant = new JButton("Not Relevant");
        notRelevant.addActionListener(this);
        notRelevant.setActionCommand("NotRelevant");
        relevant.setPreferredSize(new Dimension(115, 25));
        notRelevant.setPreferredSize(new Dimension(115, 25));
        relevant.setFont(vs.getNormalFont());
        notRelevant.setFont(vs.getNormalFont());
        buttonContainer.add(relevant, BoxLayout.X_AXIS);
        buttonContainer.add(notRelevant, BoxLayout.X_AXIS);
    }

    public void createEmptySpace(){
        empty = new JPanel();
        empty.setPreferredSize(new Dimension(vs.getPopupWidth()/10,vs.getPopupHeight()));
        empty.setOpaque(false);
        empty.setBorder(BorderFactory.createEmptyBorder());
        empty.setBackground(new Color(0,0,0,0));
    }

    public void setRanks() throws IOException {
        listModel = new DefaultListModel();
        System.out.println(RANK_PATH);
        BufferedReader br = new BufferedReader(new FileReader(RANK_PATH));
        String currentLine;
        int rank = 1;
        while((currentLine = br.readLine()) != null){
            listModel.addElement("Rank: " + rank + ", Documentname: " + currentLine);
            rank++;
        }
        list = new JList(listModel);
        list.setFont(vs.getNormalFont());
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setVisibleRowCount(4);
        list.setCellRenderer(new MyListRenderer());
        list.setEnabled(false);
        listScrollPane = new JScrollPane(list,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        listScrollPane.setMinimumSize(new Dimension(vs.getPopUpSnippetWidth(),vs.getPopupHeight()-30));
    }


    public Exp2(QueryObject qo) throws IOException {
        this.helpPanel    = new HelpPanel();
        this.COLLECTION   = qo.getCollection();
        this.WEB_PATH     = qo.getWebgraphPath();
        this.SNIPPET_PATH = qo.getSnippetpath();
        this.RANK_PATH    = qo.getRankPath();
        this.QUERY        = qo.getQuery();
        this.queryTerms   = QUERY.split(" ");
        try {
            robot = new Robot();
        } catch (AWTException e) {
            e.printStackTrace();
        }
        setRanks();
        //setSnippets();
        createEmptySpace();
        createButtonContainer();
    }

    public VisualizationViewer<MyNode,MyEdge> getViz(){
        buildGraph();
        ScalingControl scaler = new CrossoverScalingControl();
        scaler.scale(panel, (float)0.5, panel.getCenter());
        return panel;
    }

    @Override
    public void mouseClicked(MouseEvent e){
        GraphElementAccessor<MyNode,MyEdge> pickSupport = panel.getPickSupport();
        final MyNode station = pickSupport.getVertex(panel.getGraphLayout(), e.getX(), e.getY());
        if(station != null){
            nodesVisisted.add(station.getID());
            Point p     = checkBounds(e.getX(), e.getY());
            timeStarted = System.currentTimeMillis();
            showPopupMenu(p.x,p.y);
            visitedVertices.add(station);
        }
    }

    public void showPopupMenu(int corX, int corY){
        // Create JPanel
        infoPanel = new JPopupMenu();
        infoPanel.setOpaque(false);
        infoPanel.setBorder(vs.getFullEmptyBorder());
        infoPanel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        infoPanel.setPreferredSize(new Dimension(vs.getPopupWidth(), vs.getPopupHeight()));
        // We have a 3-split pane
        JPanel snippet = new JPanel();
        snippet.setLayout(new GridBagLayout());
        GridBagConstraints cc = new GridBagConstraints();
        JLabel heading = new JLabel("Document snippet:");
        heading.setBorder(vs.getLowerMatteBorder());
        heading.setPreferredSize(new Dimension(vs.getPopUpSnippetWidth(), 20));
        heading.setFont(vs.getBoldFont());
        cc.anchor  = GridBagConstraints.NORTH;
        cc.gridx   = 0;
        cc.gridy   = 0;
        cc.weightx = 1;
        cc.weighty = 1;
        cc.fill    = GridBagConstraints.HORIZONTAL;
        cc.insets  = new Insets(2,2,2,2);
        snippet.add(heading, cc);

        JLabel textsnippet = new JLabel("<html>\"Macbeth, upon hearing that Macduff has fled to England, determines to kill Macduff's family. He justifies himself by saying that from now on he will follow his first impulse, because if he had followed his first impulse, Macduff would already be dead.\"</html>");
        /*
         * Begin untested code (waiting for snippets)
         * int snippetid = currentNodeSelected.getID();
         * String currentNodeSnippet = snippets[snippetid-1]; // 0-indexed
         * JLabel info = new JLabel("<html>"+highLightQueryWords(currentNodeSnippet, queryTerms)+"</html>); // case sensitivity in method
         */
        textsnippet.setFont(vs.getItalicFont());
        textsnippet.setHorizontalAlignment(SwingConstants.LEFT);
        snippet.setPreferredSize(new Dimension(vs.getPopUpSnippetWidth(), vs.getPopupHeight()));
        snippet.setBorder(vs.getFullMatteBorder());
        snippet.setOpaque(true);

        cc.gridx = 0;
        cc.gridy = 1;
        cc.weightx = 1.0;
        cc.weighty = 1.0;
        cc.fill = GridBagConstraints.HORIZONTAL;
        cc.insets = new Insets(5,5,5,5);
        snippet.add(textsnippet,cc);

        //buttonContainer.add(fill)
        cc.gridx = 0;
        cc.gridy = 2;
        cc.weighty = 1;
        cc.anchor = GridBagConstraints.PAGE_END;
        //buttonContainer.add(fill);
        snippet.add(buttonContainer,cc);

        c.weightx = 1;
        c.weighty = 1;
        c.gridx = 0;
        c.gridy = 0;
        infoPanel.add(snippet, c);

        c.gridx = 1;
        c.weightx = 1;
        infoPanel.add(empty,c);

        JPanel listRank = new JPanel();
        listRank.setLayout(new GridBagLayout());
        GridBagConstraints lc = new GridBagConstraints();
        listRank.setPreferredSize(new Dimension(vs.getPopUpSnippetWidth(),vs.getPopupHeight()));
        JLabel rankheading = new JLabel("Ranking:");
        rankheading.setBorder(vs.getLowerMatteBorder());
        rankheading.setPreferredSize(new Dimension(vs.getPopUpSnippetWidth(), 20));
        rankheading.setFont(vs.getBoldFont());

        lc.anchor = GridBagConstraints.NORTH;
        lc.gridx = 0;
        lc.gridy = 0;
        lc.weightx = 1;
        lc.weighty = 1;
        lc.fill = GridBagConstraints.HORIZONTAL;
        lc.insets = new Insets(5,5,5,5);
        listRank.add(rankheading,lc);

        list.setSelectedIndex(currentNodeSelected.getID()-1);
        lc.insets = new Insets(5,5,5,5);
        lc.gridx = 0;
        lc.gridy = 1;
        lc.weighty = 1;
        lc.anchor = GridBagConstraints.PAGE_START;
        lc.fill = GridBagConstraints.VERTICAL;
        listRank.add(listScrollPane,lc);
        listRank.setOpaque(true);
        listRank.setBorder(vs.getFullMatteBorder());

        infoPanel.add(listRank, c);
        infoPanel.show(panel,corX-(vs.getPopupWidth()/2), corY);
        //infoPanel.show(panel,corX, corY);
        infoPanel.revalidate();
        infoPanel.repaint();
        infoPanel.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String action = e.getActionCommand();

        if(action.equalsIgnoreCase("Relevant")){
            timeEnded = System.currentTimeMillis();
            updateTimeSpent();
            pickedState.pick(currentNodeSelected, true);
            relevantNodes.put(currentNodeSelected.getLabel(), currentNodeSelected);
            seedVertices.add(currentNodeSelected);
            infoPanel.setVisible(false);
            System.gc();
        }
        if(action.equalsIgnoreCase("NotRelevant")){
            timeEnded = System.currentTimeMillis();
            updateTimeSpent();
            if(relevantNodes.containsKey(currentNodeSelected.getLabel())){
                relevantNodes.remove(currentNodeSelected.getLabel());
                seedVertices.remove(currentNodeSelected);
            }
            infoPanel.setVisible(false);
            System.gc();
        }

        if(action.equalsIgnoreCase("Help")){
            JOptionPane.showConfirmDialog(null,
                    helpPanel.getHelp(),
                    "Help",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE);
        }

        robot.mousePress(InputEvent.BUTTON1_MASK);
    }

    public void buildGraph(){

        //bg.createGraph(20); // this should be a

        nodeColors = bg.getNodeColors();
        bg.setGraphLayout(bg.getGraph(),viewArea,this,this);
        panel = bg.getPanel();
        this.layout = bg.getLayout();
        pickedState = bg.getPickedState();
        visitedVertices = bg.getVisitedVertices();
        seedVertices = bg.getSeedVertices();
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
    @Override
    public void itemStateChanged(ItemEvent e) {
        Object subject = e.getItem();
        if (subject instanceof MyNode) {
            MyNode vertex = (MyNode) subject;
            if (pickedState.isPicked(vertex)) {
                currentNodeSelected = vertex;
            }
        }
    }

    private class MyListRenderer extends DefaultListCellRenderer {
        public Component getListCellRendererComponent( JList list,
                                                       Object value, int index, boolean isSelected,
                                                       boolean cellHasFocus ) {
            Component c = super.getListCellRendererComponent( list, value, index,
                    isSelected, cellHasFocus );
            c.setEnabled(currentNodeSelected.getID() == index+1);
            c.setFont(c.getFont().deriveFont(Font.BOLD));
            return c;
        }
    }

    public String highLightQueryWords(String text, String[] terms){
        for(String term : terms){
            text = text.toLowerCase().replaceAll(term.toLowerCase(), "<b>"+term.toLowerCase()+"</b>");
        }
        return text;
    }

    public Point checkBounds(int x, int y){
        int y_slack = 100;

        if(x - (vs.getPopupWidth()/2) < 0){
            System.out.println("X is below 0");
        }
        if(x + (vs.getPopupWidth()/2) > viewArea.width){
            System.out.println("X is above screen_x_size");
        }
        System.out.println("y: " + y + ", viewArea.height: " + viewArea.height);
        if(y + (vs.getPopupHeight()) > viewArea.height-y_slack){
            System.out.println("Y falls out of the bottom");
        }
        System.out.println("**************************");
 /*
        if(x - (vs.getPopupWidth()/2) < 0){
           int tmp = x - (vs.getPopupWidth()/2);
           System.out.println("x: " + x + ", y: " + y + ", (vs.getPopupWidth()/2): " + (vs.getPopupWidth()/2));
           System.out.println("X below 0");
           return (new Point(x + Math.abs(tmp),y));
        }

        System.out.println("x: " + x + ", y: " + y + ", vs.getScreenYSize()/2: " + vs.getScreenYSize()/2 + ", vs.getPopupHeight: " + vs.getPopupHeight());
        if(y + (vs.getPopupHeight()) > vs.getScreenYSize()-100){
            System.out.println("x: " + x + ", y: " + y + ", vs.getScreenYSize()/2: " + vs.getScreenYSize()/2 + ", vs.getPopupHeight: " + vs.getPopupHeight());
        }

        if(x + (vs.getPopupWidth()/2) > this.getSize().getWidth()){
            System.out.println("X exceeded");
        }
*/
/*
        int pWidth  = vs.getPopupWidth();
        int pHeight = vs.getPopupHeight();
        System.out.println("x: " + x + ", y: " + y);
        System.out.println("pWidth: " + pWidth + ", pHeight: " + pHeight);
        System.out.println("Screen XSize: " + vs.getScreenXSize() + ", Screen YSize: " + vs.getScreenYSize());
        System.out.println("this.getSize().getWidth(): " + panel.getSize().getWidth() + ", this.getSize().getHeight()" + panel.getSize().getHeight());
*/
        return (new Point(x,y));
    }


    public Map<String, MyNode> getRelevantNodes(){
        return relevantNodes;
    }

    public Vector<Integer> getNodesVisisted(){
        return nodesVisisted;
    }

    public Map<Integer, Long> getNodesTimeSpent(){
        return nodesTimeSpent;
    }

    public void updateTimeSpent(){
        long diff = (timeEnded-timeStarted);
        if(nodesTimeSpent.containsKey(currentNodeSelected.getID())){
            nodesTimeSpent.put(currentNodeSelected.getID(), nodesTimeSpent.get(currentNodeSelected.getID()) + diff);
        }else{
            nodesTimeSpent.put(currentNodeSelected.getID(), diff);
        }
    }
}