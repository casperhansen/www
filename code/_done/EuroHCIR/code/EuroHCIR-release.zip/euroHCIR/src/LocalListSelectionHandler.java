import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

class LocalListSelectionHandler implements ListSelectionListener {
    private int listIndexSelected;

    public void valueChanged(ListSelectionEvent e) {
        listIndexSelected = -1;
        ListSelectionModel lsm = (ListSelectionModel)e.getSource();
        if (!lsm.isSelectionEmpty()) {
            // Find out which indexes are selected.
            int minIndex = lsm.getMinSelectionIndex();
            int maxIndex = lsm.getMaxSelectionIndex();
            for (int i = minIndex; i <= maxIndex; i++) {
                if (lsm.isSelectedIndex(i)) {
                    if(!e.getValueIsAdjusting()){
                        System.out.println("Index " + i + " was selected");
                        listIndexSelected = i;
                    }
                    break;
                }
            }
        }
    }
}