// All Rights Reserved. Copyright (C) Kazuo Misue (2010)

import java.awt.*;
import java.awt.event.*;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;
import java.util.Vector;

import javax.swing.*;

import edu.uci.ics.jung.algorithms.layout.GraphElementAccessor;
import edu.uci.ics.jung.visualization.control.CrossoverScalingControl;
import edu.uci.ics.jung.visualization.control.ModalGraphMouse;
import edu.uci.ics.jung.visualization.control.ScalingControl;
import edu.uci.ics.jung.visualization.decorators.PickableVertexPaintTransformer;
import edu.uci.ics.jung.visualization.picking.PickedState;
import org.apache.commons.collections15.Transformer;

import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;

import edu.uci.ics.jung.algorithms.layout.FRLayout;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.UndirectedSparseGraph;
import edu.uci.ics.jung.visualization.VisualizationViewer;
import edu.uci.ics.jung.visualization.control.DefaultModalGraphMouse;

public class Sample6c2 implements MouseListener{
    private GlassGamePane m_glassPane;
    private JPopupMenu snippet;
    private final int docInfoViewWidth = 220;
    private final int docInfoViewHeight = 170;
    private Font f = new Font("Verdana", Font.PLAIN, 10);
    private Font fat = new Font("Verdana", Font.BOLD, 10);
    private Border b = BorderFactory.createMatteBorder(0, 0, 1, 0, Color.darkGray);
    private Border empty = new EmptyBorder(0, 0, 5, 0);
    private CompoundBorder border = new CompoundBorder(b, empty);

    private VisualizationViewer<MyNode,MyEdge> panel;

    public static void main(String[] args){
        new Sample6c2();
    }

    public Sample6c2(){
        init();
    }

    public void init() {
        Dimension viewArea = new Dimension(800, 800);
        Graph<MyNode,MyEdge> graph = createGraph();
        FRLayout<MyNode,MyEdge> layout = new FRLayout<MyNode,MyEdge>(graph, viewArea);
        panel = new VisualizationViewer<MyNode,MyEdge>(layout, viewArea);
        panel.setBackground(Color.WHITE);
        panel.addMouseListener(this);
        DefaultModalGraphMouse<MyNode,MyEdge> gm = new DefaultModalGraphMouse<MyNode,MyEdge>();
        gm.setMode(ModalGraphMouse.Mode.PICKING);
        panel.setGraphMouse(gm);

        JFrame frame = new JFrame("Annotation");
        frame.setSize(1000,1000);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        Container contentPane = frame.getContentPane();
        contentPane.setBackground(Color.WHITE);
        contentPane.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        // Set up the "header"

        JPanel header = new JPanel();
        JLabel left = new JLabel("Select query2",SwingConstants.RIGHT);
        left.setPreferredSize(new Dimension(325,30));
        JComboBox queryDropDown = new JComboBox();
        queryDropDown.setPreferredSize(new Dimension(150, 20));
        queryDropDown.addItem("Query 1");
        queryDropDown.addItem("Query 2");
        queryDropDown.addItem("Query 3");
        queryDropDown.addItem("Query 4");
        queryDropDown.addItem("Query 5");
        queryDropDown.addItem("Query 6");
        queryDropDown.addItem("Query 7");

        JLabel right = new JLabel();
        right.setPreferredSize(new Dimension(325,30));
        header.add(left);
        header.add(queryDropDown);
        header.add(right);
        header.setBorder(border);

        c.gridx = 0;
        c.gridy = 0;
        contentPane.add(header,c);
        c.gridy = 1;
        //c.insets = new Insets(50,50,50,50);
        contentPane.add(panel,c);
        ScalingControl scaler = new CrossoverScalingControl();
        //scaler.scale(panel, (float)0.40, panel.getCenter());

        layout.initialize();
        Collection<MyNode> nodes = graph.getVertices();
        Iterator itr = nodes.iterator();
        Vector<Vertex> v = new Vector<Vertex>();
        while (itr.hasNext()) {
            MyNode tmp = (MyNode)itr.next();
            v.add(new Vertex(tmp.getID(),tmp.getLabel(),layout.getX(tmp), layout.getY(tmp)+36));
            //System.out.println((int)layout.getX(tmp) + ", " + (int)layout.getY(tmp));
        }

        m_glassPane = new GlassGamePane(v);//(v);
        frame.setGlassPane(m_glassPane);
        //set opaque to false, i.e. make transparent
        m_glassPane.setOpaque(false);
        m_glassPane.setVisible(true);

        frame.pack();
        frame.setVisible(true);
    }

    @Override
    public void mouseClicked(MouseEvent e){
    }

    @Override
    public void mousePressed(MouseEvent e) {
//        System.out.println(e.getX() + ", " + e.getY());
    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    private static Graph<MyNode,MyEdge> createGraph() {
        Graph<MyNode,MyEdge> g = new UndirectedSparseGraph<MyNode,MyEdge>();
        MyNode n1 = new MyNode("n1",1);
        MyNode n2 = new MyNode("n2",2);
        MyNode n3 = new MyNode("n3",3);
        MyNode n4 = new MyNode("n4",4);
        MyNode n5 = new MyNode("n5",5);
        MyNode n6 = new MyNode("n6",6);
        MyNode n7 = new MyNode("n7",7);
        MyNode n8 = new MyNode("n8",8);
        MyNode n9 = new MyNode("n9",9);
        MyNode n10 = new MyNode("n10",10);
        MyNode n11 = new MyNode("n11",11);
        MyNode n12 = new MyNode("n12",12);
        MyNode n13 = new MyNode("n13",13);
        MyNode n14 = new MyNode("n14",14);
        MyNode n15 = new MyNode("n15",15);
        MyNode n16 = new MyNode("n16",16);
        MyNode n17 = new MyNode("n17",17);
        MyNode n18 = new MyNode("n18",18);
        MyNode n19 = new MyNode("n19",19);
        MyNode n20 = new MyNode("n20",20);
        g.addEdge(new MyEdge("e1"), n1, n2);
        g.addEdge(new MyEdge("e2"), n2, n3);
        g.addEdge(new MyEdge("e3"), n3, n4);
        g.addEdge(new MyEdge("e4"), n4, n1);
        g.addEdge(new MyEdge("e5"), n5, n6);
        g.addEdge(new MyEdge("e6"), n6, n7);
        g.addEdge(new MyEdge("e7"), n7, n8);
        g.addEdge(new MyEdge("e8"), n8, n5);
        g.addEdge(new MyEdge("e9"), n1, n5);
        g.addEdge(new MyEdge("e10"), n2, n6);
        g.addEdge(new MyEdge("e11"), n3, n7);
        g.addEdge(new MyEdge("e12"), n4, n8);
        g.addEdge(new MyEdge("e13"), n8, n10);
        g.addEdge(new MyEdge("e14"), n1, n10);
        g.addEdge(new MyEdge("e15"), n9, n17);
        g.addEdge(new MyEdge("e16"), n7, n14);
        g.addEdge(new MyEdge("e17"), n3, n12);
        g.addEdge(new MyEdge("e18"), n11, n3);
        g.addEdge(new MyEdge("e19"), n20, n13);
        g.addEdge(new MyEdge("e20"), n5, n19);
        g.addEdge(new MyEdge("e21"), n19, n14);
        g.addEdge(new MyEdge("e22"), n16, n8);
        g.addEdge(new MyEdge("e23"), n18, n4);
        g.addEdge(new MyEdge("e23"), n15, n4);
        return g;
    }
}