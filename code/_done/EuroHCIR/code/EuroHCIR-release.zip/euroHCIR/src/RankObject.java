public class RankObject {
    private int ID;
    private String NAME;

    public RankObject(int id, String name){
       this.ID = id;
       this.NAME = name;
    }

    public int getID(){
        return ID;
    }

    public String getName(){
        return NAME;
    }
}
