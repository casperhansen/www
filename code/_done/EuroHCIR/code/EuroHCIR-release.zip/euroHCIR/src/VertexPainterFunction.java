import edu.uci.ics.jung.visualization.picking.PickedInfo;
import edu.uci.ics.jung.visualization.picking.PickedState;
import org.apache.commons.collections15.Transformer;

import java.awt.*;
import java.util.Iterator;
import java.util.Set;
import java.util.Vector;

public class VertexPainterFunction<MyNode> implements Transformer<MyNode, Paint>
{
    /**
     * A collection of nodes that were picked
     */
    private PickedState<MyNode> pickedInfo;
    private Vector<MyNode> v;

    public VertexPainterFunction(PickedState<MyNode> pickedInfo_, Vector<MyNode> vs)
    {
        pickedInfo = pickedInfo_;
        v = vs;
        System.out.println(vs.size());
        for (MyNode v1 : v) {
            pickedInfo.pick(v1, true);
        }
        Set<MyNode> s = pickedInfo.getPicked();
        Iterator it = s.iterator();
        while(it.hasNext()){
            MyNode m = (MyNode)it.next();
            System.out.println(m.toString());
        }
    }
    public Paint transform(MyNode node)
    {
        float alpha = 1.0f;
        if (pickedInfo.isPicked(node)) //for picked nodes make them blue.
        {
            System.out.println(node.toString());
            return new Color(0, 0, 1f, alpha);
        }

        return (new Color(0.25f,0.75f,0.75f,alpha)); //for other nodes make them this color (cyan-ish).
    }
}