import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created with IntelliJ IDEA.
 * User: casper
 * Date: 17-05-13
 * Time: 09:30
 * To change this template use File | Settings | File Templates.
 */
public class RelevanceListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
        String actionName = e.getActionCommand();
        if(actionName.equals("Relevance")){

        }
    }
}
