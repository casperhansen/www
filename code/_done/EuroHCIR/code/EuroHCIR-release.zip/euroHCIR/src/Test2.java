import edu.uci.ics.jung.algorithms.layout.StaticLayout;
import edu.uci.ics.jung.graph.DirectedSparseGraph;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.visualization.VisualizationViewer;
import edu.uci.ics.jung.visualization.control.*;
import org.apache.commons.collections15.Transformer;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Point2D;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

public class Test2 extends JFrame {

    public static void main(String[] args) throws IOException {

        JFrame frame = new JFrame("Test2");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        Container contentPane = frame.getContentPane();
        Graph<MyNode,MyEdge> g = new DirectedSparseGraph<MyNode,MyEdge>();
        String path = "C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2013\\workshop\\Data\\test.edgelist.txt";
        BufferedReader br = new BufferedReader(new FileReader(path));
        String currentLine;
        int id = 1;
        while((currentLine=br.readLine()) != null){
            String[] ar  = currentLine.split(" ");
            /* Need to decipher between what we can add edges to and isolated vertices
             * If we have a to and from vertex
             */
            if(ar.length == 2){
                int from     = Integer.parseInt(ar[0]);
                int to       = Integer.parseInt(ar[1]);
                MyNode f     = new MyNode(Integer.toString(from), from);
                MyNode t     = new MyNode(Integer.toString(to), to);
                g.addEdge(new MyEdge("e"+Integer.toString(id)), f, t);
                id++;
            }else{
                /*
                 * We have just an isolated node
                 */
                int from     = Integer.parseInt(ar[0]);
                MyNode f     = new MyNode(Integer.toString(from), from);
                g.addVertex(f);
            }
        }
        br.close();
        final int viewX = 600;
        final int viewY = 600;
        Dimension viewArea = new Dimension(viewX,viewY);
        Transformer<MyNode, Point2D> locationTransformer = new Transformer<MyNode, Point2D>() {

            @Override
            public Point2D transform(MyNode vertex) {
                double x = viewX/2 + viewY/2.5 * Math.cos(Math.toRadians(vertex.getID() * 18));
                double y = viewY/2 + viewY/2.5 * Math.sin(Math.toRadians(vertex.getID() * 18));
                return new Point2D.Double(x, y);
            }
        };

        int graphVertexCount = g.getVertexCount();
        //FRLayout<MyNode,MyEdge> layout = new FRLayout<MyNode,MyEdge>(g, viewArea);
        StaticLayout<MyNode, MyEdge> layout = new StaticLayout<MyNode, MyEdge>(g, locationTransformer);
        VisualizationViewer<MyNode, MyEdge> panel = new VisualizationViewer<MyNode, MyEdge>(layout, viewArea);
        panel.setPreferredSize(viewArea);
        panel.setMinimumSize(viewArea);
        panel.getRenderContext().setVertexLabelTransformer(new Transformer<MyNode, String>() {
            public String transform(MyNode e) {
                return "<html><font size=7><b>" + e.getLabel() + "</b></font></html>";
            }
        });
        panel.getRenderer().getVertexLabelRenderer().setPosition(edu.uci.ics.jung.visualization.renderers.Renderer.VertexLabel.Position.CNTR);

        PluggableGraphMouse gm = new PluggableGraphMouse();
        gm.add(new MyPickingGraphMousePlugin<MyNode, MyEdge>());
        panel.setGraphMouse(gm);

/*
        DefaultModalGraphMouse<MyNode,MyEdge> gm = new DefaultModalGraphMouse<MyNode,MyEdge>();

        gm.setMode(ModalGraphMouse.Mode.PICKING);
        panel.setGraphMouse(gm);
*/
        ScalingControl scaler = new CrossoverScalingControl();
        scaler.scale(panel, (float) 0.80, panel.getCenter());
        contentPane.add(panel);
        frame.pack();
        frame.setVisible(true);
    }
}
