/*
 * Copyright (c) 1995, 2008, Oracle and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *   - Neither the name of Oracle or the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

import edu.uci.ics.jung.algorithms.layout.FRLayout;
import edu.uci.ics.jung.algorithms.layout.GraphElementAccessor;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.UndirectedSparseGraph;
import edu.uci.ics.jung.visualization.VisualizationViewer;
import edu.uci.ics.jung.visualization.control.CrossoverScalingControl;
import edu.uci.ics.jung.visualization.control.DefaultModalGraphMouse;
import edu.uci.ics.jung.visualization.control.ModalGraphMouse;
import edu.uci.ics.jung.visualization.control.ScalingControl;
import edu.uci.ics.jung.visualization.renderers.*;
import edu.uci.ics.jung.visualization.renderers.Renderer;
import org.apache.commons.collections15.Transformer;

import java.io.IOException;
import java.util.Random;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.event.*;

/* ListDemo.java requires no other files. */
public class ListViewViz extends JPanel implements ListSelectionListener, ActionListener, MouseListener {
    Graph<MyNode,MyEdge> g;
    FRLayout<MyNode,MyEdge> layout;
    private VisualizationViewer<MyNode,MyEdge> panel;
    private ListSelectionModel ls;
    private QuerySelector qs;
    private int selectedQueryID = -1;
    private final int FONT_SIZE                 = 10;
    private final Color softred                 = new Color(238,221,130);
    private final Color softgreen               = new Color(152,251,152);
    private final Color softblue                = new Color(224,255,255);
    private Font normal                         = new Font("Verdana", Font.PLAIN, FONT_SIZE);
    private Font italic                         = new Font("Verdana", Font.ITALIC, FONT_SIZE);
    private Font bold                           = new Font("Verdana", Font.BOLD, FONT_SIZE);
    private Border lowerMatteBorder             = BorderFactory.createMatteBorder(0, 0, 1, 0, Color.darkGray);
    private Border fullMatteBorder              = BorderFactory.createMatteBorder(1, 1, 1, 1, Color.darkGray);
    private Border fullEmptyBorder              = new EmptyBorder(0, 0, 0, 0);
    private Point cursorLoc;
    private JList list;
    private DefaultListModel listModel;

    public void addComponentToPane(Container pane) throws IOException {
        super.repaint();
        super.setLayout(new BorderLayout());
        pane.setLayout(new BorderLayout());
        //pane.setPreferredSize(new Dimension(800, 800));
        //pane.setLayout(new GridBagLayout());
        //GridBagConstraints c = new GridBagConstraints();
/*
        LoadMenu lm = new LoadMenu(800,20,this);
        JMenuBar menuBar = lm.getMenuBar();
        c.gridx = 0;
        c.gridy = 0;
        pane.add(menuBar,c);

        c.gridy = 1;
        qs = new QuerySelector(800,20);
        JPanel querySelector = qs.buildQuerySelectionBar(this);
        selectedQueryID = 0;
        pane.add(querySelector,c);
        c.gridy = 2;
        c.fill = GridBagConstraints.VERTICAL;
*/

        listModel = new DefaultListModel();
        populateList();

        //Create the list and put it in a scroll pane.
        list = new JList(listModel);
        list.setPreferredSize(new Dimension(300,500));
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setSelectedIndex(0);
        list.clearSelection();
        list.addListSelectionListener(this);
        list.setVisibleRowCount(10);
        list.addMouseListener(this);
        ls = list.getSelectionModel();
        //ls.addListSelectionListener(new SharedListSelectionHandler());
        DefaultListCellRenderer renderer =
                (DefaultListCellRenderer)list.getCellRenderer();
        renderer.setHorizontalAlignment(JLabel.CENTER);
        JScrollPane listScrollPane = new JScrollPane(list);
        //listScrollPane.setPreferredSize(new Dimension(800,760));
        pane.add(listScrollPane, BorderLayout.CENTER);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {
        cursorLoc = new Point(e.getX(), e.getY());
        System.out.println(e.getX() + ", " + e.getY());
    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    //This method is required by ListSelectionListener.
    public void valueChanged(ListSelectionEvent e) {
        System.out.println("Value Changed");
        if (!e.getValueIsAdjusting()) {
            //showPopupMenu();
            showPop();
        }
    }

    public ListViewViz(){};

    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    private static void createAndShowGUI() throws IOException {
        JFrame frame = new JFrame("OrderedListView");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        //Create and set up the content pane.
        ListViewViz lvv = new ListViewViz();
        lvv.addComponentToPane(frame.getContentPane());

        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    createAndShowGUI();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void showPop(){
        JPopupMenu infoPanel = new JPopupMenu();
        infoPanel.setOpaque(false);
        infoPanel.setBorder(fullEmptyBorder);
        infoPanel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        JPanel snippet = new JPanel();
        JLabel heading = new JLabel("Document snippet:");
        snippet.add(heading);
        c.gridx = 0;
        c.gridy = 0;
        infoPanel.add(snippet, c);
        infoPanel.show(infoPanel, cursorLoc.x, cursorLoc.y);
    }

    public void populateList(){
        for(int i = 0; i < 20; i++){
            listModel.addElement("Rank: "+i+", Documentname: " + "abcd");
        }
    }

    public void showPopupMenu(){
        int infoPanelWidth = 480;
        int infoPanelHeight = 190;
        JPopupMenu infoPanel = new JPopupMenu();
        infoPanel.setOpaque(false);
        infoPanel.setBorder(fullEmptyBorder);
        infoPanel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        infoPanel.setPreferredSize(new Dimension(infoPanelWidth, infoPanelHeight));
        // We have a 3-split pane
        JPanel snippet = new JPanel();
        snippet.setLayout(new GridBagLayout());
        GridBagConstraints cc = new GridBagConstraints();
        JLabel heading = new JLabel("Document snippet:");
        heading.setBorder(lowerMatteBorder);
        heading.setPreferredSize(new Dimension(225, 20));
        heading.setFont(bold);

        cc.gridx = 0;
        cc.gridy = 0;
        cc.weightx = 1;
        cc.weighty = 1;
        cc.fill = GridBagConstraints.HORIZONTAL;
        cc.insets = new Insets(5,5,5,5);
        snippet.add(heading, cc);

        JLabel info = new JLabel("<html>\"Macbeth, upon hearing that Macduff has fled to England, determines to kill Macduff's family. He justifies himself by saying that from now on he will follow his first impulse, because if he had followed his first impulse, Macduff would already be dead.\"</html>");
        info.setFont(italic);
        info.setVerticalAlignment(SwingConstants.TOP);
        info.setHorizontalAlignment(SwingConstants.LEFT);
        //info.setBorder(fullBorder);
        snippet.setPreferredSize(new Dimension(225, infoPanelHeight));
        snippet.setBorder(fullMatteBorder);
        snippet.setOpaque(true);
        cc.gridx = 0;
        cc.gridy = 1;
        cc.weightx = 1;
        cc.weighty = 1;
        cc.fill = GridBagConstraints.HORIZONTAL;
        cc.insets = new Insets(5,5,5,5);
        snippet.add(info,cc);


        JPanel buttonContainer = new JPanel();
        JButton relevant = new JButton("Relevant");
        relevant.setActionCommand("Relevant");
        relevant.addActionListener(this);
        JButton notRelevant = new JButton("Not Relevant");
        notRelevant.addActionListener(this);
        notRelevant.setActionCommand("NotRelevant");
        relevant.setPreferredSize(new Dimension(100, 25));
        notRelevant.setPreferredSize(new Dimension(100, 25));
        relevant.setFont(normal);
        notRelevant.setFont(normal);
        //relevance.setVerticalAlignment(SwingConstants.BOTTOM);

        //buttonContainer.add(fill)
        cc.gridx = 0;
        cc.gridy = 2;
        cc.weighty = 1;
        cc.anchor = GridBagConstraints.PAGE_END;
        buttonContainer.add(relevant, BoxLayout.X_AXIS);
        buttonContainer.add(notRelevant, BoxLayout.X_AXIS);
        //buttonContainer.add(fill);
        snippet.add(buttonContainer,cc);

        c.weightx = 1;
        c.weighty = 1;
        c.gridx = 0;
        c.gridy = 0;
        infoPanel.add(snippet, c);

        JPanel empty = new JPanel();
        empty.setPreferredSize(new Dimension(75,infoPanelHeight));
        empty.setOpaque(false); // added by OP
        empty.setBorder(BorderFactory.createEmptyBorder());
        empty.setBackground(new Color(0,0,0,0));
        c.gridx = 1;
        c.weightx = 1;
        infoPanel.add(empty,c);

        JPanel listRank = new JPanel();
        listRank.setLayout(new GridBagLayout());
        GridBagConstraints lc = new GridBagConstraints();
        listRank.setPreferredSize(new Dimension(150,infoPanelHeight));
        JLabel rankheading = new JLabel("Graph:");
        rankheading.setBorder(lowerMatteBorder);
        rankheading.setPreferredSize(new Dimension(150, 20));
        rankheading.setFont(bold);

        lc.anchor = GridBagConstraints.NORTH;
        lc.gridx = 0;
        lc.gridy = 0;
        lc.weightx = 1;
        lc.weighty = 1;
        lc.fill = GridBagConstraints.HORIZONTAL;
        lc.insets = new Insets(2,2,2,2);
        listRank.add(rankheading,lc);

        Dimension viewArea = new Dimension(140, infoPanelHeight-20);
        g = constructGraph();
        layout = new FRLayout<MyNode,MyEdge>(g, viewArea);
        panel = new VisualizationViewer<MyNode,MyEdge>(layout, viewArea);
        panel.setPreferredSize(viewArea);
        panel.setMinimumSize(viewArea);
        panel.getRenderContext().setVertexLabelTransformer(new Transformer<MyNode, String>() {
            public String transform(MyNode e) {
                return "<html><font size=8><b>"+e.getLabel()+"</b></font></html>";
            }
        });

        panel.addMouseListener(this);
        DefaultModalGraphMouse<MyNode,MyEdge> gm = new DefaultModalGraphMouse<MyNode,MyEdge>();
        gm.setMode(ModalGraphMouse.Mode.PICKING);
        panel.setGraphMouse(gm);
        panel.getRenderer().getVertexLabelRenderer().setPosition(Renderer.VertexLabel.Position.CNTR);

        ScalingControl scaler = new CrossoverScalingControl();
        scaler.scale(panel, (float)0.50, panel.getCenter());
        lc.gridx = 0;
        lc.gridy = 1;
        lc.fill = GridBagConstraints.VERTICAL;
        lc.insets = new Insets(2,2,2,2);
        listRank.add(panel, lc);

        listRank.setOpaque(true);
        listRank.setBorder(fullMatteBorder);
        c.gridx = 2;
        c.weighty = 1;
        c.fill = GridBagConstraints.VERTICAL;
        c.weightx = 0.2;
        infoPanel.add(listRank, c);
        //infoPanel.show(this, (cursorLoc.x/3), cursorLoc.y);
        infoPanel.show(this,cursorLoc.x, cursorLoc.y);
        infoPanel.setVisible(true);
        //infoPanel.show(this, 200,200);
        //infoPanel.show(this, (int)(cursorLoc.x - 275), cursorLoc.y);
        infoPanel.revalidate();
        infoPanel.repaint();

    }

    private Graph<MyNode,MyEdge> constructGraph(){
        g = new UndirectedSparseGraph<MyNode,MyEdge>();

        Random randomGenerator = new Random();
        int randomInt = randomGenerator.nextInt(100);
        if(randomInt > 50){
            MyNode n1 = new MyNode("1",1);
            MyNode n2 = new MyNode("2",2);
            MyNode n3 = new MyNode("3",3);
            MyNode n4 = new MyNode("4",4);
            MyNode n5 = new MyNode("5",5);
            g.addEdge(new MyEdge("e1"), n3, n2);
            g.addEdge(new MyEdge("e2"), n3, n1);
            g.addEdge(new MyEdge("e3"), n3, n4);
            g.addEdge(new MyEdge("e4"), n3, n5);
        }else{
            MyNode n1 = new MyNode("1",1);
            MyNode n2 = new MyNode("2",2);
            MyNode n3 = new MyNode("3",3);
            MyNode n4 = new MyNode("4",4);
            g.addEdge(new MyEdge("e1"), n3, n2);
            g.addEdge(new MyEdge("e2"), n3, n1);
            g.addEdge(new MyEdge("e3"), n3, n4);
        }
        return g;
    }
}