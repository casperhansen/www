import java.io.*;

public class ExtractColumns {
    /*
     * ALEX:
     * You must always include 0 as the first entry in COLUMNS. 0 corresponds to the first column, 1 to the second
     * column, 2 to the third column and so on
     *
     * To compile the code:
     * javac ExtractColumns.java
     *
     * To run the code:
     * java ExtractColumns /path/to/csv/file.csv /path/to/outputdir/
     */
    private static int[] COLUMNS = {0,1,2,3,4};
    public static void main(String[] args) throws IOException {

        BufferedReader br = new BufferedReader(new FileReader(args[0]));
        String currentLine;
        String[] headers = new String[100];
        int firstline  = 0;
        while((currentLine = br.readLine()) != null){
               if(firstline == 0){
                  headers = currentLine.split(";");
                  firstline++;
               }else{

               String[] tmp = currentLine.split(";");
               String st = "";
               for(int i = 0; i < COLUMNS.length-1; i++){
                   st = st+headers[COLUMNS[i]]+"\n"+tmp[COLUMNS[i]]+"\n";
               }
               st = st+headers[COLUMNS[COLUMNS.length-1]]+"\n"+tmp[COLUMNS[COLUMNS.length-1]];

               File file = new File(args[1]+tmp[0]+".txt");
               FileWriter fw = new FileWriter(file.getAbsoluteFile());
               BufferedWriter bw = new BufferedWriter(fw);
               bw.write(st);
               bw.close();

             }
        }
    }
}
