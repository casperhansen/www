import java.io.*;

public class ToTrecFormat {

    public static void main(String[] args) throws IOException {
        new ToTrecFormat();
    }

    public ToTrecFormat() throws IOException {
        FileWriter fw = new FileWriter("C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2013\\workshop\\Data\\queries\\trec.2012.queries.151-200.trec_format");
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write("<parameter>\n");
        bw.write("<index>/data/local/workspace/calioma/myIndexFieldClueweb/</index>\n" +
                "<count>20</count>");
        bw.newLine();
        bw.flush();
        BufferedReader br = null;
        String sCurrentLine;
        br = new BufferedReader(
             new FileReader(
             "C:\\Casper\\Universitet\\PhD\\Articles\\2013\\SIGIR2013\\workshop\\Data\\queries\\trec.2012.queries.151-200.txt"));
        while ((sCurrentLine = br.readLine()) != null) {
            String[] ar = sCurrentLine.split(":");
            String toWrite = "<query> <number>" + ar[0] + "</number> <text> #combine(" + ar[1] + ")</text> </query> ";
            bw.write(toWrite);
            bw.newLine();
            bw.flush();
        }
        br.close();
        bw.write("<parameters>");
        bw.flush();
        bw.close();
        fw.close();
    }

}
