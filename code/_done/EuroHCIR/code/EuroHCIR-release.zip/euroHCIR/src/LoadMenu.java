import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

public class LoadMenu {
    private JMenuBar menuBar;
    public LoadMenu(int width, int height, ActionListener bl){
        menuBar = new JMenuBar();
        menuBar.setPreferredSize(new Dimension(width,height));
        JMenu fileMenu = new JMenu("  Application  ");
        menuBar.add(fileMenu);
        // Add buttons to the menu
        JMenuItem saveResults = new JMenuItem("Close application", KeyEvent.VK_T);
        saveResults.setActionCommand("Exit");
        saveResults.getAccessibleContext().setAccessibleDescription(
                "Exits the application");
        fileMenu.add(saveResults);
        saveResults.addActionListener(bl);
/*
        JMenu helpMenu = new JMenu("  Help  ");
        JMenuItem about = new JMenuItem("About");
        about.setActionCommand("Help");
        about.addActionListener(bl);
        helpMenu.add(about);
        menuBar.add(helpMenu);
        */
    }

    public JMenuBar getMenuBar(){
        return menuBar;
    }

}
