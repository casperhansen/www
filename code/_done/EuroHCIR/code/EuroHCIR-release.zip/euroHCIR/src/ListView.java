import edu.uci.ics.jung.algorithms.layout.*;
import edu.uci.ics.jung.algorithms.scoring.DegreeScorer;
import edu.uci.ics.jung.algorithms.scoring.util.VertexScoreTransformer;
import edu.uci.ics.jung.graph.DirectedSparseGraph;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.UndirectedSparseGraph;
import edu.uci.ics.jung.visualization.VisualizationViewer;
import edu.uci.ics.jung.visualization.control.CrossoverScalingControl;
import edu.uci.ics.jung.visualization.control.ScalingControl;
import org.apache.commons.collections15.Transformer;
import javax.swing.*;
import javax.swing.SpringLayout;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Point2D;
import java.io.*;
import java.util.*;


public class ListView extends JPanel implements ListSelectionListener, MouseListener, ActionListener {
    private Set<Integer> relevantIndexes        = new HashSet<Integer>();
    private VisualizationStatics vs             = new VisualizationStatics();
    private Vector<Integer> nodesVisisted       = new Vector<Integer>();
    private Map<Integer, MyNode> nodesMap       = new HashMap<Integer, MyNode>();
    private Map<Integer, Long> nodesTimeSpent   = new HashMap<Integer, Long>();
    private final Color softred                 = new Color(238,221,130);
    private String[] cluewebfilenames           = new String[20];
    private Map<String, String> snippetMap      = new HashMap<String, String>();
    private Map<Integer, String> rankMap        = new HashMap<Integer, String>();
    private Set<String> queryTerms              = new HashSet<String>();
    private BuildGraph BG;
    private int graphVertexCount;
    private int selectedListIndex;
    private QueryObject queryObject;
    private DefaultListModel listModel;
    private VisualizationViewer<MyNode, MyEdge> panel;
    private Map<Integer, String> NIDCLUEWEB;
    private Map<String, Vector<Integer>> NODEOUTLINKS;
    private JList list;
    private JPanel pane;
    private JPanel empty;
    private Point cursorLoc;
    private JPopupMenu infoPanel;
    private HelpPanel helpPanel;
    private Long timeStarted;
    private Long timeEnded;
    private JPanel buttonContainer;
    private JLabel rankheading;
    private JLabel heading;
    private String[] snippets;
    private String COLLECTION;
    private String QUERY;
    private String WEB_PATH;
    private String SNIPPET_PATH;

    private String RANK_PATH;
    private String QUERYNUMBER;

    public ListView(QueryObject qo, Map<String, Vector<Integer>> nodeoutlinks, Map<Integer, String> nidclueweb, BuildGraph bg) throws IOException {
        this.queryObject  = qo;
        this.helpPanel    = new HelpPanel();
        this.COLLECTION   = qo.getCollection();
        this.WEB_PATH     = qo.getWebgraphPath();
        this.SNIPPET_PATH = qo.getSnippetpath();
        this.RANK_PATH    = qo.getRankPath();
        this.QUERY        = qo.getQuery();
        this.QUERYNUMBER  = qo.getQueryNumber();
        String[] qt       = QUERY.split(" ");
        for (String q : qt){
            queryTerms.add(q);
        }

        this.NIDCLUEWEB   = nidclueweb;
        this.NODEOUTLINKS = nodeoutlinks;
        this.BG           = bg;
        setupUI();
        buttonContainer = vs.createButtonContainer(this);
        empty           = vs.createEmptySpace();
        rankheading     = vs.createHeading("Graph:");
        heading         = vs.createHeading("Document snippet:");
    }

    public void loadSnippets(){
        File folder = new File(SNIPPET_PATH);
        File[] listOfFiles = folder.listFiles();
        assert listOfFiles != null;
        for (File f : listOfFiles) {
            if (f.isFile()) {
                String cluewebfilepath = SNIPPET_PATH+f.getName();
                BufferedReader br = null;
                try {
                    String sCurrentLine;
                    br = new BufferedReader(new FileReader(cluewebfilepath));
                    while((sCurrentLine = br.readLine()) != null) {
                        //Trim extension
                        String cluwebname = (f.getName()).substring(0, (f.getName()).lastIndexOf("."));
                        snippetMap.put(cluwebname, sCurrentLine);
                    }
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                    System.err.println("GraphView:loadSnippets(): Error reading file " + cluewebfilepath);
                }
            }
        }
    }

    public void setupUI() throws IOException {
/*
        pane = new JPanel();
        pane.setPreferredSize(new Dimension(vs.getScreenXSize(), vs.getScreenYSize()));
        listModel = new DefaultListModel();
        JList list = new JList(listModel);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setSelectedIndex(0);
        list.clearSelection();
        list.addMouseListener(this);
        list.addListSelectionListener(this);
        list.setVisibleRowCount(40);
        list.setCellRenderer(new MyListRenderer());
        DefaultListCellRenderer renderer =
                (DefaultListCellRenderer) list.getCellRenderer();
        renderer.setHorizontalAlignment(JLabel.CENTER);
        JScrollPane listScrollPane = new JScrollPane(list);
        listScrollPane.setVisible(true);
        listScrollPane.setPreferredSize(new Dimension(vs.getScreenXSize(),vs.getScreenYSize()));
        pane.add(listScrollPane);
*/

        pane = new JPanel();
        pane.setPreferredSize(new Dimension(vs.getScreenXSize(), vs.getScreenYSize()));
        listModel = new DefaultListModel();
        BufferedReader br = new BufferedReader(new FileReader(RANK_PATH));
        String currentLine;
        int rank = 1;
        while((currentLine = br.readLine()) != null){
            cluewebfilenames[rank-1] = currentLine;
            rankMap.put(rank,currentLine);
            listModel.addElement("Rank: " + rank + ", Documentname: " + currentLine);
            rank++;
        }
        list = new JList(listModel);
        list.setFont(vs.getNormalFont());
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.clearSelection();
        list.addMouseListener(this);
        list.addListSelectionListener(this);
        list.setVisibleRowCount(40);
        list.setCellRenderer(new MyListRenderer());
        DefaultListCellRenderer renderer =
                (DefaultListCellRenderer) list.getCellRenderer();
        renderer.setHorizontalAlignment(JLabel.CENTER);
        JScrollPane listScrollPane = new JScrollPane(list);
        listScrollPane.setVisible(true);
        listScrollPane.setPreferredSize(new Dimension(vs.getScreenXSize(),vs.getScreenYSize()));
        pane.add(listScrollPane);
        loadSnippets();
        buildGraphVisualization();
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
        if(e.getValueIsAdjusting()){
            timeStarted = System.currentTimeMillis();
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

        Object o = e.getSource();
        if(o instanceof JList){
           JList theList = (JList) o;
           selectedListIndex = theList.getSelectedIndex();
           nodesVisisted.add(selectedListIndex);
           cursorLoc = new Point(e.getX(), e.getY());
           showPopupMenu();
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {


    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String action = e.getActionCommand();

        if(action.equalsIgnoreCase("Relevant")){
            timeEnded = System.currentTimeMillis();
            updateTimeSpent();
            relevantIndexes.add(selectedListIndex);
            infoPanel.setVisible(false);
            System.gc();
        }
        if(action.equalsIgnoreCase("NotRelevant")){
            timeEnded = System.currentTimeMillis();
            updateTimeSpent();
            if(relevantIndexes.contains(selectedListIndex)){
               relevantIndexes.remove(selectedListIndex);
            }
            infoPanel.setVisible(false);
            System.gc();
        }

        if(action.equalsIgnoreCase("Help")){
            JOptionPane.showConfirmDialog(null,
                    helpPanel.getHelp(),
                    "Help",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE);
        }
    }

    public void showPopupMenu(){
        int infoPanelWidth = vs.getPopupWidth();
        int infoPanelHeight = vs.getPopupHeight();
        infoPanel = new JPopupMenu();
        infoPanel.setOpaque(false);
        infoPanel.setBorder(vs.getFullEmptyBorder());
        infoPanel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        infoPanel.setPreferredSize(new Dimension(infoPanelWidth, infoPanelHeight));
        // We have a 3-split pane
        JPanel snippet = new JPanel();
        snippet.setLayout(new GridBagLayout());
        GridBagConstraints cc = new GridBagConstraints();

        cc.anchor = GridBagConstraints.NORTH;
        cc.gridx = 0;
        cc.gridy = 0;
        cc.weightx = 1;
        cc.weighty = 1;
        cc.fill = GridBagConstraints.HORIZONTAL;
        cc.insets = new Insets(2,2,2,2);
        snippet.add(heading, cc);

        String currentNodeSnippet = snippetMap.get(rankMap.get(selectedListIndex+1)); // to offset ranking starting at 1
        JLabel info = new JLabel("<html>"+highLightQueryWords(currentNodeSnippet, queryTerms)+"</html>"); // case sensitivity in method
        info.setFont(vs.getItalicFont());
        info.setVerticalAlignment(SwingConstants.TOP);
        info.setHorizontalAlignment(SwingConstants.LEFT);
        snippet.setPreferredSize(new Dimension((int)(infoPanelWidth/2.5), infoPanelHeight));
        //snippet.setPreferredSize(new Dimension((int)(infoPanelWidth/2.5), (int)(infoPanelHeight/2.5)));
        snippet.setBorder(vs.getFullMatteBorder());
        snippet.setOpaque(true);
        cc.gridx = 0;
        cc.gridy = 1;
        cc.weightx = 1;
        cc.weighty = 1;
        cc.fill = GridBagConstraints.HORIZONTAL;
        cc.insets = new Insets(5,5,5,5);
        snippet.add(info,cc);

        cc.gridx = 0;
        cc.gridy = 2;
        cc.weighty = 1;
        cc.anchor = GridBagConstraints.PAGE_END;
        snippet.add(buttonContainer,cc);

        c.weightx = 1;
        c.weighty = 1;
        c.gridx = 0;
        c.gridy = 0;
        infoPanel.add(snippet, c);

        c.gridx = 1;
        c.weightx = 1;
        infoPanel.add(empty,c);

        JPanel listRank = new JPanel();
        listRank.setLayout(new GridBagLayout());
        GridBagConstraints lc = new GridBagConstraints();
        //listRank.setPreferredSize(new Dimension((int)(infoPanelWidth/2.5),infoPanelHeight));
        listRank.setPreferredSize(new Dimension((int)(infoPanelWidth/2),infoPanelHeight));

        lc.anchor = GridBagConstraints.NORTH;
        lc.gridx = 0;
        lc.gridy = 0;
        lc.weightx = 1;
        lc.weighty = 1;
        lc.fill = GridBagConstraints.HORIZONTAL;
        lc.insets = new Insets(2,2,2,2);
        listRank.add(rankheading,lc);

        lc.gridx = 0;
        lc.gridy = 1;
        lc.fill = GridBagConstraints.VERTICAL;
        lc.insets = new Insets(2,2,2,2);
        listRank.add(panel, lc);

        listRank.setOpaque(true);
        listRank.setBorder(vs.getFullMatteBorder());
        c.gridx = 2;
        c.weighty = 1;
        c.fill = GridBagConstraints.VERTICAL;
        c.weightx = 0.2;
        infoPanel.add(listRank, c);
        infoPanel.show(pane,cursorLoc.x-(vs.getPopupWidth()/2), cursorLoc.y+50);
        infoPanel.revalidate();
        infoPanel.repaint();
        infoPanel.setVisible(true);
    }

    public void buildGraphVisualization(){

        final int viewX = (int)(vs.getPopupWidth()/2)-10;
        final int viewY = vs.getPopupHeight()-20;
        Dimension viewArea = new Dimension(viewX,viewY);
/*
        Transformer<MyNode, Point2D> locationTransformer = new Transformer<MyNode, Point2D>() {

            @Override
            public Point2D transform(MyNode vertex) {
                double x = viewX/2 + viewY/2.5 * Math.cos(Math.toRadians(vertex.getID() * 18));
                double y = viewY/2 + viewY/2.5 * Math.sin(Math.toRadians(vertex.getID() * 18));
                return new Point2D.Double(x, y);
            }
        };
*/
        Graph<MyNode,MyEdge> graph = createGraph();
        graphVertexCount = graph.getVertexCount();
//        System.out.println(graphVertexCount);
        //StaticLayout<MyNode, MyEdge> layout = new StaticLayout<MyNode, MyEdge>(g, locationTransformer);
        FRLayout<MyNode,MyEdge> layout = new FRLayout<MyNode,MyEdge>(graph, viewArea);
        layout.setAttractionMultiplier(1.0);
        layout.setRepulsionMultiplier(2.5);
        //KKLayout<MyNode,MyEdge> layout = new KKLayout<MyNode, MyEdge>(graph);
        //DAGLayout<MyNode,MyEdge> layout = new DAGLayout<MyNode, MyEdge>(graph);
        //ISOMLayout<MyNode,MyEdge> layout = new ISOMLayout<MyNode, MyEdge>(graph);

        panel = new VisualizationViewer<MyNode, MyEdge>(layout, viewArea);
        panel.setPreferredSize(viewArea);
        panel.setMinimumSize(viewArea);
        panel.getRenderContext().setVertexLabelTransformer(new Transformer<MyNode, String>() {
            public String transform(MyNode e) {
                return "<html><font size=6><b>" + e.getLabel() + "</b></font></html>";
            }
        });
        panel.getRenderer().getVertexLabelRenderer().setPosition(edu.uci.ics.jung.visualization.renderers.Renderer.VertexLabel.Position.CNTR);
        Transformer<MyNode,Paint> vertexColor = new Transformer<MyNode,Paint>() {
            public Paint transform(MyNode i) {
                if((i.getID() - 1) == selectedListIndex){
                    nodesMap.put(selectedListIndex, i);
                    return Color.GREEN;
                }
                return softred;
            }
        };
        panel.getRenderContext().setVertexFillPaintTransformer(vertexColor);
        DegreeScorer<MyNode> degree = new DegreeScorer<MyNode>(graph);
        Transformer<MyNode, Integer> degrees = new VertexScoreTransformer<MyNode, Integer>(degree);
        VertexShapeSizeAspect<MyNode, MyEdge> vssa = new VertexShapeSizeAspect<MyNode, MyEdge>(graph, degrees);
        vssa.setScaling(true);
        panel.getRenderContext().setVertexShapeTransformer(vssa);
        ScalingControl scaler = new CrossoverScalingControl();
        scaler.scale(panel, (float) 0.7, panel.getCenter());
    }

    public Graph<MyNode, MyEdge> createGraph() {
        BG.createGraph(cluewebfilenames, NIDCLUEWEB, NODEOUTLINKS);
        return BG.getGraph();

/*
        Graph<MyNode,MyEdge> g = new UndirectedSparseGraph<MyNode,MyEdge>();
        MyNode n1 = new MyNode("1",0);
        MyNode n2 = new MyNode("2",1);
        MyNode n3 = new MyNode("3",2);
        MyNode n4 = new MyNode("4",3);
        MyNode n5 = new MyNode("5",4);
        MyNode n6 = new MyNode("6",5);
        MyNode n7 = new MyNode("7",6);
        MyNode n8 = new MyNode("8",7);
        MyNode n9 = new MyNode("9",8);
        MyNode n10 = new MyNode("10",9);
        MyNode n11 = new MyNode("11",10);
        MyNode n12 = new MyNode("12",11);
        MyNode n13 = new MyNode("13",12);
        MyNode n14 = new MyNode("14",13);
        MyNode n15 = new MyNode("15",14);
        MyNode n16 = new MyNode("16",15);
        MyNode n17 = new MyNode("17",16);
        MyNode n18 = new MyNode("18",17);
        MyNode n19 = new MyNode("19",18);
        MyNode n20 = new MyNode("20",19);
        g.addEdge(new MyEdge("e1"), n1, n2);
        g.addEdge(new MyEdge("e2"), n2, n3);
        g.addEdge(new MyEdge("e3"), n3, n4);
        g.addEdge(new MyEdge("e4"), n4, n1);
        g.addEdge(new MyEdge("e5"), n5, n6);
        g.addEdge(new MyEdge("e6"), n6, n7);
        g.addEdge(new MyEdge("e7"), n7, n8);
        g.addEdge(new MyEdge("e8"), n8, n5);
        g.addEdge(new MyEdge("e9"), n1, n5);
        g.addEdge(new MyEdge("e10"), n2, n6);
        g.addEdge(new MyEdge("e11"), n3, n7);
        g.addEdge(new MyEdge("e12"), n4, n8);
        g.addEdge(new MyEdge("e13"), n8, n10);
        g.addEdge(new MyEdge("e14"), n1, n10);
        g.addEdge(new MyEdge("e15"), n9, n17);
        g.addEdge(new MyEdge("e16"), n7, n14);
        g.addEdge(new MyEdge("e17"), n3, n12);
        g.addEdge(new MyEdge("e18"), n11, n3);
        g.addEdge(new MyEdge("e19"), n20, n13);
        g.addEdge(new MyEdge("e20"), n5, n19);
        g.addEdge(new MyEdge("e21"), n19, n14);
        g.addEdge(new MyEdge("e22"), n16, n8);
        g.addEdge(new MyEdge("e23"), n18, n4);
        g.addEdge(new MyEdge("e23"), n15, n4);
        g.addEdge(new MyEdge("e24"), n12, n17);
        g.addEdge(new MyEdge("e25"), n9, n14);
        g.addEdge(new MyEdge("e26"), n11, n20);
        g.addEdge(new MyEdge("e27"), n10, n13);
        return g;
*/
    }

    private class MyListRenderer extends DefaultListCellRenderer {

        public Component getListCellRendererComponent( JList list,
                                                       Object value, int index, boolean isSelected,
                                                       boolean cellHasFocus ) {
            Component c = super.getListCellRendererComponent( list, value, index,
                    isSelected, cellHasFocus );

            for(int i = 0; i < graphVertexCount; i++){
                if(nodesVisisted.contains(index)){
                    c.setForeground(Color.GREEN);
                }
                if(relevantIndexes.contains(index)){
                    c.setForeground(Color.BLUE);
                }
            }
            if (isSelected){
                c.setForeground(Color.RED);
            }
            return(c);
        }
    }

    public String highLightQueryWords(String text, Set<String> terms){
        try{
            String[] words         = text.split(" ");
            String highlightedText = "";
            for(String word : words){
                String s = "";
                if(terms.contains(word)){
                    s = "<b>"+word+"</b>";
                }else{
                    s = word;
                }
                highlightedText = highlightedText+s+" ";
            }
            return highlightedText;
        }catch(NullPointerException npe){
            return "No snippet available";
        }
    }

    public Set<Integer> getRelevantIndexes(){
        return relevantIndexes;
    }

    public Vector<Integer> getIndexesVisisted(){
        return nodesVisisted;
    }

    public Map<Integer, Long> getIndexesTimeSpent(){
        return nodesTimeSpent;
    }

    public JPanel getPane(){
        return pane;
    }

    public Graph<MyNode,MyEdge> getGraph(){
        return panel.getGraphLayout().getGraph();
    }

    public Map<Integer, MyNode> getNodesMap(){
        return nodesMap;
    }

    public void updateTimeSpent(){
        long diff = (timeEnded-timeStarted);
        if(nodesTimeSpent.containsKey(selectedListIndex)){
            nodesTimeSpent.put(selectedListIndex, nodesTimeSpent.get(selectedListIndex) + diff);
        }else{
            nodesTimeSpent.put(selectedListIndex, diff);
        }
    }

    public QueryObject getQueryObject(){
        return queryObject;
    }
}
