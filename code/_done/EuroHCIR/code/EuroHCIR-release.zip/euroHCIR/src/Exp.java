import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

import edu.uci.ics.jung.algorithms.layout.GraphElementAccessor;
import edu.uci.ics.jung.visualization.control.CrossoverScalingControl;
import edu.uci.ics.jung.visualization.control.ScalingControl;
import edu.uci.ics.jung.visualization.picking.PickedState;
import edu.uci.ics.jung.algorithms.layout.FRLayout;
import edu.uci.ics.jung.visualization.VisualizationViewer;


public class Exp extends JPanel implements MouseListener, ActionListener, ItemListener {
    private BuildGraph bg = new BuildGraph();
    private VisualizationViewer<MyNode,MyEdge> panel;
    private FRLayout<MyNode,MyEdge> layout;
    private MyNode currentNodeSelected;
    private PickedState<MyNode> pickedState;
    private Map<MyNode,Color> nodeColors;
    private DefaultListModel listModel;
    private JList list;
    private HelpPanel helpPanel;
    private VisualizationStatics vs             = new VisualizationStatics();
    private Map<String, MyNode> relevantNodes   = new HashMap<String, MyNode>();
    private Set<MyNode> seedVertices            = new HashSet<MyNode>();
    private Set<MyNode> visitedVertices         = new HashSet<MyNode>();
    private String COLLECTION;
    private String WEB_PATH;
    private String SNIPPET_PATH;
    private String RANK_PATH;


    public Map<String, MyNode> getRelevantNodes(){
        return relevantNodes;
    }

    public static void main(String[] args) throws IOException {
        new VizNoGlassPane();
    }

    public Exp() throws IOException {

        helpPanel = new HelpPanel();
    }



    public void setRanks() throws IOException {
        listModel = new DefaultListModel();
        BufferedReader br = new BufferedReader(new FileReader(RANK_PATH));
        String currentLine;
        int rank = 1;
        while((currentLine = br.readLine()) != null){
              listModel.addElement("Rank: " + rank + ", Documentname: " + currentLine);
        }
    }


    public Exp(QueryObject qo) throws IOException{
        this.helpPanel = new HelpPanel();
        this.COLLECTION = qo.getCollection();
        this.WEB_PATH = qo.getWebgraphPath();
        this.SNIPPET_PATH = qo.getSnippetpath();
        this.RANK_PATH = qo.getRankPath();
        setRanks();
    }

    public VisualizationViewer<MyNode,MyEdge> getViz(){
        buildGraph();
        ScalingControl scaler = new CrossoverScalingControl();
        scaler.scale(panel, (float)0.66, panel.getCenter());
        return panel;
    }

    @Override
    public void mouseClicked(MouseEvent e){
        GraphElementAccessor<MyNode,MyEdge> pickSupport = panel.getPickSupport();
        final MyNode station = pickSupport.getVertex(panel.getGraphLayout(), e.getX(), e.getY());
        if(station != null){
            showPopupMenu(e.getX(), e.getY());
            visitedVertices.add(station);
        }
    }

    public void showPopupMenu(int corX, int corY){
        int infoPanelWidth = vs.getPopupWidth();
        int infoPanelHeight = vs.getPopupHeight();
        // Create JPanel
        JPopupMenu infoPanel = new JPopupMenu();
        infoPanel.setOpaque(false);
        infoPanel.setBorder(vs.getFullEmptyBorder());
        infoPanel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        infoPanel.setPreferredSize(new Dimension(infoPanelWidth, infoPanelHeight));
        // We have a 3-split pane
        JPanel snippet = new JPanel();
        snippet.setLayout(new GridBagLayout());
        GridBagConstraints cc = new GridBagConstraints();
        JLabel heading = new JLabel("Document snippet:");
        heading.setBorder(vs.getLowerMatteBorder());
        heading.setPreferredSize(new Dimension(vs.getPopUpSnippetWidth(), 20));
        heading.setFont(vs.getBoldFont());
        cc.anchor  = GridBagConstraints.NORTH;
        cc.gridx   = 0;
        cc.gridy   = 0;
        cc.weightx = 1;
        cc.weighty = 1;
        cc.fill    = GridBagConstraints.HORIZONTAL;
        cc.insets  = new Insets(2,2,2,2);
        snippet.add(heading, cc);

        JLabel info = new JLabel("<html>\"Macbeth, upon hearing that Macduff has fled to England, determines to kill Macduff's family. He justifies himself by saying that from now on he will follow his first impulse, because if he had followed his first impulse, Macduff would already be dead.\"</html>");
        info.setFont(vs.getItalicFont());
        //info.setVerticalAlignment(SwingConstants.TOP);
        info.setHorizontalAlignment(SwingConstants.LEFT);
        //info.setBorder(fullBorder);
        snippet.setPreferredSize(new Dimension(vs.getPopUpSnippetWidth(), infoPanelHeight));
        snippet.setBorder(vs.getFullMatteBorder());
        snippet.setOpaque(true);
        cc.gridx = 0;
        cc.gridy = 1;
        cc.weightx = 1;
        cc.weighty = 1;
        cc.fill = GridBagConstraints.HORIZONTAL;
        cc.insets = new Insets(5,5,5,5);
        snippet.add(info,cc);


        JPanel buttonContainer = new JPanel();
        JButton relevant = new JButton("Relevant");
        relevant.setActionCommand("Relevant");
        relevant.addActionListener(this);
        JButton notRelevant = new JButton("Not Relevant");
        notRelevant.addActionListener(this);
        notRelevant.setActionCommand("NotRelevant");
        relevant.setPreferredSize(new Dimension(115, 25));
        notRelevant.setPreferredSize(new Dimension(115, 25));
        relevant.setFont(vs.getNormalFont());
        notRelevant.setFont(vs.getNormalFont());
        //relevance.setVerticalAlignment(SwingConstants.BOTTOM);

        //buttonContainer.add(fill)
        cc.gridx = 0;
        cc.gridy = 2;
        cc.weighty = 1;
        cc.anchor = GridBagConstraints.PAGE_END;
        buttonContainer.add(relevant, BoxLayout.X_AXIS);
        buttonContainer.add(notRelevant, BoxLayout.X_AXIS);
        //buttonContainer.add(fill);
        snippet.add(buttonContainer,cc);

        c.weightx = 1;
        c.weighty = 1;
        c.gridx = 0;
        c.gridy = 0;
        infoPanel.add(snippet, c);

        JPanel empty = new JPanel();
        empty.setPreferredSize(new Dimension(infoPanelWidth/10,infoPanelHeight));
        empty.setOpaque(false); // added by OP
        empty.setBorder(BorderFactory.createEmptyBorder());
        empty.setBackground(new Color(0,0,0,0));
        c.gridx = 1;
        c.weightx = 1;
        infoPanel.add(empty,c);

        JPanel listRank = new JPanel();
        listRank.setLayout(new GridBagLayout());
        GridBagConstraints lc = new GridBagConstraints();
        listRank.setPreferredSize(new Dimension(vs.getPopUpSnippetWidth(),infoPanelHeight));
        JLabel rankheading = new JLabel("Ranking:");
        rankheading.setBorder(vs.getLowerMatteBorder());
        rankheading.setPreferredSize(new Dimension(vs.getPopUpSnippetWidth(), 20));
        rankheading.setFont(vs.getBoldFont());

        lc.anchor = GridBagConstraints.NORTH;
        lc.gridx = 0;
        lc.gridy = 0;
        lc.weightx = 1;
        lc.weighty = 1;
        lc.fill = GridBagConstraints.HORIZONTAL;
        lc.insets = new Insets(5,5,5,5);
        listRank.add(rankheading,lc);

        //listModel = new DefaultListModel();
//        populateList();
        //Create the list and put it in a scroll pane.
        list = new JList(listModel);
        list.setFont(vs.getNormalFont());
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setVisibleRowCount(4);
        list.setEnabled(false);
        list.setCellRenderer(new MyListRenderer());
/*
        list.setCellRenderer(new DefaultListCellRenderer() {

            public Component getListCellRendererComponent(JList list, Object value, int index,
                                                          boolean isSelected, boolean cellHasFocus) {
                list.setSelectedIndex(currentNodeSelected.getID()-1);
                super.getListCellRendererComponent(list, value, index, false, false);

                return this;
            }
        });
*/
        list.setSelectedIndex(currentNodeSelected.getID()-1);
        list.addMouseListener(this);
        JScrollPane listScrollPane = new JScrollPane(list,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        listScrollPane.setMinimumSize(new Dimension(vs.getPopUpSnippetWidth(),infoPanelHeight-30));
        lc.insets = new Insets(5,5,5,5);
        lc.gridx = 0;
        lc.gridy = 1;
        lc.weighty = 1;
        lc.anchor = GridBagConstraints.PAGE_START;
        lc.fill = GridBagConstraints.VERTICAL;
        listRank.add(listScrollPane,lc);
        listRank.setOpaque(true);
        listRank.setBorder(vs.getFullMatteBorder());

        infoPanel.add(listRank, c);
        infoPanel.show(panel,corX-(infoPanelWidth/2), corY);
        infoPanel.revalidate();
        infoPanel.repaint();
    }
/*
    public void populateList(){
        for(int i = 1; i <= 20; i++){
            listModel.addElement("Rank: "+i+", Documentname: " + "abcd");
        }
    }
*/
    @Override
    public void actionPerformed(ActionEvent e) {
        String action = e.getActionCommand();

        if(action.equalsIgnoreCase("Relevant")){
            pickedState.pick(currentNodeSelected, true);
            relevantNodes.put(currentNodeSelected.getLabel(), currentNodeSelected);
            seedVertices.add(currentNodeSelected);
        }
        if(action.equalsIgnoreCase("NotRelevant")){
            if(relevantNodes.containsKey(currentNodeSelected.getLabel())){
                relevantNodes.remove(currentNodeSelected.getLabel());
                seedVertices.remove(currentNodeSelected);
            }
        }

        if(action.equalsIgnoreCase("Help")){
            JOptionPane.showConfirmDialog(null,
                    helpPanel.getHelp(),
                    "Help",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE);
        }
    }

    public void buildGraph(){
        Dimension viewArea = new Dimension(790, 790);
        //graph = createGraph();
        //bg.createGraph(20); // this should be a
        nodeColors = bg.getNodeColors();
        bg.setGraphLayout(bg.getGraph(),viewArea,this,this);
        panel = bg.getPanel();
        this.layout = bg.getLayout();
        pickedState = bg.getPickedState();
        visitedVertices = bg.getVisitedVertices();
        seedVertices = bg.getSeedVertices();
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
    @Override
    public void itemStateChanged(ItemEvent e) {
        Object subject = e.getItem();
        if (subject instanceof MyNode) {
            MyNode vertex = (MyNode) subject;
            if (pickedState.isPicked(vertex)) {
                currentNodeSelected = vertex;
            }
        }
    }

    private class MyListRenderer extends DefaultListCellRenderer {
        private HashMap theChosen = new HashMap();

        public Component getListCellRendererComponent( JList list,
                                                       Object value, int index, boolean isSelected,
                                                       boolean cellHasFocus ) {
            Component c = super.getListCellRendererComponent( list, value, index,
                    isSelected, cellHasFocus );

            if(isSelected){
                c.setForeground(Color.RED);
            }else{
                c.setForeground(Color.BLACK);
            }
            return(c);
        }
    }
}