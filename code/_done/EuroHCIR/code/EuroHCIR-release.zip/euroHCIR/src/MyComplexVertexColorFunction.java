/**
 * Created with IntelliJ IDEA.
 * User: casper
 * Date: 17-05-13
 * Time: 17:02
 * To change this template use File | Settings | File Templates.
 */
public class MyComplexVertexColorFunction {
}
