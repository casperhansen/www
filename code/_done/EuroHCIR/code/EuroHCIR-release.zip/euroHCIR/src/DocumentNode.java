import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Ellipse2D;

public class DocumentNode extends JPanel implements MouseListener {
    private int ID;
    private Ellipse2D oval;

    public DocumentNode(int id, int x, int y){
        this.ID = id;
        oval = new Ellipse2D.Double(20, 20, x, y);
    }

    @Override
    public void paintComponent(Graphics g){
         Graphics2D g2d = (Graphics2D)g;
         g2d.fill(oval);
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if ((e.getButton() == 1) && oval.contains(e.getX(), e.getY()) ) {
            repaint();
            // JOptionPane.showMessageDialog(null,e.getX()+ "\n" + e.getY());
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void mouseExited(MouseEvent e) {
        //To change body of implemented methods use File | Settings | File Templates.
    }
}

