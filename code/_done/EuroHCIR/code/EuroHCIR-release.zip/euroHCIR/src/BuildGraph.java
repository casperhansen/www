import edu.uci.ics.jung.algorithms.layout.FRLayout;
import edu.uci.ics.jung.algorithms.scoring.DegreeScorer;
import edu.uci.ics.jung.algorithms.scoring.util.VertexScoreTransformer;
import edu.uci.ics.jung.graph.DirectedSparseGraph;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.UndirectedSparseGraph;
import edu.uci.ics.jung.visualization.VisualizationViewer;
import edu.uci.ics.jung.visualization.control.DefaultModalGraphMouse;
import edu.uci.ics.jung.visualization.control.ModalGraphMouse;
import edu.uci.ics.jung.visualization.control.PluggableGraphMouse;
import edu.uci.ics.jung.visualization.picking.PickedState;
import edu.uci.ics.jung.visualization.renderers.Renderer;
import org.apache.commons.collections15.Transformer;

import java.awt.*;
import java.awt.event.ItemListener;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;


public class BuildGraph {
    //private Map<Integer, String> nodeidToDocNo = new HashMap<Integer, String>();
    //private Map<String, Vector<Integer>> map   = new HashMap<String, Vector<Integer>>();

    Graph<MyNode,MyEdge> graph;
    private FRLayout<MyNode,MyEdge> layout;
    private VisualizationViewer<MyNode,MyEdge> panel;
    private PickedState<MyNode> pickedState;
    private Set<MyNode> visitedVertices         = new HashSet<MyNode>();
    private Set<MyNode> seedVertices            = new HashSet<MyNode>();
    private Map<MyNode,Color> nodeColors        = new HashMap<MyNode,Color>();
    private final Color softred                 = new Color(238,221,130);

    public FRLayout<MyNode,MyEdge> getLayout(){
        return layout;
    }

    public VisualizationViewer<MyNode,MyEdge> getPanel(){
        return panel;
    }

    public PickedState<MyNode> getPickedState(){
        return pickedState;
    }

    public Set<MyNode> getVisitedVertices(){
        return visitedVertices;
    }

    public Set<MyNode> getSeedVertices(){
        return seedVertices;
    }

    public Graph<MyNode,MyEdge> getGraph(){
        return graph;
    }

    public BuildGraph(){

    }

    public void setGraphLayout(Graph<MyNode,MyEdge> g, Dimension d, MouseListener m, ItemListener i){
        layout = new FRLayout<MyNode,MyEdge>(g, d);
        panel = new VisualizationViewer<MyNode,MyEdge>(layout, d);
        panel.addMouseListener(m);

        PluggableGraphMouse gm = new PluggableGraphMouse();
        gm.add(new MyPickingGraphMousePlugin<MyNode, MyEdge>());
        panel.setGraphMouse(gm);
/*
        DefaultModalGraphMouse<MyNode,MyEdge> gm = new DefaultModalGraphMouse<MyNode,MyEdge>();
        gm.setMode(ModalGraphMouse.Mode.PICKING);
        panel.setGraphMouse(gm);
*/
        Transformer<MyNode, String> pointedNodeNote = new Transformer<MyNode, String>() {
            @Override
            public String transform(MyNode n) {
                return "Document " + n.getLabel();
            }
        };
        panel.setVertexToolTipTransformer(pointedNodeNote);
        DegreeScorer<MyNode> degree = new DegreeScorer<MyNode>(graph);
        Transformer<MyNode, Integer> degrees = new VertexScoreTransformer<MyNode, Integer>(degree);
        VertexShapeSizeAspect<MyNode, MyEdge> vssa = new VertexShapeSizeAspect<MyNode, MyEdge>(graph, degrees);
        panel.getRenderContext().setVertexShapeTransformer(vssa);
        panel.getRenderContext().setVertexLabelTransformer(new Transformer<MyNode, String>() {
            public String transform(MyNode e) {
                return "<html><font size=6><b>"+e.getLabel()+"</b></font></html>";
            }
        });
        panel.getRenderer().getVertexLabelRenderer().setPosition(Renderer.VertexLabel.Position.CNTR);
        vssa.setScaling(true);
        pickedState = panel.getPickedVertexState();
        pickedState.addItemListener(i);
        SeedFillColor<MyNode> seedFillColor = new SeedFillColor<MyNode>(pickedState, nodeColors, seedVertices, visitedVertices);
        panel.getRenderContext().setVertexFillPaintTransformer(seedFillColor);
    }

   /*
    * We assume the graph is given in edgelist format and is stored in a space-separated file
    * The only problem is that node ids are preserved i.e. they are not shown as 0,1,2
    */
/*
    public void createGraph(QueryObject qo) throws IOException {
        Graph<MyNode,MyEdge> g = new DirectedSparseGraph<MyNode,MyEdge>();
        BufferedReader br;
        String sCurrentLine;
        br = new BufferedReader(new FileReader(qo.getWebgraphPath()));
        int id = 1;
        HashMap<Integer, Integer> nodeMap = new HashMap<Integer, Integer>();
        while((sCurrentLine = br.readLine()) != null){
               String[] ar  = sCurrentLine.split(" ");
               int from     = Integer.parseInt(ar[0]);
               if(!nodeMap.containsKey(from)){        // Probably not necessary as keys are unique, but anyway...
                   nodeMap.put(from, id);
                   id++;
               }
        }
        br.close();
        br = new BufferedReader(new FileReader(qo.getWebgraphPath()));
        String currentLine;
        id = 1;
        while((currentLine=br.readLine()) != null){
            String[] ar  = currentLine.split(" ");
            /* Need to decipher between connected and isolated vertices
             * If we have a to and from vertex

            if(ar.length == 2){
                int from     = nodeMap.get(Integer.parseInt(ar[0]));
                int to       = nodeMap.get(Integer.parseInt(ar[1]));
                MyNode f     = new MyNode(Integer.toString(from), from);
                MyNode t     = new MyNode(Integer.toString(to), to);
                nodeColors.put(f, softred);
                nodeColors.put(t, softred);
                g.addEdge(new MyEdge("e"+Integer.toString(id)), f, t);
                id++;
            }else{
                /*
                 * We have just an isolated node

                int from     = nodeMap.get(Integer.parseInt(ar[0]));
                MyNode f     = new MyNode(Integer.toString(from), from);
                nodeColors.put(f,softred);
                g.addVertex(f);
            }
        }
        br.close();
        this.graph = g;
    }
    */
    public void createGraph(String[] names, Map<Integer, String> NIDCLUEWEB, Map<String, Vector<Integer>> NODEOUTLINKS){
        Map<Integer, MyNode> rankToNode = new HashMap<Integer, MyNode>();
        Map<String, Integer> cluewebs   = new HashMap<String, Integer>();
        int rank = 1;
        for(String name : names){
            MyNode tmp =  new MyNode(String.valueOf(rank),rank);
            nodeColors.put(tmp, softred);
            rankToNode.put(rank, tmp);
            cluewebs.put(name,rank);
            rank++;
        }

        Graph<MyNode,MyEdge> g = new DirectedSparseGraph<MyNode,MyEdge>();
        //g.addEdge(new MyEdge("e1"), n1, n2);
        //We enter with a list of some kind containing the clueweb names. Call this cluewebs. Loop over them.
        int edgenr = 1;
        for(int j = 0; j < names.length; j++) {
            String clueweb = names[j];
            //System.out.println("BuildGraph: cluewebfile - " + clueweb);
            //With the current look up in map.
            if(NODEOUTLINKS.containsKey(clueweb)){
                // We know the node exist. But does it have any outlinks?
                Vector<Integer> outlinks = NODEOUTLINKS.get(clueweb);
                if(!outlinks.isEmpty()){
                    boolean edgewascreated = false;
                    //System.out.println("Node " + clueweb +" in list. Have outlinks. Looping.");
                    for (int entry : outlinks){
                        // Attempt ot find the key in the pl lookup table to get the mapping.
                        if(NIDCLUEWEB.containsKey(entry)){
                            //System.out.println("Node " + clueweb +" has mapping.");
                            String match = NIDCLUEWEB.get(entry);
                            //If the key exists, fetch it. Now we need to know if that key exist in the original list.
                            if(Arrays.asList(names).contains(match)){
                                //System.out.println("Node " + clueweb +" contains outlink " +match+" also in initial set.");
                                int rankorg = cluewebs.get(clueweb);
                                int rankmatch = cluewebs.get(match);
                                g.addEdge(new MyEdge("e"+edgenr),rankToNode.get(rankorg),rankToNode.get(rankmatch));
                                edgewascreated = true;
                                // We are happy. We lookup clueweb and match in a docno-to-rank-map and write it.
                            }
                        }
                    }
                    if(!edgewascreated){
                        int index = cluewebs.get(clueweb);
                        g.addVertex(rankToNode.get(index));
                    }
                }else{
                    //The node exists but has no outlinks. Create it anyway
                    //System.out.println("Node " + clueweb +"  in list but no outlinks. Creating.");
                    int index = cluewebs.get(clueweb);
                    g.addVertex(rankToNode.get(index));
                }
            }else{
                int index = cluewebs.get(clueweb);
                g.addVertex(rankToNode.get(index));
                // So the node in the list is one of those we could not find. We make a node nevertheless.
                //System.out.println("Node " + clueweb +" not in list. Creating.");
            }
        }
        //System.out.println("BuildGraph: " + g.getVertexCount());
        this.graph = g;
    }
/*
    public void createGraph(int numVertices) {

        Graph<MyNode,MyEdge> g = new UndirectedSparseGraph<MyNode,MyEdge>();
        Vector<MyNode> vList = new Vector<MyNode>();
        for(int i = 1; i <= numVertices; i++){
            MyNode tmp = new MyNode(Integer.toString(i),i);
            vList.add(tmp);
            nodeColors.put(tmp, softred);
        }
        MyNode n1 = new MyNode("1",1);
        nodeColors.put(n1, softred);
        MyNode n2 = new MyNode("2",2);
        nodeColors.put(n2, softred);
        MyNode n3 = new MyNode("3",3);
        nodeColors.put(n3, softred);
        MyNode n4 = new MyNode("4",4);
        nodeColors.put(n4, softred);
        MyNode n5 = new MyNode("5",5);
        nodeColors.put(n5, softred);
        MyNode n6 = new MyNode("6",6);
        nodeColors.put(n6, softred);
        MyNode n7 = new MyNode("7",7);
        nodeColors.put(n7, softred);
        MyNode n8 = new MyNode("8",8);
        nodeColors.put(n8, softred);
        MyNode n9 = new MyNode("9",9);
        nodeColors.put(n9, softred);
        MyNode n10 = new MyNode("10",10);
        nodeColors.put(n10, softred);
        MyNode n11 = new MyNode("11",11);
        nodeColors.put(n11, softred);
        MyNode n12 = new MyNode("12",12);
        nodeColors.put(n12, softred);
        MyNode n13 = new MyNode("13",13);
        nodeColors.put(n13, softred);
        MyNode n14 = new MyNode("14",14);
        nodeColors.put(n14, softred);
        MyNode n15 = new MyNode("15",15);
        nodeColors.put(n15, softred);
        MyNode n16 = new MyNode("16",16);
        nodeColors.put(n16, softred);
        MyNode n17 = new MyNode("17",17);
        nodeColors.put(n17, softred);
        MyNode n18 = new MyNode("18",18);
        nodeColors.put(n18, softred);
        MyNode n19 = new MyNode("19",19);
        nodeColors.put(n19, softred);
        MyNode n20 = new MyNode("20",20);
        nodeColors.put(n20, softred);
        g.addEdge(new MyEdge("e1"), n1, n2);
        g.addEdge(new MyEdge("e2"), n2, n3);
        g.addEdge(new MyEdge("e3"), n3, n4);
        g.addEdge(new MyEdge("e4"), n4, n1);
        g.addEdge(new MyEdge("e5"), n5, n6);
        g.addEdge(new MyEdge("e6"), n6, n7);
        g.addEdge(new MyEdge("e7"), n7, n8);
        g.addEdge(new MyEdge("e8"), n8, n5);
        g.addEdge(new MyEdge("e9"), n1, n5);
        g.addEdge(new MyEdge("e10"), n2, n6);
        g.addEdge(new MyEdge("e11"), n3, n7);
        g.addEdge(new MyEdge("e12"), n4, n8);
        g.addEdge(new MyEdge("e13"), n8, n10);
        g.addEdge(new MyEdge("e14"), n1, n10);
        g.addEdge(new MyEdge("e15"), n9, n17);
        g.addEdge(new MyEdge("e16"), n7, n14);
        g.addEdge(new MyEdge("e17"), n3, n12);
        g.addEdge(new MyEdge("e18"), n11, n3);
        g.addEdge(new MyEdge("e19"), n20, n13);
        g.addEdge(new MyEdge("e20"), n5, n19);
        g.addEdge(new MyEdge("e21"), n19, n14);
        g.addEdge(new MyEdge("e22"), n16, n8);
        g.addEdge(new MyEdge("e23"), n18, n4);
        g.addEdge(new MyEdge("e23"), n15, n4);
        g.addEdge(new MyEdge("e24"), n12, n17);
        g.addEdge(new MyEdge("e25"), n9, n14);
        g.addEdge(new MyEdge("e26"), n11, n20);
        g.addEdge(new MyEdge("e27"), n10, n13);
        this.graph = g;
    }

*/
    public Map<MyNode,Color> getNodeColors(){
        return nodeColors;
    }
}
