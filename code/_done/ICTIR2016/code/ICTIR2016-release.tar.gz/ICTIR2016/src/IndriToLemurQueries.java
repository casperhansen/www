import java.io.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This file converts a query file in Indri format to a queryfile in
 */
public class IndriToLemurQueries {
    public static void main(String[] args) throws IOException {
        new IndriToLemurQueries(args[0]);
    }

    public IndriToLemurQueries(String inputfile) throws IOException {
            //doProcess(inputfile);
            processDirectory(inputfile);
    }

    private void doProcess(String infile) throws IOException {
        PrintWriter pw = new PrintWriter(infile+".lemur");
        FileReader fr = new FileReader(infile);
        BufferedReader br = new BufferedReader(fr);
        String sCurrentLine;
        while((sCurrentLine = br.readLine()) != null){
            if(sCurrentLine.contains("<number>")){
                final Pattern pattern = Pattern.compile("<number>(.+?)</number>");
                final Matcher matcher = pattern.matcher(sCurrentLine);
                if(matcher.find()){
                    pw.println("<DOC "+matcher.group(1)+">");
                }
                continue;
            }
            if(sCurrentLine.contains("<text>#combine(")){

                String tmp = sCurrentLine.replace("<text>#combine(","");
                tmp        = tmp.replace(")</text>","");
                String[] parts = tmp.split("\\s+");
                for(String word : parts){
                    pw.println(word.trim());
                }
                pw.println("</DOC>");
            }
        }
        pw.flush();
        pw.close();
        fr.close();
        br.close();
    }

    private void processDirectory(String dir) throws IOException{
        File directory = new File(dir);
        File[] files   = directory.listFiles();

        for(File file : files){
            if(file.getAbsolutePath().contains("queries")){
                doProcess(file.getAbsolutePath());
            }
            System.out.println("Finished processing " + file.getAbsolutePath());
        }
    }
}
