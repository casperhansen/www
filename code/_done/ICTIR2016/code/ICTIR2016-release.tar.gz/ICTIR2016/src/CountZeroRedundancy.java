import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by casper on 4/13/16.
 */
public class CountZeroRedundancy {
    private int linecounter;
    private int zerocounter;
    public static void main(String[] args) throws IOException {
        new CountZeroRedundancy();
    }

    public CountZeroRedundancy() throws IOException {
        //doProcess("/home/casper/research/ictir2016/data/extracted/");
        doProcess("/home/casper/research/ictir2016/data/earthquake/");
    }

    private void doProcess(String directory) throws IOException {
        File dir = new File(directory);
        File[] files = dir.listFiles();

        assert files != null;
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        System.out.println(dateFormat.format(date) + " :: Starting processing of " + files.length + " files");
        for(File f : files){
            process(f.getAbsolutePath());
            date = new Date();
            System.out.println(dateFormat.format(date) + " :: Finished reading file " + f.getAbsolutePath());
        }
        date = new Date();
        System.out.println(dateFormat.format(date) + " :: Finished all files!");
        System.out.println("Out of " + linecounter + " lines, " + zerocounter + " was 0");
    }

    private void process(String file) throws IOException{
        FileReader fr = new FileReader(file);
        BufferedReader br = new BufferedReader(fr);
        String sCurrentLine;
        while((sCurrentLine = br.readLine()) != null){
            //String[] parts = sCurrentLine.split("\\s+");
            String[] parts = sCurrentLine.split(",");
            double val = Double.parseDouble(parts[8]);
            if(val == 0.0) {
                zerocounter++;
            }
            linecounter++;
        }
        fr.close();
        br.close();
    }
}
