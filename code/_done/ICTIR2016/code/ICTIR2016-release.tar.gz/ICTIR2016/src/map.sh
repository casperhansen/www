#/bin/bash

javac -cp . Rerank2.java

echo "Compilation finished"

java -cp . Rerank2 0 1 4;
java -cp . Rerank2 1 1 4;
java -cp . Rerank2 2 1 4;

echo "Finished for log"

java -cp . Rerank2 0 2 4;
java -cp . Rerank2 1 2 4;
java -cp . Rerank2 2 2 4;

echo "Finished satu"

java -cp . Rerank2 0 3 4;
java -cp . Rerank2 1 3 4;
java -cp . Rerank2 2 3 4;

echo "Finished sigm"
