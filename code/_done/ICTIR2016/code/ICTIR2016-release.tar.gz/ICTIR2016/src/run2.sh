#/bin/bash

# Compile
javac -cp . Rerank2.java

echo "Compilation successful"

#java -cp . Rerank2 0 1 0;
#java -cp . Rerank2 1 1 0;
#java -cp . Rerank2 2 1 0;

#java -cp . Rerank2 0 1 1;
#java -cp . Rerank2 1 1 1;
#java -cp . Rerank2 2 1 1;

#java -cp . Rerank2 0 1 2;
#java -cp . Rerank2 1 1 2;
#java -cp . Rerank2 2 1 2;

#java -cp . Rerank2 0 1 3;
#java -cp . Rerank2 1 1 3;
#java -cp . Rerank2 2 1 3;


#echo "Compelted everything for log re-ranking"

echo "Starting everything for satu re-ranking"

java -cp . Rerank2 0 2 0;
java -cp . Rerank2 1 2 0;
java -cp . Rerank2 2 2 0;

java -cp . Rerank2 0 2 1;
java -cp . Rerank2 1 2 1;
java -cp . Rerank2 2 2 1;

java -cp . Rerank2 0 2 2;
java -cp . Rerank2 1 2 2;
java -cp . Rerank2 2 2 2;

java -cp . Rerank2 0 2 3;
java -cp . Rerank2 1 2 3;
java -cp . Rerank2 2 2 3;


echo "Completed everything for satu re-ranking"


java -cp . Rerank2 0 3 0;
java -cp . Rerank2 1 3 0;
java -cp . Rerank2 2 3 0;

java -cp . Rerank2 0 3 1;
java -cp . Rerank2 1 3 1;
java -cp . Rerank2 2 3 1;

java -cp . Rerank2 0 3 2;
java -cp . Rerank2 1 3 2;
java -cp . Rerank2 2 3 2;

java -cp . Rerank2 0 3 3;
java -cp . Rerank2 1 3 3;
java -cp . Rerank2 2 3 3;

echo "Completed everything for sigm re-ranking"
