package top20;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.Map;
import java.util.TreeMap;
import java.util.Vector;


public class Process {
    DecimalFormat df = new DecimalFormat("#.#####");
    private TreeMap<String, TreeMap<String, Double>> lookup_qrels;
    private TreeMap<String, TreeMap<String, Double>> lookup_res;
    public static void main(String[] args) throws IOException {
        new Process();
    }

    public Process() throws IOException {
        df.setRoundingMode(RoundingMode.CEILING);
        LoadQrelsFile l   = new LoadQrelsFile("/home/casper/research/ictir2016/qrels.adhoc");
        lookup_qrels      = l.getLookup();
        metaprocess();
    }

    private void metaprocess() throws IOException {
        String baseinpath = "/home/casper/research/ictir2016/output2/analysis/top20/input/";
        String baseoutpath = "/home/casper/research/ictir2016/output2/analysis/top20/output/";
        File dircontent = new File(baseinpath);
        File[] files    = dircontent.listFiles();
        int i = 1;
        PrintWriter pw = new PrintWriter(baseoutpath+"averages");
        for(File f : files){
            LoadResultFile l2 = new LoadResultFile(f.getAbsolutePath());
            lookup_res        = l2.getResults();
            doProcess(baseoutpath,f.getName(), pw);
            System.out.println("Finished " + f.getAbsolutePath() + " ("+i+"/"+files.length+")");
            i++;
        }
        pw.flush();
        pw.close();
    }

    private void doProcess(String outpath, String name, PrintWriter out) throws IOException {

        // Loop over queries
        Vector<Results> v = new Vector<Results>();
        for(Map.Entry<String, TreeMap<String, Double>> entry : lookup_res.entrySet()){
            // Get the qrels
            TreeMap<String, Double> qrels = lookup_qrels.get(entry.getKey());
            // Loop over the top-20 docs
            TreeMap<String, Double> documents = entry.getValue();
            double err_agg = 0.0;
            double[] TR_array    = new double[20];
            double[] AR_array    = new double[20];
            double[] error_array = new double[20];
            int index = 0;
            for(Map.Entry<String, Double> doc : documents.entrySet()){
                String document     = doc.getKey();
                double document_rsv = doc.getValue();
                double qrels_rsv    = 0.0;
                if(qrels.containsKey(document)){
                    qrels_rsv = qrels.get(document);
                }
                double err = Math.abs(document_rsv - qrels_rsv);
                error_array[index] = err;
                TR_array[index] = qrels_rsv;
                AR_array[index] = document_rsv;
                index++;
            }

            /*
               Calculate \sigma^2 TR, \sigma^2 AR and mean error
             */
            double TRvar = getVariance(TR_array);
            double ARvar = getVariance(AR_array);
            double ratio = TRvar/ARvar;
            /*
               Calculate ratio for query q
             */
            double meanERR = getMean(error_array);
            v.add(new Results(entry.getKey(),TRvar,ARvar,ratio,meanERR));
        }
        double aggTR      = 0.0;
        double aggAR      = 0.0;
        double aggRatio   = 0.0;
        double aggAvgmean = 0.0;
        PrintWriter pw = new PrintWriter(outpath+name);
        for(Results r : v){
            pw.println(r.toString());
            aggTR += r.getTrVariance();
            aggAR += r.getArVariance();
            aggRatio += r.getRatio();
            aggAvgmean += r.getAvgError();
        }
        //pw.println("null,"+(aggTR/v.size())+","+(aggAR/v.size())+","+(aggRatio/v.size())+","+(aggAvgmean/v.size()));
        out.println(name+","+df.format((aggTR/v.size()))+","+df.format((aggAR/v.size()))+","+df.format((aggRatio/v.size()))+","+df.format((aggAvgmean/v.size())));
        pw.flush();
        pw.close();
        //System.out.println("null,"+(aggTR/v.size())+","+(aggAR/v.size())+","+(aggRatio/v.size())+","+(aggAvgmean/v.size()));
    }

    private double getMean(double[] data){
        double sum = 0.0;
        for(double a : data)
            sum += a;
        return sum/data.length;
    }

    private double getVariance(double[] data){
        double mean = getMean(data);
        double temp = 0;
        for(double a :data)
            temp += (mean-a)*(mean-a);
        return temp/data.length;
    }

}

class Results{
    DecimalFormat df = new DecimalFormat("#.#####");
    private double TRVAR  = 0.0;
    private double ARVAR  = 0.0;
    private double RATIO  = 0.0;
    private double AVGERR = 0.0;
    private String QUERYID = "";

    public Results(String queryid, double trvar, double arvar, double ratio, double avgerr){
        df.setRoundingMode(RoundingMode.CEILING);
        QUERYID = queryid;
        TRVAR = trvar;
        ARVAR = arvar;
        RATIO = ratio;
        AVGERR = avgerr;
    }

    public String getQueryID(){
        return QUERYID;
    }

    public double getTrVariance(){
        return TRVAR;
    }

    public double getArVariance(){
        return ARVAR;
    }

    public double getAvgError(){
        return AVGERR;
    }

    public double getRatio(){
        return RATIO;
    }

    public String toString(){
        return QUERYID+","+df.format(TRVAR)+","+df.format(ARVAR)+","+df.format(RATIO)+","+df.format(AVGERR);
    }

}