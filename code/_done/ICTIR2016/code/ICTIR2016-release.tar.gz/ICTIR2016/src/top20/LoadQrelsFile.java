package top20;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;

/**
 * Loads a qrels file
 */
public class LoadQrelsFile {
    private TreeMap<String, TreeMap<String, Double>> lookup = new TreeMap<>();

    public static void main(String[] args) throws IOException {
        new LoadQrelsFile(args[0]);
    }

    public LoadQrelsFile(String file) throws IOException {
        doProcess(file);
    }


    private void doProcess(String file) throws IOException {
        FileReader fr = new FileReader(file);
        BufferedReader br = new BufferedReader(fr);
        String sCurrentLine = br.readLine();
        String[] parts      = sCurrentLine.split("\\s+");
        String queryid      = parts[0];
        TreeMap<String, Double> local = new TreeMap<>();
        String document     = parts[2];
        double value        = (Double.parseDouble(parts[3])+2.0)/6.0;
        local.put(document, value);
        while((sCurrentLine = br.readLine()) != null){
            parts = sCurrentLine.split("\\s+");
            if(parts[0].equalsIgnoreCase(queryid)){
                // Still have the same query
                document = parts[2];
                value    = (Double.parseDouble(parts[3])+2)/6.0; //Add 2 to enforce all qrels are at least 0
                local.put(document, value);
            }else{
                lookup.put(queryid, local);
                //System.out.println("Inserting queryid " + queryid + " of size " + local.size() + " into table");
                local = new TreeMap<String, Double>();
                queryid = parts[0];
                // New query
                document = parts[2];
                value    = Integer.parseInt(parts[3]);
                local.put(document, value);
            }
        }

        lookup.put(queryid, local);
        //System.out.println("Inserting queryid " + queryid + " of size " + local.size() + " into table");
        fr.close();
        br.close();
    }

    public TreeMap<String, TreeMap<String, Double>> getLookup(){
        return lookup;
    }
}
