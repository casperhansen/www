import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class Rerank2 {
    private TreeMap<Integer, String> FOLD_TO_FILE = new TreeMap<Integer, String>();
    private HashMap<Integer, TreeMap<String, Vector<ResultLine>>> FOLDS = new HashMap<Integer, TreeMap<String, Vector<ResultLine>>>();
    private HashMap<String, Document> lookup = new HashMap<String, Document>();
    private final int MRR_INDEX    = 0;
    private final int P10_INDEX    = 1;
    private final int NDCG20_INDEX = 2;
    private final int ERR20_INDEX  = 3;
    private final int MAP_INDEX    = 4;

    private final static String extracted_files = "/home/casper/research/ictir2016/data/extracted/";
    private final static String qrels = "/home/casper/research/ictir2016/qrels.adhoc";

    /*
      First argument is the coherence scores
      Second argument is the output directory for the indri folds
      Third argument is the path to the qrels
      Fourth argument is the network metric (either 0,1 or 2);
     */
    public static void main(String[] args) {
/*
        if (args.length != 6) {
            System.err.println("Error! Incorrect number of arguments");
            System.err.println("First argument.: Path to folder containing the coherence scores");
            System.err.println("Second argument: Path to folder containing the test-folds of cross-validation with RunXFoldDir.java (see /home/casper/sigir2016/code/java/ on angua");
            System.err.println("Third argument.: Path to the qrels file");
            System.err.println("Fourth argument: The network metric to use (must be either 0 (bip), 1 (abip) or 2 (red))");
            System.err.println("Fifth argument.: The reranking procedure to use  (must be either 0 = original ictir paper, 1 = log, 2 = satu, 3 = sigm)");
            System.err.println("Sixth argument.: The metric to optimise for (must be either 0 = MRR, 1 = P10, 2 = NDCG20, 3 = ERR20, 4 = MAP)");
        }
*/

        String networkmetric = args[0];
        String rerankingprocedure = args[1];
        int performancemetric = Integer.parseInt(args[2]);


/*
        String networkmetric      = "0";
        String rerankingprocedure = "2";
        int performancemetric     = 1;
*/
        String rerank = "";
        if(rerankingprocedure.equalsIgnoreCase("0")){
            rerank = "normal/";
        }
        if(rerankingprocedure.equalsIgnoreCase("1")){
            rerank = "log/";
        }
        if(rerankingprocedure.equalsIgnoreCase("2")){
            rerank = "satu/";
        }
        if(rerankingprocedure.equalsIgnoreCase("3")){
            rerank = "sigm/";
        }

        String inputdir = "";
        String outputdir = "";
        switch (performancemetric){
            case 0: inputdir = "/home/casper/research/ictir2016/input/mrr/";
                    outputdir = "/home/casper/research/ictir2016/output2/mrr/"+rerank;
                    break;
            case 1: inputdir = "/home/casper/research/ictir2016/input/p10/";
                    outputdir = "/home/casper/research/ictir2016/output2/p10/"+rerank;
                    break;
            case 2: inputdir = "/home/casper/research/ictir2016/input/ndcg20/";
                    outputdir = "/home/casper/research/ictir2016/output2/ndcg20/"+rerank;
                    break;
            case 3: inputdir = "/home/casper/research/ictir2016/input/err20/";
                    outputdir = "/home/casper/research/ictir2016/output2/err20/"+rerank;
                    break;
            case 4: inputdir = "/home/casper/research/ictir2016/input/map/";
                    outputdir = "/home/casper/research/ictir2016/output2/map/"+rerank;
                    break;
            default: System.err.println("Performance metric " + performancemetric + " not recognized"); System.exit(-1);
        }
        System.out.println("Processing:");
        System.out.println("Network metric.....: " + networkmetric);
        System.out.println("Reranking procedure: " + rerankingprocedure);
        System.out.println("Performance metric.: " + performancemetric);
        System.out.println("Qrels..............: " + qrels);
        System.out.println("Input directory....: " + inputdir);
        System.out.println("Output directory...: " + outputdir);
        System.out.println();

        new Rerank2(extracted_files, inputdir, qrels, networkmetric, rerankingprocedure, performancemetric, outputdir);
    }

    public Rerank2(String networkmetricfile, String indrioutputdir, String qrels, String metric, String rerankmethod, int performancemetric, String outputdir) {

        int networkmetric = Integer.parseInt(metric);
        int rerank = Integer.parseInt(rerankmethod);
        if (!(networkmetric == 0 || networkmetric == 1 || networkmetric == 2)) {
            System.err.println("Network metric must be either 0, 1 or 2");
            System.exit(-1);
        }

        if (!(performancemetric == 0 || performancemetric == 1 || performancemetric == 2 || performancemetric == 3 || performancemetric == 4)) {
            System.err.println("Performance metric must be either 0 (MRR), 1 (P10), 2 (NDCG20), 3 (ERR20) or 4 (MAP)");
            System.exit(-1);
        }

        populatelookup(networkmetricfile);
        locateTestFiles(indrioutputdir);
        System.out.println("Finished locating test files");
        readTestFiles();
        System.out.println("Finished reading test files");

        switch (rerank) {
            case 0: reRank(qrels, networkmetric, performancemetric, outputdir);
                break;
            case 1:
                reRanklog(qrels,  networkmetric, performancemetric, outputdir);
                break;
            case 2:
                reRanksatu(qrels, networkmetric, performancemetric, outputdir);
                break;
            case 3:
                reRanksigm(qrels, networkmetric, performancemetric, outputdir);
                break;
            default:
                System.err.println("Illegal reranking method: " + rerankmethod);
                break;
        }

        System.out.println("Finished!");
    }


    private void populatelookup(String directory) {
        LoadFiles lf = null;
        try {
            lf = new LoadFiles();
            lf.doProcess(directory);
        } catch (IOException e) {
            e.printStackTrace();
        }
        assert lf != null;
        lookup = lf.getLookUp();
    }

    private void locateTestFiles(String directory) {
        //System.out.println(directory);
        File dir = new File(directory);
        File[] files = dir.listFiles();
        for (File f : files) {
            if (f.getAbsolutePath().contains("-test-")) {
                String[] parts = f.getAbsolutePath().split("-");
                String tmp = parts[parts.length - 1];
                tmp = tmp.replaceAll(".out.fixed", "");
                int foldnr = Integer.parseInt(tmp);
                FOLD_TO_FILE.put(foldnr, f.getAbsolutePath());
                System.out.println("Found " + f.getAbsolutePath() + " having fold number " + foldnr);
            }
        }
        System.out.println("Found " + FOLD_TO_FILE.size() + " test files in " + directory);
    }

    private void readTestFiles() {
        if (FOLD_TO_FILE.isEmpty()) {
            System.err.println("Fold to file was empty");
            System.exit(-1);
        }

        for (Map.Entry<Integer, String> entry : FOLD_TO_FILE.entrySet()) {
            FileReader fr = null;
            try {
                fr = new FileReader(entry.getValue());
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            assert fr != null;
            BufferedReader br = new BufferedReader(fr);
            String sCurrentLine = null;
            try {
                sCurrentLine = br.readLine();
            } catch (IOException e) {
                e.printStackTrace();
            }

            TreeMap<String, Vector<ResultLine>> QUERYID_TO_RANKEDLIST = new TreeMap<>();
            String[] parts = sCurrentLine.split("\\s+");
            String prev_id = parts[0];
            ResultLine d = new ResultLine(sCurrentLine);
            Vector<ResultLine> re = new Vector<ResultLine>();
            re.add(d);
            int linecounter = 0;
            try {
                while ((sCurrentLine = br.readLine()) != null) {
                    parts = sCurrentLine.split("\\s+");
                    if (parts[0].equalsIgnoreCase(prev_id)) {
                        //Same as what we've seen so far
                        d = new ResultLine(sCurrentLine);
                        re.add(d);
                    } else {
/*
                        if(prev_id.equalsIgnoreCase("151")){
                            System.out.println("Found query 151! Size of vector is: " + re.size());
                        }
*/
                        // We have encountered a new query id. Insert the old one, clear it and loop around
                        QUERYID_TO_RANKEDLIST.put(prev_id, re);
                        re = new Vector<ResultLine>();
                        prev_id = parts[0];
                        d = new ResultLine(sCurrentLine);
                        re.add(d);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            QUERYID_TO_RANKEDLIST.put(prev_id, re);
            System.out.println("Fold " + entry.getKey() + " - Size of QUERYID_TO_RANKEDLIST: " + QUERYID_TO_RANKEDLIST.size());
            FOLDS.put(entry.getKey(), QUERYID_TO_RANKEDLIST);
            try {
                fr.close();
                br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void reRank(String qrelsfile, int networkmetric, int performancemetric, String outputdir) {
        String outpath = outputdir + networkmetric + "/";
        String summaryfile = outpath + "summary";
        PrintWriter summary = null;
        try {
            summary = new PrintWriter(summaryfile);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        double[] alphas = new double[200];//{0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9};
        for (int i = 0; i < 200; i++) {
            alphas[i] = -2 + (i * 0.02);
        }

        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        for (Map.Entry<Integer, TreeMap<String, Vector<ResultLine>>> entry : FOLDS.entrySet()) {
            // Entry.getKey() is the fold number
            // Entry.getValue() is a TreeMap. The TreeMap is indexed by the query id. The values are the ranked lists for each query id

            TreeMap<String, Vector<ResultLine>> rs = entry.getValue();

            double BEST_PERFORMANCE = 0.0;
            double BEST_ALPHA = 0.0;
            String BEST_FILE = "";
            for (double alpha : alphas) {
                //Now we need to loop over each query in rs
                String out = outpath + getMetricString(performancemetric) + "-foldnr-" + entry.getKey() + "-alpha-" + alpha + ".txt";
                PrintWriter pw = null;
                try {
                    pw = new PrintWriter(out);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                assert pw != null;
                // Loop over individual queries
                for (Map.Entry<String, Vector<ResultLine>> query : rs.entrySet()) {
                    List<ScoreObject> rerankeddocs = new ArrayList<>();

                    Vector<ResultLine> rankedlist = query.getValue();
                    // Loop over the ranked list of each query
                    for (ResultLine r : rankedlist) {
                        if (lookup.containsKey(r.getFileName())) {
                            Document d = lookup.get(r.getFileName());
                            if(d.getMetric(networkmetric) != 0.0) {
                                // Ensure that we do not take the log of 0.0
                                ScoreObject s = new ScoreObject(r, score(r.getScore(), d.getMetric(networkmetric), alpha));
                                rerankeddocs.add(s);
                            }else{
                                ScoreObject s = new ScoreObject(r, r.getScore());
                                rerankeddocs.add(s);
                            }
                        } else {
                            ScoreObject s = new ScoreObject(r, r.getScore());
                            rerankeddocs.add(s);
                        }
                    }
                    Comparator<ScoreObject> comp = new ScoreObjectComparator();
                    Collections.sort(rerankeddocs, comp);
                    int position = 1;
                    for (ScoreObject s : rerankeddocs) {
                        pw.println(s.getResultLine().getQueryID() + " Q0 " + s.getResultLine().getFileName() + " " + position + " " + s.getScore() + " ictir2016");
                        position++;
                    }
                    pw.flush();
                }
                pw.flush();
                pw.close();


                double[] x = doTrecEval(qrelsfile, out);

                if (x[performancemetric] > BEST_PERFORMANCE) {
                    BEST_PERFORMANCE = x[performancemetric];
                    BEST_ALPHA = alpha;
                    BEST_FILE = out;
                }
            }
            System.out.println();
            System.out.println("*******************************************************************************************************");
            System.out.println("*                             FINISHED FOLD NUMBER " + entry.getKey() + "                                                  *");
            System.out.println("*                             Best alpha value: " + BEST_ALPHA + "                                                   *");
            System.out.println("*                             Best MAP value..: " + BEST_PERFORMANCE + "                                                 *");
            System.out.println("*******************************************************************************************************");
            System.out.println();

            summary.println(BEST_FILE);

        }
        summary.flush();
        summary.close();
    }


    private void reRanklog(String qrelsfile, int networkmetric, int performancemetric, String outputdir) {
        String outpath = outputdir + networkmetric + "/";
        String summaryfile = outpath + "summary";
        PrintWriter summary = null;
        try {
            summary = new PrintWriter(summaryfile);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        final int nof_weights = 400;
        double[] ws = new double[nof_weights];
        for (int i = 0; i < nof_weights; i++) {
            ws[i] = -2 + (i * 0.01);
        }

        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        for (Map.Entry<Integer, TreeMap<String, Vector<ResultLine>>> entry : FOLDS.entrySet()) {
            // Entry.getKey() is the fold number
            // Entry.getValue() is a TreeMap. The TreeMap is indexed by the query id. The values are the ranked lists for each query id

            TreeMap<String, Vector<ResultLine>> rs = entry.getValue();

            double BEST_VALUE = 0.0;
            double BEST_W     = 0.0;
            String BEST_FILE = "";
            for (double w : ws) {
                //Now we need to loop over each query in rs
                String out = outpath + getMetricString(performancemetric) + "-foldnr-" + entry.getKey() + "-w-" + w + ".txt";
                PrintWriter pw = null;
                try {
                    pw = new PrintWriter(out);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                assert pw != null;
                // Loop over individual queries
                for (Map.Entry<String, Vector<ResultLine>> query : rs.entrySet()) {
                    List<ScoreObject> rerankeddocs = new ArrayList<>();

                    Vector<ResultLine> rankedlist = query.getValue();
                    // Loop over the ranked list of each query
                    for (ResultLine r : rankedlist) {
                        if (lookup.containsKey(r.getFileName())) {
                            Document d = lookup.get(r.getFileName());
                            if(d.getMetric(networkmetric) != 0.0) {
                                // Ensure that we do not take the log of 0.0
                                ScoreObject s = new ScoreObject(r, score_log(r.getScore(), d.getMetric(networkmetric), w));
                                rerankeddocs.add(s);
                            }else{
                                ScoreObject s = new ScoreObject(r, r.getScore());
                                rerankeddocs.add(s);
                            }
                        } else {
                            // Otherwise we just insert the line as is using its original score
                            ScoreObject s = new ScoreObject(r, r.getScore());
                            rerankeddocs.add(s);
                        }
                    }
                    Comparator<ScoreObject> comp = new ScoreObjectComparator();
                    Collections.sort(rerankeddocs, comp);
                    int position = 1;
                    for (ScoreObject s : rerankeddocs) {
                        pw.println(s.getResultLine().getQueryID() + " Q0 " + s.getResultLine().getFileName() + " " + position + " " + s.getScore() + " ictir2016");
                        position++;
                    }
                    pw.flush();
                }
                pw.flush();
                pw.close();


                double[] x = doTrecEval(qrelsfile, out);
                Date date = new Date();
                //System.out.println(dateFormat.format(date) + " :: Finished evaluating fold " + entry.getKey() + " for w " + w);

                if (x[performancemetric] > BEST_VALUE) {
                    BEST_VALUE = x[performancemetric];
                    BEST_W    = w;
                    BEST_FILE = out;
                }
            }
            System.out.println();
            System.out.println("*******************************************************************************************************");
            System.out.println("*                             FINISHED FOLD NUMBER " + entry.getKey() + "                                                  *");
            System.out.println("*                             Best W value....: " + BEST_W + "                                                   *");
            System.out.println("*                             Best " + getMetricString(performancemetric) + " value..: " + BEST_VALUE + "                                                 *");
            System.out.println("*******************************************************************************************************");
            System.out.println();

            summary.println(BEST_FILE);

        }
        summary.flush();
        summary.close();
    }

    private void reRanksatu(String qrelsfile, int networkmetric, int performancemetric, String outputdir) {
        String outpath = outputdir + networkmetric + "/";
        String summaryfile = outpath + "summary";
        PrintWriter summary = null;
        try {
            summary = new PrintWriter(summaryfile);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        final int nof_weights = 40;
        double[] ws = new double[nof_weights];
        for (int i = 0; i < nof_weights; i++) {
            ws[i] = -1 + (i * 0.05);
        }

        final int nof_ks = 40;
        double[] ks = new double[nof_ks];
        for (int j = 0; j < nof_ks; j++) {
            ks[j] = -1 * (j * 0.05);
        }

        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        for (Map.Entry<Integer, TreeMap<String, Vector<ResultLine>>> entry : FOLDS.entrySet()) {
            // Entry.getKey() is the fold number
            // Entry.getValue() is a TreeMap. The TreeMap is indexed by the query id. The values are the ranked lists for each query id

            TreeMap<String, Vector<ResultLine>> rs = entry.getValue();

            double BEST_VALUE = 0.0;
            double BEST_W = 0.0;
            double BEST_K = 0.0;
            String BEST_FILE = "";
            for (double w : ws) {
                for (double k : ks) {
                    //Now we need to loop over each query in rs
                    String out = outpath + getMetricString(performancemetric) + "-foldnr-" + entry.getKey() + "-w-" + w + "-k-" + k + ".txt";
                    PrintWriter pw = null;
                    try {
                        pw = new PrintWriter(out);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                    assert pw != null;
                    // Loop over individual queries
                    for (Map.Entry<String, Vector<ResultLine>> query : rs.entrySet()) {
                        List<ScoreObject> rerankeddocs = new ArrayList<>();

                        Vector<ResultLine> rankedlist = query.getValue();
                        // Loop over the ranked list of each query
                        for (ResultLine r : rankedlist) {
                            if (lookup.containsKey(r.getFileName())) {
                                Document d = lookup.get(r.getFileName());
                                if(d.getMetric(networkmetric) != 0.0) {
                                    ScoreObject s = new ScoreObject(r, score_satu(r.getScore(), d.getMetric(networkmetric), k, w));
                                    rerankeddocs.add(s);
                                }
                                else{
                                    ScoreObject s = new ScoreObject(r, r.getScore());
                                    rerankeddocs.add(s);
                                }
                            } else {
                                ScoreObject s = new ScoreObject(r, r.getScore());
                                rerankeddocs.add(s);
                            }
                        }
                        Comparator<ScoreObject> comp = new ScoreObjectComparator();
                        Collections.sort(rerankeddocs, comp);
                        int position = 1;
                        for (ScoreObject s : rerankeddocs) {
                            pw.println(s.getResultLine().getQueryID() + " Q0 " + s.getResultLine().getFileName() + " " + position + " " + s.getScore() + " ictir2016");
                            position++;
                        }
                        pw.flush();
                    }
                    pw.flush();
                    pw.close();


                    double[] x = doTrecEval(qrelsfile, out);
                    //System.out.println(dateFormat.format(date) + " :: Finished evaluating fold " + entry.getKey() + " for w " + w);

                    if (x[performancemetric] > BEST_VALUE) {
                        BEST_VALUE = x[performancemetric];
                        BEST_W = w;
                        BEST_K = k;
                        BEST_FILE = out;
                    }
                }
            }
            System.out.println();
            System.out.println("*******************************************************************************************************");
            System.out.println("*                             FINISHED FOLD NUMBER " + entry.getKey() + "                                                  *");
            System.out.println("*                             Best W value....: " + BEST_W + "                                                   *");
            System.out.println("*                             Best K value....: " + BEST_K + "                                                   *");
            System.out.println("*                             Best " + getMetricString(performancemetric) + " value..: " + BEST_VALUE + "                                                 *");
            System.out.println("*******************************************************************************************************");
            System.out.println();

            summary.println(BEST_FILE);

        }
        summary.flush();
        summary.close();
    }


    private void reRanksigm(String qrelsfile, int networkmetric, int performancemetric, String outputdir) {
        String outpath = outputdir + networkmetric + "/";
        String summaryfile = outpath + "summary";
        PrintWriter summary = null;
        try {
            summary = new PrintWriter(summaryfile);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        final int nof_weights = 10;
        double[] ws = new double[nof_weights];
        for (int i = 0; i < nof_weights; i++) {
            ws[i] = -1 + (i * 0.2);
        }

        final int nof_ks = 10;
        double[] ks = new double[nof_ks];
        for (int j = 0; j < nof_ks; j++) {
            ks[j] = -1 * (j * 0.2);
        }

        final int nof_as = 10;
        double[] as = new double[nof_as];
        for (int t = 0; t < nof_as; t++) {
            as[t] = -1 + (t * 0.2);
        }

        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        for (Map.Entry<Integer, TreeMap<String, Vector<ResultLine>>> entry : FOLDS.entrySet()) {
            // Entry.getKey() is the fold number
            // Entry.getValue() is a TreeMap. The TreeMap is indexed by the query id. The values are the ranked lists for each query id

            TreeMap<String, Vector<ResultLine>> rs = entry.getValue();

            double BEST_VALUE  = 0.0;
            double BEST_W = 0.0;
            double BEST_K = 0.0;
            double BEST_A = 0.0;
            String BEST_FILE = "";
            for (double w : ws) {
                for (double k : ks) {
                    for (double a : as) {
                        //Now we need to loop over each query in rs
                        String out = outpath + getMetricString(performancemetric) + "-foldnr-" + entry.getKey() + "-w-" + w + "-k-" + k + "-a-" + a + ".txt";
                        PrintWriter pw = null;
                        try {
                            pw = new PrintWriter(out);
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }
                        assert pw != null;
                        // Loop over individual queries
                        for (Map.Entry<String, Vector<ResultLine>> query : rs.entrySet()) {
                            List<ScoreObject> rerankeddocs = new ArrayList<>();

                            Vector<ResultLine> rankedlist = query.getValue();
                            // Loop over the ranked list of each query
                            for (ResultLine r : rankedlist) {
                                if (lookup.containsKey(r.getFileName())) {
                                    Document d = lookup.get(r.getFileName());
                                    if(d.getMetric(networkmetric) != 0.0) {
                                        ScoreObject s = new ScoreObject(r, score_sigm(r.getScore(), d.getMetric(networkmetric), k, a, w));
                                        rerankeddocs.add(s);
                                    }
                                    else{
                                        ScoreObject s = new ScoreObject(r, r.getScore());
                                        rerankeddocs.add(s);
                                    }
                                } else {
                                    ScoreObject s = new ScoreObject(r, r.getScore());
                                    rerankeddocs.add(s);
                                }
                            }
                            Comparator<ScoreObject> comp = new ScoreObjectComparator();
                            Collections.sort(rerankeddocs, comp);
                            int position = 1;
                            for (ScoreObject s : rerankeddocs) {
                                pw.println(s.getResultLine().getQueryID() + " Q0 " + s.getResultLine().getFileName() + " " + position + " " + s.getScore() + " ictir2016");
                                position++;
                            }
                            pw.flush();
                        }
                        pw.flush();
                        pw.close();


                        double[] x = doTrecEval(qrelsfile, out);
                        //System.out.println(dateFormat.format(date) + " :: Finished evaluating fold " + entry.getKey() + " for w " + w);

                        if (x[performancemetric] > BEST_VALUE) {
                            BEST_VALUE = x[performancemetric];
                            BEST_W = w;
                            BEST_K = k;
                            BEST_A = a;
                            BEST_FILE = out;
                        }
                    }
                }
            }
            System.out.println();
            System.out.println("*******************************************************************************************************");
            System.out.println("*                             FINISHED FOLD NUMBER " + entry.getKey() + "                                                  *");
            System.out.println("*                             Best W value....: " + BEST_W + "                                                   *");
            System.out.println("*                             Best K value....: " + BEST_K + "                                                   *");
            System.out.println("*                             Best A value....: " + BEST_A + "                                                   *");
            System.out.println("*                             Best " + getMetricString(performancemetric) + " value..: " + BEST_VALUE + "                                                 *");
            System.out.println("*******************************************************************************************************");
            System.out.println();

            summary.println(BEST_FILE);

        }
        summary.flush();
        summary.close();
    }

    private double score(double rsv, double coh, double alpha_parameter) {
        return (rsv * alpha_parameter + coh * (1 - alpha_parameter));
    }

    private double score_log(double rsv, double S, double w) {
        return (rsv + (Math.log(S) * w));
    }
/*
    private double score_nonlog(double rsv, double S, double w) {
        return (rsv + (S * w));
    }

    private double score_add(double rsv, double S, double w) {
        return (rsv + Math.sinh(S) * w);
    }

    private double score_exp(double rsv, double S, double w) {
        return (rsv + (Math.exp(S) * w));
    }
*/
    private double score_satu(double rsv, double S, double k, double w) {
        return (rsv + (w * S / (k + S)));
    }

    private double score_sigm(double rsv, double S, double k, double alpha, double w) {
        return (rsv + (w * Math.pow(S, alpha) / (Math.pow(k, alpha) + Math.pow(S, alpha))));
    }

    private double[] doTrecEval(String qrels_file, String file) {
        //System.out.println(qrels_file + " :: " + file);
        //Vector<Double> x = new Vector<Double>(100);
        double[] x = new double[5];
        try {
            String[] command4 = {"trec_eval", "-m", "ndcg_cut", "-m", "recip_rank", "-m", "P", "-m", "map", qrels_file, file};
            final Process proc = Runtime.getRuntime().exec(command4);

            try {
                proc.waitFor();
            } catch (final InterruptedException e) {
                e.printStackTrace();
            }

            final BufferedReader outputReader = new BufferedReader(new InputStreamReader(proc
                    .getInputStream()));
            final BufferedReader errorReader = new BufferedReader(new InputStreamReader(proc
                    .getErrorStream()));

            String line;
            while ((line = outputReader.readLine()) != null) {
                //System.out.println(line);
                double mrr_local    = 0.0;
                double p10_local    = 0.0;
                double ndcg20_local = 0.0;
                double map_local    = 0.0;
                String[] parts = line.split("\\s+");
                if (parts[0].trim().equalsIgnoreCase("recip_rank")) {
                    mrr_local = Double.valueOf(parts[2]);
                    //x.add(MRR_INDEX,mrr_local);
                    x[MRR_INDEX] = mrr_local;
                }
                if (parts[0].trim().equalsIgnoreCase("P_10")) {
                    p10_local = Double.valueOf(parts[2]);
                    //x.add(P10_INDEX, p10_local);
                    x[P10_INDEX] = p10_local;
                }
                if (parts[0].trim().equalsIgnoreCase("ndcg_cut_20")) {
                    ndcg20_local = Double.valueOf(parts[2]);
                    //x.add(NDCG10_INDEX, ndcg10_local);
                    x[NDCG20_INDEX] = ndcg20_local;
                }
                if (parts[0].trim().equalsIgnoreCase("map")) {
                    map_local = Double.valueOf(parts[2]);
                    //x.add(NDCG10_INDEX, ndcg10_local);
                    x[MAP_INDEX] = map_local;
                }
            }
            outputReader.close();
            while ((line = errorReader.readLine()) != null) {
                System.err.println(line);
            }
            errorReader.close();
        } catch (final IOException e) {
            e.printStackTrace();
        }

        String[] command5 = {"perl", "-w", "/home/casper/research/ictir2016/gdeval.pl", qrels_file, file};
        Process proc = null;
        try {
            proc = Runtime.getRuntime().exec(command5);
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            proc.waitFor();
        } catch (final InterruptedException e) {
            e.printStackTrace();
        }

        final BufferedReader outputReader = new BufferedReader(new InputStreamReader(proc
                .getInputStream()));
        final BufferedReader errorReader = new BufferedReader(new InputStreamReader(proc
                .getErrorStream()));
        String line = null;
        try {
            line = outputReader.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }

        assert line != null;
        double err_20 = Double.valueOf(line);
        x[ERR20_INDEX] = err_20;


        return x;
    }

    private String getMetricString(int i){
        String ret = "";
        switch(i){
            case 0: ret = "MRR"; break;
            case 1: ret = "P10"; break;
            case 2: ret = "NDCG20"; break;
            case 3: ret = "ERR20"; break;
            case 4: ret = "MAP"; break;
            default: System.err.println("No default string for performance metric " + i);
                     System.exit(-1);
        }
        return ret;
    }
}


class ScoreObject{
    ResultLine R;
    double SCORE;

    public ScoreObject(ResultLine r, double score){
        R = r;
        SCORE = score;
    }

    public double getScore(){
        return SCORE;
    }

    public ResultLine getResultLine(){
        return R;
    }
}

class ScoreObjectComparator implements Comparator<ScoreObject>{
    // Multiplying by -1 asserts that the ranking is of the form:
    /*
       1 bla bla -6.2
       2 bla bla -6.3
       3 bla bla -6.4
     */
    @Override
    public int compare(ScoreObject o1, ScoreObject o2) {
        return -1*Double.compare(o1.getScore(), o2.getScore());
    }
}

class ResultLine{
    // Input is the result of an IndriRunQuery file e.g.
    // 187 Q0 clueweb09-enwp03-29-13616 1 -4.8881 2016
    private String LINE;
    private String QUERYID;
    private String FILENAME;
    private int POSITION;
    private double SCORE;
    public ResultLine(String line){
        String[] parts = line.split("\\s+");
        LINE           = line;
        QUERYID        = parts[0];
        FILENAME       = parts[2];
        POSITION       = Integer.parseInt(parts[3]);
        SCORE          = Double.parseDouble(parts[4]);
    }

    public String getLine(){
        return LINE;
    }

    public String getFileName(){
        return FILENAME;
    }

    public int getPosition(){
        return POSITION;
    }

    public double getScore(){
        return SCORE;
    }

    public String getQueryID(){
        return QUERYID;
    }
}


class Document{
    private double BIP;
    private double ASSYM_BIP;
    private double REDUNDANCY;
    public Document(double bip, double assym_bip, double redundancy){
        BIP = bip;
        ASSYM_BIP  = assym_bip;
        REDUNDANCY = redundancy;
    }

    public double getMetric(int val){
        switch(val){
            case 0 : return BIP;
            case 1 : return ASSYM_BIP;
            case 2 : return REDUNDANCY;
            default: return -1.0;
        }
    }

    public double getBip(){
        //bipartite clustering coefficient
        return BIP;
    }

    public double getAssymBip(){
        // assymetric bipartite clustering coefficient
        return ASSYM_BIP;
    }

    public double getRedundancy(){
        // redundancy coefficient
        return REDUNDANCY;
    }
}