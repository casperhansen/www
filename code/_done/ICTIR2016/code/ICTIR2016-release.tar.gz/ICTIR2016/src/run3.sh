#/bin/bash

javac -cp . Rerank2.java

echo "Compilation finished"

java -cp . Rerank2 0 0 0;
java -cp . Rerank2 1 0 0;
java -cp . Rerank2 2 0 0;

echo "Finished for MRR"

java -cp . Rerank2 0 0 1;
java -cp . Rerank2 1 0 1;
java -cp . Rerank2 2 0 1;

echo "Finished for P10"

java -cp . Rerank2 0 0 2;
java -cp . Rerank2 1 0 2;
java -cp . Rerank2 2 0 2;

echo "Finished NDCG20"

java -cp . Rerank2 0 0 3;
java -cp . Rerank2 1 0 3;
java -cp . Rerank2 2 0 3;

echo "Finished ERR20"
