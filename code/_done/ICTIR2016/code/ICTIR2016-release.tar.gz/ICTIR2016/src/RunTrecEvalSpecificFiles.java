import java.io.IOException;

/**
 * Created by casper on 4/10/16.
 */
public class RunTrecEvalSpecificFiles {
    public static void main(String[] args) throws IOException {
        System.out.println("0");
        TrecEvalSpecificFiles t1  = new TrecEvalSpecificFiles("/home/casper/research/ictir2016/runs/increasing/0/eval","/home/casper/research/ictir2016/qrels.adhoc");
        System.out.println("1");
        TrecEvalSpecificFiles t2  = new TrecEvalSpecificFiles("/home/casper/research/ictir2016/runs/increasing/1/eval","/home/casper/research/ictir2016/qrels.adhoc");
        System.out.println("2");
        TrecEvalSpecificFiles t3  = new TrecEvalSpecificFiles("/home/casper/research/ictir2016/runs/increasing/2/eval","/home/casper/research/ictir2016/qrels.adhoc");

        System.out.println("BASELINE");
        TrecEvalSpecificFiles baseline  = new TrecEvalSpecificFiles("/home/casper/research/ictir2016/data/code-input/treceval_specificfiles.txt","/home/casper/research/ictir2016/qrels.adhoc");

    }
}
