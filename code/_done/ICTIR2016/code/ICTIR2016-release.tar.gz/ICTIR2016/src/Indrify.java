import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class Indrify {

    public static void main(String[] args) throws IOException{
        FileReader fr = new FileReader("/home/casper/Downloads/cacm-collection.txt");
        BufferedReader br = new BufferedReader(fr);
        String sCurrentLine;
        PrintWriter pw = new PrintWriter("/home/casper/Downloads/cacm-collection-fixed.txt");
        while((sCurrentLine = br.readLine()) != null) {
            if (sCurrentLine.contains("<DOCNO>") || sCurrentLine.contains("</DOC>")) {
                if(sCurrentLine.contains("<DOCNO>")){
                    pw.println(sCurrentLine);
                    pw.println("<TEXT>");
                }else{
                    pw.println("</TEXT>");
                    pw.println(sCurrentLine);
                }
            }else{
                    pw.println(sCurrentLine);
            }
        }
        pw.flush();
        pw.close();
        fr.close();
        br.close();
    }
}
