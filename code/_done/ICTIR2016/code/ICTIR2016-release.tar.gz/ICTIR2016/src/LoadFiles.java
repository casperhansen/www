import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

/**
 * This class loads the network metrics provided by fabien. These metrics may be found at:
 * C:\Casper\Universitet\PhD\Articles\2016\ICTIR\data\original\extracted
 */

public class LoadFiles {
    private HashMap<String, Document> lookup = new HashMap<String, Document>();
    private int linecounter = 0;
    public static void main(String[] args) throws IOException{
        new LoadFiles(args[0]);
    }

    public LoadFiles() throws IOException{

    }

    public LoadFiles(String dir) throws IOException{
        doProcess(dir);
    }

    public void doProcess(String directory) throws IOException{
        File dir = new File(directory);
        File[] files = dir.listFiles();

        assert files != null;
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        System.out.println(dateFormat.format(date) + " :: Starting processing of " + files.length + " files");
        for(File f : files){
            process(f.getAbsolutePath());
            date = new Date();
            System.out.println(dateFormat.format(date) + " :: Finished reading file " + f.getAbsolutePath());
        }
        date = new Date();
        System.out.println(dateFormat.format(date) + " :: Finished all files!");
        System.out.println("Read " + linecounter + " lines");
        System.out.println("Size of lookup table: " + lookup.size() + " entries");
    }

    private void process(String file) throws IOException{
        FileReader fr = new FileReader(file);
        BufferedReader br = new BufferedReader(fr);
        String sCurrentLine;
        while((sCurrentLine = br.readLine()) != null){
            String[] parts = sCurrentLine.split("\\s+");
            Document d     = new Document(Double.parseDouble(parts[1]), Double.parseDouble(parts[2]), Double.parseDouble(parts[3]));
            lookup.put(parts[0].replaceAll(".sentence",""), d);
            linecounter++;
        }
        fr.close();
        br.close();
    }

    public HashMap<String, Document> getLookUp(){
        return lookup;
    }
}


