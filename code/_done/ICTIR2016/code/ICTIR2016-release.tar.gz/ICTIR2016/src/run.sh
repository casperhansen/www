#/bin/bash

# Compile
javac -cp . Rerank2.java

echo "Compilation successful"

java -cp . Rerank2 0 1 0;
java -cp . Rerank2 1 1 0;
java -cp . Rerank2 2 1 0;

java -cp . Rerank2 0 1 1;
java -cp . Rerank2 1 1 1;
java -cp . Rerank2 2 1 1;

java -cp . Rerank2 0 1 2;
java -cp . Rerank2 1 1 2;
java -cp . Rerank2 2 1 2;

java -cp . Rerank2 0 1 3;
java -cp . Rerank2 1 1 3;
java -cp . Rerank2 2 1 3;

echo "Finished MRR for sigm"

#P@10

java -cp . Rerank2 1 2 1;
java -cp . Rerank2 2 2 1;

echo "Finished P@10 for satu"

java -cp . Rerank2 0 3 1;
java -cp . Rerank2 1 3 1;
java -cp . Rerank2 2 3 1;

echo "Finished P@10 for sigm"

#NDCG@20
java -cp . Rerank2 0 1 2;
java -cp . Rerank2 1 1 2;
java -cp . Rerank2 2 1 2;

echo "Finished NDCG@20 for log"

java -cp . Rerank2 0 2 2;
java -cp . Rerank2 1 2 2;
java -cp . Rerank2 2 2 2;

echo "Finished NDCG@20 for satu"

java -cp . Rerank2 0 3 2;
java -cp . Rerank2 1 3 2;
java -cp . Rerank2 2 3 2;

echo "Finished NDCG@20 for sigm"

#ERR@20
java -cp . Rerank2 0 1 3;
java -cp . Rerank2 1 1 3;
java -cp . Rerank2 2 1 3;

echo "Finished ERR@20 for log"

java -cp . Rerank2 0 2 3;
java -cp . Rerank2 1 2 3;
java -cp . Rerank2 2 2 3;

echo "Finished ERR@20 for satu"

java -cp . Rerank2 0 3 3;
java -cp . Rerank2 1 3 3;
java -cp . Rerank2 2 3 3;

echo "Finished ERR@20 for sigm"
