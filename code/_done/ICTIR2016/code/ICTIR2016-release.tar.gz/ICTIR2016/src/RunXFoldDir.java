import org.apache.commons.io.FilenameUtils;

import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.Map;
import java.util.Vector;

public class RunXFoldDir {

    /*
       /home/casper/TREC-123-folds.txt \/home\/casper\/indexes\/TREC\/TREC-123-adhoc\/index\/trec-123-collection-adhoc-stop-porter /home/casper/indexes/TREC/TREC-123-adhoc/qrels/qrels-trec-123.all
       /home/casper/TREC-8-folds.txt \/home\/casper\/indexes\/TREC\/TREC-8-adhoc\/index\/trec8-collection-stop-porter /home/casper/indexes/TREC/TREC-8-adhoc/qrels/qrels.trec8.adhoc

       /home/casper/trec-123/trec-123-folds.txt \/home\/casper\/indexes\/TREC\/TREC-123-adhoc\/index\/trec-123-collection-nostop-nostem/ /home/casper/indexes/TREC/TREC-123-adhoc/qrels/qrels-trec-123.all
     */


    private Vector<String> PATHS              = new Vector<String>();
    private Vector<MTestTrainPair> CVPAIRS    = new Vector<MTestTrainPair>();
    private int NUM_FOLDS                     = 0;
    private double ACC_MRR_SCORE              = 0.0;
    private double ACC_P10_SCORE              = 0.0;
    private double ACC_NDCG20_SCORE           = 0.0;
    private double ACC_ERR20_SCORE            = 0.0;
    private double ACC_MAP_SCORE              = 0.0;
    private int BEST_MU                       = 0;
    private double BEST_VAL                   = 0.0;


    private final int MRR_INDEX               = 0;
    private final int P10_INDEX               = 1;
    private final int NDCG20_INDEX            = 2;
    private final int ERR20_INDEX             = 3;
    private final int MAP_INDEX               = 4;

    public static void main(String[] args){
        /*
          Assume argument is a file containing the paths to the training and test sets
          Lines in the file must specify an Indri query file, and must be in the order:
          <testing-file-fold-0>
          <training-file-fold-0>
          <testing-file-fold-1>
          <training-file-fold-1>
          .
          .
          <testing-file-fold-n>
          <training-file-fold-n>
          The indri query file (assuming here only BM25) can be found examples of at:
          C:\Casper\Universitet\PhD\Queries\cweb09\baseline
          */
        // Argument: Above file, indexlocation and location of qrels
        //String foldfile = "/home/casper/research/ictir2016/folds/indri/folds.txt";
        //String indexlocation = "/home/casper/indexes/cweb09catBNoSpam90percent/";
        //String qrels = "/home/casper/research/ictir2016/qrels.adhoc";
        //new RunXFoldDir(foldfile, indexlocation, qrels);
        new RunXFoldDir(args[0], args[1], args[2]);
    }

    private void readfolds(String file){
        FileReader fr = null;
        try {
            fr = new FileReader(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        BufferedReader br   = new BufferedReader(fr);
        String sCurrentLine = "";
        int counter         = 0;
        try {
            while((sCurrentLine = br.readLine()) != null){
                counter++;
                PATHS.add(sCurrentLine);
            }
        } catch (IOException e) {
            System.err.println("Could not read line after " + sCurrentLine);
            e.printStackTrace();
            System.exit(-1);
        }
        try {
            fr.close();
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        int CVPAIRSADDED = 0;
        for(int j = 0; j < PATHS.size(); j += 2){
            MTestTrainPair tp = new MTestTrainPair(PATHS.get(j), PATHS.get(j+1));
            CVPAIRS.add(tp);
            CVPAIRSADDED++;
        }
        System.out.println("Read " + counter + " paths from " + file + " and added " + CVPAIRSADDED + " x-fold pairs");
    }

    public RunXFoldDir(String file, String indexlocation, String qrels_file){
        readfolds(file);
        int[] mu        = {100, 500, 800, 1000, 2000, 3000, 4000, 5000, 8000, 10000};

        // How many folds
        NUM_FOLDS = (int)PATHS.size()/2;
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        for(int foldnr = 0; foldnr < NUM_FOLDS; foldnr++){
            MTestTrainPair fold = CVPAIRS.elementAt(foldnr);
            String train = fold.getTrainingFile();
            System.out.println("Starting training for fold: " + foldnr);
            //Train
            for(int j = 0; j < mu.length; j++) {
                Date date             = new Date();
                System.out.println(dateFormat.format(date) + " - Starting mu: " + mu[j]);
                run(train, indexlocation, qrels_file, mu[j], true, foldnr);
            }
            System.out.println("Finished all training for fold: " + foldnr);
            System.out.println("Optimal mu values was: " + BEST_MU);
            // Test
            String test = fold.getTestingFile();
            System.out.println("Starting testing for fold: " + foldnr);
            double[] x = run(test, indexlocation, qrels_file, BEST_MU, false, foldnr);
            Date date = new Date();
            System.out.println(dateFormat.format(date) + " :: Finished testing for fold: " + foldnr);
            System.out.println("**************************");
            System.out.println("MRR....: " + x[MRR_INDEX]);
            System.out.println("P@10...: " + x[P10_INDEX]);
            System.out.println("nDCG@20: " + x[NDCG20_INDEX]);
            System.out.println("ERR@20.: " + x[ERR20_INDEX]);
            System.out.println("MAP....: " + x[MAP_INDEX]);
            System.out.println("**************************");
            ACC_MRR_SCORE    = ACC_MRR_SCORE + x[MRR_INDEX];
            ACC_P10_SCORE    = ACC_P10_SCORE + x[P10_INDEX];
            ACC_NDCG20_SCORE = ACC_NDCG20_SCORE + x[NDCG20_INDEX];
            ACC_ERR20_SCORE  = ACC_ERR20_SCORE + x[ERR20_INDEX];
            ACC_MAP_SCORE    = ACC_MAP_SCORE + x[MAP_INDEX];
            BEST_MU          = 0;
            BEST_VAL         = 0.0;
        }

        double AVG_MRR_SCORE    = ACC_MRR_SCORE/(double)NUM_FOLDS;
        double AVG_P10_SCORE    = ACC_P10_SCORE/(double)NUM_FOLDS;
        double AVG_NDCG20_SCORE = ACC_NDCG20_SCORE/(double)NUM_FOLDS;
        double AVG_ERR20_SCORE  = ACC_ERR20_SCORE/(double)NUM_FOLDS;
        double AVG_MAP_SCORE    = ACC_MAP_SCORE/(double)NUM_FOLDS;
        System.out.println("Average MRR score across all folds....: " + AVG_MRR_SCORE);
        System.out.println("Average P@10 score across all folds...: " + AVG_P10_SCORE);
        System.out.println("Average nDCG@10 score across all folds: " + AVG_NDCG20_SCORE);
        System.out.println("Average ERR@20 score across all folds.: " + AVG_ERR20_SCORE);
        System.out.println("Average MAP score across all folds....: " + AVG_MAP_SCORE);
    }

    private double[] run(String file, String indexlocation, String qrels_file, int muval, boolean isTrain, int foldnr) {

        // Change the index
        String tmp = "2s/.*/<index>" + indexlocation + "<\\/index>/";
        String[] command = {"sed", "-i", tmp, file};

        Process runSedCommand = null;
        try {
            runSedCommand = Runtime.getRuntime().exec(command);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            runSedCommand.waitFor();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


        // Set the b-value
        tmp = "6s/.*/<rule>method:dirichlet,mu:"+muval+"<\\/rule>/";
        String[] command2 = {"sed", "-i", tmp, file};
        Process px = null;
        try {
            px = Runtime.getRuntime().exec(command2);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            px.waitFor();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        px.destroy();

        // Now we can run the IndriRunQuery
	String writefile = "";
        if(isTrain){
		writefile = "/home/casper/lmdir-baseline-train-mu:"+muval+"-foldnr-"+foldnr+".out";
	}else{
		writefile = "/home/casper/lmdir-baseline-test-mu:"+ muval+"-foldnr-"+foldnr+".out";
	}

        try {
            String[] command3 = {"IndriRunQuery", file};
            final Process proc = Runtime.getRuntime().exec(command3);
            final BufferedReader outputReader = new BufferedReader(new InputStreamReader(proc
                    .getInputStream()));
            String line;
            PrintWriter pw = new PrintWriter(writefile);
            while ((line = outputReader.readLine()) != null) {
                pw.println(line);
            }
            pw.flush();
            pw.close();
            try {
                proc.waitFor();
            } catch (final InterruptedException e) {
                e.printStackTrace();
            }
/*
            final BufferedReader outputReader = new BufferedReader(new InputStreamReader(proc
                    .getInputStream()));
            final BufferedReader errorReader = new BufferedReader(new InputStreamReader(proc
                    .getErrorStream()));

            String line;
            PrintWriter pw = new PrintWriter("/home/casper/bm25-baseline-train-b:" + bval + ".out");
            while ((line = outputReader.readLine()) != null) {
                pw.println(line);
            }
            pw.flush();
            pw.close();
            while ((line = errorReader.readLine()) != null) {
                System.err.println(line);
            }
*/
        } catch (final IOException e) {
            e.printStackTrace();
        }

        FileReader fr = null;
        try {
            fr = new FileReader(writefile);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        BufferedReader br = new BufferedReader(fr);
        String cLine;
        String fixedFile = writefile + ".fixed";
        PrintWriter pw = null;

        try {
            pw = new PrintWriter(fixedFile);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        assert pw != null;
        try {
            while((cLine = br.readLine()) != null){
                String[] parts = cLine.split("\\s+");
                String filename = parts[2].replace(".text","");
                pw.println(parts[0] + " " + parts[1] + " " + FilenameUtils.getBaseName(filename) + " " + parts[3] + " " + parts[4] + " " + parts[5]);
            }
            pw.flush();
            pw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            fr.close();
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }


        // Now we can run trec_eval
        //Vector<Double> x = new Vector<Double>();
        double[] x = new double[5];
        try {
            String[] command4 = {"trec_eval", "-m", "ndcg_cut", "-m", "recip_rank", "-m", "P", "-m", "map" ,qrels_file, fixedFile};
            final Process proc = Runtime.getRuntime().exec(command4);

            try {
                proc.waitFor();
            } catch (final InterruptedException e) {
                e.printStackTrace();
            }

            final BufferedReader outputReader = new BufferedReader(new InputStreamReader(proc
                    .getInputStream()));
            final BufferedReader errorReader = new BufferedReader(new InputStreamReader(proc
                    .getErrorStream()));

            String line;
            while ((line = outputReader.readLine()) != null) {
                double mrr_local    = 0.0;
                double p10_local    = 0.0;
                double ndcg20_local = 0.0;
                double map_local    = 0.0;
                String[] parts = line.split("\\s+");
                if(parts[0].trim().equalsIgnoreCase("recip_rank")){
                    //System.out.println("b: " + bval + ", MRR: " + parts[2]);
                    mrr_local      = Double.valueOf(parts[2]);
                    x[MRR_INDEX] = mrr_local;
                }
                if(parts[0].trim().equalsIgnoreCase("P_10")){
                    //System.out.println("b: " + bval + ", P@10: " + parts[2]);
                    p10_local      = Double.valueOf(parts[2]);
                    x[P10_INDEX] = p10_local;
                }
                if(parts[0].trim().equalsIgnoreCase("ndcg_cut_20")){
                    //System.out.println("b: " + bval + ", nDCG@10: " + parts[2]);
                    ndcg20_local   = Double.valueOf(parts[2]);
                    x[NDCG20_INDEX] = ndcg20_local;
                }
                if(parts[0].trim().equalsIgnoreCase("map")){
                    map_local = Double.valueOf(parts[2]);
                    if(mrr_local > BEST_VAL){
                        BEST_VAL = map_local;
                        BEST_MU  = muval;
                    }
                    x[MAP_INDEX] = map_local;
                }
            }
            while ((line = errorReader.readLine()) != null) {
                System.err.println(line);
            }
        } catch (final IOException e) {
            e.printStackTrace();
        }


        String[] command5 = {"perl","-w","/home/casper/research/ictir2016/gdeval.pl", qrels_file, fixedFile};
        Process proc = null;
        try {
            proc = Runtime.getRuntime().exec(command5);
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            proc.waitFor();
        } catch (final InterruptedException e) {
            e.printStackTrace();
        }

        final BufferedReader outputReader = new BufferedReader(new InputStreamReader(proc
                .getInputStream()));
        final BufferedReader errorReader = new BufferedReader(new InputStreamReader(proc
                .getErrorStream()));
        String line = null;
        try {
            line = outputReader.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }

        assert line != null;
        double err_20 = Double.valueOf(line);
        x[ERR20_INDEX] = err_20;


        return x;
    }
}

class MTestTrainPair{
    private String testFile;
    private String trainFile;
    public MTestTrainPair(String test, String train){
        testFile  = test;
        trainFile = train;
    }

    public String getTrainingFile(){
        return trainFile;
    }

    public String getTestingFile(){
        return testFile;
    }
}
