package accuracy;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;
import java.util.TreeMap;

/**
  The purpose of this class is:
  1 - You specify a permutation number
  2 - For each file, you look at the coherence score of the chosen permutation and compare it to the ORIGINAL document.
      If the permuted document has a lower coherence score, we count a 1 (let c denote the counter).
  3 - Repeat this for each of the N documents.
  4 - The accuracy for the nth permutation is then c/N.

 */
public class NewAccuracy {
  /*
    - field 1: name of the input document
    - field 5: bipartite clustering coefficient
    - field 6: asymmetric bipartite clustering coefficient
    - field 9: redundancy coefficient

    */
    private final int FILENAME_INDEX = 0;
    private final int BIP_INDEX      = 4;
    private final int ABIP_INDEX     = 5;
    private final int RED_INDEX      = 8;

    public static void main(String[] args) throws IOException {
        // Argument is the folder containing either the accidents or earthquake dataset
        new NewAccuracy(args[0]);
    }

    public NewAccuracy(String dir) throws IOException {
        doProcess(dir);
    }

    private void doProcess(String dir) throws IOException {
        File content = new File(dir);
        File[] files = content.listFiles();

        for(int i = 1; i < 21; i++) {
            int counter = 0;
            int permNotInDoc = 0;
            for (File file : files) {
                int x = processFile(file.getAbsolutePath(), i, RED_INDEX);
                if(x != -1) {
                    counter += x;
                }else{
                    permNotInDoc++;
                }
            }
            // We subtract the number of permutations not found
            System.out.println(i+"\t" + counter/(double)(files.length - permNotInDoc));
        }
    }
/*
  The assumption (by setting RETVAL = 0) is that the original coherence score (org_score) is smaller than the permuted score (perm_score).
  If we find, the permutation number and our assumption is wrong we can return a 1.
  However, consider a file (e.g. for permutation 5) that only has 4 permutations. In this case, because we don't find the fifth permutation
  we are returning 0, which biases the final calculation of the results.
  Thus, we instead normalise by the number of documents where we actually have the permutation. This is what happens
  in the last line of the doProcess method.

 */

    private int processFile(String filepath, int permnumber, int index) throws IOException {
        if(permnumber < 1){
            System.err.println("Permnumber must be 1 or larger");
            System.exit(-1);
        }
        FileReader fr       = new FileReader(filepath);
        BufferedReader br   = new BufferedReader(fr);
        String sCurrentLine = br.readLine();
        String[] parts      = sCurrentLine.split(",");
        double org_score    = Double.parseDouble(parts[index]);

        int RETVAL          = 0;
        boolean PERM_FOUND  = false;
        while((sCurrentLine = br.readLine()) != null){
            parts           = sCurrentLine.split(",");
            String[] permnr = parts[0].split("-");
            int permutation = Integer.parseInt(permnr[2]);
            if(permutation == permnumber){
                PERM_FOUND = true;
                double perm_score = Double.parseDouble(parts[index]);
                // If the score of the original document is higher than the score of the permuted document
                if(perm_score <= org_score){
                    RETVAL = 1;
                    break;
                }
            }
        }
        fr.close();
        br.close();
        if(PERM_FOUND){
            return RETVAL;
        }
        return -1;
    }
}
