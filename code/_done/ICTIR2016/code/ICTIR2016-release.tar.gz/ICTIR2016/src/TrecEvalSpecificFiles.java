/*
  The purpose of this class is to calculate e.g. the mean MAP, P@10 etc for the files specified in the single input.
  The input is a single file containing the absolute paths to the files that should be aggregated over
 */

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Vector;

public class TrecEvalSpecificFiles {
    Vector<String> filestoread = new Vector<>();

    private final int MAP_INDEX = 0;
    private final int MRR_INDEX = 1;
    private final int P10_INDEX = 2;
    private final int NDCG10_INDEX = 3;
    private final int BPREF_INDEX = 4;
    private final int ERR_INDEX   = 5;

    public static void main(String[] args) throws IOException{
        if(args.length == 2){
           new TrecEvalSpecificFiles(args[0], args[1]);
        }else {
            System.err.println("Must supply exactly two files as input");
        }
    }

    public TrecEvalSpecificFiles(String file, String qrelsfile) throws IOException {

        FileReader fr = new FileReader(file);
        BufferedReader br = new BufferedReader(fr);
        String sCurrentLine;
        while((sCurrentLine = br.readLine()) != null){
            filestoread.add(sCurrentLine);
            System.out.println(sCurrentLine);
        }

        int N = filestoread.size();

        System.out.println("Found " + N + " files to process...");

        double MAP_SCORE = 0.0;
        double MRR_SCORE = 0.0;
        double P10_SCORE = 0.0;
        double NDCG20_SCORE = 0.0;
        double ERR_SCORE = 0.0;
        double BPREF_SCORE = 0.0;
        for(String s : filestoread){
            double[] result = processFile(s, qrelsfile);
            // Aggregate
            MAP_SCORE += result[MAP_INDEX];
            MRR_SCORE += result[MRR_INDEX];
            P10_SCORE += result[P10_INDEX];
            NDCG20_SCORE += result[NDCG10_INDEX];
            //BPREF_SCORE += result[BPREF_INDEX];
            ERR_SCORE += result[ERR_INDEX];
        }

        System.out.println("Average MAP across " + N + " folds: " + ((MAP_SCORE/N)));
        System.out.println("Average MRR across " + N + " folds: " + ((MRR_SCORE/N)));
        System.out.println("Average P@10 across " + N + " folds: " + ((P10_SCORE/N)));
        System.out.println("Average nDCG@20 across " + N + " folds: " + ((NDCG20_SCORE/N)));
        System.out.println("Average bpref across " + N + " folds: " + ((BPREF_SCORE/N)));
        System.out.println("Average ERR@20 across " + N + " folds: " + ((ERR_SCORE/N)));
    }

    private double[] processFile(String s, String qrelsfile) throws IOException {
        //Vector<Double> x = new Vector<Double>();
        double[] x = new double[6];
        try {
            String[] command4 = {"trec_eval", "-m", "map", "-m", "recip_rank", "-m", "P", "-m", "ndcg_cut", "-m", "bpref", qrelsfile, s};
            final Process proc = Runtime.getRuntime().exec(command4);

            try {
                proc.waitFor();
            } catch (final InterruptedException e) {
                e.printStackTrace();
            }

            final BufferedReader outputReader = new BufferedReader(new InputStreamReader(proc
                    .getInputStream()));
            final BufferedReader errorReader = new BufferedReader(new InputStreamReader(proc
                    .getErrorStream()));

            String line;
            while ((line = outputReader.readLine()) != null) {
                //System.out.println(line);/home/casper/research/ictir2016/runs/decreasing/1/eval  /home/casper/research/ictir2016/qrels.adhoc
                double map_local    = 0.0;
                double mrr_local    = 0.0;
                double p10_local    = 0.0;
                double ndcg20_local = 0.0;
                double bpref_local  = 0.0;
                String[] parts = line.split("\\s+");
                if (parts[0].trim().equalsIgnoreCase("map")) {
                    //System.out.println("b: " + bval + ", MAP: " + parts[2]);
                    map_local = Double.valueOf(parts[2]);
                    x[MAP_INDEX] = map_local;
                }
                if(parts[0].trim().equalsIgnoreCase("recip_rank")){
                    //System.out.println("b: " + bval + ", MRR: " + parts[2]);
                    mrr_local      = Double.valueOf(parts[2]);
                    //x.add(mrr_local);
                    x[MRR_INDEX] = mrr_local;
                }
                if(parts[0].trim().equalsIgnoreCase("P_10")){
                    //System.out.println("b: " + bval + ", P@10: " + parts[2]);
                    p10_local      = Double.valueOf(parts[2]);
                    //x.add(p10_local);
                    x[P10_INDEX] = p10_local;
                }
                if(parts[0].trim().equalsIgnoreCase("ndcg_cut_20")){
                    //System.out.println("b: " + bval + ", P@10: " + parts[2]);
                    ndcg20_local      = Double.valueOf(parts[2]);
                    //x.add(ndcg10_local);
                    x[NDCG10_INDEX] = ndcg20_local;
                }
                if(parts[0].trim().equalsIgnoreCase("bpref")){
                    //System.out.println("b: " + bval + ", P@10: " + parts[2]);
                    bpref_local      = Double.valueOf(parts[2]);
                    //x.add(bpref_local);
                    x[BPREF_INDEX] = bpref_local;
                }
            }
            while ((line = errorReader.readLine()) != null) {
                System.err.println(line);
            }
        } catch (final IOException e) {
            e.printStackTrace();
        }


        String[] command5 = {"perl","-w","/home/casper/research/ictir2016/gdeval.pl", qrelsfile, s};
        final Process proc = Runtime.getRuntime().exec(command5);

        try {
            proc.waitFor();
        } catch (final InterruptedException e) {
            e.printStackTrace();
        }

        final BufferedReader outputReader = new BufferedReader(new InputStreamReader(proc
                .getInputStream()));
        final BufferedReader errorReader = new BufferedReader(new InputStreamReader(proc
                .getErrorStream()));
        String line = outputReader.readLine();
        double err_20 = Double.valueOf(line);
        x[ERR_INDEX] = err_20;
        return x;
    }
}
