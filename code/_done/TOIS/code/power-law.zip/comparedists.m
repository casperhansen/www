function ret = comparedists(data, distlist, nestdists)
%Compares distributions pair-wise.
%   
%   RET = COMPAREDISTS(DATA, DISTLIST, NESTDIST) stores 
%   (a) the calculated log-likelihood ratios and P-values of the fitted 
%   distributions, (b) the Vuong ratio between each pair of distributions
%   (provided they are not nested -- in that case a 'raw' chi-square 
%   likelihood ratio is calculated. See Clauset et al. 2009 for details)
%   and (c) the Akaikes Information Criteria adjusted for finite sample 
%   size (AICc).
%   
%   [...] = COMPAREDISTS(...) iteratively calls FITDATATODIST to calculate
%   the MLE parameters of a distribution, sample the distributions PDF,
%   calculate the loglikelihood and confidence intervals. Consult the
%   documentation on that file for further comments.
%
%   Input:
%   DATA      - A N x 1 vector of observations. Zeros not allowed.
%   DISTLIST  - A M x 1 cell array containing the identifiers of the
%               distributions used in FITDATATODIST. DISTLIST is the second
%               column in the matrix returned from misc/getDistMapping.m.
%   NESTDISTS - A M x M binary cell array containing information on which
%               distributions nest the distribution on row i <= M.
%
%   Output:
%   RET       - A cell array containing:
%      LRtable  : A M x M matrix of LR values.
%      Ptable   : A M x M matrix of P values associated with the LR values.
%      wasEdited: A M x 1 vector. Indicates if a distribution was fixed.
%      AICtable : A M x 1 vector of AIC values.
%      distFits : A M x 1 cell array containing all structs returned from
%               fitdatatodist.m
%
%   Example (> indicate the MatLab terminal):
%   > addpath('misc','lib','write','clauset');
%   > disttable = getDistMapping;
%   > nesttable = getNestedDistributions;
%   > ret = distPDFcomp(x,disttable, nesttable);
%
%   where x is some vector of observation void of zeros.
%
%   Remarks:
%   1 - The code is only set up for integer data void of zeros.
%   2 - As some datasets causes the MLE parameters to return NaN we label
%       them as bad, rather than replacing them with the highest or lowest
%       value of the system
%   3 - We found that for some data sets, a negative log-likelihood was
%       returned (CHECK AT DET STADIG ER SANDT EFTER VI HAR FJERNET NEWMANS
%       DATA SET).
%
%   Casper Petersen and Jakob Grue Simonsen, 2012
%   Department of Computer Science
%   University of Copenhagen
%
M          = size(distlist,1);
LRtable    = zeros(M,M); Ptable   = zeros(M,M); AICtable = zeros(M,1);
wasEdited  = zeros(M,1); distFits = cell(M,1);  badllike = zeros(M,1);
badPval    = NaN;
badlogls   = zeros(M,1);
blctr      = 1;
% Loop over all distributions and fit each individually
for i = 1 : M
    distFits{i,1}   = fitdatatodist2(data, distlist{i,1}, min(data));    
    fprintf('******************************\n %s : Finished ''%s''\n******************************\n', datestr(clock), distlist{i,1});
end

% Now loop over the fitted distributions and calculate Vuong
for i = 1 : M
    if(ismember(i,badlogls))
       LRtable(i,:)  = badPval;
       Ptable(i,:)   = badPval;
       wasEdited(i)  = 1; 
       AICtable(i,1) = NaN; 
       distFits{i,1} = defunctDist(numel(data), distlist{i,1}, distlist{i,2});
       fprintf('****************************\n Skipping %s\n****************************\n', distlist{i,1});
       continue;        
    end
    current         = distFits{i,1};
    % One of the estimated parameters was NaN (Yes that does happen)
    if(ischar(current.logl)) 
       LRtable(i,:)  = badPval;
       Ptable(i,:)   = badPval;
       wasEdited(i)  = 1; 
       AICtable(i,1) = NaN; 
       if(~ismember(i,badlogls))
          badlogls(blctr) = i; 
          blctr = blctr + 1;
       end
       continue;
    end
    % Save the AIC value for the fitted distribution. This is the finite
    % case AIC. 
    K             = numel(current.parms);
    AIC           = 2*K - 2*current.logl;
    AICtable(i,1) = AIC + (2*K*(K+1))/(numel(data) - K - 1);
    cpdf          = current.pdf;
    if(current.wasEdited)
       wasEdited(i) = 1; 
    end
    for j = 1 : M
        % No point fitting distributions we already know fails.
        if(ismember(j,badlogls))
           LRtable(i,j)  = badPval;
           Ptable(i,j)   = badPval;
           continue;
        end
        % Comparing distributions against themselves is redundant.        
        if(i == j)
           LRtable(i,j) = badPval;
           Ptable(i,j)  = badPval;
           continue; 
        else
           rival = distFits{j,1};
           if(ischar(rival.logl))
              LRtable(i,j) = badPval;
              Ptable(i,j)  = badPval;
              %added
              wasEdited(i)  = 1; 
              AICtable(i,1) = NaN; 
              if(~ismember(j,badlogls))
                 badlogls(blctr) = j; 
                 blctr = blctr + 1;
              end              
              continue;
           end
           rpdf = rival.pdf;
           try
             % Is the i'th distribution nested by the j'th distribution?
             check_nested = ismember(nestdists(i,2:end),distlist{j,1});
             if(any(check_nested))
                % See getNestedDistributions. We only have dof = 1 cases.
                vval         = nested(current.logl, rival.logl,...
                                      numel(current.parms),...
                                      numel(rival.parms),...
                                      numel(cpdf));
                LRtable(i,j) = vval.logdiff;
                Ptable(i,j)  = vval.pval;
             else
                vval         = vuong(cpdf,rpdf,...
                                     numel(current.parms),...
                                     numel(rival.parms));
                LRtable(i,j) = vval.Vuong;
                Ptable(i,j)  = vval.pTwoSided;
             end
           catch err
             error('Error: currentdist %s, rivaldist %s\n',...
                    distlist{i,1}, distlist{j,1});
           end
        end
    end
end

ret = {LRtable, Ptable, wasEdited, AICtable, distFits, badllike};
end

function dstruct = defunctDist(nof_data_points, rand, numparms)
distpdf = ones(nof_data_points, 1);
switch(numparms)
    case 1, parms = [NaN];           ci = [0 0];
    case 2, parms = [NaN, NaN];      ci = [0 0; 0 0];
    case 3, parms = [NaN, NaN, NaN]; ci = [0 0; 0 0; 0 0];    
end
logl    = 'No Info';
dstruct = struct('parms',     parms,...
                 'pdf',       distpdf,...
                 'ci',        ci,...
                 'logl',      logl,...
                 'wasEdited', 0,...
                 'rand', rand);
end