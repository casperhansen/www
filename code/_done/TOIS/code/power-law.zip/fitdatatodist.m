function dstruct = fitdatatodist(data, distname, xmin)
%Fits a distribution to data using maximum likelihood.
%
%   RES = FITDATATODIST(DATA,DISTNAME,XMIN) fits the 
%   distribution identified by DISTNAME to DATA. The distribution's 
%   parameters are estimated using maximum likelihood. The estimated 
%   parameters are returned in DSTRUCT along with a vector of size N x 1 
%   containing samples from the distributions PDF sampled using the 
%   estimated parameters, the 
%   loglikelihood of the fitted distribution, 95% confidence intervals and
%   an edited-flag. USENORM instruct the function to use a normalization 
%   constant when a lower cutoff is applied. After applying a cutoff we
%   need to provide an initial guess of the parameter values. As the MLE
%   and pdfs are sensitive to these initial guess we adopt a multiple
%   restart procedure to try and get an estimate on the parameters.
%
%   [...] = FITDATATODIST(...) employs MatLabs built-in MLE estimator. In 
%   the cases where a closed-form expression does not exist for obtaining 
%   the MLE parameters, MatLabs fminsearch is used.
%
%
%   Input:
%   DATA      - A N x 1 vector of observations. Must contain integer values
%               void of zeros.
%   DISTNAME  - The name of the distribution to fit. This corresponds to
%               any entry in the second column of the table returned by
%               getDistMapping.m.
%   XMIN      - Only observations above or equal to this value is fitted.
%
%   Output:
%   DSTRUCT  - A structure containing:
%             (a) The MLE estimated parameters
%             (b) A N x 1 vector containing samples from the DISTNAME's PDF
%                 sampled used the MLE estimated parameters.
%             (c) The 95% confidence intervals for the estimated paramters.
%             (c) The loglikelihood of the fitted data.
%             (d) The original data.
%             (e) The edited flag (see the fixpdf function at the bottom of
%                 this script).
%
%   Example (> indicate the MatLab terminal):
%   > addpath('misc','lib','write','clauset');
%   > res = fitdatatodist(x, 'exp', min(x));
%
%   Remarks:
%   1 - As we make use of MatLabs builtin MLE estimator, the Optimization
%       toolbox is required in order to run this function.
%   2 - Some distributions used are not native to MatLab and are defined in
%       auxilliary functions. These have been taken from the original
%       papers.
%   3 - Several of the built-in functions do not come with log-likelihood
%       functions. We implement these in the *like.m functions in the lib/
%       directory and list where the log-likelihood functions were taken
%       from.
%
% Casper Petersen and Jakob Grue Simonsen, 2014
% Department of Computer Science
% University of Copenhagen
%

% Cut away all data above specified cutoff
data        = data(data >= xmin);
distname    = lower(distname);
% Update the MLE option set to allow for more iterations.
options = statset('MaxIter',300, 'MaxFunEvals',300);

switch(distname)
    case {'geo','geometric'}, 
         [parms,ci] = mle(data, 'distribution', 'geo','options',options);
         if(any(isnan(parms)) || any(isinf(parms)))
             dstruct    = optimFailed(length(data), 'geo', 1);
         else
%             distpdf    = pdf('Geometric',data, parms);
%             [distpdf, wasEdited] = fixpdf(distpdf);
             distpdf    = likegeo(parms, data);
             logl       = sum(distpdf);
             dstruct    = struct('parms',    parms,...
                                 'pdf',      distpdf,...
                                 'ci',       ci,...
                                 'logl',     logl,...
                                 'wasEdited',0);
         end
         
    case {'nbin','negative binomial'},
          % Memory heavy -- may fail as a result of for large datasets
          [parms,ci] = mle(data, 'distribution', 'nbin',...
                              'options', options);
          
          if(any(isnan(parms)) || any(isinf(parms)))
             dstruct = optimFailed(length(data), 'nbin', 2);
          else
%             r          = parms(1);
%             p          = parms(2);  
%             distpdf    = pdf('Negative Binomial',data, r, p);
%             [distpdf, wasEdited] = fixpdf(distpdf);
             distpdf    = likenbin(parms, data);
             logl       = sum(distpdf);
             dstruct    = struct('parms',    parms,...
                                 'pdf',      distpdf,...
                                 'ci',       ci,...
                                 'logl',     logl,...
                                 'wasEdited',0);
          end                
          
    case {'pois','poisson'}, 
          [parms,ci]  = mle(data, 'distribution', 'Poisson',...
                            'options',options);

          if(any(isnan(parms)) || any(isinf(parms)))
              dstruct    = optimFailed(length(data), 'poiss', 1); 
          else
%              ppdf       = pdf('Poisson', data, parms);
%              [ppdf, wasEdited] = fixpdf(ppdf);
              distpdf    = likepoiss(parms, data);
              logl       = sum(distpdf);
              dstruct    = struct('parms',    parms,...
                                  'pdf',      distpdf,...
                                  'ci',       ci,...
                                  'logl',     logl,...
                                  'wasEdited',0);
          end
          
    case {'powerlaw', 'power-law'},
          % The definition of the PDF is taken from Clauset et al. (2007).
          % In the event that the MLE optimization fails we revert to the
          % non-optimal solution which performs poor for xmin <= 6 
          % according to Clauset et al. (2007).
          try
             a_guess    = 3.5;
             f          = @(d, a) (d.^-a)/zeta_hurwitz(a,xmin);
             [a_hat,ci] = mle(data, 'pdf', f, 'start', a_guess,...
                              'options',options);
          catch err %#ok<NASGU>
             fprintf('MLE optimization failed. Using Eqn 3.7 instead\n');
             a_hat    = 1 + numel(data)/(sum(log(data./xmin)));
             ci       = [NaN, NaN];
          end
%          plpdf    = powerlawpdf(data,a_hat,xmin);
%          [plpdf, wasEdited] = fixpdf(plpdf);
          distpdf  = likepower([a_hat, xmin], data);
          logl     = sum(distpdf);
          dstruct  = struct('parms',    [a_hat, xmin],...
                            'pdf',      distpdf,...
                            'ci',       ci,...
                            'logl',     logl,...
                            'wasEdited',0);
                        
    case {'yule', 'yule-simon'}
         % Similar to Clauset, we use the power law fit as an initial
         % estimate. We also try a range of other parameters.
         pfit       = fitdatatodist(data,'powerlaw', min(data));
         y_guess    = [pfit.parms(1), 0.09, 3.5, 0.00001,0.02,1.4,10]; % Ad hoc
            success = 0;
            yulefunc = @(alpha) -yulell(data, alpha, [], []);
            for i = 1 : numel(y_guess)
                try
                %[parms,ci] = mle(data, 'pdf', @yulepdf, 'start', y_guess(i),...
                %                 'options',options); 
                parms   = fminsearch(yulefunc, pfit.parms(1));
                ci      = [NaN, NaN];
                success = 1;
                catch err %#ok<NASGU>
                  parms = NaN;
                end
                if(success)
                   break; 
                end
            end
         if(any(isnan(parms)) || any(isinf(parms)))
             dstruct    = optimFailed(length(data), 'yule', 1); 
         else
             % We take the exp of the pdf as it is the logarithm already
%             ypdf       = exp(ylpdf(data, parms));
%             [ypdf, wasEdited] = fixpdf(ypdf);
             distpdf    = likeyule(parms, data);
             logl       = sum(distpdf);
             dstruct    = struct('parms',    parms,...
                                 'pdf',      distpdf,...
                                 'ci',       ci,...
                                 'logl',     logl,...
                                 'wasEdited',0);                       
         end
          
    case {'exp','exponential'},
          [parms,ci] = mle(data, 'distribution', 'Exponential',...
                             'options',options);
          if(any(isnan(parms)) || any(isinf(parms)))
              dstruct    = optimFailed(length(data), 'exp', 1);
          else
%              expopdf    = pdf('Exponential',data, parms);
%              [expopdf, wasEdited] = fixpdf(expopdf);
              distpdf    = likeexp(parms, data);
              logl       = sum(distpdf);
              dstruct    = struct('parms',    parms,...
                                  'pdf',      distpdf,...
                                  'ci',       ci,...
                                  'logl',     logl,...
                                  'wasEdited',0);
          end            
          
    case {'gam','gamma'},
          [parms,ci] = mle(data, 'distribution', 'Gamma',...
                           'options',options);

          if(any(isnan(parms)) || any(isinf(parms)))
              dstruct = optimFailed(length(data), 'gam', 2);
          else
%              a          = parms(1); 
%              b          = parms(2); 
%              distpdf    = pdf('Gamma',data, a, b);
%              [distpdf, wasEdited] = fixpdf(distpdf);
              distpdf    = likegam(parms, data);
              logl       = sum(distpdf);
              dstruct    = struct('parms',    parms,...
                                  'pdf',      distpdf,...
                                  'ci',       ci,...
                                  'logl',     logl,...
                                  'wasEdited',0);
          end
                          
    case {'gev','generalized extreme value'}, 
          % We employ a minimal modified version of MatLab's gev-fitting 
          % procedure. The changes are:
          % 1 - The non-linear optimization routine is fminunc
          % 2 - Calculation of the gradients are included.
          % We use this procedure as the derivate-free fminsearch used by
          % default, returns parameters that, compared to fitting packages
          % for Python and Octave are (i) quite different and visually very
          % different, when the fit is plotted.

          %[parms,ci] = octave_gevfit(data);
          [parms,ci] = mygevfit(data,[]);
 
          if(any(isnan(parms)) || any(isinf(parms)))
              dstruct = optimFailed(length(data), 'gev', 3);
          else
%              k          = parms(1);
%              sigma      = parms(2);
%              mu         = parms(3);
%              distpdf    = pdf('Generalized Extreme Value',data, k, sigma, mu);
%              [distpdf, wasEdited] = fixpdf(distpdf);
              distpdf    = likegev(parms, data);
              logl       = sum(distpdf);
              dstruct    = struct('parms',    parms,...
                                  'pdf',      distpdf,...
                                  'ci',       ci,...
                                  'logl',     logl,...
                                  'wasEdited',0);
          end
          
    case {'gp', 'generalized pareto'},
         % The MLE of the Generalizd Pareto distribution estimates only two
         % of the three parameters. For this reason we explicitly set the
         % location parameters to the smallest value in the data set minus
         % one to ensure to ensure nothing is removed.
          [parms,ci] = mle(data, 'distribution', 'gp',...
                            'options', options);

          if(any(isnan(parms)) || any(isinf(parms)))
             dstruct = optimFailed(length(data), 'gp', 3);
          else
             shape      = parms(1);
             scale      = parms(2);
             location   = min(data)-1;
             parms      = [shape, scale, location];
%             distpdf    = pdf('Generalized Pareto',data,shape,scale,location);
%             [distpdf, wasEdited] = fixpdf(distpdf);
             distpdf    = likegp(parms, data);
             logl       = sum(distpdf);
             dstruct    = struct('parms',    parms,...
                                 'pdf',      distpdf,...
                                 'ci',       ci,...
                                 'logl',     logl,...
                                 'wasEdited',0);
          end
          
    case {'inormal', 'igauss', 'inversegaussian'},
          [parms,ci] = mle(data, 'distribution','inversegaussian',...
                             'options',options);
          if(any(isnan(parms)) || any(isinf(parms)))
              dstruct = optimFailed(length(data), 'igauss', 2);
          else
%              mu         = parms(1); 
%              lambda     = parms(2); 
%              ineval     = igausspdf(data, mu, lambda);
%              [ineval, wasEdited] = fixpdf(ineval);
              distpdf    = likeigauss(parms, data);
              logl       = sum(distpdf);
              dstruct    = struct('parms',    parms,...
                                  'pdf',      distpdf,...
                                  'ci',       ci,...
                                  'logl',     logl,...
                                  'wasEdited',0);
          end
          
    case {'logn', 'lognormal'},
          [parms,ci] = mle(data, 'distribution','Lognormal',...
                              'options',options);
 
          if(any(isnan(parms)) || any(isinf(parms)))
              dstruct = optimFailed(length(data), 'logn', 2);
          else
%              mu         = parms(1);
%              sigma      = parms(2);
%              lpdf       = pdf('Lognormal',data, mu, sigma);
%              [lpdf, wasEdited] = fixpdf(lpdf);
              distpdf    = likelogn(parms, data);
              logl       = sum(distpdf);
              dstruct    = struct('parms',    parms,...
                                  'pdf',      distpdf,...
                                  'ci',       ci,...
                                  'logl',     logl,...
                                  'wasEdited',0);
          end

    case {'logistic','log'},
         [parms,ci] = mle(data, 'distribution','logistic',...
                            'options',options);

          if(any(isnan(parms)) || any(isinf(parms)))
              dstruct = optimFailed(length(data), 'log', 2);
          else
%              mu         = parms(1); 
%              sigma      = parms(2); 
%              lpdf       = logpdf(data, mu, sigma);
%              [lpdf, wasEdited] = fixpdf(lpdf);
              distpdf    = likelog(parms, data);
              logl       = sum(distpdf);
              dstruct    = struct('parms',    parms,...
                                  'pdf',      distpdf,...
                                  'ci',       ci,...
                                  'logl',     logl,...
                                  'wasEdited',0);
          end
          
    case {'nakagami','naka'}, 
          [parms,ci] = mle(data, 'distribution','nakagami',...
                              'options',options);

          if(any(isnan(parms)) || any(isinf(parms)))
              dstruct = optimFailed(length(data), 'naka', 2);
          else
%              mu         = parms(1);
%              om         = parms(2);
%              npdf       = nakagamipdf(data, mu, om);
%              [npdf, wasEdited] = fixpdf(npdf);
              distpdf    = likenaka(parms, data);
              logl       = sum(distpdf);
              dstruct    = struct('parms',    parms,...
                                  'pdf',      distpdf,...
                                  'ci',       ci,...
                                  'logl',     logl,...
                                  'wasEdited',0);
          end           
          
    case {'normal', 'gaussian', 'gauss'},
          [parms,ci] = mle(data, 'options', options);
          
          if(any(isnan(parms)) || any(isinf(parms)))
             dstruct    = optimFailed(length(data), 'norm', 2);
          else
%             mu         = parms(1);
%             stds       = parms(2);
%             npdf       = normpdf(data, mu, stds);
%             [npdf, wasEdited] = fixpdf(npdf);
             distpdf    = likenorm(parms, data);
             logl       = sum(distpdf);
             dstruct    = struct('parms',    parms,...
                                 'pdf',      distpdf,...
                                 'ci',       ci,...
                                 'logl',     logl,...
                                 'wasEdited',0);
         end         
         
    case {'rayleigh','ray','rayl'},
         [parms,ci]  = mle(data, 'distribution', 'Rayleigh',...
                                  'options',options);
          if(any(isnan(parms)) || any(isinf(parms)))
              dstruct     = optimFailed(length(data), 'rayl',1); 
          else
%              scale       = parms(1);
%              rpdf        = pdf('Rayleigh', data, scale);
%              [rpdf, wasEdited] = fixpdf(rpdf);
              distpdf     = likerayl(parms, data);
              logl        = sum(distpdf);
              dstruct     = struct('parms',    parms,...
                                   'pdf',      distpdf,...
                                   'ci',       ci,...
                                   'logl',     logl,...
                                   'wasEdited',0);
          end        
          
    case {'weib','weibull', 'wbl'},
          [parms,ci] = mle(data, 'distribution','wbl','options',options);

          if(any(isnan(parms)) || any(isinf(parms)))
              dstruct    = optimFailed(length(data), 'wbl', 2);
          else
%              scale      = parms(1);
%              shape      = parms(2);
%              wpdf       = pdf('wbl', data, scale, shape);
%              [wpdf, wasEdited] = fixpdf(wpdf);
              distpdf    = likewbl(parms, data);
              logl       = sum(distpdf);
              dstruct    = struct('parms',    parms,...
                                  'pdf',      distpdf,...
                                  'ci',       ci,...
                                  'logl',     logl,...
                                  'wasEdited',0);
          end
    otherwise, error('Distribution identified by %s not recognized\n', distname);
end
end

%function ret = locallogl(data)
% This subroutine is used to calculate the loglikelihood of the data.
%ret = sum(log(data));
%end

function dstruct = optimFailed(nof_data_points, dist, numparms)
fprintf('%s: failed optimization - one or more parameters are NaN, Inf or 0\n', dist);
distpdf = ones(nof_data_points, 1);
switch(numparms)
    case 1, parms = NaN; ci = [0 0];
    case 2, parms = [NaN, NaN]; ci = [0 0; 0 0];
    case 3, parms = [NaN, NaN, NaN]; ci = [0 0; 0 0; 0 0];    
end
logl    = 'No Info';
dstruct = struct('parms',     parms,...
                 'pdf',       distpdf,...
                 'ci',        ci,...
                 'logl',      logl,...
                 'wasEdited', 0);
end

function [inpdf, wasEdited] = fixpdf(inpdf)
% This function performs two tasks. First, it replaces NaNs from the input
% pdf with zeros, and secondly it removes zeros from the input pdf. The 
% former case occurs as the MLE estimated parameters can cause the PDF 
% sampled in the data points using said parameters to return NaNs. In the
% latter case, zeros entries are replaced by epsilon to avoid crashing the
% subsequent Vuong calculation.
wasEdited  = 0;

% Remove NaNs
inpdf(isnan(inpdf)) = 0;

% Find and replace 0 entries
badEntries = find(not(inpdf));
if(not(isempty(badEntries)))
   inpdf(badEntries) = eps; 
   wasEdited = 1;
end
end