function dstruct = fitdatatodist(data, distname, xmin, usenorm)
%Fits a distribution to data using maximum likelihood.
%
%   DSTRUCT = FITDATATODIST(DATA,DISTNAME,XMIN,USENORM) fits the 
%   distribution identified by DISTNAME to DATA having size N x 1 using a 
%   lower cutoff value of XMIN. The distributions parameters is estimated 
%   using maximum likelihood. The estimated parameters are returned in 
%   DSTRUCT along with a vector of size N x 1 containing samples from the 
%   distributions PDF sampled using the estimated parameters, the 
%   loglikelihood of the fitted distribution, 95% confidence intervals and
%   an edited-flag. USENORM instruct the function to use a normalization 
%   constant when a lower cutoff is applied. After applying a cutoff we
%   need to provide an initial guess of the parameter values. As the MLE
%   and pdfs are sensitive to these initial guess we adopt a multiple
%   restart procedure to try and get an estimate on the parameters.
%
%   [...] = FITDATATODIST(...) employs MatLabs built-in MLE estimator. In 
%   the cases where a closed-form expression does not exist for obtaining 
%   the MLE parameters, MatLabs fminsearch is used.
%
%
%   Input:
%   DATA      - A N x 1 vector of observations. Must contain integer values
%               void of zeros.
%   DISTNAME  - The name of the distribution to fit. This corresponds to
%               any entry in the second column of the table returned by
%               getDistMapping.m.
%   XMIN      - Only observations above or equal to this value is fitted.
%
%   Output:
%   DSTRUCT  - A structure containing:
%             (a) The MLE estimated parameters
%             (b) A N x 1 vector containing samples from the DISTNAME's PDF
%                 sampled used the MLE estimated parameters.
%             (c) The 95% confidence intervals for the estimated paramters.
%             (c) The loglikelihood of the fitted data.
%             (d) The original data.
%             (e) The edited flag (see the fixpdf function at the bottom of
%                 this script).
%
%   Example (> indicate the MatLab terminal):
%   > addpath('misc','lib','write','clauset');
%   > dstruct= distPDFcomp(x, 'exp', min(x));
%
%   Remarks:
%   1 - As we make use of MatLabs builtin MLE estimator, the Optimization
%       toolbox is required in order to run this function.
%   2 - Some distributions used are not native to MatLab and are defined in
%       auxilliary functions. These have been taken from the original
%       papers.
%
%
% Casper Petersen and Jakob Grue Simonsen, 2014
% Department of Computer Science
% University of Copenhagen
%

% Cut away all data above x_min
global mxmin;
mxmin       = xmin;
data        = data(data >= xmin);
distname    = lower(distname);
uParmLimit  = 99999;
NOF_GUESSES = 10;
% Update the MLE option set to allow for more iterations.
options = statset('MaxIter',300, 'MaxFunEvals',Inf);

switch(distname)
    case {'geo','geometric'}, 
         parms = [NaN];
         if(usenorm)
           parmCombs = rRestart([0,1], NOF_GUESSES); % Produce five guesses of the p value
           [M,~]     = size(parmCombs);
           for i = 1 : M
               try
                 [parms,ci] = mle(data, 'pdf', @geopdfxmin, 'start', parmCombs(i,:)); 
                 break;
               catch err %#ok<NASGU>
                  continue; 
               end
           end              
         else
           [parms,ci] = mle(data, 'distribution', 'geo','options',options);
         end
         if(any(isnan(parms)) || any(isinf(parms)))
             dstruct    = optimFailed(length(data), 'geo', 'geornd', 1);
         else
             distpdf    = pdf('Geometric',data, parms);
             [distpdf, wasEdited] = fixpdf(distpdf);
             logl       = locallogl(distpdf);
             dstruct    = struct('parms',    parms,...
                                 'pdf',      distpdf,...
                                 'ci',       ci,...
                                 'logl',     logl,...
                                 'wasEdited', wasEdited,...
                                 'rand', 'geornd');
         end
    case {'nbin','negative binomial'},
          % Memory heavy -- may fail as a result of for large datasets
          parms = [NaN, NaN];
          if(usenorm)
            % r > 0 
            % p \in (0,1)
            parmCombs = rRestart([0,uParmLimit,0,1], NOF_GUESSES); % Produce four guesses of the p value
            [M,~]     = size(parmCombs);
            for i = 1 : M
                try
                  [parms,ci] = mle(data, 'pdf', @nbinpdfxmin, 'start', parmCombs(i,:)); 
                  break;
                catch err %#ok<NASGU>
                   continue; 
                end
            end              
          else              
            [parms,ci] = mle(data, 'distribution', 'nbin',...
                             'options', options);
          end
          r          = parms(1);
          p          = parms(2);    
          
          if(any(isnan(parms)) || any(isinf(parms)))
             dstruct = optimFailed(length(data), 'nbin', 'nbinrnd', 2);
          else
             distpdf    = pdf('Negative Binomial',data, r, p);
             [distpdf, wasEdited] = fixpdf(distpdf);
             logl       = locallogl(distpdf);
             dstruct    = struct('parms',     parms,...
                                 'pdf',       distpdf,...
                                 'ci',        ci,...
                                 'logl',      logl,...
                                 'wasEdited', wasEdited,...
                                 'rand', 'nbinrnd');
          end                
          
    case {'pois','poisson'}, 
          parms = [NaN];
          if(usenorm)
            % lambda > 0 
            parmCombs = rRestart([0,uParmLimit], NOF_GUESSES); % Produce four guesses of the p value
            [M,~]     = size(parmCombs);
            for i = 1 : M
                try
%                  fprintf('%1.4f\n', parmCombs(i,:));
                  [parms,ci] = mle(data, 'pdf', @poisspdfxmin, 'start', parmCombs(i,:)); 
                  break;
                catch err %#ok<NASGU>
                   continue; 
                end
            end              
          else 
          [parms,ci]  = mle(data, 'distribution', 'Poisson',...
                            'options',options);
          end
          if(any(isnan(parms)) || any(isinf(parms)))
              dstruct    = optimFailed(length(data), 'poiss', 'poissrnd', 1); 
          else
              ppdf       = pdf('Poisson', data, parms);
              [ppdf, wasEdited] = fixpdf(ppdf);
              logl       = locallogl(ppdf);
              dstruct    = struct('parms',    parms,...
                                  'pdf',      ppdf,...
                                  'ci',       ci,...
                                  'logl',     logl,...
                                  'wasEdited', wasEdited,...
                                  'rand',     'poissrnd');
          end
          
    case {'powerlaw', 'power-law'},
          % The definition of the PDF is taken from Clauset et al. (2007).
          % In the event that the MLE optimization fails we revert to the
          % non-optimal solution which performs poor for xmin <= 6 
          % according to Clauset et al. (2007).
          try
             a_guess    = 3.5;
             f          = @(d, a) (d.^-a)/zeta_hurwitz(a,xmin);
             [a_hat,ci] = mle(data, 'pdf', f, 'start', a_guess,...
                              'options',options);
          catch err %#ok<NASGU>
             fprintf('MLE optimization failed. Using Eqn 3.7 instead\n');
             a_hat    = 1 + numel(data)/(sum(log(data./xmin)));
             ci       = [NaN, NaN];
          end
          plpdf    = powerlawpdf(data,a_hat,xmin);
          [plpdf, wasEdited] = fixpdf(plpdf);
          logl     = locallogl(plpdf);
          dstruct  = struct('parms',    [a_hat, xmin],...
                            'pdf',      plpdf,...
                            'ci',       ci,...
                            'logl',     logl,...
                            'wasEdited', wasEdited,...
                            'rand', 'randht');
                        
    case {'yule', 'yule-simon'}
         y_guess    = [0.09, 3.5, 0.00001,0.02,1.4,10,40,100,200,500,6000,20000, 40000000]; % Ad hoc
            success = 0;
            for i = 1 : numel(y_guess)
                try
                [parms,ci] = mle(data, 'pdf', @yulepdf, 'start', y_guess(i),...
                                 'options',options);    
                success = 1;
                catch err
                  parms = NaN;
                  fprintf('Yule :: No luck on parameter guess %d\n', y_guess(i));
                end
                if(success)
                   break; 
                end
            end
         if(any(isnan(parms)) || any(isinf(parms)))
             dstruct    = optimFailed(length(data), 'yule', 'yulernd', 1); 
         else
             ypdf       = yulepdf(data, parms);
             [ypdf, wasEdited] = fixpdf(ypdf);
             logl       = locallogl(ypdf);
             dstruct    = struct('parms',    parms,...
                                 'pdf',      ypdf,...
                                 'ci',       ci,...
                                 'logl',     logl,...
                                 'wasEdited', wasEdited,...
                                 'rand', 'yulernd');                       
         end
          
    case {'exp','exponential'},
          parms = [NaN];
          if(usenorm)
            % mu > 0 
            parmCombs = rRestart([0,uParmLimit], NOF_GUESSES);
            [M,~]     = size(parmCombs);
            for i = 1 : M
                try
                  [parms,ci] = mle(data, 'pdf', @exppdfxmin, 'start', parmCombs(i,:)); 
                  break;
                catch err %#ok<NASGU>
                   continue; 
                end
            end              
          else         
            [parms,ci] = mle(data, 'distribution', 'Exponential',...
                             'options',options);
          end
          
          if(any(isnan(parms)) || any(isinf(parms)))
              dstruct    = optimFailed(length(data), 'exp', 'exprnd', 1);
          else
              expopdf    = pdf('Exponential',data, parms);
              [expopdf, wasEdited] = fixpdf(expopdf);
              expl       = locallogl(expopdf);
              dstruct    = struct('parms',    parms,...
                                  'pdf',      expopdf,...
                                  'ci',       ci,...
                                  'logl',     expl,...
                                  'wasEdited', wasEdited,...
                                  'rand', 'exprnd');
          end            
          
    case {'gam','gamma'},
          parms = [NaN,NaN];
          if(usenorm)
            parmCombs = rRestart([0,uParmLimit,0,uParmLimit], NOF_GUESSES); % Produce four guesses of the p value
            [M,~]     = size(parmCombs);
            for i = 1 : M
                try
                  [parms,ci] = mle(data, 'pdf', @gampdfxmin, 'start', parmCombs(i,:),'optimfun','fmincon'); 
                  break;
                catch err %#ok<NASGU>
                  continue; 
                end
            end              
          else        
            [parms,ci] = mle(data, 'distribution', 'Gamma',...
                           'options',options);
          end
          if(any(isnan(parms)) || any(isinf(parms)))
              dstruct = optimFailed(length(data), 'gam', 'gamrnd', 2);
          else
              a          = parms(1); 
              b          = parms(2); 
              distpdf    = pdf('Gamma',data, a, b);
              [distpdf, wasEdited] = fixpdf(distpdf);
              glike      = locallogl(distpdf);
              dstruct    = struct('parms',    parms,...
                                  'pdf',      distpdf,...
                                  'ci',       ci,...
                                  'logl',     glike,...
                                  'wasEdited', wasEdited,...
                                  'rand', 'gamrnd');
          end
                          
    case {'gev','generalized extreme value'}, 
    % Gives convergence warning. Increase 'MaxFunEvals' in the options at
    % the beginning of this file to change the number. Experiments with
    % increasing this value did not clear the warning. If this becomes too
    % annoying write 'warning off' in the MatLab terminal, but keep in mind
    % that this turns off ALL warnings.
          parms = [NaN, NaN, NaN];
          if(usenorm)
            % mu > 0 
            parmCombs = rRestart([-uParmLimit,uParmLimit, 0, uParmLimit, -uParmLimit, uParmLimit], NOF_GUESSES); % Produce four guesses of the p value
            [M,~]     = size(parmCombs);
            for i = 1 : M
                try
                  [parms,ci] = mle(data, 'pdf', @gevpdfxmin, 'start', parmCombs(i,:)); 
                  break;
                catch err %#ok<NASGU>
                   continue; 
                end
            end              
          else            
            [parms,ci] = mle(data, 'distribution', 'gev','options',options);
          end
          if(any(isnan(parms)) || any(isinf(parms)))
              dstruct = optimFailed(length(data), 'gev', 'gevrnd', 3);
          else
              k          = parms(1);
              sigma      = parms(2);
              mu         = parms(3);
              distpdf    = pdf('Generalized Extreme Value',data, k, sigma, mu);
              [distpdf, wasEdited] = fixpdf(distpdf);
              gevl       = locallogl(distpdf);
              dstruct    = struct('parms',    parms,...
                                  'pdf',      distpdf,...
                                  'ci',       ci,...
                                  'logl',     gevl,...
                                  'wasEdited', wasEdited,...
                                  'rand', 'gevrnd');
          end
          
    case {'gp', 'generalized pareto'},
         % The MLE of the Generalizd Pareto distribution estimates only two
         % of the three parameters. For this reason we explicitly set the
         % location parameters to the smallest value in the data set minus
         % one to ensure to ensure nothing is removed.
          parms = [NaN, NaN, NaN];
          if(usenorm)
            % mu > 0 
            parmCombs = rRestart([-uParmLimit,uParmLimit,0,uParmLimit,-uParmLimit,uParmLimit], NOF_GUESSES); % Produce four guesses of the p value
            [M,~]     = size(parmCombs);
            for i = 1 : M
                try
                  [parms,ci] = mle(data, 'pdf', @gppdfxmin, 'start', parmCombs(i,:)); 
                  break;
                catch err %#ok<NASGU>
                   continue; 
                end
            end              
          else         
            [parms,ci] = mle(data, 'distribution', 'gp',...
                            'options', options);
          end
          
          if(any(isnan(parms)) || any(isinf(parms)))
             dstruct = optimFailed(length(data), 'gp', 'gprnd', 3);
          else
             shape      = parms(1);
             scale      = parms(2);
             location   = min(data)-1;
             %location   = parms(3);
             parms      = [shape, scale, location];
             distpdf    = pdf('Generalized Pareto',data,shape,scale,location);
             [distpdf, wasEdited] = fixpdf(distpdf);
             gpl        = locallogl(distpdf);
             dstruct    = struct('parms',    parms,...
                                 'pdf',      distpdf,...
                                 'ci',       ci,...
                                 'logl',     gpl,...
                                 'wasEdited', wasEdited,...
                                 'rand', 'gprnd');
          end
          
    case {'inormal', 'igauss'},
          parms = [NaN, NaN];  
          if(usenorm)
            % mu > 0 
            parmCombs = rRestart([0,uParmLimit, 0, uParmLimit], NOF_GUESSES); % Produce four guesses of the p value
            [M,~]     = size(parmCombs);
            for i = 1 : M
                try
                  [parms,ci] = mle(data, 'pdf', @igausspdfxmin, 'start', parmCombs(i,:)); 
                  break;
                catch err %#ok<NASGU>
                   continue; 
                end
            end              
          else         
             [parms,ci] = mle(data, 'distribution','inversegaussian',...
                             'options',options);
          end
          if(any(isnan(parms)) || any(isinf(parms)))
              dstruct = optimFailed(length(data), 'igauss', 'igaussrnd', 2);
          else
              mu         = parms(1); 
              lambda     = parms(2); 
              ineval     = igausspdf(data, mu, lambda);
              [ineval, wasEdited] = fixpdf(ineval);
              iglike     = locallogl(ineval);
              dstruct    = struct('parms',    parms,...
                                  'pdf',      ineval,...
                                  'ci',       ci,...
                                  'logl',     iglike,...
                                  'wasEdited', wasEdited,...
                                  'rand', 'igaussrnd');
          end
          
    case {'logn', 'lognormal'},
          parms = [NaN, NaN];
          if(usenorm)
            % mu > 0 
            parmCombs = rRestart([-uParmLimit,uParmLimit,0,uParmLimit], NOF_GUESSES); % Produce four guesses of the p value
            [M,~]     = size(parmCombs);
            for i = 1 : M
                try
                  [parms,ci] = mle(data, 'pdf', @lognpdfxmin, 'start', parmCombs(i,:)); 
                  break;
                catch err %#ok<NASGU>
                   continue; 
                end
            end              
          else         
             [parms,ci] = mle(data, 'distribution','Lognormal',...
                              'options',options);
          end
          
          if(any(isnan(parms)) || any(isinf(parms)))
              dstruct = optimFailed(length(data), 'logn', 'lognrnd', 2);
          else
              mu         = parms(1);
              sigma      = parms(2);
              lpdf       = pdf('Lognormal',data, mu, sigma);
              [lpdf, wasEdited] = fixpdf(lpdf);
              llike      = locallogl(lpdf);
              dstruct    = struct('parms',    parms,...
                                  'pdf',      lpdf,...
                                  'ci',       ci,...
                                  'logl',     llike,...
                                  'wasEdited', wasEdited,...
                                  'rand', 'lognrnd');
          end

    case {'logistic','log'},
           parms = [NaN, NaN];
           if(usenorm)
              parmCombs = rRestart([-uParmLimit,uParmLimit,0,uParmLimit], NOF_GUESSES); % Produce four guesses of the p value
              [M,~]     = size(parmCombs);
              for i = 1 : M
                  try
                    [parms,ci] = mle(data, 'pdf', @logpdfxmin, 'start', parmCombs(i,:)); 
                    break;
                  catch err %#ok<NASGU>
                     continue; 
                  end
              end              
           else         
            [parms,ci] = mle(data, 'distribution','logistic',...
                            'options',options);
           end
          if(any(isnan(parms)) || any(isinf(parms)))
              dstruct = optimFailed(length(data), 'log', 'logrnd', 2);
          else
              mu         = parms(1); 
              sigma      = parms(2); 
              lpdf       = logpdf(data, mu, sigma);
              [lpdf, wasEdited] = fixpdf(lpdf);
              llog       = locallogl(lpdf);
              dstruct    = struct('parms',    parms,...
                                  'pdf',      lpdf,...
                                  'ci',       ci,...
                                  'logl',     llog,...
                                  'wasEdited', wasEdited,...
                                  'rand', 'logrnd');
          end
          
    case {'nakagami','naka'}, 
          parms = [NaN, NaN];
          if(usenorm)
            % mu > 0 
            parmCombs = rRestart([0,uParmLimit,0,uParmLimit], NOF_GUESSES); % Produce four guesses of the p value
            [M,~]     = size(parmCombs);
            for i = 1 : M
                try
                  [parms,ci] = mle(data, 'pdf', @nakagamipdfxmin, 'start', parmCombs(i,:)); 
                  break;
                catch err %#ok<NASGU>
                   continue; 
                end
            end              
          else         
             [parms,ci] = mle(data, 'distribution','nakagami',...
                              'options',options);
          end
          
          if(any(isnan(parms)) || any(isinf(parms)))
              dstruct = optimFailed(length(data), 'naka', 'nakarnd', 2);
          else
              mu         = parms(1);
              om         = parms(2);
              npdf       = nakagamipdf(data, mu, om);
              [npdf, wasEdited] = fixpdf(npdf);
              nlike      = locallogl(npdf);
              dstruct    = struct('parms',    parms,...
                                  'pdf',      npdf,...
                                  'ci',       ci,...
                                  'logl',     nlike,...
                                  'wasEdited', wasEdited,...
                                  'rand', 'nakarnd');
          end           
          
    case {'normal'},
          parms = [NaN, NaN];
          if(usenorm)
             parmCombs = rRestart([-uParmLimit,uParmLimit,0,uParmLimit], NOF_GUESSES); % Produce four guesses of the p value
             [M,~]     = size(parmCombs);
             for i = 1 : M
                 try
                   [parms,ci] = mle(data, 'pdf', @normpdfxmin, 'start', parmCombs(i,:)); 
                   break;
                 catch err %#ok<NASGU>
                    continue; 
                 end
             end              
          else         
             [parms,ci] = mle(data, 'options', options);
          end
          
          if(any(isnan(parms)) || any(isinf(parms)))
             dstruct    = optimFailed(length(data), 'norm', 'normrnd', 2);
          else
             mu         = parms(1);
             stds       = parms(2);
             npdf       = normpdf(data, mu, stds);
             [npdf, wasEdited] = fixpdf(npdf);
             nlog       = locallogl(npdf);
             dstruct    = struct('parms',    parms,...
                                 'pdf',      npdf,...
                                 'ci',       ci,...
                                 'logl',     nlog,...
                                 'wasEdited', wasEdited,...
                                 'rand', 'normrnd');
         end         
         
    case {'rayleigh','ray'},
          parms = [NaN];
          if(usenorm)
            % mu > 0 
            parmCombs = rRestart([0,uParmLimit], NOF_GUESSES); % Produce four guesses of the p value
            [M,~]     = size(parmCombs);
            for i = 1 : M
                try
                  [parms,ci] = mle(data, 'pdf', @raylpdfxmin, 'start', parmCombs(i,:)); 
                  break;
                catch err %#ok<NASGU>
                  continue; 
                end
            end              
          else         
                [parms,ci]  = mle(data, 'distribution', 'Rayleigh',...
                                  'options',options);
          end
          if(any(isnan(parms)) || any(isinf(parms)))
              dstruct     = optimFailed(length(data), 'rayl','raylrnd', 1); 
          else
              scale       = parms(1);
              rpdf        = pdf('Rayleigh', data, scale);
              [rpdf, wasEdited] = fixpdf(rpdf);
              rlog        = locallogl(rpdf);
              dstruct     = struct('parms',    parms,...
                                   'pdf',      rpdf,...
                                   'ci',       ci,...
                                   'logl',     rlog,...
                                   'wasEdited', wasEdited,...
                                   'rand', 'raylrnd');
          end        
    case {'weib','weibull', 'wbl'},
          parms = [NaN, NaN];
          if(usenorm)
            parmCombs = rRestart([0,uParmLimit,0,uParmLimit], NOF_GUESSES); % Produce four guesses of the p value
            [M,~]     = size(parmCombs);
            for i = 1 : M
                try
                  [parms,ci] = mle(data, 'pdf', @wblpdfxmin, 'start', parmCombs(i,:)); 
                  break;
                catch err %#ok<NASGU>
                   continue; 
                end
            end              
          else         
               [parms,ci] = mle(data, 'distribution','wbl','options',options);
          end
          if(any(isnan(parms)) || any(isinf(parms)))
              dstruct    = optimFailed(length(data), 'wbl', 'wblrnd', 2);
          else
              scale      = parms(1);
              shape      = parms(2);
              wpdf       = pdf('wbl', data, scale, shape);
              [wpdf, wasEdited] = fixpdf(wpdf);
              wlike      = locallogl(wpdf);
              dstruct    = struct('parms',    parms,...
                                  'pdf',      wpdf,...
                                  'ci',       ci,...
                                  'logl',     wlike,...
                                  'wasEdited', wasEdited,...
                                  'rand', 'wblrnd');
          end
end
end

function ret = locallogl(data)
% This subroutine is used to calculate the loglikelihood of the data.
 ret = sum(log(data));
end

function [inpdf, wasEdited] = fixpdf(inpdf)
% This function performs two tasks. First, it replaces NaNs from the input
% pdf with zeros, and secondly it removes zeros from the input pdf. The 
% former case occurs as the MLE estimated parameters can cause the PDF 
% sampled in the data points using said parameters to return NaNs. In the
% latter case, zeros entries are replaced by epsilon to avoid crashing the
% subsequent Vuong calculation.
wasEdited  = 0;

% Remove NaNs
inpdf(isnan(inpdf)) = 0;

% Find and replace 0 entries
badEntries = find(not(inpdf));
if(not(isempty(badEntries)))
   inpdf(badEntries) = eps; 
   wasEdited = 1;
end
end

function dstruct = optimFailed(nof_data_points, dist, rand, numparms)
fprintf('%s: failed optimization - one or more parameters are NaN, Inf or 0\n', dist);
distpdf = ones(nof_data_points, 1);
switch(numparms)
    case 1, parms = [NaN]; ci = [0 0];
    case 2, parms = [NaN, NaN]; ci = [0 0; 0 0];
    case 3, parms = [NaN, NaN, NaN]; ci = [0 0; 0 0; 0 0];    
end
logl    = 'No Info';
dstruct = struct('parms',     parms,...
                 'pdf',       distpdf,...
                 'ci',        ci,...
                 'logl',      logl,...
                 'wasEdited', 0,...
                 'rand',      rand);
end