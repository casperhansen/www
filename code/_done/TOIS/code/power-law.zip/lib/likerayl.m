function nLogL = likerayl(parms, data)
% Log likelihood calculated from:
% https://www.maths.otago.ac.nz/home/resources/stat380/2014_Lectures/lect11.pdf?m=1395653543
% (corrected as the first term is n and should be sum(log(x_i))

% Return NaN for out of range parameter or data.
parms(parms < 0) = NaN;
data(data < 0)   = NaN;

n     = numel(data);
nLogL = log(data) - log(parms^2) - (1/(2*parms^2)).*(data.^2);
%nLogL = sum(log(data)) - n*log(parms^2) - (1/(2*parms^2))*sum(data.^2);
end