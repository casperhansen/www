function lower = getSupport(name)
% getSupport(name)
% The function returns the lowest point of support for g(x), the
% hypothesized distributions. Notice crucially that because the dataset
% employed /do not/ allow for 0s. 
%
% names are taken from the second column of getDistMapping.m
switch(name)
    case 'expcdf'     , lower = 0;
    case 'gamcdf'     , lower = 1;
    case 'geocdf'     , lower = 0; % MatLab implements the version w. 0
    case 'gevcdf'     , lower = 0;  
    case 'gpcdf'      , lower = 0; % 5 
    case 'igausscdf'  , lower = 1;
    case 'logisticcdf', lower = 0;
    case 'logncdf'    , lower = 1;
    case 'nakagamicdf', lower = 1; % 9
    case 'nbincdf'    , lower = 0;
    case 'normcdf'    , lower = 0;
    case 'poisscdf'   , lower = 0;
    case 'powerlawcdf', lower = 1;
    case 'raylcdf'    , lower = 0;
    case 'wblcdf'     , lower = 0;
    case 'yulecdf'    , lower = 1;
end

end