function rs = powerlawcdf(data, alpha, xmin)
%Power law cumulative distribution function.
%
%   RS = POWERLAWCDF(DATA,ALPHA,XMIN) returns the cumulative distribution
%   function (CDF) of the power law distribution on DATA using parameters 
%   ALPHA and XMIN. The power law is conditioned on being in the tail which
%   is why we subtract the samples from one. The definitions from Clauset 
%   et al. (2007) is used.
%
%   Input:
%   DATA - A N x 1 vector of observations void of zeros.
%   ALPHA - The MLE estimated power law exponent.
%   XMIN  - The lower cutoff of the power law distribution.
%
%   Output:
%   RS - The power law CDF of DATA using ALPHA and XMIN.
%
%   Example (> indicate the MatLab terminal):
%   > addpath('misc','lib','write','clauset');
%   > rs = powerlawcdf(x, alpha, xmin);
%
%   where x is some vector of observation void of zeros, and alpha and xmin
%   are the parameters returned from power law MLE estimation (see
%   fitdatatodist.m).
%
%   Remarks:
%   If you are on a windows system the hzeta function must be exchanged for
%   the zeta_hurwitz. If you are on linux you just need to compile the
%   hzeta.c file. See the file for details.
%
%   1 - As calculations are independent the <for> loop can be replaced with
%   a <parfor> loop.
%
%   2 - We are actually calculating the CCDF as per Equation 2.7 in
%   Clauset's paper. We retrieve the CDF by doing a 1-P(x) before
%   returning.
%
%   Casper Petersen and Jakob Grue Simonsen, 2012
%   Department of Computer Science
%   University of Copenhagen
%


denom = zeta_hurwitz(alpha, xmin);
M     = length(data);
xs    = zeros(M,1);
for i = 1 : M
    try
       xs(i) = zeta_hurwitz(alpha, data(i));
    catch err, 
       error('powerlawcdf: failed'); 
    end
end
rs = 1 - (xs./denom);
end