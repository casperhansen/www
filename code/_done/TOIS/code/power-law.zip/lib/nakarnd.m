function out = nakarnd(sampleSize, m, omega) % m = SHAPE, omega=SPREAD
out = sqrt( randraw('gamma', [0, omega/m, m], sampleSize) );
end