function nLogL = likenbin(parms, data)
% Log likelihood calculated from http://vixra.org/pdf/1211.0113v1.pdf

% Return NaN for out of range parameter or data.
parms(parms < 0) = NaN;
data(data < 0)   = NaN;

n = numel(data);

r = parms(1);
p = parms(2);
nLogL = r*log(p) - gammaln(r) + gammaln(r + data) + data.*log(1 - p) - gammaln(data + 1);
%nLogL = n*r*log(p) - n*gammaln(r) + sum(gammaln(r + data) + data.*log(1 - p) - gammaln(data + 1));
end