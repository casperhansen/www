function rs = yulecdf(data, p)
%Yule-Simon cumulative distribution function.
%
%   RS = YULECDF(DATA,P) returns the cumulative distribution function (CDF)
%   of the Yule-Simon distribution on DATA with parameter P. The definition
%   used is taken from Simons original paper.
%
%   Input:
%   DATA - A N x 1 vector of observations void of zeros.
%   P    - The MLE estimated Yule exponent
%
%   Output:
%   RS - The Yule-Simon CDF of DATA with parameter P.
%
%   Example (> indicate the MatLab terminal):
%   > addpath('misc','lib','write','clauset');
%   > rs = yulecdf(x, p);
%
%   where x is some vector of observation void of zeros, and p is the
%   exponent of the Yule-Simon distribution estimated using MLE estimation
%   (see fitdatatodist.m).
%
%   Remarks:
%
%   Casper Petersen and Jakob Grue Simonsen, 2012
%   Department of Computer Science
%   University of Copenhagen
%

rs = 1-(data+1).*beta(data+1,p);
%rs = cumsum(yulepdf(data, p));
end