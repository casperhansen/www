function [x, fval, info, output, grad, hess] = my_fminunc (fcn, x0)

  % Get default options if requested.
  if (nargin == 1 && ischar (fcn) && strcmp (fcn, 'defaults'))
    %x = optimset ("MaxIter", 400, "MaxFunEvals", Inf, \
    %"GradObj", "off", "TolX", 1e-7, "TolFun", 1e-7,
    %"OutputFcn", [], "FunValCheck", "off",
    %"FinDiffType", "central",
    %"TypicalX", [], "AutoScaling", "off");
	options = optimoptions( 'fminunc',...
							'GradObj','on',... 
							'FinDiffType', 'central',...
							'MaxFunEvals', Inf,...
							'MaxIter', 400,...
							'TolX', 1e-7,...
							'TolFun', 1e-7,... 
							'TypicalX', ones(3,1));
    return;
  end

  if (ischar (fcn))
    fcn = str2func (fcn, 'global');
  end

  xsiz = size (x0);
  n = numel (x0);

  has_grad = 1;%strcmpi (optimget (options, "GradObj", "off"), "on");
  cdif = 1;%strcmpi (optimget (options, "FinDiffType", "central"), "central");
  maxiter = 400;%optimget (options, "MaxIter", 400);
  maxfev = Inf;%optimget (options, "MaxFunEvals", Inf);
  outfcn = [];%optimget (options, "OutputFcn");

  % Get scaling matrix using the TypicalX option. If set to "auto", the
  % scaling matrix is estimated using the jacobian.
  typicalx = [];%optimget (options, "TypicalX");
  if (isempty (typicalx))
    typicalx = ones (n, 1);
  end
  autoscale = 0;%strcmpi (optimget (options, "AutoScaling", "off"), "on");
  if (not(autoscale))
    dg = 1 ./ typicalx;
  end

  funvalchk = 0;%strcmpi (optimget (options, "FunValCheck", "off"), "on");

  if (funvalchk)
    % Replace fcn with a guarded version.
    fcn = @(x) guarded_eval (fcn, x);
  end

  % These defaults are rather stringent. I think that normally, user
  % prefers accuracy to performance.

  macheps = eps (class (x0));

  tolx = 1e-7;%optimget (options, "TolX", 1e-7);
  tolf = 1e-7;%optimget (options, "TolFun", 1e-7);

  factor = 0.1;
  % FIXME: TypicalX corresponds to user scaling (???)
  autodg = true;

  niter = 1;
  nfev = 0;

  x = x0(:);
  info = 0;

  % Initial evaluation.
  fval = fcn (reshape (x, xsiz));
  n = length (x);

  if (not(isempty (outfcn)))
    optimvalues.iter = niter;
    optimvalues.funccount = nfev;
    optimvalues.fval = fval;
    optimvalues.searchdirection = zeros (n, 1);
    state = 'init';
    stop = outfcn (x, optimvalues, state);
    if (stop)
      info = -1;
      return;
    end
  end

  nsuciter = 0;
  lastratio = 0;

  grad = [];

  % Outer loop.
  while (niter < maxiter && nfev < maxfev && not(info))
    %fprintf('niter: %d(%d), nfev: %d(%d)\n', niter, maxiter, nfev, maxfev);
    grad0 = grad;

    % Calculate function value and gradient (possibly via FD).
    if (has_grad)
      [fval, grad] = fcn (reshape (x, xsiz));
      grad = grad(:);
      nfev = nfev + 1;
    else
      grad = my_fdjac(fcn, reshape (x, xsiz), fval, typicalx, cdif);
      grad = grad(:);
      nfev = nfev + ((1 + cdif) * length (x));
    end
    %fprintf('grad(1): %1.4f, grad(2): %1.4f, grad(3): %1.4f\n', grad(1), grad(2), grad(3));
    if (niter == 1)
      % Initialize by identity matrix.
      hesr = eye (n);
    else
      % Use the damped BFGS formula.
      y = grad - grad0;
      sBs = sumsqr(w);
      Bs = hesr'*w;
      sy = y'*s;
      theta = 0.8 / max (1 - sy / sBs, 0.8);
      r = theta * y + (1-theta) * Bs;
      %disp(hesr);
      hesr = cholupdate (hesr, r / sqrt (s'*r), '+');
      %fprintf('Info BEFORE cholupdate was: %d\n', info);
      [hesr, info] = cholupdate (hesr, Bs / sqrt (sBs), '-');
      %disp(hesr);
      %fprintf('Info AFTER cholupdate was: %d\n', info);
     
      %for j = 1 : M
      %    for k = 1 : N
      %      fprintf('%d ', hesr(j,k));
      %    end
      %    fprintf('\n');
      %end
      %fprintf('\n');        
      if (info)
        hesr = eye (n);
      end
    end
    if (autoscale)
      % Second derivatives approximate the hessian.
      d2f = norm (hesr, 'columns').';
      if (niter == 1)
        dg = d2f;
      else
        % FIXME: maybe fixed lower and upper bounds?
        dg = max (0.1*dg, d2f);
      end
    end

    if (niter == 1)
      xn = norm (dg .* x);
      % FIXME: something better?
      delta = factor * max (xn, 1);
    end

    % FIXME -- why tolf*n*xn? If abs (e) ~ abs(x) * eps is a vector
    % of perturbations of x, then norm (hesr*e) <= eps*xn, i.e. by
    % tolf ~ eps we demand as much accuracy as we can expect.
    %fprintf('norm(grad) = %.10f, tolf*n*xn: %.10f\n', norm(grad), tolf*n*xn);
    if (norm (grad) <= tolf*n*xn)
      info = 1;
      %fprintf('inside norm(grad) <= tolf*n*xn\n');
      break;
    end
    %fprintf('delta: %1.4f\n', delta);
    suc = false;
    decfac = 0.5;
    % Inner loop.
    while (not(suc) && niter <= maxiter && nfev < maxfev && not(info))
      %fprintf('\nPRINTING VALUES GIVEN TO DOGLEGM AT ITERATION %d\n', niter);
      %fprintf('HESR:\n');
      %[M,N] = size(hesr);
      %for i = 1 : M
      %    for j = 1 : N
      %        fprintf('%1.4f ', hesr(i,j));
      %    end
      %    fprintf('\n');
      %end
      %fprintf('\n');
      %fprintf('GRAD:\n');
      %%fprintf('%d :: grad(1): %1.10f, grad(2): %1.10f, grad(3): %1.10f\n', niter, grad(1), grad(2), grad(3));
      %fprintf('DG:\n');
      %fprintf('dg(1): %1.4f, dg(2): %1.4f, dg(3): %1.4f\n', dg(1), dg(2), dg(3));
      %fprintf('DELTA:\n');
      %fprintf('%1.4f\n', delta);
      s = - my_doglegm(hesr, grad, dg, delta);
      sn = norm (dg .* s);
      if (niter == 1)
        delta = min (delta, sn);
      end

      fval1 = fcn(reshape (x + s, xsiz));
      fval1 = fval1(:);
      nfev = nfev + 1;

      if (fval1 < fval)
        % Scaled actual reduction.
        actred =  (fval - fval1) / (abs (fval1) + abs (fval));
      else
        actred = -1;
      end

      w = hesr*s;
      % Scaled predicted reduction, and ratio.
      t = 1/2 * sumsqr (w) + grad'*s;
      %fprintf('itr: %d :: sumsqr(w): %1.4f, grad''*s: %1.4f\n', niter, sumsqr(w), grad'*s);
      if (t < 0)
        prered = -t/(abs (fval) + abs (fval + t));
        ratio = actred / prered;
      else
        prered = 0;
        ratio = 0;
      end

      % Update delta.
      %fprintf('BEFORE: niter: %d, delta: %1.4f, sn: %1.4f, ratio: %1.4f\n', niter, delta,sn,ratio);
      if (ratio < min(max(0.1, 0.8*lastratio), 0.9))
        %fprintf('Took IF\n');
        delta = delta * decfac;
        decfac = decfac^1.4142;
        if (delta <= 1e1*macheps*xn)
          % Trust region became uselessly small.
          info = -3;
          %fprintf('Trust region became uselessly small\n');
          break;
        end
      else
        %fprintf('Took ELSE\n');
        lastratio = ratio;
        decfac = 0.5;
        if (abs (1-ratio) <= 0.1)
          delta = 1.4142*sn;
        elseif (ratio >= 0.5)
          delta = max (delta, 1.4142*sn);
        end
      end
      %fprintf('AFTER: niter: %d, delta: %1.4f, sn: %1.4f, ratio: %1.4f\n', niter, delta,sn,ratio);
      if (ratio >= 1e-4)
        % Successful iteration.
        x = x + s;
        xn = norm (dg .* x);
        fval = fval1;
        nsuciter = nsuciter + 1;
        suc = true;
      end

      niter = niter + 1;

      % FIXME: should outputfcn be only called after a successful iteration?
      if (not(isempty (outfcn)))
        optimvalues.iter = niter;
        optimvalues.funccount = nfev;
        optimvalues.fval = fval;
        optimvalues.searchdirection = s;
        state = 'iter';
        stop = outfcn (x, optimvalues, state);
        if (stop)
          info = -1;
          %fprintf('Inside not(isempty(outfcn))\n');
          break;
        end
      end

      % Tests for termination conditions. A mysterious place, anything
      % can happen if you change something here...

      % The rule of thumb (which I'm not sure M*b is quite following)
      % is that for a tolerance that depends on scaling, only 0 makes
      % sense as a default value. But 0 usually means uselessly long
      % iterations, so we need scaling-independent tolerances wherever
      % possible.

      % The following tests done only after successful step.
      if (ratio >= 1e-4)
        % This one is classic. Note that we use scaled variables again,
        % but compare to scaled step, so nothing bad.
        %fprintf('tolx*xn: %1.4f\n', tolx*xn);
        if (sn <= tolx*xn)
          info = 2;
            %fprintf('sn <= tolx*xn\n');
          % Again a classic one.
        elseif (actred < tolf)
            %fprintf('actred < tolf\n');
          info = 3;
        end
      end

    end
  end

  % Restore original shapes.
  x = reshape (x, xsiz);

  output.iterations = niter;
  output.successful = nsuciter;
  output.funcCount = nfev;

  if (nargout > 5)
    hess = hesr'*hesr;
  end

end

% An assistant function that evaluates a function handle and checks for
% bad results.
function [fx, gx] = guarded_eval (fun, x)
  if (nargout > 1)
    [fx, gx] = fun (x);
  else
    fx = fun (x);
    gx = [];
  end

  if (not(isreal (fx) && isreal (gx)))
    error ('fminunc:notreal', 'fminunc: non-real value encountered');
  elseif (any (isnan (fx(:))))
    error ('fminunc:isnan', 'fminunc: NaN value encountered');
  elseif (any (isinf (fx(:))))
    error ('fminunc:isinf', 'fminunc: Inf value encountered');
  end
end


%!function f = __rosenb (x)
%!  n = length (x);
%!  f = sumsqr (1 - x(1:n-1)) + 100 * sumsqr (x(2:n) - x(1:n-1).^2);
%!endfunction
%!test
%! [x, fval, info, out] = fminunc (@__rosenb, [5, -5]);
%! tol = 2e-5;
%! assert (info > 0);
%! assert (x, ones (1, 2), tol);
%! assert (fval, 0, tol);
%!test
%! [x, fval, info, out] = fminunc (@__rosenb, zeros (1, 4));
%! tol = 2e-5;
%! assert (info > 0);
%! assert (x, ones (1, 4), tol);
%! assert (fval, 0, tol);
%% Test FunValCheck works correctly
%!assert (fminunc (@(x) x^2, 1, optimset ("FunValCheck", "on")), 0, eps)
%!error <non-real value> fminunc (@(x) x + i, 1, optimset ("FunValCheck", "on"))
%!error <NaN value> fminunc (@(x) x + NaN, 1, optimset ("FunValCheck", "on"))
%!error <Inf value> fminunc (@(x) x + Inf, 1, optimset ("FunValCheck", "on"))


% Solve the double dogleg trust-region minimization problem:
% Minimize 1/2*norm(r*x)^2  subject to the constraint norm(d.*x) <= delta,
% x being a convex combination of the gauss-newton and scaled gradient.

% TODO: error checks
% TODO: handle singularity, or leave it up to mldivide?

function x = my_doglegm(r, g, d, delta)
  % Get Gauss-Newton direction.
  b = r' \ g;
  x = r \ b;
  xn = norm (d .* x);
  if (xn > delta)
    % GN is too big, get scaled gradient.
    s = g ./ d;
    sn = norm (s);
    if (sn > 0)
      % Normalize and rescale.
      s = (s / sn) ./ d;
      % Get the line minimizer in s direction.
      tn = norm (r*s);
      snm = (sn / tn) / tn;
      %fprintf('snm: %1.10f\n', snm);
      if (snm < delta)
        % Get the dogleg path minimizer.
        bn = norm (b);
        dxn = delta/xn; snmd = snm/delta;
        t = (bn/sn) * (bn/xn) * snmd;
        t = t - (dxn * snmd^2 - sqrt ((t-dxn)^2 + (1-dxn^2)*(1-snmd^2)));
        alpha = dxn*(1-snmd^2) / t;
        %fprintf('bn: %1.10f, dxn: %1.10f, t: %1.10f, snmd: %1.10f, sn: %1.10f, xn: %1.10f, delta: %1.10f\n', bn, dxn, t, snmd, sn, xn, delta);
      else
        alpha = 0;
      end
    else
      alpha = delta / xn;
      snm = 0;
    end
    % Form the appropriate convex combination.
    x = alpha * x + ((1-alpha) * min (snm, delta)) * s;
    %fprintf('alpha: %1.10f, snm: %1.10f, delta: %1.10f\n', alpha, snm, delta);
  end
end