function nLogL = likenorm(parms, data)
% Log likelihood calculated from 
% http://ocw.mit.edu/courses/mathematics/18-443-statistics-for-applications-fall-2006/lecture-notes/lecture2.pdf

% Return NaN for out of range parameter or data.
parms(parms < 0) = NaN;
data(data < 0)   = NaN;

n = numel(data);
alpha = parms(1);
sigma = parms(2);
nLogL = log(1/(sqrt(2*pi))) - log(sigma) - (1/(2*sigma^2)).*((data - alpha).^2);
%nLogL = n*log(1/(sqrt(2*pi))) - n*log(sigma) - (1/(2*sigma^2))*sum((data - alpha).^2);
end