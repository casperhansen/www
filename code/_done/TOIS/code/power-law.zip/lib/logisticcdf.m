function rs = logisticcdf(data,loc,scale)
%Logistic cumulative distribution function.
%
%   RS = LOGISTICCDF(DATA,LOC,SCALE) returns the cumulative distribution 
%   function (CDF) of the Logistic distribution on DATA using 
%   parameters LOC and SCALE.
%
%   Input:
%   DATA   - A N x 1 vector of observations void of zeros.
%   LOC    - The MLE estimated location parameter.
%   SCALE  - The MLE estimated scale parameter.
%
%   Output:
%   RS - The Logistic CDF of DATA using LOC and SCALE.
%
%   Example (> indicate the MatLab terminal):
%   > addpath('misc','lib','write','clauset');
%   > rs = logisticcdf(x, loc, scale);
%
%   where x is some vector of observation void of zeros, and loc and scale
%   are the parameters returned from Logistic MLE estimation (see
%   fitdatatodist.m).
%
%   Remarks:
%
%   Casper Petersen and Jakob Grue Simonsen, 2012
%   Department of Computer Science
%   University of Copenhagen
%
rs = 1 ./ (1+exp(-(data-loc)/scale));
end
