function nLogL = likenaka(parms, data)
% Log likelihood calculated from Schwartz et al.
% "Improved Maximum Likelihood Estimation of the Shape Parameter 
% in the Nakagami Distribution"
% http://web.uvic.ca/~dgiles/downloads/working_papers/ewp1109.pdf

% Return NaN for out of range parameter or data.
parms(parms < 0) = NaN;
data(data < 0)   = NaN;

mu = parms(1);
w  = parms(2);

n = numel(data);
nLogL = log(2) + mu.*log(mu) - gammaln(mu) - mu*log(w) + (2*mu - 1).*log(data) - (mu/w).*data.^2;
%nLogL = n*log(2) + n*mu*log(mu) - n*gammaln(mu) - n*mu*log(w) + (2*mu - 1)*sum(log(data)) - (mu/w)*sum(data.^2);
end