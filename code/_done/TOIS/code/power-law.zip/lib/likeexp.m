function nLogL = likeexp(parms, data)
% Log likelihood calculated straigt-forward from PDF.

% Return NaN for out of range parameter or data.
parms(parms < 0) = NaN;
data(data < 0)   = NaN;

n = numel(data);

nLogL = -log(parms) - (1/parms).*data;
%nLogL = -n*log(parms) - (1/parms)*sum(data);
end