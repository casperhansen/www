function formatAxis
hXLabel = get(gca,'XLabel');
hYLabel = get(gca,'YLabel');
set([hXLabel, hYLabel], ...
    'FontName'   , 'AvantGarde', ...
    'FontSize'   , 9, ...
    'FontWeight' , 'bold');

hLegend = findobj(gcf,'Type','axes','Tag','legend');
if(~isempty(hLegend))
   hLegend = legend(hLegend);
   set(hLegend, ...
       'FontName'   , 'AvantGarde', ...
       'FontSize'   , 8);
   legend boxoff    
end

end