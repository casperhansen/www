function nLogL = likegev(parms, data)
% Log likelihood calculated from http://www.ral.ucar.edu/~ericg/read2.pdf

% Return NaN for out of range parameter or data.
data(data < 0)   = NaN;

k     = parms(1);
sigma = parms(2);
mu    = parms(3);

t     = k.*(data - mu)./sigma;
t     = t(t > -1);

nLogL = -log(sigma) - (1 + (1/k)).*log(1 + t) - (1 + t).^(-1/k);
if(sum(nLogL) > 0)
   nLogL = -1.*nLogL; 
end
%nLogL = -n*log(sigma) - (1 + (1/k))*sum(log(1 + t)) - sum((1 + t).^(-1/k));

end