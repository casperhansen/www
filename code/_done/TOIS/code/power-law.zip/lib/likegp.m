function nLogL = likegp(parms, data)
% Log likelihood from MatLab implementation

% Return NaN for out of range parameter or data.
%parms(parms < 0) = NaN;
data(data < 0)   = NaN;

n = numel(data);

k       = parms(1);    % Tail index parameter
sigma   = parms(2);    % Scale parameter
lnsigma = log(sigma);   % Scale parameter, logged

n = numel(data);
z = data./sigma;
if abs(k) > eps
    if k > 0 || max(z) < -1/k
        sumlnu = sum(log1p(k.*z));
        %nLogL = n*lnsigma + (1+1/k).*sumlnu;
        nLogL = lnsigma + (1+1/k).*log1p(k.*z);
    else
        nLogL = Inf;
    end
else
    nLogL = lnsigma + z;
    %nLogL = n*lnsigma + sum(z); 
end
nLogL = -1.*nLogL;
end