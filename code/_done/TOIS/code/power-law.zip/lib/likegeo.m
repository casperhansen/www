function nLogL = likegeo(parms, data)
% Log likelihood calculated from http://data.princeton.edu/wws509/notes/a1.pdf

% Return NaN for out of range parameter or data.
parms(parms < 0) = NaN;
data(data < 0)   = NaN;

n     =  numel(data);
yhat  =  mean(data);
nLogL =  data.*log(1 - parms) + log(parms);
%nLogL = n*(yhat*log(1 - parms) + log(parms));
end