function [bins, csum] = ecdf_all(input, norm)
%Empirical cumulative distribution function.
%
%   RF = ECDF_ALL(DATA,NORM) calculates the empirical cumulative 
%   distribution function of DATA and normalizes it, provided NORM is set.
%
%   Input:
%   DATA - An N x 1 vector of observations.
%   NORM - Either 0 or 1. 
%
%   Output:
%   RF   - An N x 2 matrix containing the plot-indices in the first column
%   and the associated CDF value in the second column. 
%
%   Example (> indicate the MatLab terminal) with plotting:
%   > rs = ecdf_all(x, 1);
%   > loglog(rs(:,1), rs(:,2), 'ro');
%
%   where x is a vector of observations (0's are permitted) and norm, in
%   this case, is one.
%
bins = 1:max(input);
vals = histc(input,bins);
low  = min(bins);
high = max(bins);
N    = numel(input);
clear bins;
clear input;

vals = vals(:);
csum = cumsum(vals);
clear vals;
if(norm)
   csum = csum./N;
end
bins = [low:high]';
csum = csum(:);
end