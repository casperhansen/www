function nLogL = likeigauss(parms, data)
% Log likelihood calculated from 
% "Inverse Gaussian Model and Its Applications in Reliability and Survival Analysis" 
% Lemeshko et al. 2010

% Return NaN for out of range parameter or data.
parms(parms < 0) = NaN;
data(data < 0)   = NaN;

mu      = parms(1);
lambda  = parms(2);

n       = numel(data);
t1      = (3/2)*sum(log(data));
t2      = sum((lambda.*(data-mu).^2)./(2.*mu^2.*data));
nLogL   = 0.5*log(lambda) - 0.5*log(2*pi) - (3/2).*log(data) - ((lambda.*(data-mu).^2)./(2.*mu^2.*data));
%nLogL   = n/2 * log(lambda) - n/2 * log(2*pi) - t1 - t2;
end