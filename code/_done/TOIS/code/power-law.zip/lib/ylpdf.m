function rs = ylpdf(x, alpha)
% Imitage the approch by Clauset et al.
if(min(x) == 1)
   C = 0; 
else
   dmin = min(x)-1;
   C = log(dmin) + betaln(dmin,alpha) - 0; 
end
rs = log(alpha-1) + betaln(x,alpha) - C;
rs(x ~= round(x) | (x < 1)) = 0;
end