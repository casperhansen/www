function rf = cumdistfunc(data, norm)
%Cumulative distribution function.
%
%   RF = CUMDISTFUNC(DATA,NORM) calculates the cumulative distribution
%   function of DATA and normalizes it, provided NORM is set.
%
%   Input:
%   DATA - An N x 1 vector of observations.
%   NORM - Either 0 or 1. 
%
%   Output:
%   RF   - An N x 2 matrix containing the plot-indices in the first column
%   and the associated CDF value in the second column. 
%
%   Example (> indicate the MatLab terminal):
%   > addpath('misc','lib','write','clauset');
%   > rs = cumdistfunc(x, 1);
%
%   where x is a vector of observations (0's are permitted) and norm, in
%   this case, is one.
%
%   Remarks:
%   1 - The function is implemented from MEJ Newmans description in the
%   appendix of his excellent paper "Power laws, Pareto distributions and
%   Zipfs law".
%
%   Casper Petersen and Jakob Grue Simonsen, 2012
%   Department of Computer Science
%   University of Copenhagen
%
%% New version
[vals, bins] = hist(data, unique(data));
bins = bins(:);
ccdf = fliplr(cumsum(fliplr(vals)));

if(norm)
  ccdf = ccdf./numel(data);  
end
ccdf = ccdf(:);
rf   = [bins, ccdf];
%% Legacy version
%vals    = unique(data);
%N       = numel(vals);
%rf      = zeros(N,2);
%rf(:,1) = vals;
%
%for i = 1 : N
%   rf(i,2) = sum(data >= vals(i));
%   fprintf('Finished %d of %d\n', i, N);
%end
%
%if(norm)
%   rf(:,2) = rf(:,2)./numel(data); 
%end

end