function [parmhat,parmci] = mygevfit(x,options)

if ~isvector(x)
    error(message('stats:gevfit:VectorRequired'));
end

alpha = 0.05;

classX = class(x);
if isa(classX,'single')
    x = double(x);
end

n = length(x);
x = sort(x(:));
xmin = x(1);
xmax = x(end);
rangex = range(x);

% Can't make a fit.
if n == 0 || ~isfinite(rangex)
    parmhat = NaN(1,3,classX);
    parmci = NaN(2,3,classX);
    return
elseif rangex < realmin(classX)
    % When all observations are equal, try to return something reasonable.
    parmhat = [0, 0, x(1)];
    if n == 1
        parmci = cast([-Inf 0 -Inf; Inf Inf Inf],classX);
    else
        parmci = [parmhat; parmhat];
    end
    return
    % Otherwise the data are ok to fit GEV distr, go on.
end

% Get initial param values by linearizing a P-P plot over k.
%F = (.5:1:(n-.5))' ./ n;
%k0 = fminsearch(@(k) 1-corr(x,gevinv(F,k,1,0)), 0);
%b = polyfit(gevinv(F,k0,1,0),x,1);
%sigma0 = b(1);
%mu0 = b(2);
%if (k0 < 0 && (xmax > -sigma0/k0+mu0)) || (k0 > 0 && (xmin < -sigma0/k0+mu0))
%    % The initial value cal;culation failed -- the data are not even in the
%    % support of the parameter guesses.  Fall back to an EV, whose support is
%    % unbounded.
%    k0 = 0;
%    evparms = evfit(x);
%    sigma0 = evparms(2);
%    mu0 = evparms(1);
%end
%parmhat = [k0 log(sigma0) mu0];

if(isempty(options))
   options = optimoptions('fminunc', 'GradObj', 'on', 'MaxIter', 400, 'MaxFunEvals', Inf, 'TolX', 1e-06, 'TolFun', 1e-06);
end    
    
% Set specific values for k, sigma and mu (shape, scale, location)
parmhat = [0 log(1) 0];

% Maximize the log-likelihood with respect to k, lnsigma, and mu.

[parmhat,~,err,output] = fminunc(@negloglike,parmhat,options,x);
parmhat(2) = exp(parmhat(2));

if (err == 0)
    % fminsearch may print its own output text; in any case give something
    % more statistical here, controllable via warning IDs.
    if output.funcCount >= options.MaxFunEvals
        warning(message('stats:gevfit:EvalLimit'));
    else
        warning(message('stats:gevfit:IterLimit'));
    end
elseif (err < 0)
    error(message('stats:gevfit:NoSolution'));
end

%tolBnd set one order of magnitude lower.
tolBnd = 1e-6;
atBoundary = false;
if ((parmhat(1) < 0) && (xmax > -parmhat(2)/parmhat(1) + parmhat(3) - tolBnd)) || ...
   ((parmhat(1) > 0) && (xmin < -parmhat(2)/parmhat(1) + parmhat(3) + tolBnd))
    warning(message('stats:gevfit:ConvergedToBoundary'));
    atBoundary = true;
end

if nargout > 1
    if ~atBoundary
        probs = [alpha/2; 1-alpha/2];
        [~, acov] = gevlike(parmhat, x);
        se = sqrt(diag(acov))';

        % Compute the CI for k using a normal distribution for khat.
        kci = norminv(probs, parmhat(1), se(1));

        % Compute the CI for sigma using a normal approximation for
        % log(sigmahat), and transform back to the original scale.
        % se(log(sigmahat)) is se(sigmahat) / sigmahat.
        lnsigci = norminv(probs, log(parmhat(2)), se(2)./parmhat(2));

        % Compute the CI for mu using a normal distribution for muhat.
        muci = norminv(probs, parmhat(3), se(3));

        parmci = [kci exp(lnsigci) muci];
    else
        parmci = [NaN NaN NaN; NaN NaN NaN];
    end
end

if isa(classX,'single')
    parmhat = single(parmhat);
    if nargout > 1
        parmci = single(parmci);
    end
end
end

function [nll,Grad] = negloglike(parms, data)
% Negative log-likelihood for the GEV (log(sigma) parameterization).
k       = parms(1);
lnsigma = parms(2);
sigma   = exp(lnsigma);
mu      = parms(3);

n = numel(data);
z = (data - mu) ./ sigma;

if abs(k) > eps
    u = 1 + k.*z;
    if min(u) > 0
        lnu = log1p(k.*z); % log(1 + k.*z)
        t = exp(-(1/k)*lnu); % (1 + k.*z).^(-1/k)
        nll = n*lnsigma + sumfast(t) + (1+1/k)*sumfast(lnu);
%         if nargout > 1
%             s = expm1(-(1/k)*lnu); % (1 + k.*z).^(-1/k) - 1
%             r = (s - k)./u;
%             dk = sum(lnu.*s./k - z.*r)./k;
%             dsigma = sum(1+z.*r)./sigma;
%             dmu = sum(r)./sigma;
%             ngrad = [dk dsigma*sigma dmu]; % [dL/dk dL/d(lnsigma) dL/dmu]
%         end
    else
        % The support of the GEV is 1+k*z > 0, or x > mu - sigma/k.
        nll = Inf;
    end
else % limiting extreme value dist'n as k->0
    nll = n*lnsigma + sumfast(exp(-z) + z);
%     if nargout > 1
%         s = expm1(-z); % exp(-z) - 1
%         dk = sum(z.^2.*s/2 + z);
%         dsigma = sum(1+z.*s)./sigma;
%         dmu = sum(s)./sigma;
%         ngrad = [dk dsigma*sigma dmu]; % [dL/dk dL/d(lnsigma) dL/dmu]
%     end
end
[Grad, ~] = gevgrad (data, k, sigma, mu, []);    
end

% Gradient calculation taken from Octave
function [G, kk_terms] = gevgrad (x, k, sigma, mu, k_terms)
%calculate the gradient of the negative log likelihood of data x with respect to the parameters of the generalized extreme value distribution for gevlike
kk_terms = [];
G = ones(3, 1);
if k == 0 %use the expressions for first derivatives that are the limits as k --> 0
  %a = (x - mu) ./ sigma;
  %f = exp(-a) - 1;
  
  %%fprintf('Took k == 0\n');
  %%fprintf('Input arguments are: k = %1.10f, sigma = %1.10f, mu = %1.10f\n', k, sigma, mu);
  
  a = (x - mu) ./ sigma;
  %fprintf('sum(a): %1.20f\n', sum(a));
  %f = exp(-a) - 1;
  f  = expm1(-a);
  %fprintf('sum(f): %1.20f\n', sum(f));
  
  %k
  %g = -(2 * x .* (mu .* (1 - f) - sigma .* f) + 2 .* sigma .* mu .* f + (x.^2 + mu.^2).*(f - 1)) ./ (2 * f .* sigma .^ 2);
  g = a .* (1 + a .* f / 2);
  G(1) = sumfast(g(:));
  
  %sigma
  g = (a .* f + 1) ./ sigma;
  G(2) = sumfast(g(:));
  
  %mu
  g = f ./ sigma;
  G(3) = sumfast(g(:));
  
  return
end

a = (x - mu) ./ sigma;
b = 1 + k .* a;
if any (b <= 0)
  G(:) = 0; %negative log likelihood is locally infinite
  return
end

%k
c = log(b);
d = 1 ./ k + 1;
if nargin > 4 && ~isempty(k_terms) %use a series expansion to find the gradient more accurately when k is small
  aa = k .* a;
  f = exp(-a .* k_terms);
  kk_terms = 0.5; sgn = 1; i = 0;
  while 1
    sgn = -sgn; i=i+1;
    newterm = (sgn * (i + 1) / (i + 2)) * (aa .^ i);
    kk_terms = kk_terms + newterm;
    if max(abs(newterm)) <= eps
      break
    end
  end
  g = a .* ((a .* kk_terms) .* (f - 1 - k) + k_terms);
else
  g = (c ./ k - a ./ b) ./ (k .* b .^ (1/k)) - c ./ (k .^ 2) + a .* d ./ b;
end
%keyboard
G(1) = sumfast(g(:));

%sigma
if nargin > 4 && ~isempty(k_terms) %use a series expansion to find the gradient more accurately when k is small
  g = (1 - a .* (a .* k .* kk_terms - k_terms) .* (f - k - 1)) ./ sigma;
else
  %g = (a .* b .^ (-d) - d .* k .* a ./ b + 1) ./ sigma;
  g = (a .* b .^ (-d) - (k + 1) .* a ./ b + 1) ./ sigma;
end
G(2) = sumfast(g(:));

%mu
if nargin > 4 && ~isempty(k_terms) %use a series expansion to find the gradient more accurately when k is small
  g = -(a .* k .* kk_terms - k_terms) .* (f - k - 1) ./ sigma;
else
  %g = (b .^ (-d) - d .* k ./ b) ./ sigma;
  g = (b .^ (-d) - (k + 1) ./ b) ./ sigma;
end
G(3) = sumfast(g(:));
end