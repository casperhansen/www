function nLogL = likewbl(parms, data)
% Log likelihood calculated from 
% "Bayesian Estimation of Two-Parameter Weibull Distribution Using 
% Extension of Jeffreys� Prior Information with Three Loss Functions"
% Guure, Ibrahim and Ahmen, 2012

% Return NaN for out of range parameter or data.
parms(parms < 0) = NaN;
data(data < 0)   = NaN;

n = numel(data);
alpha = parms(1);
beta = parms(2);
nLogL = (log(beta) - beta*log(alpha)) + (beta - 1).*log(data) - (1/(alpha^beta)).*data.^beta;
%nLogL = n*(log(beta) - beta*log(alpha)) + (beta - 1)*sum(log(data)) - (1/(alpha^beta))*sum(data.^beta);
end