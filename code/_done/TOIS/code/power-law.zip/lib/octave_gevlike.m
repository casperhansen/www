function [nlogL, Grad] = octave_gevlike(params, data)
  
  k = params(1);
  sigma = params(2);
  mu = params(3);
  
  %calculate negative log likelihood
  [nll, k_terms] = gevnll(data, k, sigma, mu);
  nlogL = sumfast(nll(:));
  %optionally calculate the first and second derivatives of the negative log likelihood with respect to parameters
  if nargout > 1
  	 [Grad, kk_terms] = gevgrad (data, k, sigma, mu, k_terms);    
  end

end


function [nlogL, k_terms] = gevnll (x, k, sigma, mu)
%internal function to calculate negative log likelihood for gevlike
  %fprintf('k: %1.10f, sigma: %1.10f, mu: %1.10f\n', k, sigma, mu);
  
  k_terms = [];
  a = (x - mu) ./ sigma;

  if all(k == 0)
    nlogL = exp(-a) + a + log(sigma);
  else
    aa = k .* a;
    if min(abs(aa)) < 1E-3 && max(abs(aa)) < 0.5 %use a series expansion to find the log likelihood more accurately when k is small
      k_terms = 1; sgn = 1; i = 0;
      while 1
        sgn = -sgn; i = i+1;
        newterm = (sgn  / (i + 1)) * (aa .^ i);
        k_terms = k_terms + newterm;
        if max(abs(newterm)) <= eps
          break
        end
      end
      nlogL = exp(-a .* k_terms) + a .* (k + 1) .* k_terms + log(sigma);
    else
      b = 1 + aa;
      nlogL = b .^ (-1 ./ k) + (1 + 1 ./ k) .* log(b) + log(sigma);
      nlogL(b <= 0) = Inf;
    end
  end

end

function [G, kk_terms] = gevgrad (x, k, sigma, mu, k_terms)
%calculate the gradient of the negative log likelihood of data x with respect to the parameters of the generalized extreme value distribution for gevlike
kk_terms = [];
G = ones(3, 1);
if k == 0 %use the expressions for first derivatives that are the limits as k --> 0
  %a = (x - mu) ./ sigma;
  %f = exp(-a) - 1;
  
  %%fprintf('Took k == 0\n');
  %%fprintf('Input arguments are: k = %1.10f, sigma = %1.10f, mu = %1.10f\n', k, sigma, mu);
  
  a = (x - mu) ./ sigma;
  %fprintf('sum(a): %1.20f\n', sum(a));
  %f = exp(-a) - 1;
  f  = expm1(-a);
  %fprintf('sum(f): %1.20f\n', sum(f));
  
  %k
  %g = -(2 * x .* (mu .* (1 - f) - sigma .* f) + 2 .* sigma .* mu .* f + (x.^2 + mu.^2).*(f - 1)) ./ (2 * f .* sigma .^ 2);
  g = a .* (1 + a .* f / 2);
  G(1) = sumfast(g(:));
  
  %sigma
  g = (a .* f + 1) ./ sigma;
  G(2) = sumfast(g(:));
  
  %mu
  g = f ./ sigma;
  G(3) = sumfast(g(:));
  
  return
end

a = (x - mu) ./ sigma;
b = 1 + k .* a;
if any (b <= 0)
  G(:) = 0; %negative log likelihood is locally infinite
  return
end

%k
c = log(b);
d = 1 ./ k + 1;
if nargin > 4 && ~isempty(k_terms) %use a series expansion to find the gradient more accurately when k is small
  aa = k .* a;
  f = exp(-a .* k_terms);
  kk_terms = 0.5; sgn = 1; i = 0;
  while 1
    sgn = -sgn; i=i+1;
    newterm = (sgn * (i + 1) / (i + 2)) * (aa .^ i);
    kk_terms = kk_terms + newterm;
    if max(abs(newterm)) <= eps
      break
    end
  end
  g = a .* ((a .* kk_terms) .* (f - 1 - k) + k_terms);
else
  g = (c ./ k - a ./ b) ./ (k .* b .^ (1/k)) - c ./ (k .^ 2) + a .* d ./ b;
end
%keyboard
G(1) = sumfast(g(:));

%sigma
if nargin > 4 && ~isempty(k_terms) %use a series expansion to find the gradient more accurately when k is small
  g = (1 - a .* (a .* k .* kk_terms - k_terms) .* (f - k - 1)) ./ sigma;
else
  %g = (a .* b .^ (-d) - d .* k .* a ./ b + 1) ./ sigma;
  g = (a .* b .^ (-d) - (k + 1) .* a ./ b + 1) ./ sigma;
end
G(2) = sumfast(g(:));

%mu
if nargin > 4 && ~isempty(k_terms) %use a series expansion to find the gradient more accurately when k is small
  g = -(a .* k .* kk_terms - k_terms) .* (f - k - 1) ./ sigma;
else
  %g = (b .^ (-d) - d .* k ./ b) ./ sigma;
  g = (b .^ (-d) - (k + 1) ./ b) ./ sigma;
end
G(3) = sumfast(g(:));

end

function ACOV = gevfim (x, k, sigma, mu, k_terms, kk_terms)
%internal function to calculate the Fisher information matrix for gevlike

ACOV = ones(3);

if k == 0 %use the expressions for second derivatives that are the limits as k --> 0
  %k, k
  a = (x - mu) ./ sigma;
  f = exp(-a);
  %der = (x .* (24 * mu .^ 2 .* sigma .* (f - 1) + 24 * mu .* sigma .^ 2 .* f - 12 * mu .^ 3) + x .^ 3 .* (8 * sigma .* (f - 1) - 12*mu) + x .^ 2 .* (-12 * sigma .^ 2 .* f + 24 * mu .* sigma .* (1 - f) + 18 * mu .^ 2) - 12 * mu .^ 2 .* sigma .^ 2 .* f + 8 * mu .^ 3 .* sigma .* (1 - f) + 3 * (x .^ 4 + mu .^ 4)) ./ (12 .* f .* sigma .^ 4);
  der = (a .^ 2) .* (a .* (a/4 - 2/3) .* f + 2/3 * a - 1);  
  ACOV(1, 1) = sumfast(der(:));

  %sigma, sigma
  der = (sigma .^ -2) .* (a .* ((a - 2) .* f + 2) - 1);
  ACOV(2, 2) = sumfast(der(:));

  %mu, mu
  der = (sigma .^ -2) .* f;
  ACOV(3, 3) = sumfast(der(:));

  %k, sigma
  %der =  (x .^2 .* (2*sigma .* (f - 1) - 3*mu) + x .* (-2 * sigma .^ 2 .* f + 4 * mu .* sigma .* (1 - f) + 3 .* mu .^ 2) + 2 * mu .^ 2 .* sigma .* (f - 1) + 2 * mu * sigma .^ 2 * f + x .^ 3 - mu .^ 3) ./ (2 .* f .* sigma .^ 4);
  der = (-a ./ sigma) .* (a .* (1 - a/2) .* f - a + 1);
  ACOV(1, 2) = sumfast(der(:)); ACOV(2, 1) = sumfast(der(:));

  %k, mu
  %der = (x .* (2*sigma .* (f - 1) - 2*mu) - 2 * f .* sigma .^ 2 + 2 .* mu .* sigma .* (1 - f) + x .^ 2 + mu .^ 2)./ (2 .* f .* sigma .^ 3);
  der = (-1 ./ sigma) .* (a .* (1 - a/2) .* f - a + 1);
  ACOV(1, 3) = sumfast(der(:)); ACOV(3, 1) = sumfast(der(:));

  %sigma, mu
  der = (1 + (a - 1) .* f) ./ (sigma .^ 2);
  ACOV(2, 3) = sumfast(der(:)); ACOV(3, 2) = sumfast(der(:));

  return
end

%general case

z = 1 + k .* (x - mu) ./ sigma;

%k, k
a = (x - mu) ./ sigma;
b = k .* a + 1;
c = log(b);
d = 1 ./ k + 1;
if nargin > 5 && ~isempty(kk_terms) %use a series expansion to find the derivatives more accurately when k is small
  aa = k .* a;
  f = exp(-a .* k_terms);
  kkk_terms = 2/3; sgn = 1; i = 0;
  while 1
    sgn = -sgn; i=i+1;
    newterm = (sgn * (i + 1) * (i + 2) / (i + 3)) * (aa .^ i);
    kkk_terms = kkk_terms + newterm;
    if max(abs(newterm)) <= eps
      break
    end
  end
  der = (a .^ 2) .* (a .* (a .* kk_terms .^ 2 - kkk_terms) .* f + a .* (1 + k) .* kkk_terms - 2 * kk_terms); 
else
  der = ((((c ./ k.^2) - (a ./ (k .* b))) .^ 2) ./ (b .^ (1 ./ k))) + ...
  ((-2*c ./ k.^3) + (2*a ./ (k.^2 .* b)) + ((a ./ b) .^ 2 ./ k)) ./ (b .^ (1 ./ k)) + ...
  2*c ./ k.^3 - ...
  (2*a ./ (k.^2 .* b)) - (d .* (a ./ b) .^ 2);
end
der(z <= 0) = 0; %no probability mass in this region
ACOV(1, 1) = sumfast(der(:));

%sigma, sigma
if nargin > 5 && ~isempty(kk_terms) %use a series expansion to find the derivatives more accurately when k is small
  der = ((-2*a .* k_terms + 4 * a .^ 2 .* k .* kk_terms - a .^ 3 .* (k .^ 2) .* kkk_terms) .* (f - k - 1) + f .* ((a .* (k_terms - a .* k .* kk_terms)) .^ 2) - 1) ./ (sigma .^ 2);
else
  der = (sigma .^ -2) .* (...
    -2*a .* b .^ (-d) + ...
    d .* k .* a .^ 2 .* (b .^ (-d-1)) + ...
    2 .* d .* k .* a ./ b - ...
    d .* (k .* a ./ b) .^ 2 - 1);
end
der(z <= 0) = 0; %no probability mass in this region
ACOV(2, 2) = sumfast(der(:));

%mu, mu
if nargin > 5 && ~isempty(kk_terms) %use a series expansion to find the derivatives involving k more accurately when k is small
    der = (f .* (a .* k .* kk_terms - k_terms) .^ 2 - a .* k .^ 2 .* kkk_terms .* (f - k - 1)) ./ (sigma .^ 2); 
else
  der = (d .* (sigma .^ -2)) .*  (...
  k .* (b .^ (-d-1)) - ...
  (k ./ b) .^ 2);
end
der(z <= 0) = 0; %no probability mass in this region
ACOV(3, 3) = sumfast(der(:));


%k, mu
if nargin > 5 && ~isempty(kk_terms)  %use a series expansion to find the derivatives involving k more accurately when k is small
  der = 2 * a .* kk_terms .* (f - 1 - k) - a .^ 2 .* k_terms .* kk_terms .* f + k_terms; %k, a second derivative
  der = -der ./ sigma;
else
  der = ( (b .^ (-d)) .* (c ./ k  - a ./ b) ./ k - ...
a .* (b .^ (-d-1)) + ...
((1 ./ k) - d) ./ b + ...
a .* k .* d ./ (b .^ 2)) ./ sigma;
end
der(z <= 0) = 0; %no probability mass in this region
ACOV(1, 3) = sumfast(der(:)); ACOV(3, 1) = sumfast(der(:));

%k, sigma
der = a .* der;
der(z <= 0) = 0; %no probability mass in this region
ACOV(1, 2) = sumfast(der(:)); ACOV(2, 1) = sumfast(der(:));

%sigma, mu
if nargin > 5 && ~isempty(kk_terms)  %use a series expansion to find the derivatives involving k more accurately when k is small
  der = ((-k_terms + 3 * a .* k .* kk_terms - (a .* k) .^ 2 .* kkk_terms) .* (f - k - 1) + a .* (k_terms - a .* k .* kk_terms) .^ 2 .* f) ./ (sigma .^ 2); 
else
  der = ( -(b .^ (-d)) + ...
a .* k .* d .* (b .^ (-d-1)) + ...
(d .* k ./ b) - a .* (k./b).^2 .* d) ./ (sigma .^ 2);
end
der(z <= 0) = 0; %no probability mass in this region
ACOV(2, 3) = sumfast(der(:)); ACOV(3, 2) = sumfast(der(:));

end