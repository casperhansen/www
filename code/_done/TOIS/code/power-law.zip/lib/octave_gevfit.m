function [paramhat, paramci] = octave_gevfit(data)
parmguess = [0; 1; 0];
%cost function to minimize
f = @(p) octave_gevlike(p, data);
  
options = optimoptions('fminunc','GradObj','on', 'FinDiffType', 'central', 'MaxFunEvals', Inf, 'TolX', 10^-7, 'TolFun', 10^-7, 'TypicalX', ones(3,1));
%paramhat = my_fminunc(f, parmguess);
paramhat = fminunc(f, parmguess, options);
    
if nargout > 1
  [~, ~, ACOV] = gevlike(paramhat, data);
  param_se = sqrt(diag(inv(ACOV)));
  paramci(:, 1) = paramhat - 1.96*param_se;
  paramci(:, 2) = paramhat + 1.96*param_se;
end
end