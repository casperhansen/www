function nLogL = likepower(parms, data)
% Log likelihood calculated from Clauset et al. 2009 Eqn. B.8

% Return NaN for out of range parameter or data.
parms(parms < 0) = NaN;
data(data < 0)   = NaN;

alpha = parms(1);

n     = numel(data);
sumz  = sum(log(data));
nLogL = -log(zeta_hurwitz(alpha,min(data))) - alpha.*log(data);
%nLogL = -n*log(zeta_hurwitz(alpha,min(data))) - alpha*sumz;
end