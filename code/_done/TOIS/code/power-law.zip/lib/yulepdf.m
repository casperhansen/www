function rs = yulepdf(data, rho_hat)
%Yule-Simon distribution function.
%
%   RS = YULEPDF(DATA,RHO_HAT) returns the cumulative distribution function
%   (CDF) of the Yule-Simon distribution on DATA with parameter P. The 
%   definition used is taken from Simons original paper.
%
%   Input:
%   DATA    - A N x 1 vector of observations void of zeros.
%   RHO_HAT - The MLE estimated Yule exponent
%
%   Output:
%   RS - The Yule-Simon PDF of DATA with parameter RHO_HAT.
%
%   Example (> indicate the MatLab terminal):
%   > addpath('misc','lib','write','clauset');
%   > rs = yulepdf(x, rho_hat);
%
%   where x is some vector of observation void of zeros, and rho_hat is the
%   exponent of the Yule-Simon distribution estimated using MLE estimation
%   (see fitdatatodist.m).
%
%   Remarks:
%   We use the same definition as Clauset et al. which differs from the
%   original one by Simon.
%
%   Casper Petersen and Jakob Grue Simonsen, 2012
%   Department of Computer Science
%   University of Copenhagen
%

if(min(data) == 1)
   C = 1;
else
   C = (min(data)-1) + beta(min(data)-1,rho_hat); 
end

rs = (rho_hat-1)*beta(data, rho_hat)./C;
rs(data ~= round(data) | (data < 1)) = 0;
end