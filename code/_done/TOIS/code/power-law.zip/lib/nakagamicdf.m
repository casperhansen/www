function rs = nakagamicdf(data, mu, omega)
%Nakagami cumulative distribution function.
%
%   RS = NAKAGAMICDF(DATA,MU,OMEGA) returns the cumulative distribution
%   function (CDF) of the Nakagami distribution on DATA using parameters 
%   MU and OMEGA. 
%
%   Input:
%   DATA   - A N x 1 vector of observations void of zeros.
%   MU     - The MLE estimated shape parameter.
%   OMEGA  - The MLE estimated scale parameter.
%
%   Output:
%   RS - The Nakagami CDF of DATA using MU and OMEGA.
%
%   Example (> indicate the MatLab terminal):
%   > addpath('misc','lib','write','clauset');
%   > rs =nakagamicdf(x, mu, omega);
%
%   where x is some vector of observation void of zeros, and mu and omega
%   are the parameters returned from Nakagami MLE estimation (see
%   fitdatatodist.m).
%
%   Remarks:
%
%   Casper Petersen and Jakob Grue Simonsen, 2012
%   Department of Computer Science
%   University of Copenhagen
%
rs = gammainc(mu/omega*data.^2, mu);
end