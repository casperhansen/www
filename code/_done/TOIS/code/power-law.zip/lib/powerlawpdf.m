function rs = powerlawpdf(data, a_hat, xmin)
%Power law distribution function.
%
%   RS = POWERLAWPDF(DATA,ALPHA,XMIN) returns the distribution function
%   (PDF) of the power law distribution of DATA using parameters ALPHA and 
%   XMIN. The definitions from Clauset et al. (2007) is used.
%
%   Input:
%   DATA  - A N x 1 vector of observations void of zeros.
%   ALPHA - The MLE estimated power law exponent.
%   XMIN  - The lower cutoff of the power law distribution.
%
%   Output:
%   RS - The power law PDF of DATA using ALPHA and XMIN.
%
%   Example (> indicate the MatLab terminal):
%   > addpath('misc','lib','write','clauset');
%   > rs = powerlawpdf(x, alpha, xmin);
%
%   where x is some vector of observation void of zeros, and alpha and xmin
%   are the parameters returned from power law MLE estimation (see
%   fitdatatodist.m).
%
%   Remarks:
%   1 - This files requires that hzeta.c is compiled on the current system.
%   See hzeta.c for details on compiling the file.
%
%   Casper Petersen and Jakob Grue Simonsen, 2012
%   Department of Computer Science
%   University of Copenhagen
%
rs = (1/zeta_hurwitz(a_hat,xmin)) .* data.^-a_hat;
end