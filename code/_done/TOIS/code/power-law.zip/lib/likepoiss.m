function nLogL = likepoiss(parms, data)
% Log likelihood calculated from https://onlinecourses.science.psu.edu/stat504/node/31
% Accessed 30-09-2014
% In the last term we approximate the log-factorial function with the
% gammaln

% Return NaN for out of range parameter or data.
parms(parms < 0) = NaN;
data(data < 0)   = NaN;
%data             = poisspdf(data, parms);
%n     = numel(data);
nLogL = -parms + log(parms).*data - 3*gammaln(data);
if(sum(nLogL) > 0)
   nLogL = -1.*nLogL; 
end
%nLogL = -n*parms + log(parms)*sum(data) - sum(gammaln(data));

end