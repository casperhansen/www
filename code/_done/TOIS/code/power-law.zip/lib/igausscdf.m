function rs = igausscdf(y, mu, lambda)
%Inverse Gaussian cumulative distribution function.
%
%   RS = IGAUSSCDF(DATA,MU,LAMBDA) returns the cumulative distribution 
%   function (CDF) of the Inverse Gaussian distribution on DATA using 
%   parameters MU and LAMBDA.
%
%   Input:
%   DATA   - A N x 1 vector of observations void of zeros.
%   MU     - The MLE estimated location parameter.
%   LAMBDA - The MLE estimated scale parameter.
%
%   Output:
%   RS - The Inverse Gaussian CDF of DATA using MU and LAMBDA.
%
%   Example (> indicate the MatLab terminal):
%   > addpath('misc','lib','write','clauset');
%   > rs = igausscdf(x, mu, lambda);
%
%   where x is some vector of observation void of zeros, and mu and lambda
%   are the parameters returned from Inverse Gaussian MLE estimation (see
%   fitdatatodist.m).
%
%   Remarks:
%
%   Casper Petersen and Jakob Grue Simonsen, 2012
%   Department of Computer Science
%   University of Copenhagen
%
normcdf   = @(x)0.5.*(1+erf(x./sqrt(2)));
rs = normcdf(sqrt(lambda./y).*(y/mu-1)) + ...
     exp(2*lambda/mu)*normcdf(sqrt(lambda./y).*(-y/mu-1));

end
