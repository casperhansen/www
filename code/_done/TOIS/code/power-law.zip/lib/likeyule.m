function nLogL = likeyule(parms, data)
% Log likelihood calculated straigt-forward from PDF.

% Return NaN for out of range parameter or data.
parms(parms < 0) = NaN;
data(data < 0)   = NaN;

% Calculate Yule loglikelihood
if(min(data) == 1)
   C = 0; 
else
   dmin = min(data)-1;
   C = log(dmin) + betaln(dmin, parms); 
end
nLogL = log(parms - 1) + betaln(data, parms) - C;
%nLogL = sum(log(parms - 1) + betaln(data, parms) - C);
end

%function nLogL = ynlogl(ab, a, rho)
%Follow the configuration of generalized Yule distribution in Nee 2003. 
%The configuration on wikipedia and in Simon 1955 is the special case 
%where a = 1. 
%n     = numel(ab);
%nLogL = n * (log(rho) + specialgammaln(a + rho) - specialgammaln(a));
%for i = 1 : n 
%    nLogL = nLogL + specialgammaln(a + ab(i) - 1) - specialgammaln(a + rho + ab(i));
%end
%end

%function v = specialgammaln(z)
% v = log(abs(gamma(z)));
%end