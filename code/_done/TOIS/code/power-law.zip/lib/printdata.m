function printdata(in)

fid = fopen('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\SNAP\cit-Patents\cit-Patents-from-degrees.txt','w');

for i = 1 : numel(in)
    fprintf(fid, '%d\n', in(i));
end    
    
fclose(fid);

end

