function rs = logpdf(data, mu, sigma)
%Logistic distribution function.
%
%   RS = LOGPDF(DATA,MU,SIGMA) returns the distribution function
%   (PDF) of the Logistic distribution on DATA using parameters MU 
%   and SIGMA.
%
%   Input:
%   DATA   - A N x 1 vector of observations void of zeros.
%   MU     - The MLE estimated location parameter.
%   SIGMA  - The MLE estimated scale parameter.
%
%   Output:
%   RS - The Logistic PDF of DATA using MU and SIGMA.
%
%   Example (> indicate the MatLab terminal):
%   > addpath('misc','lib','write','clauset');
%   > rs = logpdf(x, mu, sigma);
%
%   where x is some vector of observation void of zeros, and mu and sigma
%   are the parameters returned from Logistic MLE estimation (see
%   fitdatatodist.m).
%
%   Remarks:
%
%   Casper Petersen and Jakob Grue Simonsen, 2012
%   Department of Computer Science
%   University of Copenhagen
%
rs = exp((data-mu)/sigma)./(sigma*(1+exp((data-mu)/sigma)).^2);
end