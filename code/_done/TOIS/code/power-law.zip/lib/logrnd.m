function out = logrnd(sampleSize, a, k) % a = MU, k = SIGMA
u1 = rand( sampleSize );
out = a - k*log( 1./u1 - 1 );
end