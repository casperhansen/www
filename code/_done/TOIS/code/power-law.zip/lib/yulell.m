function r = yulell(data,alpha,cens,freq)
% Imitate the approach by Clauset et al.
r = sum(ylpdf(data,alpha));
end