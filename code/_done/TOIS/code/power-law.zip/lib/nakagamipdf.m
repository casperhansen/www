function rs = nakagamipdf(data,mu,omega)
%Nakagami distribution function.
%
%   RS = NAKAGAMIPDF(DATA,MU,OMEGA) returns the distribution function
%   (PDF) of the Nakagami distribution on DATA using parameters MU and 
%   OMEGA. 
%
%   Input:
%   DATA   - A N x 1 vector of observations void of zeros.
%   MU     - The MLE estimated shape parameter.
%   OMEGA  - The MLE estimated scale parameter.
%
%   Output:
%   RS - The Nakagami PDF of DATA using MU and OMEGA.
%
%   Example (> indicate the MatLab terminal):
%   > addpath('misc','lib','write','clauset');
%   > rs = nakagamipdf(x, mu, omega);
%
%   where x is some vector of observation void of zeros, and mu and omega
%   are the parameters returned from Nakagami MLE estimation (see
%   fitdatatodist.m).
%
%   Remarks:
%
%   Casper Petersen and Jakob Grue Simonsen, 2012
%   Department of Computer Science
%   University of Copenhagen
%
rs = 2/gamma(mu) * (mu/omega)^mu * data.^(2*mu-1).*exp(-mu*data.^2/omega);
end