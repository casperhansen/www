function nLogL = likegam(parms, data)
% Log likelihood calculated from http://math.wikia.com/wiki/Gamma_distribution

% Return NaN for out of range parameter or data.
parms(parms < 0) = NaN;
data(data < 0)   = NaN;

n = numel(data);

k = parms(1);
theta = parms(2);

nLogL = (k-1).*log(data) - (data./theta) - k*log(theta) - gammaln(k);
%nLogL = (k-1)*sum(log(data)) - sum(data./theta) - n*k*log(theta) - n*gammaln(k);

end