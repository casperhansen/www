function nLogL = likelog(parms, data)
% Log likelihood calculated from 
% https://www.stat.tamu.edu/~jnewton/604/chap4.pdf

% Return NaN for out of range parameter or data.
parms(parms < 0) = NaN;
data(data < 0)   = NaN;

n = numel(data);

alpha = parms(1);
beta  = parms(2);

y     = (data - alpha)./beta;
% Unless every y is composed of /very/ large numbers, the third term will
% dominate the calculation of the result which will be positive. We check
% before returning.
nLogL = log(beta) + y + 2.*log1p(exp(-y));
if(sum(nLogL) > 0)
    nLogL = -nLogL;
end
%nLogL = n*log(beta) + sum(y) + 2*sum(log(1 + exp(-y)));
end