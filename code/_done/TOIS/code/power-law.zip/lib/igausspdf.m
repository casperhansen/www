function rs = igausspdf(data, mu, lambda)
%Inverse Gaussian distribution function.
%
%   RS = IGAUSSPDF(DATA,MU,LAMBDA) returns the distribution function
%   (PDF) of the Inverse Gaussian distribution on DATA using parameters MU 
%   and LAMBDA.
%
%   Input:
%   DATA   - A N x 1 vector of observations void of zeros.
%   MU     - The MLE estimated location parameter.
%   LAMBDA - The MLE estimated scale parameter.
%
%   Output:
%   RS - The Inverse Gaussian PDF of DATA using MU and OMEGA.
%
%   Example (> indicate the MatLab terminal):
%   > addpath('misc','lib','write','clauset');
%   > rs = igausspdf(x, mu, lambda);
%
%   where x is some vector of observation void of zeros, and mu and lambda
%   are the parameters returned from Inverse Gaussian MLE estimation (see
%   fitdatatodist.m).
%
%   Remarks:
%
%   Casper Petersen and Jakob Grue Simonsen, 2012
%   Department of Computer Science
%   University of Copenhagen
%
rs = sqrt(lambda./(2*pi*data.^3)).*exp(-lambda./(2*data).*(data./mu-1).^2);
end