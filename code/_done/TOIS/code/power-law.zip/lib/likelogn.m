function nLogL = likelogn(parms, data)
% Return NaN for out of range parameter or data.
parms(parms < 0) = NaN;
data(data < 0)   = NaN;

nLogL = likenorm(parms, log(data)) - log(data);
%nLogL = sum(likenorm(parms, log(data))) - sum(log(data));
end