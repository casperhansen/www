function vstruct = vuong(cll, rll, K1, K2)
% Vuong's likelihood ratio for the difference of two distributions.
%
%   VUONG(DATA) calculates the ratio using the implementation from Clauset
%   et al. (2009). All cases, but the overlapping, from Vuongs original
%   paper are considered.
%
%   Input:
%   DATA - A N x 1 vector consisting of the difference between two
%          log-transformed sampled.
%
%   Output:
%   VSTRUCT - A structure containing Vuong ratio and two-sided p-value.
%
%   Remarks:
%   1 - Contrast to Clauset et al. we do not work on the logarithm.   
%
%   Casper Petersen and Jakob Grue Simonsen, 2012
%   Department of Computer Science
%   University of Copenhagen
%
x  = cll - rll;
n  = numel(x);
m  = mean(x);
s  = std(x);
c  = (K1 - K2)/2 * log(n); % Parameter correction.
v  = (sqrt(n)*m - c)/s;
p1 = normcdf(v,0,1); % Asymptotically normally distributed
if (p1 < 0.5) 
    p2 = 2*p1;
else
    p2 = 2*(1-p1);
end

vstruct = struct('Vuong', v,...
                 'pTwoSided', p2);
end