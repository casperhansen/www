function distances = fitAndPlot(data, structfits, distmap,...
                                        xin, ppath)
%Visualizes distribution fits.
%
%   DISTANCES = FITANDPLOT(DATA, DISTMAP, NAME, XIN, PATH) 
%   calculates and plots the MLE fit of the distributions found in DISTMAP 
%   to DATA on CDF form. The plot is saved at PATH as NAME in PDF format 
%   using XIN for the x-axis label.
%
%   There are several additional (lenghty) comments in the code detailing
%   why we did what we did.
%
%   Input:
%   DATA       - A N x 1 vector of observations. 
%   STRUCTFITS - A N x 1 cell array containing all structs returned
%                from calling distPDFcomp.m
%   DISTMAP    - The table returned from 'getDistMapping.m'
%   NAME       - The name of the dataset. Used when saving the plots.
%   XIN        - The label of the x-axis. A string.
%   PPATH      - The path where plots are saved.
%
%   Output:
%   DISTANCES  - A cell array containing the KS-distances for each
%                distribution.
%
%   Example (> indicate the MatLab terminal):
%   > addpath('misc','lib','write','clauset');
%   > ks = visualizeCDFfit_ks(x,compres,disttable, 'opticset', 'FW', tmp/') 
%
%   where x, compres and disttable can be seen in the example of
%   distPDFcomp.m.
%
%
%   Casper Petersen and Jakob Grue Simonsen, 2012
%   Department of Computer Science
%   University of Copenhagen
%
close all;
N         = size(structfits, 1);
distances = cell(N,2);
lineWidth = 1.5;

% Get discrete distributions column
discdist = cell2mat(distmap(:, 11));

% Get the empirical CDF. 
[x_e,f_e] = ecdf_all(data,1);
[f_z,x_z] = ecdf(data);
%fprintf('Calculated ECDFs -> Clearing data\n');
clear data;
% Fit each distribution in turn to the data
for j = 1 : N
    % Plot empirical CDF and set the labels
    set(gcf,'Visible','off'); % Dont show the plot. Takes forever.
    fprintf('%s : Plotting ''%s''\n', datestr(clock), distmap{j,3});
    % The data is emprical and integers, so we always plot using stairs.
    %if(not(discdist(j)))
    %    plot(  x_z, f_z, 'b-', 'LineWidth', lineWidth);
    %else
    %    stairs(x_z, f_z, 'b-', 'LineWidth', lineWidth);
    %end
    %stairs(x_z, f_z, 'b-', 'LineWidth', lineWidth); 
    
    % We need to capture the instances where the optimization has somehow
    % gone terribly wrong, plot them as errors and continue.
    res  = structfits{j,1};
    if(ischar(res.logl) || res.logl > 0) % Dirty
        plotErrorFigure(x_e, res, xin, distmap, j, ppath);
        close;
        continue;
    end
    
    % Depending on the (a) the number of parameters in the distribution,
    % and (b) whether the hypothesized distribution is discrete or
    % continuous, we switch appropriately.
    % The catch clause is never needed but was used during testing.
    switch(numel(res.parms))
        case 1,
               %try
                 if(discdist(j))
                    fit = ddiscKS(f_z,x_z,distmap{j,4}, [res.parms], x_e, f_e);
                 else
                    fit = dcontKS(f_z,x_z,distmap{j,4}, [res.parms], x_e, f_e);
                 end
               %catch ME
               %   plotErrorFigure(x_e, res, xin, distmap, j, ppath);
               %   close;
               %   continue;
               %end
        case 2,
               %try
                 if(discdist(j))
                    fit = ddiscKS(f_z,x_z,distmap{j,4},...
                                  [res.parms(1), res.parms(2)],...
                                  x_e, f_e);
                 else
                    fit = dcontKS(f_z,x_z,distmap{j,4},...
                                  [res.parms(1), res.parms(2)],...
                                  x_e, f_e);
                 end
               %catch ME
               %   plotErrorFigure(x_e, res, xin, distmap, j, ppath);
               %   close;
               %   continue;
               %end
        case 3,
               %try
                 if(discdist(j))
                    fit = ddiscKS(f_z,x_z,distmap{j,4},...
                               [res.parms(1), res.parms(2), res.parms(3)],...
                               x_e, f_e);
                 else
                    fit = dcontKS(f_z,x_z,distmap{j,4},...
                               [res.parms(1), res.parms(2), res.parms(3)],...
                               x_e, f_e);
                 end
               %catch ME
               %   plotErrorFigure(x_e, res, xin, distmap, j, ppath);
               %   close;
               %   continue;
               %end
        otherwise, error('Parms did not have length 1,2 or 3');
    end
    % The returned fit contains:
    % 1 - The x-values for the hypothesized distribution.
    % 2 - The y-values for the hypothesizes distribution, evaluated at the
    %     x-values.
    % 3 - A list of maximum KS-distances
    % As these values are ONLY used for plotting, we display the normal
    % version where y values are evaluated at x instead of at x,...x+1.
    % This is to save memory
    gxgrid = fit{1}; gxgrid = gxgrid(:);
    gxvals = fit{2}; gxvals = gxvals(:);

    NN = 1000000;
    if(numel(gxgrid) < NN)
       NN = numel(gxgrid);
    end

    xvals = gxgrid(1:NN);
    yvals = gxvals(1:NN);
    xvals = [xvals(1);xvals(:)];
    yvals = [0;yvals(:)];
    yvals(end) = 1;
    clear gxgrid gxvals
    
    % As power-law expoenent are estimated as positive, they are in fact
    % negative. Also, evaluating the power law requires the alpha and xmin,
    % whereas the plot should lists the coefficient C. We therefore make
    % the necessary changes here.
    if(strcmpi(distmap{j,2}, 'powerlaw'))
       res.parms(2) = 1/zeta_hurwitz(res.parms(1),res.parms(2));    % C
       res.parms(1) = -res.parms(1);                                % f(x) 
    end
    % Plot the empirical cdf (the sparse one)
    stairs(x_z, f_z, 'b-', 'LineWidth', lineWidth);
    %printStuff([ppath,distmap{j,8},'_empirical.txt'],x_z,f_z);
    %xvals = [gxgrid(1);gxgrid];
    %yvals = [0;gxvals];
    %clear gxgrid gxvals 
    %[M,V] = regexp(sprintf('%i',[0; diff(yvals)==0]),'1+','match');
    %fprintf('After regexp\n');
    %[M,I] = max(cellfun('length',M));
    %fprintf('After max cellfun\n');
    %M = M + 1;  % Holds the max length.
    %I = V(I) - 1;  % Holds the starting index of first run of length M.
    %V = yvals(I);  % The value of the run.
    %fprintf('After variable stuff\n');
    %low = 0.9999;
    %idx_low = find(yvals == V, 1, 'first')
    %idx_high = find(yvals == V, 1, 'last')
    %xhigh = xvals(end);
    %yhigh = yvals(end);
    %xvals(idx_low:idx_high) = [];
    %yvals(idx_low:idx_high) = [];
    %xvals = [xvals;xhigh];
    %yvals = [yvals;yhigh];
    %fprintf('After assignments\n');
    % If the j'th distribution is discrete, plot it using stairs. 
    % Replicate first entry to make stairs visually nice
    if(discdist(j))
       hold on;
         stairs(xvals, yvals, 'r-', 'LineWidth', lineWidth);
       hold off;
    else
       hold on;
         plot(xvals, yvals, 'r-', 'LineWidth', lineWidth);
       hold off;
    end
    %printStuff([ppath,distmap{j,8},'_fitted.txt'],xvals,yvals);

    % Get the maximum KS-distance, its index and plot it.
    maxvals     = fit{3};
    [KSSTAT, I] = max(maxvals(:,2));
    %maxvals(I,:)
    hold on;
        if(maxvals(I,3) <= maxvals(I,4))
            plot([maxvals(I,5), maxvals(I,6)], [maxvals(I,3), maxvals(I,4)],...
                 'k-', 'LineWidth', lineWidth+.5);
            %printMaxValsKSstat([ppath,distmap{j,8},'_vals.txt'], maxvals(I,5), maxvals(I,6), maxvals(I,3), maxvals(I,4))
        else
            plot([maxvals(I,5), maxvals(I,6)], [maxvals(I,4), maxvals(I,3)],...
                 'k-', 'LineWidth', lineWidth+.5);  
            %printMaxValsKSstat([ppath,distmap{j,8},'_vals.txt'], maxvals(I,5), maxvals(I,6), maxvals(I,3), maxvals(I,4))
        end
    hold off;
    
    distances{j,1} = distmap{j,3};
    distances{j,2} = KSSTAT;
    
    % House keeping for the plots. Switch on the number of parameters of
    % the examined distribution to set the title.
    switch(numel(res.parms))
        case 1, 
                CI     = max(abs(res.ci - abs(res.parms)));
                title({...
                sprintf('Fitted distribution: %s', distmap{j,3});
                sprintf('KS-distance: %1.4f',KSSTAT);
                sprintf('MLE: %s = %1.3f \\pm %1.2f', distmap{j,5},...
                                                      res.parms, CI)});
            
        case 2, 
                CI1    = max(abs(res.ci(:,1) - res.parms(1)));
                if(strcmpi(distmap{j,2}, 'powerlaw'))
                    % We report the alpha and C parameter -- not the x_min
                    % which we return from fitdatatodist.m. As there is no
                    % uncertainty of the constant C we have to make the
                    % power-law a special case.
                    CI2 = 'NA'; 
                    title({...
                    sprintf('Distribution: %s', distmap{j,3});
                    sprintf('KS-distance: %1.4f',KSSTAT);
                    sprintf('MLE: %s = %1.3f \\pm %1.2f, %s = %1.3f \\pm %s',...
                    distmap{j,5}, res.parms(1), CI1,...
                    distmap{j,6}, res.parms(2), CI2)});                   
                else
                    CI2 = max(abs(res.ci(:,2) - res.parms(2)));
                    title({...
                    sprintf('Distribution: %s', distmap{j,3});
                    sprintf('KS-distance: %1.4f',KSSTAT);
                    sprintf('MLE: %s = %1.3f \\pm %1.2f, %s = %1.3f \\pm %1.2f',...
                    distmap{j,5}, res.parms(1), CI1,...
                    distmap{j,6}, res.parms(2), CI2)});   
                end    

            
        case 3, 
                CI1    = max(abs(res.ci(:,1) - res.parms(1)));
                CI2    = max(abs(res.ci(:,2) - res.parms(2)));
                if(strcmpi(distmap{j,2}, 'gp'))
                    % As MLE only estimates two of the three parameters of
                    % the GP distribution, we make it a special case as
                    % well.
                    CI3 = 'NA'; 
                    title({...
                    sprintf('Distribution: %s', distmap{j,3});
                    sprintf('KS-distance: %1.4f',KSSTAT);
                    sprintf(['MLE: %s = %1.3f \\pm %1.2f, ',...
                                  '%s = %1.3f \\pm %1.2f, ',...
                                  '%s = %1.3f \\pm %s'] ,...
                             distmap{j,5}, res.parms(1), CI1,...
                             distmap{j,6}, res.parms(2), CI2,...
                             distmap{j,7}, res.parms(3), CI3)});
                else
                    CI3 = max(abs(res.ci(:,3) - res.parms(3)));
                    title({...
                    sprintf('Distribution: %s', distmap{j,3});
                    sprintf('KS-distance: %1.4f',KSSTAT);
                    sprintf(['MLE: %s = %1.3f \\pm %1.2f, ',...
                                  '%s = %1.3f \\pm %1.2f, ',...
                                  '%s = %1.3f \\pm %1.2f'] ,...
                             distmap{j,5}, res.parms(1), CI1,...
                             distmap{j,6}, res.parms(2), CI2,...
                             distmap{j,7}, res.parms(3), CI3)});                   
                end

    end
    grid on;
    % Set the legend and axis labels
    legend('Empirical CDF', 'Fitted CDF', 'KS-distance',...
           'Location', 'SouthEast');
    xlabel(xin);
    ylabel('P(X \leq x)');
    ylim([0 1]);
    xlim([-1 max(x_z)]);
    formatPlotAxis;
    formatPlotWindow;

%%  Set up inset plot
 %  We replot the original plot on smaller axes and let the xlim determine 
 %  position. 
    axes('pos',[0.68 0.425 0.175 0.325]);
    stairs(x_z, f_z, 'b-', 'LineWidth', lineWidth); 

    if(discdist(j))
       hold on;
         stairs(xvals, yvals, 'r-', 'LineWidth', lineWidth);
       hold off;
    else
       hold on;
         plot(xvals, yvals, 'r-', 'LineWidth', lineWidth);
       hold off;
    end
    
    fprintf('Plotted! -> Clearing large values\n');    
    hold on;
        if(maxvals(I,3) <= maxvals(I,4))
            plot([maxvals(I,5), maxvals(I,6)], [maxvals(I,3), maxvals(I,4)],...
                 'k-', 'LineWidth', lineWidth+.5);
        else
            plot([maxvals(I,5), maxvals(I,6)], [maxvals(I,4), maxvals(I,3)],...
                 'k-', 'LineWidth', lineWidth+.5);            
        end
    hold off;    
    
    set(gca, 'YTick', 0:0.1:1);
    ihXLabel = xlabel(xin);
    ihYLabel = ylabel('P(X \leq x)');
    box on
    set([ihXLabel, ihYLabel], ...
        'FontName'   , 'AvantGarde');
    set([ihXLabel,ihYLabel]       , ...
        'FontSize'   , 10          );
    grid on;
    ylim([0 1]);
    offset = 3;
    range = maxvals(I,5)-offset:maxvals(I,5)+offset;
    xlim([-1, max(range)]);
    savePath  = [ppath,distmap{j,8},'_CDF.pdf'];
    print(gcf, '-dpdf', savePath);    
    pause(1);
    close all;
end
end


function plotErrorFigure(xs, fit, xin, distmap, j, ppath)
    % In the case the loglikelihood of the current distribution is in error
    % due to one or more parameters being NaNs we still produce the plot,
    % but give no CI or KS-distance.
    if(strcmpi(distmap{j,2}, 'powerlaw'))
       fit.parms(2) = 1/zeta_hurwitz(fit.parms(1),fit.parms(2));
       fit.parms(1) = -fit.parms(1); 
    end    
    switch(numel(fit.parms))
        case 1, title({...
                sprintf('Fitted distribution: %s', distmap{j,3});
                sprintf('MLE: %s = %1.3f', distmap{j,5}, fit.parms)});
            
        case 2, title({...
                sprintf('Distribution: %s', distmap{j,3});
                sprintf('MLE: %s = %1.3f, %s = %1.3f', distmap{j,5},...
                fit.parms(1), distmap{j,6}, fit.parms(2))});
            
        case 3, title({...
                sprintf('Distribution: %s', distmap{j,3});
                sprintf('MLE: %s = %1.3f, %s = %1.3f, %s = %1.3f',...
                distmap{j,5}, fit.parms(1), distmap{j,6}, fit.parms(2),...
                distmap{j,7}, fit.parms(3))});
    end
    grid on;
    
    % Set the legend and axis labels
    legend('Empirical CDF','Location', 'SouthEast');
    xlabel(xin);
    ylabel('P(X \leq x)');
    formatPlotAxis;
    
    % Set up error text
    xloc = max(xs) - mean(xs);
    yloc = 0.2;
    text(xloc, yloc, 'Error in est. parameter(s)', 'FontWeight', 'bold',...
        'FontSize', 10);
    formatPlotWindow;
    savePath  = [ppath,distmap{j,8},'_CDF.pdf'];
    print(gcf, '-dpdf', savePath); 
    pause(1);
end

function formatPlotWindow
    % Set up the output to print plots in consistent size.
    xSize     = 11;
    ySize     = 0.75*xSize;
    set(gcf, 'PaperType', 'A4');
    set(gcf, 'PaperUnits', 'centimeters');
    papersize = get(gcf, 'PaperSize');
    xLeft     = papersize(1)-xSize; 
    yTop      = papersize(2)-ySize;
    set(gcf,'PaperPosition', [xLeft yTop xSize ySize]);
    set(gcf,'Position',[200 200 xSize*50 ySize*50]);
end

function formatPlotAxis
hXLabel = get(gca,'XLabel');
hYLabel = get(gca,'YLabel');
set([hXLabel, hYLabel], ...
    'FontName'   , 'AvantGarde', ...
    'FontSize'   , 10);
hTitle = get(gca,'Title');
set(hTitle,...
    'FontName'   , 'AvantGarde', ...
    'FontSize'   , 8           , ...
    'FontWeight' , 'bold'      );

hLegend = findobj(gcf,'Type','axes','Tag','legend');
if(~isempty(hLegend))
   %hLegend = legend(hLegend);
   set(hLegend, ...
       'FontName'   , 'AvantGarde', ...
       'FontSize'   , 8);
   legend boxoff    
end
end

function ret = dcontKS(f,x, cdfstring, parms, xhat, fhat)
    % This function deals with the g(x) (the hypothesized distribution)
    % is continuous. The implementation is taken from
    % "Nonparametric Goodness-of-Fit Tests for Discrete Null Distributions"
    f     = f(2:end); x = x(2:end); f = f(:); x = x(:);
    %XGrid = x;
    % Evaluate the CDF of g(x) using the estimated parameters
    switch(length(parms))
        case 1, gx = feval(cdfstring, x, parms(1)); 
        case 2, gx = feval(cdfstring, x, parms(1), parms(2)); 
        case 3, gx = feval(cdfstring, x, parms(1), parms(2), parms(3)); 
    end
   
    % Create a proper ECDF where x-values with no support are not omitted,
    % but given the same value.
    N            = numel(x);   % Loop over all values
    maxvals      = zeros(N,6);   
    for i = 1 : N 
        if(x(i) == 1)
           % i = 1 is a special case.
           % The formula states:
           % KS = max(|g(x) - f(x)|, |g(x) - f(x-1)|)
           % which is a problem when f(x) has no support in x-1, hence
           % we clamp the x-1 value to 0.
           gxcurrent    = gx(i);    % g(x) (evaluted at x)
           empcurrent   = f(i);     % f(x) (the ecdf also evaluated at x)
           empprev      = 0;        % f(x-1) (x-1 = 0 cannot exist by our datasets)
           maxvals(i,1) = x(i);
           maxvals(i,2) = ... 
                     max(...                               % max(
                         abs(gxcurrent - empcurrent),...   % |g(x) - f(x)|,
                         0);                               % according to article);
           
           % Determines which value is the lower one for plotting the KS
           % distance lager
           if(abs(gxcurrent - empcurrent) > abs(gxcurrent - empprev))
              maxvals(i,[3,4]) = [gxcurrent, empcurrent];
           else
              maxvals(i,[3,4]) = [gxcurrent, empprev]; 
           end
           maxvals(i,[5,6]) = [x(i), x(i)];
        else
           % When f(x) has support for f(x-1) we calculate it
           % straight-forward.
           gxcurrent        = gx(i);
           empcurrent       = f(i);
           % fhat is defined for all xs (xhat) = min(data):max(data). x(i) are
           % the points of support for the ECDF
           %empprev          = fhat(xhat == (x(i) - 1)); 
           empprev          = fhat(binsearch(xhat,(x(i)-1))); 
           maxvals(i,1)     = x(i);
           maxvals(i,2)     = max(...
                                  abs(gxcurrent - empcurrent),...
                                  abs(gxcurrent - empprev)...
                                 );       
           if(abs(gxcurrent - empcurrent) > abs(gxcurrent - empprev))
               if(gxcurrent > empcurrent)
                    maxvals(i,[3,4]) = [gxcurrent, empcurrent];
               else
                    maxvals(i,[3,4]) = [empcurrent, gxcurrent];
               end
               maxvals(i,[5,6]) = [x(i),x(i)];
           else
               if(gxcurrent > empprev)
                    maxvals(i,[3,4]) = [gxcurrent, empprev];      
                    maxvals(i,[5,6]) = [x(i),x(i)];
               else
                    maxvals(i,[3,4]) = [empprev, gxcurrent]; 
                    maxvals(i,[5,6]) = [x(i),x(i)];
               end
           end                     
           %maxvals(xhat(i), 5) = i;
        end
    end
    ret = {x,gx,maxvals};
end

function ret = ddiscKS(f,x,cdfstring, parms, XGridFull, fhat)
        f         = f(2:end); x = x(2:end); f = f(:); x = x(:);
        % Ensure that F(x) is evaluated in points of the ECDF 
        % (even those where ECDF have no support). I.e. the theoretical
        % support is everywhere (for all positive integers). However, the
        % definition only needs data values 1 below the datapoints where
        % ECDF has support that is: F(x_{i} - 1). 
        switch(length(parms))
            case 1, gx = feval(cdfstring, XGridFull, parms(1)); 
            case 2, gx = feval(cdfstring, XGridFull, parms(1), parms(2)); 
            case 3, gx = feval(cdfstring, XGridFull, parms(1), parms(2), parms(3)); 
        end        
        N           = numel(x); 
        maxvals     = zeros(N,6); 
        %supportLow  = getSupport(cdfstring);
        gx(gx < 0)  = 0; % In case we have first valid data point > 0 at location greater than 1
        %gx'
        %x(1)
        tmp = 0; flag = 0;
        for i = 1 : N
            % XGridFull looks like: min(x):max(x)
            % The formula states:
            % max(|g(x_i) - f(x_i)|, |g(x_i - eps) - f(x_{i - 1})|)
               gxcurrent        = gx(x(i)); % g(x_i)
               empcurrent       = f(i);     % f(x_i)
               gindex           = x(i)-1;%binsearch(XGridFull,x(i))-1;
               % If gindex == 0 that means x(1) == 1. The fitted 
               % distribution is defined across the
               % range of all integers and MAY have support in 0. In that
               % case we need to calculate a CDF value for the distribution
               % 0, and augment the return values with 0 and the CDF value.
               if(gindex == 0) % x(i) == 1. Smallest value of any dataset
                  if(getSupport(cdfstring) == 0) % However the theoretical distribution can have support in 0
                        switch(length(parms))
                            case 1, gxhalfval = feval(cdfstring, 0, parms(1)); 
                            case 2, gxhalfval = feval(cdfstring, 0, parms(1), parms(2)); 
                            case 3, gxhalfval = feval(cdfstring, 0, parms(1), parms(2), parms(3)); 
                        end
                        tmp = gxhalfval;
                  else  
                    gxhalfval = 0;
                    tmp       = gxhalfval;
                  end
                  flag = 1;
               else
                  gxhalfval = gx(gindex); % g(x_i - 1)                   
               end
               % if x(i) == 1 there cannot be a previous value as 1 is the
               % smallest value allowed in our data. A previous value
               % cannot exist, so we clamp it to 0
               if(x(i) == 1)
                  empprev   = 0; % Cannot look up or generate x0 for the emprical as we do not know the distribution
               else
                  empprev   = fhat(binsearch(XGridFull, (x(i)-1))); % f(x_{i-1}) 
               end
               maxvals(i,1)     = x(i);
               maxvals(i,2)     = max(...                           
                                      abs(gxcurrent - empcurrent),...
                                      abs(gxhalfval - empprev)...
                                  );       
               if(abs(gxcurrent - empcurrent) > abs(gxhalfval - empprev))
                  maxvals(i,[3,4]) = [gxcurrent, empcurrent];
                  maxvals(i,[5,6]) = [x(i),x(i)];
               else
                  maxvals(i,[3,4]) = [gxhalfval, empprev]; 
                  maxvals(i,[5,6]) = [x(i),x(i)];
               end                                     
        end

     % As use xhat,fhat for calculating distances we dont need them to
     % plot. Hence we recalulate using the downscaled ecdf
     %switch(length(parms))
     %       case 1, gx = feval(cdfstring, x, parms(1)); 
     %       case 2, gx = feval(cdfstring, x, parms(1), parms(2)); 
     %       case 3, gx = feval(cdfstring, x, parms(1), parms(2), parms(3)); 
     %end        

     if(flag)
        %ret = {[0;x],[tmp;gx],maxvals};
        ret = {[0;XGridFull],[tmp;gx],maxvals};
     else
        %ret = {x,gx,maxvals};
        ret = {XGridFull,gx,maxvals};
     end
     %ret{:,3}
end

function printStuff(location, v1, v2)
[v1_x,v1_y] = size(v1);
[v2_x,v2_y] = size(v2);

if(v1_x ~= v2_x)
   error('fitAndPlot :: Dimension mismatch!'); 
end

if(v1_y ~= v2_y)
   error('fitAndPlot :: Dimension mismatch!'); 
end

N = numel(v1);

fid = fopen(location,'w');
for i = 1 : N
   fprintf(fid,'%d,%12f\n',  v1(i), v2(i));
end
fclose(fid);
end

function printMaxValsKSstat(location,v1,v2,v3,v4)
fid = fopen(location,'w');
fprintf(fid,'%d,%d,%1.8f,%1.8f\n',v1,v2,v3,v4);
fclose(fid);
end