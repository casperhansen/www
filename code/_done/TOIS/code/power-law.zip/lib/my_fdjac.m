function fjac = my_fdjac(fcn, x, fvec, typicalx, cdif)
  err = 0;
  if (cdif)
    err = (max (eps, err)) ^ (1/3);
    h = typicalx*err;
    fjac = zeros (length (fvec), numel (x));
    for i = 1:numel (x)
      x1 = x; x2 = x;
      x1(i) = x1(i)+h(i);
      x2(i) = x2(i) - h(i);
      x1    = x1(:);
      x2    = x2(:);
      fjac(:,i) = (fcn (x1) - fcn (x2)) / (x1(i) - x2(i));
    end
  else
    err = sqrt (max (eps, err));
    h = typicalx*err;
    fjac = zeros (length (fvec), numel (x));
    for i = 1:numel (x)
      x1 = x;
      x1(i) = x1(i) + h(i);
      x1 = x1(:);
      fjac(:,i) = (fcn (x1) - fvec) / (x1(i) - x(i));
    end
  end
end


