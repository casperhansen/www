function runNewDatasets

warning off;

%% Document length
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\isearch\doclengths\data\isearch-BK+PF+PN-nostop-nostem.doclengths','isearch-dl/', 'iSearch', '', 'document length', 'Document lengths');
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\dl\ap_8890\ap_8890.doclengths','AP8890-dl/', 'Associated Press (88--90)', '', 'document length', 'Document lengths');
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\dl\ap19992000\ap19992000.doclengths','AP9900-dl/','Associated Press (99--00)', '', 'document length', 'Document lengths');
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\dl\apf_eng\apf_eng.doclengths','afp_eng-dl/','Agence France Presse', '', 'document length', 'Document lengths');
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\dl\apw_eng\apw_eng.doclengths','apw_eng-dl/','Associated Press', '', 'document length', 'Document lengths');
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\dl\cna_eng\cna_eng.doclengths','cna_eng-dl/','Central News Agency', '', 'document length', 'Document lengths');
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\dl\cr\cr.doclengths','cr-dl/','Congressional Record of the 103rd Congress', '', 'document length', 'Document lengths');
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\dl\doe\doe.doclengths','doe-dl/','abstracts from the Department of Energy', '', 'document length', 'Document lengths');
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\dl\fbis\fbis.doclengths','fbis-dl/','Federal Broadcast Information Service', '', 'document length', 'Document lengths');
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\dl\fr\fr.doclengths','fr-dl/','Federal Register (88--89)', '', 'document length', 'Document lengths');
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\dl\fr94\fr94.doclengths','fr94-dl/','Federal Register (1994)', '', 'document length', 'Document lengths');
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\dl\ft\ft.doclengths','ft-dl/','Financial Times', '', 'document length', 'Document lengths');
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\dl\latimes\latimes.doclengths','latimes-dl/','L.A. Times', '', 'document length', 'Document lengths');
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\dl\ltw_eng\ltw_eng.doclengths','ltw_eng-dl/','L.A. Times / Washington Post', '', 'document length', 'Document lengths');
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\dl\nyt\nyt.doclengths','nyt-dl/','New York Times (99--00)', '', 'document length', 'Document lengths');
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\dl\nyt_eng\nyt_eng.doclengths','nyt_eng-dl/','New York Times (04--06)', '', 'document length', 'Document lengths');

%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\dl\patents\patents.doclengths','patents-dl/','U.S. Patents', '', 'document length', 'Document lengths');
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\dl\sjm\sjm.doclengths','sjm-dl/','San Jose Mercury News', '', 'document length', 'Document lengths');
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\dl\wsj_8792\wsj_8792.doclengths','wsj8792-dl/','Wall Street Journal (87--92)', '', 'document length', 'Document lengths');
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\dl\xie19962000\xie19962000.doclengths','xie9600-dl/','Xinhua News Agency (96--00)', '', 'document length', 'Document lengths');
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\dl\xin_eng\xin_eng.doclengths','xie_eng-dl/','Xinhua News Agency (04--06)', '', 'document length', 'Document lengths');
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\dl\ziff\ziff.doclengths','ziff-dl/','Computer Select Disk', '', 'document length', 'Document lengths');

%% Term frequencies
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\tf\ap_8890\ap_8890.termfreq','AP8890-tf/', 'the Associated Press (88--90) dataset', '', 'term frequency');
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\tf\ap19992000\ap19992000.termfreq','AP9900-tf/','the Associated Press (99--00) dataset', '', 'term frequency');
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\tf\afp_eng\afp_eng.termfreq','afp_eng-tf/','the Agence France Presse dataset', '', 'term frequency');
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\tf\apw_eng\apw_eng.termfreq','apw_eng-tf/','the Associated Press dataset', '', 'term frequency');
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\tf\cna_eng\cna_eng.termfreq','cna_eng-tf/','the Central News Agency dataset', '', 'term frequency');
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\tf\cr\cr.termfreq','cr-tf/','the Congressional Record of the 103rd Congress dataset', '', 'term frequency');
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\tf\doe\doe.termfreq','doe-tf/','the abstracts from the Department of Energy dataset', '', 'term frequency');

%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\tf\fbis\fbis.termfreq','fbis-tf/','the Federal Broadcast Information Service dataset', '', 'term frequency');
%clear all;
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\tf\fr\fr.termfreq','fr-tf/','the Federal Register (88--89) dataset', '', 'term frequency');
%clear all;
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\tf\fr94\fr94.termfreq','fr94-tf/','the Federal Register (1994) dataset', '', 'term frequency');
%clear all;
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\tf\ft\ft.termfreq','ft-tf/','the Financial Times dataset', '', 'term frequency');
%clear all;
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\tf\latimes\latimes.termfreq','latimes-tf/','the L.A. Times dataset', '', 'term frequency');
%clear all;
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\tf\ltw_eng\ltw_eng.termfreq','ltw_eng-tf/','the L.A. Times / Washington Post dataset', '', 'term frequency');
%clear all;
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\tf\nyt\nyt.termfreq','nyt-tf/','the New York Times (99--00) dataset', '', 'term frequency');
%clear all;
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\tf\nyt_eng\nyt_eng.termfreq','nyt_eng-tf/','the New York Times (04--06) dataset', '', 'term frequency');
%clear all;
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\tf\patents\patents.termfreq','patents-tf/','the U.S. Patents dataset', '', 'term frequency');
%clear all;
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\tf\sjm\sjm.termfreq','sjm-tf/','the San Jose Mercury News dataset', '', 'term frequency');
%clear all;
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\tf\wsj_8792\wsj_8792.termfreq','wsj8792-tf/','the Wall Street Journal (87--92) dataset', '', 'term frequency');
%clear all;
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\tf\xie19962000\xie19962000.termfreq','xie9600-tf/','the Xinhua News Agency (96--00) dataset', '', 'term frequency');
%clear all;
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\tf\xin_eng\xin_eng.termfreq','xie_engv/','the Xinhua News Agency (04--06) dataset', '', 'term frequency');
%clear all;
%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\new\tf\ziff\ziff.termfreq','ziff-tf/','the Computer Select Disk dataset', '', 'term frequency');

processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\excitequerylogs\querylengths.txt', 'exicte-ql/', 'Excite', '', 'query lengths', 'Query lengths');
processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\millionquerylength\querylengths.txt', 'mq-ql/', 'MillionQuery (2007--2009)', '', 'query lengths', 'Query lengths');

%processDatasetNoCutoff('C:\Casper\Universitet\PhD\Articles\2014\ipm2014\trunk\data\isearch\citations\iSearch-direct-histogram.txt', 'isearch-citations/', 'iSearch citations', '', '\# citations received', 'number of citations received');
warning on;
end