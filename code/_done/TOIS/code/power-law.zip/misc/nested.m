function nestll = nested(loglikea, loglikeb, K1, K2, N)
%Direct log-likelihood of nested distributions.
%
%   NESTLL = NESTED(LOGLIKEA, LOGLIKEB, DOFS) calculates the 'direct'
%   log-likelihood between two distributions by using the chi-square 
%   distribution. In this case, the first parameter is taken to be the 
%   log-likelihood of the nested distributions and the second parameter is 
%   the log-likelihood of the nesting or parent distribution. See Clauset 
%   et al. (2009) for details on this.
%
%   Input:
%   LOGLIKEA - The log-likelihood of the nested distribution.
%   LOGLIKEB - The log-likelihood of the nesting or parent distribution.
%   DOF      - The degrees of freedom. 
%
%   Output:
%   NESTLL - The likelihood ratio between the two distributions.
%
%   Example (> indicate the MatLab terminal):
%   > addpath('misc','lib','write','clauset');
%   > nestll = nested(2000, 3000, 1);
%
%   Remarks:
%
%   Casper Petersen and Jakob Grue Simonsen, 2014
%   Department of Computer Science
%   University of Copenhagen
%
lr      = abs(loglikea) - abs(loglikeb);
c       = (K1-K2)/2 * log(N);
llr     = lr - c;
pval    = 1 - chi2cdf(-2*llr, abs(K1-K2)); % K2 is rival distribution which is the parent distribution
nestll  = struct('logdiff',lr,'pval', pval);
end