function distlist = getDistMapping
%Ensemble of distributions and associated information.
%
%   DISTLIST = GETDISTMAPPING returns a 16 x 12 cell array containing 
%   information used throughout the framework. Each row represents the 
%   information for a single distribution. The columns contain the 
%   following information:
%
%   Column:     Description:
%   1           PDFs
%   2           Identifiers used in fitdatatodist
%   3           Full distribution name
%   4           CDFs
%   5           Name of the first parameter of the distribution
%   6           Name of the second parameter of the distribution (if any)
%   7           Name of the third parameter of the distribution (if any)
%   8           Name used for the CDF plots from visualizeCDFfit_ks
%   9           Row and column name used in Vuong tables
%   10          The number of parameters of the distribution
%   11          Wheter the distribution is discrete or not.
%
%   Input:
%   None
%
%   Output:
%   DISTLIST - A 15 x 12 cell array containing the information described
%              above.
%
%   Example (> indicate the MatLab terminal):
%   > addpath('misc','lib','write','clauset');
%   > distlist = getDistMapping;
%
%   Casper Petersen and Jakob Grue Simonsen, 2012
%   Department of Computer Science
%   University of Copenhagen
%   
distlist = {...
'exppdf',      'exp',      'Exponential',                'expcdf',      'scale'      , '-'    , '-', 'Exponential',                    'Exp'   ,1, 0;
'gampdf',      'gamma',    'Gamma',                      'gamcdf',      'shape'      , 'scale', '-', 'Gamma',                          'Gamma' ,2, 0;
'geopdf',      'geo',      'Geometric',                  'geocdf',      'prob'       , '-'    , '-', 'Geometric',                      'Geo'   ,1, 1;
'gevpdf',      'gev',      'Generalized Extreme Value',  'gevcdf',      'shape'      , 'scale', 'loc', 'GeneralizedExtremeValue',      'Gev'   ,3, 0;
'gppdf',       'gp',       'Generalized Pareto',         'gpcdf',       'shape'      , 'scale', 'loc', 'GeneralizedPareto'      ,      'GP'    ,3, 0;
'igausspdf',   'igauss',   'Inverse Gaussian',           'igausscdf',   'location'   , 'shape', '-', 'InverseGaussian',                'IGauss',2, 0; % CDF and parameter order checked.
'logpdf',      'log',      'Logistic',                   'logisticcdf', 'location'   , 'scale', '-', 'Logistic',                       'Log'   ,2, 0; % CDF and parameter order checked.
'lognpdf',     'logn',     'Lognormal',                  'logncdf',     'scale'      , 'shape'  , '-', 'Lognormal',                    'Logn'  ,2, 0;
'nakagamipdf', 'naka',     'Nakagami',                   'nakagamicdf', 'shape'      , 'scale', '-', 'Nakagami',                       'Naka'  ,2, 0; % CDF and parameter order checked.
'nbinpdf',     'nbin',     'Negative Binomial',          'nbincdf',      '\\# success' , 'prob' , '-', 'NegBin',                         'NBin'  ,2, 1;
'normpdf',     'normal',   'Gaussian'                    'normcdf',     'location'   , 'scale', '-', 'Gaussian',                       'Gauss' ,2, 0;
'poisspdf',    'pois',     'Poisson',                    'poisscdf',    'scale'      , '-'    , '-', 'Poisson',                        'Pois'  ,1, 1;
'powerlawpdf', 'powerlaw', 'Power law',                   'powerlawcdf', 'alpha'      , 'C'    , '-', 'Powerlaw',                      'P-law' ,2, 1; % CDF and parameter order checked.
'raylpdf',     'ray',      'Rayleigh',                   'raylcdf',     'scale'      , '-'    , '-', 'Rayleigh',                       'Rayl.' ,1, 0;
'wblpdf',      'weib',     'Weibull',                    'wblcdf',      'scale'      , 'shape', '-', 'Weibull',                        'Weib'  ,2, 0;
'yulepdf',     'yule',     'Yule',                       'yulecdf',     'scale'      , '-'    , '-', 'Yule',                           'Yule'  ,1, 1
};
end