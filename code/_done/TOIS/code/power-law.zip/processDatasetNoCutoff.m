function processDatasetNoCutoff(filepath, baseoutpath, datasetname,... 
                        article, xlabel_quantity, quantity)
narginchk(6,6);
if(~exist(filepath, 'file'))
   error('File ''%s'' not found', filepath);
end

data                = load(filepath);
data                = data(data > 0);
if(~isempty(setdiff(data, floor(data))))
   error('Data are not integers'); 
end
baseoutpath         = ['output/',baseoutpath];
vtablepath          = 'vtbl/';
figspath            = 'figs/';
figspathcutoff      = 'figs_cutoff/';
vtbltexname         = 'vtbl';
vtbltexnamecutoff   = 'vtbl_cutoff';
figtexname          = 'figs';
figtexnamecutoff    = 'figs_cutoff';
if(exist(baseoutpath, 'dir'))
   rmdir(baseoutpath, 's');
end
mkdir(baseoutpath);
mkdir([baseoutpath,vtablepath]);
mkdir([baseoutpath,figspath]);
mkdir([baseoutpath,figspathcutoff]);
disp('Created all directories');
addpath misc/ lib/ clauset/ write/

%% Statics
table    = getDistMapping;
nested   = getNestedDistributions; 
vcaption = [quantity,' from the ',datasetname,' dataset. NaN means that the MLE optimization returned negative or infinite values. The best-fitting model (dark grey) is the ']; % Quantity is e.g. document length
fc_generic = [datasetname, ' from ''',article,''' using '];
fcaption   = [fc_generic,'no cutoff'];

fprintf('Processing ''%s'' with NO cutoff\n', filepath);
%% Process data with no cutoff
doProcess(data, table, nested, baseoutpath, vtablepath, vtbltexname,...
         vcaption, xlabel_quantity, figspath, figtexname,...
         fcaption, 0);
close all;
createMainTableTexFile(baseoutpath, {'vtbl.tex'; 'vtbl_cutoff.tex'});
createMainPlotTexFile(baseoutpath,  {'figs.tex'; 'figs_cutoff.tex'});
end

function doProcess(data, table, nested, baseoutpath, vtablepath,...
                   vtbltexname, vcaption, quantity,...
                   figspath, figtexname, fcap, ksdist)

ret        = distPDFcomp2(data, table(:,[2,10]), nested);
LRtable    = ret{1};
Ptable     = ret{2};
wasEdited  = ret{3};
AICtable   = ret{4};
distFits   = ret{5};
badLoglike = ret{6}; 
writeVuongFileToLatex([baseoutpath,vtablepath], vtbltexname, vcaption,...
                      'tbl:A', table, LRtable, Ptable, wasEdited,...
                      AICtable, distFits, badLoglike);
distances = fitAndPlot(data, distFits, table, quantity,...
                               [baseoutpath,figspath]);

writePlotsToTexFile(baseoutpath,figspath, figtexname, fcap, 'fig:A');

writeDistances(distances, baseoutpath, ksdist);
end

function writeDistances(dists, path, p)
N = size(dists,1);
if(p)
  fid = fopen([path,'ks_distances_cutoff.dist'],'w');
else
  fid = fopen([path,'ks_distances.dist'],'w');  
end
fprintf(fid,'Distribution\t\t\tKS-distance\n');
for i = 1 : N
   fprintf(fid, '%s\t\t\t%1.4f\n', dists{i,1}, dists{i,2}); 
end
fclose(fid);
end