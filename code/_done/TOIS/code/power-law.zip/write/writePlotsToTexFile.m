function writePlotsToTexFile(basepath, plotdir, texfile, cap, label)
%Create a tex file containing figure plots.
%
%   WRITEPLOTSTOTEXTFILE(PLOTPATH,TEXFILE,CAP,LABEL) writes TEXFILE (no
%   tex extension) to the parent directory of PLOTPATH which contains the 
%   PDF files produced by 'runVisualization.m'. TEXFILE contains 16 
%   subfloats - one for each distribution - divided across two pages.
%   Each figures is given the caption CAP and the label LABEL. Provided the
%   default location is used, a sample file (sample_plot.tex) that compiles
%   compiles the tex file produced by this file can be called to
%   see the output.
%
%   Input:
%   BASEPATH - The basepath containing the plot directory.
%   PLOTDIR  - The filename of the plot directory.
%   TEXFILE  - The name of the texfile created. No *.tex extension needed.
%   CAP      - The caption of the figure(s). A single string.
%   LABEL    - The label of the figure(s). A single string.
%   
%   Output:
%   A tex-file of subfloats containing the distribution plots.
%
%   Example (> indicate the MatLab terminal):
%   > addpath('misc','lib','write','clauset');
%   > writePlotsToTexFile('cdf_plots/','x/', 'y', 'Distribution of y', 'y')
%
%   where x is a directory containing the plots from visualizeCDFfit_ks.m
%   and y is a named quantity used for captions.
%
%   Remarks:
%   1 - This file is hardcoded to handle up to 16 subplots (8
%       subplots pr. page).
%   
%   Casper Petersen and Jakob Grue Simonsen, 2012
%   Department of Computer Science
%   University of Copenhagen
%

distTable   = getDistMapping;
distList    = unique(distTable(:,3)); clear distTable;
distList    = sort(distList);
dircontent  = dir([basepath,plotdir,'*.pdf']);
files       = {dircontent.name};
N           = numel(files);
scale       = '0.39';

% Write latex subfigs. We can only squeeze 8 in on each page (two columns
% of four)
fid         = fopen([basepath,texfile,'.tex'], 'w');
fprintf('writePlotsToTexFile :: Writing %s\n', [basepath,texfile,'.tex']);
fprintf(fid, '\\begin{figure}[!ht]\n');
fprintf(fid, '\\centering\n');
for i = 1 : N/2
    fprintf(fid, ['\\subfloat[',distList{i},']{\\includegraphics[trim=100mm 213mm 0mm 0mm,clip,width=',scale,'\\textwidth]{',[plotdir,files{i}],'}}\n']);
    if(~(i==N/2))
       fprintf(fid, '\\quad\n');
    end
end
fprintf(fid, ['\\caption{Fitting distributions to ',cap,'.}\n']);
fprintf(fid, ['\\label{tbl:',label,'}\n']);
fprintf(fid, '\\end{figure}\n');

% Write latex subfigs on the subsequent page
fprintf(fid, '\\begin{figure}[!ht]\n');
fprintf(fid, '\\ContinuedFloat\n');
fprintf(fid, '\\centering\n');
for i = (N/2 + 1) : N
    fprintf(fid, ['\\subfloat[',distList{i},']{\\includegraphics[trim=100mm 213mm 0mm 0mm,clip,width=',scale,'\\textwidth]{',[plotdir,files{i}],'}}\n']);
    if(~(i==N))
       fprintf(fid, '\\quad\n');
    end
end
fprintf(fid, ['\\caption{Fitting distributions to ',[cap,' (cont).'],'}\n']);
fprintf(fid, ['\\label{tbl:',[label,'_cont'],'}\n']);
fprintf(fid, '\\end{figure}\n');
fprintf(fid, '\\newpage\n');
fprintf(fid, '\\clearpage\n');
fprintf(fid, '\n');
fclose(fid);
end