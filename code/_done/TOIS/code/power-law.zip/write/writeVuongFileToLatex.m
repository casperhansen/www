function writeVuongFileToLatex(path, texfile, caption, label,...
                               distlist, LRtable, Ptable, wasFixed,...
                               AICtable, distFits, badLoglike)
%Constructs and writes Vuong table to disk.
%
%   WRITEVUONGFILETOLATEX(PATH,TEXFILE,CAPTION,LABEL,DISTLIST,LRTABLE,
%   PTABLE,WASFIXED,AICTABLE,PARMS) writes the Vuong table with caption
%   CAPTION and label LABEL to PATH. The header of the table is written
%   separately using DISTLIST. Parameters LRTABLE, PTABLE, WASFIXED,
%   AICTABLE, PARMS are outputs from distPDFcomp.m.
%
%   Input:
%   Path:     Path to the location on disk where the file should be saved.
%   Texfile:  The name of the tex file. E.g. 'vTabledata'.
%   Caption:  The caption of the table. E.g. 'Vuong table of data'.
%   Label:    The label of the table. E.g. 'tbl:data'.
%   Distlist: The tenth column of the matrix returned by getDistMapping.m.
%   LRtable:  Likelihood ratio cell array. The first output returned by 
%             distPDFcomp.m.
%   Ptable:   P-value cell array. Second output returned by distPDFcomp.m.
%   wasFixed: Binary vector. A 1 indicates that 0's was found in the PDF 
%             and replaced by epsilon to prevent NaNs.
%   AICtable: Mx1 cell array containing the AIC estimates of the
%             distributions.
%   distFits: An M x 1 cell array containing all the structs returned
%             fitdatatodist.m
%   badLoglike: an M x 1 vector. Indicates wheter the loglike was fixed.
%
%   Output:
%   A tex file containing the Vuong table of the dataset which has been
%   processed using distPDFcomp.m
%
%   Example (> indicate the MatLab terminal):
%   > addpath('misc','lib','write','clauset');
%   > writeVuongFileToLatexTest('output/','D1','Vuong','tbl:A',table,...
%                               table, dcomps{1}, dcomps{2}, dcomps{3},...
%                               dcomps{4}, dcomps{5});
%
%   Remarks:
%
%   Casper Petersen and Jakob Grue Simonsen, 2012
%   Department of Computer Science
%   University of Copenhagen
%
[M,~] = size(LRtable);

fidfile = [path,texfile,'.tex'];
fid     = fopen(fidfile,'w');
critVal = 0.05;
% Write intro for table
fprintf(fid,'\\begin{table}[!ht]\n');
fprintf(fid,'\\noindent\\centering\n');
fprintf(fid,'\\tiny\n');
intro = createTable(distlist(:,9), wasFixed, badLoglike);
fprintf(fid,intro{1});
fprintf(fid,intro{2});
fprintf(fid,intro{3});
nesteddist   = getNestedDistributions;
isnested     = constructIsNested(nesteddist);
[I,DI]       = findWinningDist(LRtable, Ptable, find([distlist{:,11}]));

% Determine the "best" overall distirbution for the data, and possibly the
% best discrete distribution as well.
bestOverallFitDist      = distlist{I,3};
bestFitParmsVals        = num2cell(distFits{I,1}.parms);
parmString              = getStringRep(distlist, I, bestFitParmsVals);     

if(I ~= DI)
    bestDiscreteFitDist = distlist{DI,3};
    bestFitParmsVals    = num2cell(distFits{DI,1}.parms);
    dparmString         = getStringRep(distlist, DI, bestFitParmsVals);
end

% Begin writing table.
for i = 1 : M
    if(wasFixed(i))
       fprintf(fid, '%s* ', distlist{i,9});
    else
       fprintf(fid, '%s ', distlist{i,9}); 
    end
    for j = 1 : M
        wasEdited = 0;
        if(i >= j)
            fprintf(fid,'& \\cb & \\cb ');
        else
            if(LRtable(i,j) >= 10^3 || LRtable(i,j) <= -10^3)
               wasEdited = 1;
            end
            if(Ptable(i,j) <= critVal)
               if(i == I || j == I || i == DI || j == DI)
                  if(i == I || j == I)
                     fprintf(fid,'%s', cString(0, LRtable(i,j),...
                                       Ptable(i,j), wasEdited,...
                                       badLoglike(j), badLoglike(i)));
                  else
                     fprintf(fid,'%s', cString(1, LRtable(i,j),...
                                       Ptable(i,j), wasEdited,...
                                       badLoglike(j), badLoglike(i)));
                  end
               else
                  if(isnested(i,j))
                     fprintf(fid,'%s', cString(2, LRtable(i,j),...
                                       Ptable(i,j), wasEdited,...
                                       badLoglike(j), badLoglike(i)));
                  else
                     fprintf(fid,'%s', cString(3, LRtable(i,j),...
                                       Ptable(i,j), wasEdited,...
                                       badLoglike(j), badLoglike(i)));
                  end
                end
             else
               if(i == I || j == I || i == DI || j == DI)
                  if(i == I || j == I)
                     fprintf(fid,'%s', cString(4, LRtable(i,j),...
                                       Ptable(i,j), wasEdited,...
                                       badLoglike(j), badLoglike(i)));
                  else
                     fprintf(fid,'%s', cString(5, LRtable(i,j),...
                                       Ptable(i,j), wasEdited,...
                                       badLoglike(j), badLoglike(i)));
                  end
               else
                  if(isnested(i,j))
                     fprintf(fid,'%s', cString(6, LRtable(i,j),...
                                       Ptable(i,j), wasEdited,...
                                       badLoglike(j), badLoglike(i)));
                  else
                     fprintf(fid,'%s', cString(7, LRtable(i,j),...
                                       Ptable(i,j), wasEdited,...
                                       badLoglike(j), badLoglike(i)));
                  end
               end
            end
        end
    end
    fprintf(fid,'\\\\');
    fprintf(fid,'\n');
end
distidx     = find([distlist{:,11}]);
[~,dwinner] = min(AICtable(distidx));
dwinner     = distidx(dwinner);
[~,winner]  = min(AICtable);

%AICtable
%vvv = [1:16]';
%vvv = [vvv, AICtable];
%[~,rofl] = sort(vvv(:,2));
%[vvv, vvv(rofl,:)]
%fprintf('Found discrete winner at index: %d\n', dwinner);
%fprintf('Found overall winner at index: %d\n', winner);

% Write the AIC information seperately
fprintf(fid, '\\hline\n');
fprintf(fid, 'AICc ');
for i = 1 : M
  if(isnan(AICtable(i,1))) % A NaN value
     fprintf(fid, ' & \\multicolumn{2}{c|}{--}');
  else
     if(i == winner || i == dwinner)
        switch(i == winner)
          case 0, 
              if(badLoglike(i))
                   fprintf(fid,' & \\multicolumn{2}{c|}{--}');                  
              else
                   fprintf(fid,' & \\multicolumn{2}{c|}{\\dwin{%4.3g}}',...
                         AICtable(i,1));
              end

          case 1, 
              if(badLoglike(i))
                  fprintf(fid, ' & \\multicolumn{2}{c|}{--}');                  
              else
                  fprintf(fid, ' & \\multicolumn{2}{c|}{\\win{%4.3g}}',...
                          AICtable(i,1));
              end
        end 
     else
        if(badLoglike(i))
            fprintf(fid, ' & \\multicolumn{2}{c|}{--}'); 
        else
            fprintf(fid, ' & \\multicolumn{2}{c|}{%4.3g}', AICtable(i,1)); 
        end
     end
 end
end
fprintf(fid,'\\\\\\hline\n');
fprintf(fid,'\\end{tabular}\n');
if(I == DI)
fprintf(fid,['\\caption{',caption,bestOverallFitDist,...
            ' model with MLE parameters: ', parmString,'. This',...
            ' is also the most probable discrete distribution.}\n']);
else
fprintf(fid,['\\caption{',caption,bestOverallFitDist,...
      ' model with MLE parameters: ', parmString,'. The best-fitting',...
      ' discrete model (light grey) is',...
      ' the ',bestDiscreteFitDist,' distribution with MLE parameters: ',...
       dparmString,'.}\n']);    
end

fprintf(fid,['\\label{',label,'}\n']);
fprintf(fid,'\\end{table}\n');
fclose(fid);
end

function r = cString(type, LRtabVal, PtabVal, wasEdited, isBadRows, isBadCols)
% Determine what string to write.
sfm = 'f';
if(wasEdited)
   sfm = 'g';
end

% if(isBadRows || isBadCols)
%    r = sprintf('& -- & --');
%    return
% end

switch(type)
  case 0, if(isBadRows || isBadCols)
             r = sprintf('& \\win{--} & \\win{--}');
          else
             r = sprintf(['& \\win{\\textbf{%1.2f}} & ',...
                       '\\win{\\textbf{%1.1',sfm,'}} '],...
                       PtabVal, LRtabVal);
          end
  case 1, if(isBadRows || isBadCols)
             r = sprintf('& \\dwin{\\textbf{--}} & \\dwin{\\textbf{--}}');
          else
            r = sprintf(['& \\dwin{\\textbf{%1.2f}} & ',...
                       '\\dwin{\\textbf{%1.1',sfm,'}} '],...
                       PtabVal, LRtabVal);
          end
  case 2, if(isBadRows || isBadCols)
             r = sprintf('& -- & --');
          else
             r = sprintf(['& \\nested{\\textbf{%1.2f}} & ',...
                       '\\nested{\\textbf{%1.1',sfm,'}} '],...
                       PtabVal, LRtabVal);
          end
  case 3, if(isBadRows || isBadCols)
             r = sprintf('& -- & --');
          else
             r = sprintf(['& \\textbf{%1.2f} & ',...
                       '\\textbf{%1.1',sfm,'} '],...
                       PtabVal, LRtabVal);
      end
  case 4, if(isBadRows || isBadCols)
             r = sprintf('& \\win{--} & \\win{--}');
          else
             r = sprintf(['& \\win{%1.2f} & ',...
                       '\\win{%1.1',sfm,'} '],...
                       PtabVal, LRtabVal);
          end
  case 5, if(isBadRows || isBadCols)
             r = sprintf('& \\dwin{--} & \\dwin{--}');
          else
             r = sprintf(['& \\dwin{%1.2f} & ',...
                       '\\dwin{%1.1',sfm,'} '],...
                       PtabVal, LRtabVal);
          end
  case 6, if(isBadRows || isBadCols)
             r = sprintf('& -- & --');
          else
             r = sprintf(['& \\nested{%1.2f} & ',...
                       '\\nested{%1.1',sfm,'} '],...
                       PtabVal, LRtabVal);
          end
  case 7, if(isBadRows || isBadCols)
             r = sprintf('& -- & --');
          else
             r = sprintf(['& %1.2f & %1.1',sfm,' '],PtabVal, LRtabVal);
          end
end
end

function [I,DI] = findWinningDist(LR,P,Ddidx)
% Find the winning distribution.
[M1,N1] = size(LR);
[M2,N2] = size(P);
assert(M1 == M2, 'Dimension mismatch in ''findWinningDist''');
assert(N1 == N2, 'Dimension mismatch in ''findWinningDist''');
critVal = 0.05;
rowsWon = zeros(M1, 1);
% Do rows
for i = 1 : M1-1
    pvals  = P(i,i+1:M1);
    lrvals = LR(i,i+1:M1); 
    idx    = find(pvals <= critVal);
    if(isempty(idx))
       % No pvals were significant
       continue; 
    end
    rowsWon(i) = sum(lrvals(idx) >= 0);
end

colsWon = zeros(M1,1);
for i = 2 : M1
   pvals  = P(1:(i-1),i); 
   lrvals = LR(1:(i-1),i);
   idx    = find(pvals <= critVal);
   if(isempty(idx))
      % No pvals were significant
      continue;
   end
   colsWon(i) = sum(lrvals(idx) < 0);
end
results = sum([rowsWon, colsWon],2);

% The overall winner
[~,I]   = max(results);

% The discrete only winner
[~,DI] = max(results(Ddidx));
DI     = Ddidx(DI);
end

function r = constructIsNested(nestlist)
% Construct a binary matrix used to determine what distributions are
% nested.
N = size(nestlist,1);
r = zeros(N,N);

for i = 1 : N
idx = find(ismember(nestlist(:,1), nestlist(i,2:end)));
    if(~isempty(idx))
       r(i, idx) = 1; 
    end
end
end

function parmString = getStringRep(distlist, I, bestFitParmsVals)
% Construct the string of distribution parameter names and values.
% There is an ambiguity in that fitdatatodist.m actually returns xmin
% as the second power law parameter, but getDistMapping lists it as C
% for easier lookup when plotting and saving the distributions. Hence
% we make a 'special' case here.
    if(strcmpi(distlist{I,2}, 'powerlaw'))
        bestFitParmsString = {'$\\alpha$', '$x_{\\min}$'};
    else
        bestFitParmsString = distlist(I,5:(5+distlist{I,10}-1));
    end
    parmString       = cellfun(@(x,y) sprintf('%s = %1.4g, ',x,y),...
                               bestFitParmsString, bestFitParmsVals,...
                               'UniformOutput', false);
    parmString       = [parmString{:}];
    parmString       = parmString(1:end-2);  
end