function createMainPlotTexFile(path, includefile)
% Writes a compile-ready tex file for plot visualization.
%
%   CREATEMAINPLOTTEXFILE writes the tex file required to compile the tex
%   file produced by 'writePlotsToTexFile.m'.
%
%   Input: 
%   PATH - Location of where the produced tex file should be located.
%   INCLUDEFILE - A M x 2 cell array of locations for the tex files
%                 containing the subplots of a data set with and without 
%                 cutoff. These locations must be relative to the location
%                 of file produced by this function.
%
%   Output:
%   A tex file ready to compile with PDFlatex
%
%   Example (> indicate the MatLab terminal):
%   > addpath('misc','lib','write','clauset');
%   > createMainPlotTexFile('output/Data1/',{'fig1/p1.tex','fig2/p2.tex'};
%
%   will create a tex file named 'plot_main' (default) in output/Data1/
%   where the locations of the included tex files can be found in
%   'output/Data1/figs1/p1.tex' and 'output/Data1/figs2/p2.tex'
%   respectively.
%
%   Remarks:
%
%   Casper Petersen and Jakob Grue Simonsen, 2012
%   Department of Computer Science
%   University of Copenhagen
%
fid      = fopen([path,'plot_main.tex'], 'w');
fprintf(fid,'\\documentclass[11pt,a4paper]{article}\n'); 
fprintf(fid,'\\usepackage[latin1]{inputenc}\n');
fprintf(fid,'\\usepackage[OT1]{fontenc}\n');
fprintf(fid,'\\usepackage[english]{babel}\n');
fprintf(fid,'\\usepackage{charter}\n');
fprintf(fid,'\\usepackage{lscape}\n');
fprintf(fid,'\\usepackage[pdftex]{hyperref}\n');
fprintf(fid,'\\usepackage[small,bf]{caption}\n');
fprintf(fid,'\\usepackage{graphicx}\n');
fprintf(fid,'\\usepackage{subfig}\n');
fprintf(fid,'\\usepackage{a4wide}\n');
fprintf(fid,'\\usepackage[top=1cm, bottom=2.5cm, left=1cm, right=1cm]{geometry}\n');
fprintf(fid,'\\normalfont\n');
fprintf(fid,'\\begin{document}\n');
fprintf(fid,'\\pagestyle{empty}\n');
fprintf(fid,'\\input{%s}\n', includefile{1});
%fprintf(fid,'\\newpage\n');
%fprintf(fid,'\\input{%s}\n', includefile{2});
fprintf(fid,'\\clearpage\n');
fprintf(fid,'\\end{document}\n');
fclose(fid);
end