function header = createTable(dlist,wasFixed,badloglike)
%Writes header for Vuong table
%   HEADER = CREATETABLE(DLIST,WASFIXED) is an auxillary function that 
%   construct the header for the Vuong table, and is not intended to be
%   called directly.
%
%   Input:
%   DLISt - A M x 1 cell array of distributions names. These are the tenth
%           column of the cell array returned by getDistMapping.m.
%   wasFixed - A binary vector indicating which distributions had fixes
%   applied to them (see fitdatatodist.m)
%
%   Output:
%   RET - A tex string constituting the header of the Vuong table.
%
%   Example (> indicate the MatLab terminal):
%   > addpath('misc','lib','write','clauset');
%   > header = createTable(distlist(:,10), compres{3});
%
%   where distlist is the output from getDistMapping.m and compres is the
%   output from distPDFcomp.m
%
%   Casper Petersen and Jakob Grue Simonsen, 2012
%   Department of Computer Science
%   University of Copenhagen
%
N    = numel(dlist);
str  = ['\\begin{tabular}{l',repmat('|cc',1,numel(dlist)),'|}\n'];
str2 = '& ';
for i = 1 : N-1
    str2 = [str2,'\\multicolumn{2}{c}{',dlist{i}]; 
    if(wasFixed(i))
        str2 = [str2, '*'];
    end
    if(badloglike(i))
        str2 = [str2, '$^{\\dagger}$'];
    end
    str2 = [str2,'} & '];
end

str2 = [str2, '\\multicolumn{2}{c}{',dlist{N}];
if(wasFixed(N))
   str2 = [str2, '*'];
end
if(badloglike(i))
   str2 = [str2, '$^{\\dagger}$'];
end
str2 = [str2,'}\\\\\n'];

str3 = ' & ';
strK = repmat('\\emph{p} & LR & ', 1, N);
strK = strK(1:end-2);
str3 = [str3,strK,'\\\\\\hline\n']; 
header  = {str, str2, str3};
end