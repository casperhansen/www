function createMainTableTexFile(path, includefiles)
% Writes a compile-ready tex file for Vuong tables.
%
%   CREATEMAINTABLETEXFILE writes the tex file required to compile the tex
%   file produced by 'writeVuongFileToTexFile.m'.
%
%   Input: 
%   PATH - Location of where the produced tex file should be located.
%   INCLUDEFILE - A M x 2 cell array of locations for the tex files
%                 containing the Vuong tables of a data set with and 
%                 without cutoff. These locations must be relative to the 
%                 location of file produced by this function.
%
%   Output:
%   A tex file ready to compile with PDFlatex
%
%   Example (> indicate the MatLab terminal):
%   > addpath('misc','lib','write','clauset');
%   > createMainTableTexFile('output/Data1/',{'vtbl/v1.tex','vtbl/v2.tex'};
%
%   will create a tex file named 'table_main' (default) in output/Data1/
%   where the locations of the included tex files can be found in
%   'output/Data1/vtbl/v1.tex' and 'output/Data1/vtbl/v2.tex'
%   respectively.
%
%   Remarks:
%
%   Casper Petersen and Jakob Grue Simonsen, 2012
%   Department of Computer Science
%   University of Copenhagen
%
fid      = fopen([path,'table_main.tex'], 'w');
fprintf(fid,'\\documentclass[11pt,a4paper]{article}\n');
fprintf(fid,'\\usepackage[latin1]{inputenc}\n');
fprintf(fid,'\\usepackage[OT1]{fontenc}\n');
fprintf(fid,'\\usepackage[english]{babel}\n');
fprintf(fid,'\\usepackage{tabularx}\n');
fprintf(fid,'\\usepackage{charter}\n');
fprintf(fid,'\\usepackage{booktabs}\n');
fprintf(fid,'\\usepackage{lscape}\n');
fprintf(fid,'\\usepackage{color}\n');
fprintf(fid,'\\usepackage{colortbl}\n');
fprintf(fid,'\\usepackage[pdftex]{hyperref}\n');
fprintf(fid,'\\usepackage[table]{xcolor}\n');
fprintf(fid,'\\usepackage[small,bf]{caption}\n');
fprintf(fid,'\\usepackage{graphicx}\n');
fprintf(fid,'\\usepackage{a4wide}\n');
fprintf(fid,'\\usepackage[top=1cm, bottom=2.5cm, left=1cm, right=1cm]{geometry}\n');
fprintf(fid,'\\normalfont\n');
fprintf(fid,'\\newcommand{\\cb}{\\cellcolor{black}}\n');
fprintf(fid,'\\newcommand{\\nested}[1]{\\cellcolor[gray]{0.455}\\textcolor{white}{#1}}\n');
fprintf(fid,'\\newcommand{\\win}[1]{\\cellcolor{blue!25}\\textcolor{black}{#1}}\n');
fprintf(fid,'\\newcommand{\\dwin}[1]{\\cellcolor{green!25}\\textcolor{black}{#1}}\n');
fprintf(fid,'\\begin{document}\n');
fprintf(fid,'\\pagestyle{empty}\n');
fprintf(fid,'\\setlength{\\tabcolsep}{1pt}\n');
fprintf(fid,'\\input{%s}\n', ['vtbl/',includefiles{1}]);
%fprintf(fid,'\\input{%s}\n', ['vtbl/',includefiles{2}]);
fprintf(fid,'\\end{document}\n');
fclose(fid);
end