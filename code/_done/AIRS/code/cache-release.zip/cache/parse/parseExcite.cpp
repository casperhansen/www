/*
 * parseExcite.cpp
 *
 *  Created on: Nov 13, 2014
 *      Author: casper
 */
#include <algorithm>
#include <boost/algorithm/string.hpp>
#include <cstring>
#include <cctype>
#include <fstream>
//#include <iostream>
//#include <iterator>
//#include <sstream>
//#include <stdio.h>
//#include <stdlib.h>
//#include <string>
#include <vector>
#include "FileUtils.hpp"
#include "FileUtils.cpp"

using namespace std;

std::string cleanString(string arg){
	// Remove all bad characters
	boost::replace_all(arg, "+","");
	boost::replace_all(arg, "\"","");
	boost::replace_all(arg, ".","");
	boost::replace_all(arg, "?","");
	boost::replace_all(arg, ",","");
	boost::replace_all(arg, "/","");
	boost::replace_all(arg, "\\","");
	boost::replace_all(arg, "-","");
	boost::replace_all(arg, "&","");
	boost::replace_all(arg, "\'","");
	boost::algorithm::trim(arg);
	return arg;
}

void writeQueries(std::vector<string> queries, std::string writeFile){
	//<DOC> <DOCNO>1</DOCNO> <TEXT> document content </TEXT> </DOC>
	int qcounter = 1;
	std::string fpath = cache::fileutils::getFilePath(writeFile);
	std::string fname = cache::fileutils::getFileName(writeFile, false);
	const char * wtxtfile = (fpath+fname+"_trec").c_str();
	ofstream wfile;
	wfile.open(wtxtfile);
	for(std::vector<string>::iterator it = queries.begin(); it != queries.end(); ++it) {
		string str(*it);
		wfile << "<DOC>\n";
		wfile << "<DOCNO>" << qcounter << "</DOCNO>\n";
		wfile << "<TEXT>" << str << "</TEXT>\n";
		wfile << "</DOC>\n";
		qcounter++;
	}
	wfile.close();
}

void parseLog(const char * readfrom){
	std::string STRING;
	std::ifstream infile;
	std::vector<string> queries;
	infile.open(readfrom);
	int qcounter = 0;
    while(getline (infile,STRING)) {
           // Format is: UID\tSESSIONID\tNUMBER\tQUERY
           std::vector<std::string> strs;
           std::string query = boost::split(strs, STRING, boost::is_any_of("\t"))[3];
           //cout << cleanString(query) << endl;
           queries.push_back(cleanString(query));
           qcounter++;
    }
	infile.close();
	cout << "Parsed " << qcounter << " queries" << endl;
	std::string writeFile(readfrom);
	writeQueries(queries, writeFile);
	// Remove multiple spaces
}



int main( int argc, char** argv ) {
	// Compile from command line with:
	// g++ parseExcite.cpp -o parseExcite -lboost_system -lboost_filesystem -I /home/casper/Coding/Workspace/cache/lib/

	/**
	 * We assume only a single input - The query log to parse
	 */
	clock_t tStart = clock();
	parseLog(argv[1]);
	printf("Time taken: %.2fs\n", (double)(clock() - tStart)/CLOCKS_PER_SEC);
	return 0;
}

