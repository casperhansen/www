#include "aux.hpp"
using namespace std;

bool cache::aux::invalidChar (char c){
    return !(c >= 0 && c < 128);
}

double cache::aux::fRand(double fMin, double fMax) {
    double f = (double)rand() / (RAND_MAX + 1.0);
    return fMin + f * (fMax - fMin);
}

std::string cache::aux::doubletostr(double d){
	std::ostringstream strs;
	strs << std::fixed << std::setprecision(4) << d;
	return strs.str();
}

std::vector<std::string> cache::aux::split(const std::string &s, char delim, std::vector<std::string> &elems) {
    std::stringstream ss(s);
    std::string item;
    while (std::getline(ss, item, delim)) {
        elems.push_back(item);
    }
    return elems;
}

void cache::aux::printhelp(){
	cout << "Help:" << endl;
	cout << "---------------------------" << endl;
	cout << "This program outputs a file file containing terms to be loaded into a cache and experimented with." << endl;
	cout << "This program was developed to test if linear integer programming could improve over the ad-hoc selection methods of Ricardo et al (see Design Trade-off for Large-scale Search Engines)" << endl;
	cout << "Usage:" << endl;
	cout << "./FQFDT <parm>" << endl;
	cout << "Input:" << endl;
	cout << "<parm> - a parameter file in a 'key = value' format" << endl;
	cout << "Valid keys are: " << endl;
	cout << "queryindex      - Full path to the index where the queries are located" << endl;
    cout << "collectionindex - Full path to the collectionindex" << endl;
    cout << "lpfilename      - Name of the lp file to be written to disk" << endl;
    cout << "format          - File format. Default is LP." << endl;
    cout << "cachesize       - The size of the cache in KB" << endl;
    cout << "cutoff          - Positive number of variables to include in the LIP" << endl;
    cout << "useQTFDF        - Use Ricardo's approach" << endl;
    cout << "cachefile       - Full path of the outputfile" << endl;
	cout << "" << endl;
}

/*
 * AS OF 01-12-2014 writeLPSOLVE is not used!
 */
void writeLPSOLVE(std::vector<cache::aux::QTFDFOBJ *> vals, int cutoff, std::string filename, int CACHE_SIZE_IN_BYTES, bool usealt){
	/* Initialize objective function string*/
	std::string objfunc = "max: ";
	/* Initialize constraints string */
	std::string cons = "";
	/* Initialize variable bounds string */
	std::string varbounds = "";
	/* Initialize integer definitions */
	std::string intdefs = "int ";

	std::string index;
	std::string qval;
	std::string cval;
	ofstream myfile;
	myfile.open(filename.c_str());
	int i;
	for(i=0; i<cutoff-1;i++){
		cache::aux::QTFDFOBJ * ob = vals.at(i);
		index = SSTR(i);
		if(!usealt){
			qval  = SSTR(ob->queryval);
		}else{
			qval  = cache::aux::doubletostr(ob->score);
		}
		cval      = SSTR(ob->colval);
		objfunc   = objfunc.append("+").append(qval).append(" x").append(index).append(" ");
		cons      = cons.append("+").append(cval).append(" x").append(index).append(" ");
		varbounds = varbounds.append("x").append(index).append(" <= 1;\n");
		intdefs   = intdefs.append("x").append(index).append(",");
	}
	cache::aux::QTFDFOBJ * ob = vals.at(cutoff-1);
	if(!usealt){
		objfunc   = objfunc+"+"+SSTR(ob->queryval)+" x"+SSTR(cutoff-1)+";\n";
	}else{
		objfunc   = objfunc+"+"+cache::aux::doubletostr(ob->score)+" x"+SSTR(cutoff-1)+";\n";
	}
	cons      = cons+"+"+SSTR(ob->colval)+" x"+SSTR(cutoff-1)+" <= "+SSTR(CACHE_SIZE_IN_BYTES)+";\n";
	varbounds = varbounds+"x"+SSTR(cutoff-1)+" <= 1;\n";
	intdefs   = intdefs+"x"+SSTR(cutoff-1)+";\n";

	myfile << "/* Objective function */" << endl;
	myfile << objfunc << endl;

	myfile << "/* Constraints */" << endl;
	myfile << cons << endl;

	myfile << "/* Variable bounds */" << endl;
	myfile << varbounds << endl;

	myfile << "/* Integer definitions */" << endl;
	myfile << intdefs << endl;
	myfile.close();
}

void writeLP(std::vector<cache::aux::QTFDFOBJ *> vals, int cutoff, std::string filename, int CACHE_SIZE_IN_BYTES, bool usealt){
	/* Initialize objective function string*/
	std::string objfuncheader = "Maximize";
	std::string objfunc       = "obj: ";
	/* Initialize constraints string */
	std::string consheader = "Subject To";
	std::string cons = "c1: ";
	/* Initialize variable bounds string */
	std::string boundsheader = "Bounds";
	std::string varbounds = "";
	/* Initialize general integer definitions */
	std::string genheader = "Binary";
	std::string general = "";
	std::string endfile = "End";

	std::string index;
	std::string qval;
	std::string cval;

	ofstream myfile;
	myfile.open(filename.c_str());
	int i;
	for(i=0; i<cutoff-1;i++){
		cache::aux::QTFDFOBJ * ob = vals.at(i);
		index     = SSTR(i);
		if(!usealt){
			qval  = SSTR(ob->queryval);					// F_q(t)
		}else{
			qval  = cache::aux::doubletostr(ob->score);  // F_d(t)
		}
		cval      = SSTR(ob->colval);
		objfunc   = objfunc.append("+ ").append(qval).append(" x").append(index+" ");
		cons      = cons.append("+").append(cval).append(" x").append(index+" ");
		varbounds = varbounds.append("x").append(index).append(" <= 1\n");
		general   = general.append("x").append(index+" ");
	}
	cache::aux::QTFDFOBJ * ob = vals.at(cutoff-1);
	if(!usealt){
		objfunc   = objfunc+"+ "+SSTR(ob->queryval)+" x"+SSTR(cutoff-1)+"\n";
	}else{
		objfunc   = objfunc+"+ "+cache::aux::doubletostr(ob->score)+" x"+SSTR(cutoff-1)+"\n";
	}
	cons      = cons+"+"+SSTR(ob->colval)+" x"+SSTR(cutoff-1)+" <= "+SSTR(CACHE_SIZE_IN_BYTES)+"\n";
	varbounds = varbounds+"x"+SSTR(cutoff-1)+" <= 1\n";
	general   = general+"x"+SSTR(cutoff-1)+"\n";

	myfile << objfuncheader << endl;
	myfile << objfunc << endl;

	myfile << consheader << endl;
	myfile << cons << endl;

	myfile << boundsheader << endl;
	myfile << varbounds << endl;

	myfile << genheader << endl;
	myfile << general << endl;
	myfile << endfile << endl;
	myfile << flush;
	myfile.close();
}

void cache::aux::writefile(std::string format, const std::vector<cache::aux::QTFDFOBJ *>& vals, int cutoff, std::string filename, int cachesize, bool usealt){
	if(format.compare("lp_solve") == 0){
		writeLPSOLVE(vals, cutoff, filename, cachesize, usealt);
	}else if(format.compare("LP") == 0){
		writeLP(vals, cutoff, filename, cachesize, usealt);
	}else{
		exit(-1);
	}
}

void cache::aux::writecacheterms(const std::set<std::string>& terms, std::string& filename) {
	ofstream outfile;
	outfile.open(filename.c_str());
	set<std::string>::iterator it;
	for (it = terms.begin(); it != terms.end(); it++) {
	     outfile << ""+*it << endl;
	}
	outfile.close();
}

void cache::aux::writeQTFDFterms(std::set<cache::aux::QTFDFOBJ*>& v, std::string& filename){
	ofstream myfile;
	myfile.open(filename.c_str());
	std::set<cache::aux::QTFDFOBJ*>::iterator it;
	for(it = v.begin(); it != v.end(); ++it){
		cache::aux::QTFDFOBJ* obj = *it;
		myfile << obj->stringValue << "," << obj->score << "," << obj->queryval << "," << obj->colval << endl;
	}
	myfile.flush();
	myfile.close();
}

void cache::aux::writeCacheParameterFile(std::string CACHE_PARM_FILE, std::string collectionName, std::string CACHE_TERMS_FILE, std::string R_CACHE_TERMS_FILE, bool usealt, int countQuery, int countTotalQueryHits, int NUM_TERMS_IN_HIT, int TOTAL_QUERIES){
	ofstream myfile;
	myfile.open(CACHE_PARM_FILE.c_str());
	myfile << "# input file for cache/cache.cpp" << endl;
	myfile << "index = \"" << collectionName << "\";"<< endl;
	myfile << "queries = \"" << SSTR(countQuery) << "\";" << endl;
	myfile << "totalhits = \"" << SSTR(countTotalQueryHits) << "\";"<< endl;
	myfile << "noftermsprhit = \"" << SSTR(NUM_TERMS_IN_HIT) << "\";" << endl;
	myfile << "queriestotal = \"" << SSTR(TOTAL_QUERIES) << "\";" << endl;
	if(!usealt){
		myfile << "useAlt = \"false\";" << endl;
		myfile << "ourMethod = \"" << CACHE_TERMS_FILE << "\";" << endl;
		myfile << "ricardoMethod = \""<< R_CACHE_TERMS_FILE << "\";" <<endl;
	}else{
		myfile << "useAlt = \"true\";" << endl;
		myfile << "ourMethod = \"" << CACHE_TERMS_FILE << "\";" << endl;
		myfile << "ricardoMethod = \"" << R_CACHE_TERMS_FILE << "\";"<< endl;
	}
	myfile << flush;
	myfile.close();
}


std::string cache::aux::trim(const std::string& str,
                 const std::string& whitespace = " \t"){
    const unsigned long int strBegin = str.find_first_not_of(whitespace);
    if (strBegin == std::string::npos)
        return ""; // no content

    const unsigned long int strEnd = str.find_last_not_of(whitespace);
    const unsigned long int strRange = strEnd - strBegin + 1;

    return str.substr(strBegin, strRange);
}

std::string cache::aux::reduce(const std::string& str){
	const std::string& fill = " ";
	const std::string& whitespace = " \t";
    // trim first
    std::string result = trim(str, whitespace);

    // replace sub ranges
    unsigned long int beginSpace = result.find_first_of(whitespace);
    while (beginSpace != std::string::npos)
    {
    	const unsigned long int endSpace = result.find_first_not_of(whitespace, beginSpace);
    	const unsigned long int range = endSpace - beginSpace;

        result.replace(beginSpace, range, fill);

        const unsigned long int newStart = beginSpace + fill.length();
        beginSpace = result.find_first_of(whitespace, newStart);
    }
    return result;
}

std::string cache::aux::fixString(std::string& str){
	str.erase(std::remove(str.begin(), str.end(), '\n'), str.end());
	std::transform(str.begin(), str.end(), str.begin(), ::tolower);
	str.erase(std::remove_if(str.begin(),str.end(), invalidChar), str.end());
	str = reduce(str);
	return str;
}

std::string cache::aux::toTrecFormat(std::string& query, int docnr){
	std::string str;
	str = str.append("<DOC>\n");
	str = str.append("<DOCNO>").append(SSTR(docnr)).append("</DOCNO>\n");
	str = str.append("<TEXT>\n");
	str = str.append(query).append("\n");
	str = str.append("</TEXT>\n");
	str = str.append("</DOC>");
	return str;
}

void cache::aux::printQueries(std::vector< std::vector<std::string> >& queries, const char * filename, int id, bool trecTextFormat){
	ofstream myfile;
	myfile.open(filename);
	std::vector< std::vector< std::string > >::iterator it;
	for(it = queries.begin(); it != queries.end(); ++it){
		std::string query = "";
		std::vector< std::string >::iterator q;
		for(q = (*it).begin(); q != (*it).end(); ++q){
			query = query.append(*q).append(" ");
		}
		query = reduce(query);
		if(query.compare("") != 0){
			if(trecTextFormat){
				query = toTrecFormat(query, id);
			}
			myfile << query << endl;
			id++;
		}
	}
	myfile << flush;
	myfile.close();
	std::cout << "Next query nr: " << id << std::endl;
}


std::string cache::aux::getTime(){
	time_t rawtime;
	struct tm * timeinfo;
	char buffer[80];

	time (&rawtime);
	timeinfo = localtime(&rawtime);

	strftime(buffer,80,"%d-%m-%Y %I:%M:%S",timeinfo);
	std::string str(buffer);

	return str;
}
