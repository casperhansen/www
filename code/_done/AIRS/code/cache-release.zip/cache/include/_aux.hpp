/*
 * aux.hpp
 *
 *  Created on: Nov 18, 2014
 *      Author: casper
 */

#include <iostream>
#include <fstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <set>
#include <stdlib.h>
#include <sstream>
#include <iomanip>      // std::setprecision
#include <algorithm>
#include <utility>
#include <sstream>
#include <map>
#include <time.h>
#include <cmath>
#include <limits>
#include <iterator>
#include <random>
#include <ctime>
#include <cctype>


#ifndef AUX_HPP_
#define AUX_HPP_

#define SSTR( x ) dynamic_cast< std::ostringstream & >( \
        ( std::ostringstream() << std::dec << x ) ).str()

namespace cache{
	namespace aux{

		class QTFDFOBJ {
		private:
		public:
			double score;
			std::string stringValue;
			int queryval;
			int colval;
			QTFDFOBJ();
			QTFDFOBJ(const std::string& s, float k, unsigned int qval, unsigned int collectionval){
				 score       = k;
				 stringValue = s;
				 queryval    = qval;
				 colval      = collectionval;
			}
			~QTFDFOBJ(){};
		};

		struct ge_queryfreq
		{
		    inline bool operator() (const QTFDFOBJ * struct1, const QTFDFOBJ * struct2)
		    {
		        return (struct1->queryval > struct2->queryval);
		    }
		};
/*
		inline bool operator<(const QTFDFOBJ * lhs, const QTFDFOBJ * rhs){
		      return (lhs->score < rhs->score);
		}
*/
		struct ge_score
		{
		    inline bool operator() (const QTFDFOBJ * struct1, const QTFDFOBJ * struct2)
		    {
		        return (struct1->score > struct2->score);
		    }
		};

		/*
		 * Structs
		 */
/*
		struct QTFDFOBJ
		{
			double score;
			std::string stringValue;
			int queryval;
			int colval;

			QTFDFOBJ(const std::string& s, double k, int qval, int collectionval) : score(k), stringValue(s), queryval(qval), colval(collectionval) {}
			QTFDFOBJ() : score(), stringValue(), queryval(), colval() {};
		};

		inline bool operator<(const QTFDFOBJ& lhs, const QTFDFOBJ& rhs){
		      return lhs.score < rhs.score;
		}

		// Sort score >=
		struct ge_score
		{
		    inline bool operator() (const QTFDFOBJ& struct1, const QTFDFOBJ& struct2)
		    {
		        return (struct1.score > struct2.score);
		    }
		};

		// Sort queryval >=
		struct ge_queryfreq
		{
		    inline bool operator() (const QTFDFOBJ& struct1, const QTFDFOBJ& struct2)
		    {
		        return (struct1.queryval > struct2.queryval);
		    }
		};
*/
		/* Compare keys in maps */
		struct Pair_First_Equal {
		    template <typename Pair>
		    bool operator() (Pair const &lhs, Pair const &rhs) const {
		        return lhs.first == rhs.first;
		    }
		};

		/* Compare maps size and keys in maps*/
		template <typename Map>
		bool key_compare (Map const &lhs, Map const &rhs) {
		    return lhs.size() == rhs.size()
		        && std::equal(lhs.begin(), lhs.end(),
		                      rhs.begin(),
		                      Pair_First_Equal()); // predicate instance
		}

		/*
		 * The following two template sorts a map by its values in increasing order.
		 * Use a reverse_iterator to iterate over the map in reverse
		 */
		template<typename A, typename B>
		std::pair<B,A> flip_pair(const std::pair<A,B> &p)
		{
		    return std::pair<B,A>(p.second, p.first);
		}

		template<typename A, typename B>
		std::multimap<B,A> flipAndSortmap(const std::map<A,B> &src)
		{
		    std::multimap<B,A> dst;
		    std::transform(src.begin(), src.end(), std::inserter(dst, dst.begin()),
		                   flip_pair<A,B>);
		    return dst;
		}

		struct FQTFDT
		{
			int FQT;
			int FDT;

			FQTFDT(int qval, int collectionval) : FQT(qval), FDT(collectionval) {}
			FQTFDT() : FQT(), FDT() {};
		};


		/*
		 * Functions
		 */
		void printhelp();
		void writefile(std::string, const std::vector<cache::aux::QTFDFOBJ *>& v, int c, std::string f, int ms, bool usealt);
		void writecacheterms(const std::set<std::string>& terms, std::string& filename);
		void writeCacheParameterFile(std::string CACHE_PARM_FILE, std::string collectionName, std::string CACHE_TERMS_FILE, std::string R_CACHE_TERMS_FILE, bool usealt, int cq, int cqsum, int termsprhit, int total_queries);
		void writeQTFDFterms(std::set<cache::aux::QTFDFOBJ*>& v, std::string& filename);
		// Cannot const queries
		void printQueries(std::vector< std::vector<std::string> >& queries, const char * filename, int queryidstart, bool trectextformat);
		double fRand(double xmin, double xmax);

		std::vector<std::string> split(const std::string &s, char delim, std::vector<std::string> &elems);
		std::string doubletostr(double d);
		std::string fixString(std::string& str);
		std::string trim(const std::string& str, const std::string& whitespace);
		std::string reduce(const std::string& str);
		std::string toTrecFormat(std::string& query, int docnr);
		std::string getTime();

		bool invalidChar(char c);
	}
}
#endif /* AUX_HPP_ */
