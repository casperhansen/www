/*
 * FileUtils.hpp
 *
 *  Created on: Nov 14, 2014
 *      Author: casper
 */

#include "boost/filesystem.hpp"
#include <string>
#include <iterator>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <iostream>

#ifndef FILEUTILS_HPP_
#define FILEUTILS_HPP_
namespace cache{
	namespace fileutils{

	   /*
		* Typedefs
		*/

	   /*
		* Functions
		*/
		std::string getFilePath(std::string s);
		std::string getFileName(std::string s, bool ext);

		/*
		 * Comparison operators
		 */
	};
};
#endif /* FILEUTILS_HPP_ */
