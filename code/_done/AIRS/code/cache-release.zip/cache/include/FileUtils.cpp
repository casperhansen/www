#include "FileUtils.hpp"

using namespace boost::filesystem;

std::string cache::fileutils::getFilePath(std::string s){
	boost::filesystem::path data_dir = s;
	const path absolute_path = absolute(data_dir) ;
	std::string fpath(absolute_path.parent_path().c_str());
	return fpath+"/";
}

std::string cache::fileutils::getFileName(std::string s, bool ext){
	boost::filesystem::path data_dir = s;
	const path absolute_path = absolute(data_dir) ;
	if(ext){
		// Remove extension
		std::string str(absolute_path.stem().c_str());
		return str;
	}
    std::string str(absolute_path.filename().c_str());
	return str;
}

/*


int main( int argc, char** argv ){
	// Compile with: g++ FileUtils.cpp -o FileUtils -lboost_system -lboost_filesystem -I /home/casper/Coding/Workspace/cache/lib/
	std::cout << cache::fileutils::getFilePath(argv[1]) << std::endl;
	std::cout << cache::fileutils::getFileName(argv[1],true) << std::endl;
	return 1;
}
*/
