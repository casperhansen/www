#include <iostream>
#include <fstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include "../include/aux.hpp"

void printhelp(){
	std::cout << "********************************************************************************************************" << std::endl;
	std::cout << "* Must specify the following three arguments in order:                                                 *" << std::endl;
	std::cout << "* 1 - The number of queries to output.                                                                 *" << std::endl;
	std::cout << "* 2 - The input file containing the queries. This file contains one query per line in raw text format. *" << std::endl;
	std::cout << "* 3 - The output file holding the queries in TRECTEXT format.                                          *" << std::endl;
	std::cout << "********************************************************************************************************" << std::endl;
}

int main(int argc, char ** argv){
	  if(argc != 4){
		  printhelp();
		  exit(EXIT_FAILURE);
	  }
	  std::cout << "Started............: " << cache::aux::getTime() << std::endl;
	  std::cout << "Number of queries..: " << argv[1]               << std::endl;
	  std::cout << "Reading from.......: " << argv[2]               << std::endl;
	  std::cout << "Writing to.........: " << argv[3]               << std::endl;
	  std::string line;
	  int nof_queries = atoi(argv[1]);

	  //Set up percent
	  int fpercent     = 5*((int)ceil(nof_queries/100));
	  int fpcounter    = 0;
	  std::ifstream  infile (argv[2]);
	  std::ofstream outfile (argv[3]);


	  if (infile.is_open()){
		  int docid = 1;
		  while (getline (infile,line)) {
			  line = cache::aux::fixString(line);
			  outfile << cache::aux::toTrecFormat(line, docid) << std::endl;
			  docid++;
			  if((docid % fpercent) == 0){
				  fpcounter += 5;
				  std::cout << "Completed " << fpcounter <<"%" << std::endl;
			  }
			  if(docid > nof_queries) break;
		  }
		  infile.close();
		  outfile.close();
	  }else{
		  std::cerr << "Could not open file " << argv[1] << std::endl;
		  exit(EXIT_FAILURE);
	  }
	  std::cout << "Finished............: " << cache::aux::getTime() << std::endl;
}
