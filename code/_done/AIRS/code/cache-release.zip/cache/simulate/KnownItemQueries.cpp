/*
 * KnownItemQueries.cpp
 */
#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include <config4cpp/Configuration.h>
#include <boost/random/linear_congruential.hpp>      /* PRNGs                   Boost  */
#include <boost/random/uniform_int.hpp>              /* PRNGs                   Boost  */
#include <boost/random/uniform_real.hpp>             /* PRNGs                   Boost  */
#include <boost/random/variate_generator.hpp>        /* PRNGs                   Boost  */
#include <boost/filesystem.hpp>
#include "../include/aux.hpp"

typedef std::map<std::string, double> ProbMap;

struct TermProperty {
  std::string stem;
  bool is_badterm;
  bool is_stopword;
  bool is_empty;
};

// The queries generated
std::vector< std::vector<std::string> > queries;

//The noise in the user's querying model
float LAMBDA;
float ONE_MINUS_LAMBDA;

/* The Threshold above which we duplicate queries to skip generating a gazillion queries*/
float THRESHOLD = 0.0;

/* Should queries be written in trectext format?*/
bool TRECTEXT;

// Index name
std::string COLLECTION,OUTPUT_FILE,METHOD,STOPWORDLIST;
int SWITCHPARM, QUERY_LENGTH, VLEVEL,NEXT_QUERYID;
int NOF_DOCS = 0;
int NOF_QUERIES_PR_DOC = 0;

// Integer to string
#define SSTR( x ) dynamic_cast< std::ostringstream & >( \
        ( std::ostringstream() << std::dec << x ) ).str()

#define BOOL_STR(b) ((b)?"true":"false")

// Sets
std::set<std::string> STOP_WORDS;

// Namespaces
using namespace config4cpp;

TermProperty checkTerm(std::string stem){
	TermProperty tp;
	std::string str  = cache::aux::fixString(stem);
	bool is_badterm  = (stem.compare("[oov]") == 0) || (stem.compare("[OOV]") == 0);
	bool is_stopword = STOP_WORDS.find(stem) != STOP_WORDS.end();
	bool is_empty    = str.compare("") == 0;
	tp.stem          = str;
	tp.is_badterm    = is_badterm;
	tp.is_stopword   = is_stopword;
	tp.is_empty      = is_empty;
	return tp;
}

/*
 * Input is:
 * document: The document language model p(t_i | d_k)
 * background: The background language model (MLE estimates of each term in d_k) i.e. p(t_i)
 *
 */
void selectQueries(ProbMap& document, ProbMap& background){
	  /* Assert that (a) the size of the maps are the same and (b) they contain the same keys */
	  bool equalMaps = cache::aux::key_compare(document,background);
	  if(!equalMaps){
		  std::cerr << "Maps provided to selectQueries differ in size or keys" << std::endl;
		  std::cout << "document.size(): " << document.size() << ", background.size(): " << background.size() << endl;
/*
		  ProbMap::iterator docitr;
		  std::cout << "Document" << endl;
		  for(docitr = document.begin(); docitr != document.end(); ++docitr){
			  std::cout << docitr->first << endl;
		  }

		  ProbMap::iterator backitr;
		  for(backitr = background.begin(); backitr != background.end(); ++docitr){
			  std::cout << backitr->first << endl;
		  }
*/
		  exit(EXIT_FAILURE);
	  }

	  /*
	   * The linear combination of the user querying model and background model means we cannot
	   * be sure that the probability (when compared to to the uniform distributed random number)
	   * will always exceed that number. Hence the second argument (0.2 below) to
	   * > boost::uniform_real<> uniDblUnit(0,0.2);
	   * must, instead of 1, be set to the total sum of the linear combination.
	   */
	  double tsum = 0.0;
	  ProbMap::iterator d_it;
	  for(d_it = document.begin(); d_it != document.end(); ++d_it){
	  	  std::string term      = d_it->first;
	  	  double docProb        = d_it->second;
	  	  double backgroundProb = 0.0;
			  ProbMap::iterator it  = background.find(term);
			  if(it != background.end()){
				  backgroundProb = it->second;
			  }
			  tsum += ((1.0-LAMBDA)*docProb + LAMBDA*backgroundProb);
	  }
      for(int j = 0; j<NOF_QUERIES_PR_DOC;j++){
		  std::vector<string> query;
		  /*
		   * Loop over number of terms we want in the query. We are assuming that we will never have
		   * documents whose length is smaller than QUERY_LENGTH
		   */
		  for(int i=0;i<QUERY_LENGTH;i++){
			  double p = cache::aux::fRand(0.0, tsum);
			  while(p == 0.0){
				p = cache::aux::fRand(0.0, tsum);
			  }
			  double cumulativeProbability = 0.0;
			  //ProbMap::iterator d_it;
			  for(d_it = document.begin(); d_it != document.end(); ++d_it){
				  std::string term      = d_it->first;
				  double docProb        = d_it->second;
				  double backgroundProb = 0.0;
				  /*
				   * The assert in the beginning guards against backgroundProb = 0.0 but the compiler
				   * wants the check.
				   */
				  ProbMap::iterator it  = background.find(term);
				  if(it != background.end()){
					  backgroundProb = it->second;
				  }
				  cumulativeProbability += ((1.0-LAMBDA)*docProb + LAMBDA*backgroundProb);
				  if (p <= cumulativeProbability) { // && d_it->second != 0
					  query.push_back(d_it->first);
					  break;
				  }
			  }

		  }
		  queries.push_back(query);
		  /*
		   * 19-12-2014:
		   * Added this. To avoid having to generate 100M queries to get 56% of the query stream to be duplicates
		   * we add this simple check. We define a threshold (e.g. 0.44) and generate a random number r.
		   * If r > 0.44 then we duplicate the query
		   */
		  double unifrng = (double)rand()/((double)RAND_MAX + 1.);
		  if(unifrng > THRESHOLD) queries.push_back(query);

      }
}

/*
 * p(k) - We assume each document has an equal probability of being selected
 */
int selectDoc(UINT64& docC){
	  /* generate secret number between 1 and # docs */
	  int r = rand() % docC + 1;
	  if(VLEVEL > 1){
		  cout << "*******************************"<< endl;
		  cout << "Selected docNr: " << r << endl;
		  cout << "*******************************"<< endl;
	  }
	  return r;
}

/*
 * 1 - First for-loop iterates over the terms and selects the unique ones.
 * 2 - Second for-loop calculates p(t) [which is val]
 *     It also calculates the sum of inidivdual contributions i.e. the sum in the denominator of Eqn 4.
 */
std::pair< ProbMap, double> documentTermMLE(indri::server::LocalQueryServer& local, indri::api::DocumentVector* docVector){
	std::pair<ProbMap, double > retstr;
	ProbMap termmle;
	std::set<std::string> unique_terms;

	double totaltermCount = (double)local.termCount();
	/* Only interested in the unique terms as otherwise the same term would have several entries in the map */
	for( size_t j=0; j<docVector->positions().size(); j++ ) {
	  int pos         = docVector->positions()[j];
	  TermProperty tp;
	  tp = checkTerm(docVector->stems()[pos]);
	  // If it is not the [oov] term and we dont find the term in the list of stop words, we insert it
	  if(!tp.is_badterm && !tp.is_stopword && !tp.is_empty){
		  //std::cout << "Inserted term: " << tp.stem << ", is_badterm: " << tp.is_badterm << ", is_stopword: " << tp.is_stopword << endl;
		  unique_terms.insert(tp.stem);
	  }
	}
//        std::cout << "Found " << unique_terms.size() << " unique terms" << std::endl;
	std::set<std::string>::iterator it;
	double rsum = 0.0;
	for(it = unique_terms.begin(); it != unique_terms.end(); ++it){
		UINT64 termCount = local.termCount( *it );
		double val       = (double)termCount/totaltermCount; // MLE estimate of p(t_j)
		termmle[*it]     = val;
		/*
		 * b(t_j,d_k) = 1 if t_j occurs in d_k. It does as we loop over them
		 * val        = p(t_j).
		 * ************************
		 * rsum       = \sum_{t_j\in d_k} \frac{b(t_j,d_k}{p(t_j)}
		 * b(t_j,d_k) is 1 for each term as that term is in the document. It is divided by its probability
		 */
		rsum 			+= (1.0/val);
		//std::cout << "term: " << *it << ", termCount: " << termCount << ", val: " << val << ", rsum: " << rsum << endl;
		//cout << "Term: " << *it << ", rsum: " << rsum << ", val: " << val << endl;
	}
	//std::cout << "documentTermMLE: Size of map: " << termmle.size() << endl;
	retstr.first  = termmle;
	retstr.second = rsum;
	return retstr;
}

void discriminativeSelection(indri::server::LocalQueryServer& local, UINT64 docCount){
	 int docNr;
	 int tp   = 10*((int)floor(NOF_DOCS/100));
	 int accC = 10;
	 for(int j=0;j<NOF_DOCS;j++){
	     if(VLEVEL == 1){
		    if((j+1) % tp == 0){
			    std::cout << accC << "%," << std::flush;
				accC += 10;
			}
		}
		docNr = selectDoc(docCount);
		// Setup map
		lemur::api::DOCID_T documentID = docNr;
		std::vector<lemur::api::DOCID_T> documentIDs;
		documentIDs.push_back(documentID);
		UINT64 doclength;
		// Fetch the document
		indri::server::QueryServerVectorsResponse* response = local.documentVectors( documentIDs );
		ProbMap background, TERM_PROP;
		if( response->getResults().size() ) {
			indri::api::DocumentVector* docVector = response->getResults()[0];

			std::pair<ProbMap, double> ret        = documentTermMLE(local, docVector);
			/* The <term,prob> map */
			background			= ret.first;
			/* The sum of each term divided by its probability */
			double sumProbs		= ret.second;
			/*
			 * Calculate p(t_i) -> t_i is in d_k but we calculate the MLE from the background collection
			 */
			double cum = 0.0;
			ProbMap::iterator it;
			for(it = background.begin(); it != background.end(); ++it){
				double nom           = 1.0; // The term
				double denom         = it->second * sumProbs; // The term probability times the sum of term probabilities
				TERM_PROP[it->first] = nom/denom;
				//std::cout << "Stem: " << it->first << ", nom: " << nom << ", it->second: " << it->second << ", sumProbs: " << sumProbs << endl;
			}
//			std::cout << "After background iteration" << std::endl;
		}
	   /*
		* TERM_PROP: Probabilities when sampling from document p(t_i | d_k)
		* background: MLE probabilities of each term p(t_i) - Background probabilities
		* doclength: The number of terms in the document
		*/
		selectQueries(TERM_PROP, background);
		TERM_PROP.clear();
	}
}

/*
 * 07-12-2014 - Works
 * Each term is given a count of 1 (we overwrite indiscriminately)
 * and divided by the document length (total number of terms)
 */
//void randomSelection(indri::collection::Repository& index){
void randomSelection(indri::server::LocalQueryServer&local, UINT64 docCount){
	  int docNr;
	  int tp   = 10*((int)floor(NOF_DOCS/100));
	  int accC = 10;
	  for(int j=0;j<NOF_DOCS;j++){
		  if(VLEVEL == 1){
			  if((j+1) % tp == 0){
				  std::cout << accC << "%," << std::flush;
				  accC += 10;
			  }
		  }
		  std::map<std::string, int> histogram;
		  docNr = selectDoc(docCount);
		  // Setup map
		  lemur::api::DOCID_T documentID = docNr;
		  std::vector<lemur::api::DOCID_T> documentIDs;
		  documentIDs.push_back(documentID);
		  UINT64 doclength;
		  // Fetch the document
		  ProbMap background;
		  indri::server::QueryServerVectorsResponse* response = local.documentVectors( documentIDs );
		  if( response->getResults().size() ) {
			indri::api::DocumentVector* docVector = response->getResults()[0];
			std::pair<ProbMap, double> ret        = documentTermMLE(local, docVector);
			/* Get p(t_i) */
			background = ret.first;
			/* Loop over the content of the document.
			 * Here we calculate p(t_i | d_k)
			 */
			doclength = docVector->positions().size();
			for( size_t j=0; j<docVector->positions().size(); j++ ) {
			  int pos = docVector->positions()[j];
			  TermProperty tp  = checkTerm(docVector->stems()[pos]);
			  if(!tp.is_stopword && !tp.is_badterm && !tp.is_empty){
				  /* Overwrite indiscriminately for all non stopwords*/
				  histogram[tp.stem] = 1;
			  }
			}
		  }
		  ProbMap Pr;
		  map<std::string, int>::iterator it;
		  double total = 0.0;
		  for(it = histogram.begin(); it != histogram.end(); ++it){
			  int val = it->second;
			  double totalval = (double)val/(double)histogram.size();
			  total += totalval;
			  Pr[it->first] = totalval;
		  }
		  if(VLEVEL > 1){
			  std::cout << "randomSelection -- Pr.size(): " << Pr.size() << endl;
		  }
		  selectQueries(Pr, background);
	  }
}

/*
 * 07-12-2014 - Working as intended
 */
void popularSelection(indri::server::LocalQueryServer& local, UINT64 docCount){
	  int docNr;
	  int tp   = 10*((int)floor(NOF_DOCS/100));
	  int accC = 10;
	  for(int j=0;j<NOF_DOCS;j++){
		  if(VLEVEL == 1){
			  if((j+1) % tp == 0){
				  std::cout << accC << "%," << std::flush;
				  accC += 10;
			  }
		  }
		  int empty_counter = 0;
		  std::map<std::string, int> histogram;
		  docNr = selectDoc(docCount);
		  // Setup map
		  lemur::api::DOCID_T documentID = docNr;
		  std::vector<lemur::api::DOCID_T> documentIDs;
		  documentIDs.push_back(documentID);
		  UINT64 doclength;
		  // Fetch the document
		  ProbMap background;
		  indri::server::QueryServerVectorsResponse* response = local.documentVectors( documentIDs );
		  if( response->getResults().size() ) {
			indri::api::DocumentVector* docVector = response->getResults()[0];
			std::pair<ProbMap, double> ret = documentTermMLE(local, docVector);
			background = ret.first;
			/* Loop over the content of the document.
			 * Here we calculate p(t_i | d_k)
			 */
			doclength = docVector->positions().size();
			for( size_t j=0; j<docVector->positions().size(); j++ ) {
			  int pos          = docVector->positions()[j];
			  TermProperty tp  = checkTerm(docVector->stems()[pos]);
			  const bool is_in = histogram.find(tp.stem) != histogram.end();

			  if(!tp.is_stopword && !tp.is_badterm && !tp.is_empty){ // Not a stop word
				  if(is_in){ // Increment or create new
					  histogram[tp.stem]++;
				  }else{
					  histogram[tp.stem] = 1;
				  }
			  }
			  if(tp.stem.compare("") == 0){
				  empty_counter++;
			  }
			}
		  }
		  //std::cout << j << " - For docNr: " << docNr << " there was " << empty_counter << " empty stems" << endl;
		  ProbMap Pr;
		  map<std::string, int>::iterator it;
		  double total = 0.0;
		  /*
		   * Histogram contains the unique terms in the document and their count.
		   * "totalval" is the MLE of the term (see Eqn. 2 in Leif's paper)
		   */
		  for(it = histogram.begin(); it != histogram.end(); ++it){
			  int val = it->second;
			  double totalval = (double)val/(double)doclength;
			  total += totalval;
			  Pr[it->first] = totalval;
		  }
		  // Extract queries
		  selectQueries(Pr, background);
	  }
	  std::cout << "Complete!" <<std::endl;
}

void parse_configuration(const char * configFile){
	Configuration *  _cfg       = Configuration::create();
	const char *     _scope     = "";

    try {
        _cfg->parse(configFile);
        COLLECTION         = _cfg->lookupString( _scope, "collection" );
        OUTPUT_FILE        = _cfg->lookupString( _scope, "output"     );
        SWITCHPARM         = _cfg->lookupInt(    _scope, "method"     );
        QUERY_LENGTH       = _cfg->lookupInt(    _scope, "querylength");
        NOF_QUERIES_PR_DOC = _cfg->lookupInt(    _scope, "nofqueries" );
        NOF_DOCS           = _cfg->lookupInt(    _scope, "nofdocs"    );
        STOPWORDLIST       = _cfg->lookupString( _scope, "stopwords"  );
        VLEVEL             = _cfg->lookupInt(    _scope, "vlevel"     );
        NEXT_QUERYID       = _cfg->lookupInt(    _scope, "nextqid"    );
        LAMBDA             = _cfg->lookupFloat(  _scope, "noiselevel" );
        THRESHOLD          = _cfg->lookupFloat(  _scope, "threshold"  );
        TRECTEXT           = _cfg->lookupBoolean(_scope, "trectext"  );
    } catch(const ConfigurationException & ex) {
        std::cerr << ex.c_str() << std::endl;
        _cfg->destroy();
    }

    /* Set document language probability */
    ONE_MINUS_LAMBDA = 1.0 - LAMBDA;

    switch(SWITCHPARM){
    	case 1: METHOD = "Popular";
    			break;
    	case 2: METHOD = "Random";
				break;
    	case 3: METHOD = "Discriminative";
				break;
    	default: std::cerr << "Unknown method!" << endl; exit(EXIT_FAILURE);
    }

    std::string printname = "";
    int idx = COLLECTION.find_last_of("\\/");
    if (std::string::npos != idx){
        std::string tmp(COLLECTION.substr(0,idx));
        idx = tmp.find_last_of("\\/");
        std::string filename(tmp.substr(idx+1));
        printname = filename;
    }

    OUTPUT_FILE = OUTPUT_FILE + "-col="+printname
    		      +"-qlen="+SSTR(QUERY_LENGTH)+"-NOFDOCS="+SSTR(NOF_DOCS)
    		      +"-NOF_Q_DOCS="+SSTR(NOF_QUERIES_PR_DOC)+"-METHOD="+METHOD
    		      +"-NEXT_Q_ID="+SSTR(NEXT_QUERYID);

    std::cout << std::endl;
    std::cout << "******************** INITIALISATION ********************" << std::endl;
    std::cout << "Collection.................: " << COLLECTION         << std::endl;
    std::cout << "Output file................: " << OUTPUT_FILE        << std::endl;
    std::cout << "Stop word list.............: " << STOPWORDLIST       << std::endl;
    std::cout << "Method.....................: " << METHOD             << std::endl;
    std::cout << "Query length...............: " << QUERY_LENGTH       << std::endl;
    std::cout << "Number of documents........: " << NOF_DOCS           << std::endl;
    std::cout << "Number of queries per doc..: " << NOF_QUERIES_PR_DOC << std::endl;
    std::cout << "Next query id..............: " << NEXT_QUERYID       << std::endl;
    std::cout << "Noise level (lambda).......: " << LAMBDA             << std::endl;
    std::cout << "Verbose level..............: " << VLEVEL             << std::endl;
    std::cout << "Threshold..................: " << THRESHOLD          << std::endl;
    std::cout << "Write trectext queries.....: " << BOOL_STR(TRECTEXT) << std::endl;
    std::cout << "Expected number of queries.: " << ceil((double)NOF_DOCS*(double)NOF_QUERIES_PR_DOC * (1.0+(1.0-THRESHOLD))) << std::endl;
    _cfg->destroy();
}

int main(int argc, char ** argv){
	 srand (time(NULL));
	/*
	 * Leif's method:
	 * 1 - Initialize the empty query set q = {}
	 * 2 - Select the document d to be the known item with probability p(d)
	 * 3 - Select the query length s with probability p(s)
	 * 4 - Repeat k times:
	 * 5 - 		Select a term t from the document model of d with probability p(t | \Sigma_d) (the topic model)
	 * 6 - 		Add t to the query set q
	 * 7 - Record d and q to define the known-item query set
	 *
	 * Step 2 -> p(d) can be set to be uniform.
	 * Step 3 -> p(k) /can/ be selected by fitting
	 * Step 5 -> p(t | \Sigma_d) = (1-\lambda)p(t|d) + \lambda p(t)
	 *           - p(t) = is the probability of t in the collection.
	 *           - p(t | \Sigma_d) = three different options -- see Query Side Evaluation
	 *
	 */
	parse_configuration(argv[1]);

	if(STOPWORDLIST.compare("") != 0){
		// Load stopwords.
		  std::string line;
		  std::ifstream myfile (STOPWORDLIST.c_str());
		  if (myfile.is_open()){
			  while (getline (myfile,line)) {
				  line = cache::aux::fixString(line);
				  STOP_WORDS.insert(line);
			  }
			  myfile.close();
		  }else{
			  cout << "Unable to open file" << endl;
			  exit(EXIT_FAILURE);
		  }
		  std::cout << endl;
		  std::cout << "*************************************" << endl;
	      std::cout << "Loaded " << STOPWORDLIST               << endl;
	      std::cout << "*************************************" << endl;
	}
    indri::collection::Repository index;
    // Open the index
    index.openRead( COLLECTION );
    std::cout << endl;
    std::cout << "***************************" << endl;
    std::cout << "Processing...." << endl;
    std::cout << "***************************" << endl;

	indri::server::LocalQueryServer local(index);
	UINT64 docCount = local.documentCount();
	if(NOF_DOCS > docCount){
	   std::cerr << "Number of docs specified exceeds collection size (" << docCount << "). Setting NOF_DOCS = " << docCount << endl;
	   NOF_DOCS = docCount;
	}

    switch(SWITCHPARM){
		case 1:
			popularSelection(local, docCount);
			break;
		case 2:
			randomSelection(local, docCount);
			break;
		case 3:
			discriminativeSelection(local, docCount);
			break;
		default:
			std::cerr << "Parameter value " << SWITCHPARM << " not valid. Aborting... " << endl;
			exit(EXIT_FAILURE);
    }
    // Write the queries
    std::cout << "***************************" << endl;
    std::cout << "Processing finished! Wrote all queries to " << OUTPUT_FILE << endl;
    std::cout << "***************************" << endl;

    cache::aux::printQueries(queries, OUTPUT_FILE.c_str(), NEXT_QUERYID, TRECTEXT);
    index.close();
}


