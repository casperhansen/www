#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include "symphony.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <map>
#include <time.h>
#include <set>
#include <cmath>
#include <cstring>
#include <limits>
#include <iterator>
#include <string>
#include <config4cpp/Configuration.h>
#include <boost/regex.hpp>
#include "../include/aux.hpp"
#include "lpsolve/lp_lib.h"
typedef std::pair<std::string, double > TermFreq;
typedef std::string Variable;
typedef std::string Term;

/* 09-02-2015
 * Added Query and Queries to contain the processed queries.
 * QUERYLOG is initialized here. Each query is created locally.
 */
typedef std::vector<std::string> Query;
typedef std::vector< Query > Queries;
Queries QUERYLOG;

// Default file format
std::string fileformat = "LP";

// Default cutoff (no cutoff)
int cutoff = -1;

// Default map
std::vector< TermFreq > mapping;

//Default number of bytes we assume each posting takes
int NUM_BYTES_PER_POSTING = 0;
int NUM_TERMS_IN_HIT      = 0;
int NOF_QUERIES           = 0;

//Default number of bytes in cache (cache size is a mandatory argument)
int CACHE_SIZE_IN_BYTES = 0;

//Default file to write the cache terms to
std::string CACHE_TERMS_FILE, R_CACHE_TERMS_FILE, TIMINGS_FILE, QTFDF_TERMS_FILE, QTFDF_R_TERMS_FILE, C_FILE, R_FILE, Q_REPO = "";
std::string CACHE_FILE_INFO, RCACHE_FILE_INFO = "";
std::string ALL_TERMS_FILE = "";

//Default timingsfile
std::ofstream timingsfile;

// Whether to use alternative (see FQFDT.parameters)
std::string CACHE_PARM_FILE;

// Timings
double solver_t  = 0.0;
double ricardo_t = 0.0;

// Default initializations
int countQuery;          // How many queries occur at least twice?
int countTotalQueryHits; // What is the total number of hits?
std::string INFILE_NAME;
std::string filename,rfilename;
std::vector<                   std::string > collections;
std::map<Variable,    Term                 > cachemapping;
std::map<Variable,    cache::aux::QTFDFOBJ*> COP_t2qtfdf;
std::map<Variable,    cache::aux::QTFDFOBJ*> TERM_TO_QTFDFOBJ;
std::vector<          cache::aux::QTFDFOBJ*> vals;
std::set<             cache::aux::QTFDFOBJ*> QTFDF_TERMCACHE;
std::set<             cache::aux::QTFDFOBJ*> QTFDF_RICARDOCACHE;
std::set<             std::string          > termcache, ricardoCache;
std::map<std::string, int                  > cmaps;


// Integer to string
#define SSTR( x ) dynamic_cast< std::ostringstream & >( \
        ( std::ostringstream() << std::dec << x ) ).str()

inline const char * const BoolToString(const bool b){
  return b ? "true" : "false";
}

using namespace config4cpp;

void doSynthesize(){
	/* Read file from disk and construct */
	std::string line;
    std::ifstream myfile (INFILE_NAME.c_str());
	int linecounter = 0;
	if (myfile.is_open()){
	    while (getline (myfile,line)) {
			line = cache::aux::fixString(line);
			std::vector<std::string> elems;
			cache::aux::split(line, ',', elems);

			std::string stem  = elems.at(0);
			std::string fqt   = elems.at(1); int _fqt      = std::atoi(fqt.c_str());
			std::string fdt   = elems.at(2); int _fdt      = std::atoi(fdt.c_str());
			std::string score = elems.at(3); double _score = (double)std::atoi(score.c_str());
			cache::aux::QTFDFOBJ * qtfobj = new cache::aux::QTFDFOBJ(stem, _score, _fqt, _fdt * NUM_BYTES_PER_POSTING);
			vals.push_back(qtfobj);
			TERM_TO_QTFDFOBJ[stem] = qtfobj;
			linecounter++;
	    }
	    myfile.close();
	}
	cutoff = (int)vals.size();

	int cutcounter = 0;
	std::string var = "";
	for(std::vector<cache::aux::QTFDFOBJ*>::iterator it = vals.begin(); it != vals.end(); ++it) {
   	    var 				= "x"+SSTR(cutcounter);
   	    cachemapping[var] = (*it)->stringValue;
   	    COP_t2qtfdf[var]  = *it;
   	    cutcounter++;
	}
	cache::aux::writefile(fileformat,vals,cutoff,filename,CACHE_SIZE_IN_BYTES,false);
}

void doRicardosMethod(vector<cache::aux::QTFDFOBJ *> v){
	  // Time sorting. clock measures the CPU clock time (see doc for time.h)
	  clock_t tStart = clock();
	  std::sort(v.begin(), v.end(), cache::aux::ge_score());
	  ricardo_t = (double)(clock() - tStart)/CLOCKS_PER_SEC;
	  timingsfile << R_CACHE_TERMS_FILE << " :: " << ricardo_t << endl;

	  ofstream myfile;
	  myfile.open(RCACHE_FILE_INFO.c_str());

	  std::string strval = "";
	  int acc            = 0;
	  int tcounter       = 0;
	  int poscounter     = 0;
	  for(std::vector<cache::aux::QTFDFOBJ * >::iterator it = v.begin(); it != v.end(); ++it) {
		  if((acc+(*it)->colval <= CACHE_SIZE_IN_BYTES) && (tcounter <= cutoff)){
			  cache::aux::QTFDFOBJ * obj = *it;
			  strval                     = obj->stringValue;
			  cache::aux::QTFDFOBJ * t   = new cache::aux::QTFDFOBJ(obj->stringValue, obj->score, obj->queryval, obj->colval);
			  QTFDF_RICARDOCACHE.insert(t);
			  ricardoCache.insert(strval);
			  acc += obj->colval; // colval is the F_d(t) times the number of bytes per posting
			  tcounter++;
			  myfile << SSTR(poscounter) << "," << obj->stringValue << "," << obj->queryval << "," << obj->colval << endl;
			  poscounter++;
		  }
	  }
	  myfile.flush();
	  myfile.close();
	  cout << endl;
	  cout << "***************** STEP 4 *****************"                          << endl;
	  cout << "Ricardo's method:       " 						 				    << endl;
	  cout << "Found.................: " << tcounter 				  << " terms"   << endl;
	  cout << "Left-over cache space.: " << (CACHE_SIZE_IN_BYTES-acc) << " bytes"   << endl;
	  cout << "Sorted values in......: " << ricardo_t 				  << " seconds" << endl;
	  cout << "Inserted..............: " << QTFDF_RICARDOCACHE.size() << " terms"   << endl;

/*
	  int accum = 0;
	  std::vector<cache::aux::QTFDFOBJ>::iterator sitr;
	  for(sitr = vals.begin(); sitr != vals.end(); ++sitr){
	      if(ricardoCache.find((*sitr).stringValue) != ricardoCache.end()){
	    	  accum += (*sitr).queryval;
	      }
	  }
	  std::cout << "Total hits for " << ricardoCache.size() << " terms was " << accum << endl;
*/
}

void overlap(){
	// Loop over Ricardo's terms to find overlap
	std::string term;
	bool is_in;
	int intersection = 0;
	std::set<std::string>::iterator it;
	for(it = ricardoCache.begin(); it != ricardoCache.end(); ++it){
		term  = *it;
		is_in = termcache.find(term) != termcache.end();
		if(is_in){
			intersection++;
		}
	}
	/* Overlap is not "accurate" as it depends on which set we loop over. The overlap
	 * or Szymkiewicz-Simpson coefficient may be a better choice
	 */
	double overlap_coeff = intersection/((double)min(ricardoCache.size(), termcache.size()));
	cout << endl;
	cout << "***************** STEP 5 *****************" << endl;
	cout << "Found " << intersection << " terms in both caches (" << ((int) 100*((double)(intersection)/(double)(termcache.size()))) << "%)" << endl;
	cout << "Overlap coefficient............: " << overlap_coeff       << endl;
	cout << "Total terms in our cache.......: " << termcache.size()    << endl;
	cout << "Total terms in Ricardo's cache.: " << ricardoCache.size()  << endl;
	cout << endl;
}

void solveLP(std::vector<cache::aux::QTFDFOBJ *>& myvals, int CACHEVAL){

   /*
    * Load into argv-style array
    */

    std::vector<std::string> ols;
    ols.push_back("program"); // Can be anything. Does not matter

    /*
     * Uncomment and change four to specify the number of threads allocated to the problem
     */
    ols.push_back("-p");	  // see https://github.com/coin-or/SYMPHONY
    ols.push_back("1");
	ols.push_back("-L");	  // Solve files in the LP format
    ols.push_back(filename);
    cout << endl;
    cout << "***************** STEP 3 *****************" << endl;
    cout << "Solving.....: " << filename 				 << endl;
    cout << "Cache size..: " << CACHEVAL 				 << endl;
    cout << "Vals size...: " << myvals.size() 			 << endl;
	int N = (int)ols.size();
	char **cLineStrings = new char*[N];

	for (int i = 0; i < ols.size(); ++i){
		cLineStrings[i] = (char *)ols[i].c_str();
	}

  /*
   * Define the result array. Must be at least the same number of variables
   */
	double * result = new double[cutoff];

   /*
    * Set up the environment for the solver
 	*/
	sym_environment *env = sym_open_environment();
	sym_parse_command_line(env, N, cLineStrings);
	sym_load_problem(env);
	sym_set_int_param(env, "verbosity"          , -3   );
    sym_set_int_param(env, "node_selection_rule",  3   ); // LOWEST_LP_FIRST, 1: HIGHEST_LP_FIRST, 2: BREADTH_FIRST_SEARCH, 3: DEPTH_FIRST_SEARCH
    sym_set_dbl_param(env, "gap_limit"          , -1.0 );
    sym_set_int_param(env, "time_limit"         , -1.0 );
    sym_set_int_param(env, "find_first_feasible", FALSE);
    sym_set_int_param(env, "do_branch_and_cut"  , TRUE );
    sym_set_int_param(env, "problem_type"       ,  0   );
    sym_set_int_param(env, "prep_level"         ,  5   );

    //sym_set_int_param(env, "node_limit", -1); // No limit on the number of nodes to process
    //sym_set_int_param(env, "time_limit", -1); // No limit on the time the program can use to find a solution
    sym_solve(env);
    int termcode = sym_get_status(env);
    switch(termcode){
        case  227: std::cout << "TermCode: "  << termcode << " => TreeManager found OPTIMAL solution and stopped" << std::endl;
                   break;
        case  228: std::cout << "TermCode: "  << termcode << " => TreeManager stopped after reaching the predefined time limit" << std::endl;
                   break;
        case  229: std::cout << "TermCode: "  << termcode << " => TreeManager stopped after reaching the predefined node limit" << std::endl;
                   break;
        case  231: std::cout << "TermCode: "  << termcode << " => TreeManager stopped after reaching the predefined target gap" << std::endl;
                   break;
        case  232: std::cout << "TermCode: "  << termcode << " => TreeManager stopped after finding first feasible solution" << std::endl;
                   break;
        case -250: std::cout << "TermCode: "  << termcode << " => Error: TM stopped. User didn't select branching candidate in user_select_candidates() callback" << std::endl;
                   break;
        case -251: std::cout << "TermCode: "  << termcode << " => Error: TM stopped after getting an invalid return code" << std::endl;
                   break;
        case -252: std::cout << "TermCode: "  << termcode << " => Error: TM stopped due to some numerical difficulties" << std::endl;
                   break;
        case -253: std::cout << "TermCode: "  << termcode << " => Error: TM stopped due to communication error" << std::endl;
                   break;
        case -275: std::cout << "TermCode: "  << termcode << " => Error: TM stopped. User error detected in user callback" << std::endl;
                   break;
        case -100: std::cout << "TermCode: "  << termcode << " => Error: TM stopped. User error detected in one of several user functions" << std::endl;
                   break;
    }

    sym_get_col_solution(env,result);
    sym_close_environment(env);

    ofstream myfile;
    myfile.open(CACHE_FILE_INFO.c_str());
    int poscounter = 0;
    // Check if we have a solution at all
    Variable str = "";
    bool solutionfound  = false;
	map<std::string,                 Term  >::iterator p;
	map<std::string, cache::aux::QTFDFOBJ *>::iterator pp;
	int found_counter = 0;
        int cache_fill    = 0;
        for(int i=0; i<cutoff; i++){
    	if(*(result+i) > 0){ // We have a result! Current variable is to be included
    		solutionfound = true;
    		// Construct variable
    		str = "x"+SSTR(i);

    		p  = cachemapping.find(str);
    		pp = COP_t2qtfdf.find(str);
    		if ( p == cachemapping.end() ) {
    		  // This should never happen!
    			cout << "Something terrible has happened for term " << str << " (not found in cachemapping) after solving the LP problem! Aborting..." << endl;
    			exit(EXIT_FAILURE);
    		} else {
    		    // We have found a match. Insert the cache term
    			std::string obj = p->second;
    			termcache.insert(obj);
    			bool iss = TERM_TO_QTFDFOBJ.find(obj) != TERM_TO_QTFDFOBJ.end();
    			if(iss){
    				cache_fill += TERM_TO_QTFDFOBJ[obj]->colval;
    			}
    			myfile << SSTR(poscounter) << "," <<  TERM_TO_QTFDFOBJ[obj]->stringValue << "," << TERM_TO_QTFDFOBJ[obj]->queryval << "," << TERM_TO_QTFDFOBJ[obj]->colval << endl;
        		found_counter++;
    			poscounter++;
    		}
    		if( pp != COP_t2qtfdf.end()){
    			cache::aux::QTFDFOBJ * qobj = pp->second;
    			cache::aux::QTFDFOBJ * t    = new cache::aux::QTFDFOBJ(qobj->stringValue,qobj->score,qobj->queryval,qobj->colval);
    			QTFDF_TERMCACHE.insert(t);
    		}
    	}
    }
    myfile.flush();
    myfile.close();
    std::cout << "Inserted objects: " << found_counter << std::endl;
    // Determine how much of the cache the principled approached managed to fill out
    std::map<int,std::string> term_;
    int _acc = 0;
    int ctr  = 0;
	for(std::vector<cache::aux::QTFDFOBJ *>::iterator it = vals.begin(); it != vals.end(); ++it) {
//	    cache::aux::QTFDFOBJ obj = *it;
		if(termcache.find((*it)->stringValue) != termcache.end()){
//			_acc += (*it)->colval;
			term_[(*it)->colval] = (*it)->stringValue;
//			std::cout << "Term: " << (*it)->stringValue << ", colval: " << (*it)->colval << std::endl;
			ctr++;
		}
	}
	_acc = cache_fill;
	std::cout << "Term cache size: " << termcache.size() << endl;
	std::cout << "_acc: Found " << ctr << " terms, worth: " << _acc << " bytes "<< std::endl;
	/* Very rarely the _acc is larger. This happens if the best solution found was obtained by a relaxation of a constraint
	 * that could not be satisfied further.
	 * We remedy this by removing terms until the constraint is met
	 */

	if(_acc > CACHEVAL){
	    int diff    = _acc - CACHEVAL;
	    bool foundc = term_.find(diff) != term_.end(); /* Can we find a term with the discrepancy in the cache? */
	    if(foundc){
	        std::string offkey = term_[diff]; /* Get the term */
	        termcache.erase(offkey);	      /* Erase the term */
	        _acc -= diff;                     /* Decrement _acc */
	        found_counter--;
	    }else{
	    	/* Could not find the difference */
	    	for(int j = 1; j < 1000; j++){
	    		if((j*NUM_BYTES_PER_POSTING) >= diff){ /* Find the term with the smallest weight strictly larger than the diff in multiples of the NUM_POSTINGS_IN_BYTES size*/
	    			bool wasFound = term_.find(diff) != term_.end(); /* Can we find a term with that weight? */
	    			if(wasFound){
	    		        std::string offkey = term_[(j*NUM_BYTES_PER_POSTING)]; /* Get the term */
	    		        termcache.erase(offkey);	      /* Erase the term */
	    		        _acc -= diff;                     /* Decrement _acc */
	    		        found_counter--;
	    			   break;
	    			}
	    		}
	    	}
	    }
	}

    if(!solutionfound){
    	cout << "No variables were non-zero. No solution obtained!" << endl;
    	exit(EXIT_FAILURE);
    }
    cout << "Solution found! "													    << endl;
    cout << "Found.................: " << termcache.size()            << " terms" 	<< endl;
    cout << "Left-over cache space.: " << (CACHEVAL-_acc)             << " bytes"   << endl;
    cout << "Solved CCO in.........: " << solver_t 					  << " seconds" << endl;
    cout << "Inserted..............: " << QTFDF_TERMCACHE.size()      << " terms"   << endl;
}


std::string getFileID(std::string qRn, int _cachesize){
   	std::string fileIns =  "-qindex="+qRn+"-csize="+SSTR(_cachesize)+
	           	   	   	   "-POSTING_BYTES="+SSTR(NUM_BYTES_PER_POSTING);
   	return fileIns;
}

void parse_configuration(const char * configFile){
	Configuration *  _cfg       = Configuration::create();
	const char *     _scope     = "";
    const char *     _cachesize = "";

    try {
        _cfg->parse(configFile);
        INFILE_NAME           = _cfg->lookupString( _scope, "synfile"      );
        filename              = _cfg->lookupString( _scope, "lpfilename"      );
        fileformat            = _cfg->lookupString( _scope, "format"          );
        _cachesize 			  = _cfg->lookupString( _scope, "cachesize"       );
        CACHE_TERMS_FILE      = _cfg->lookupString( _scope, "cachefile"       );
        R_CACHE_TERMS_FILE    = _cfg->lookupString( _scope, "ricardocachefile");
        CACHE_PARM_FILE       = _cfg->lookupString( _scope, "cacheParmFile"   );
        NUM_BYTES_PER_POSTING = _cfg->lookupInt(    _scope, "postingsize"     );
        NUM_TERMS_IN_HIT      = _cfg->lookupInt(    _scope, "noftermsinhit"   );
    } catch(const ConfigurationException & ex) {
        cerr << ex.c_str() << endl;
        _cfg->destroy();
    }
    CACHE_SIZE_IN_BYTES = atoi(_cachesize);

    std::string tmp = "";

    int idx = (int)INFILE_NAME.find_last_of("\\/");
   	std::string Q_REPO(INFILE_NAME.substr(idx+1,INFILE_NAME.size()));

   	/* Added 02-02-2015. Allows us to "reset" the qtfdf files that will print the QTFDF terms */

   	size_t lastindex           = CACHE_TERMS_FILE.find_first_of("-");
   	std::string CACHE_RAWNAME  = CACHE_TERMS_FILE.substr(0, lastindex);

   	lastindex                  = R_CACHE_TERMS_FILE.find_first_of("-");
   	std::string RCACHE_RAWNAME = R_CACHE_TERMS_FILE.substr(0, lastindex);

   	C_FILE 				= CACHE_RAWNAME;
   	R_FILE 				= RCACHE_RAWNAME;
   	std::string fileIns = getFileID(Q_REPO, CACHE_SIZE_IN_BYTES);
   	/* Cache files */
    CACHE_TERMS_FILE    = C_FILE+fileIns+".cache";
    R_CACHE_TERMS_FILE  = R_FILE+fileIns+".cache";
    /* QTFDF files */
    QTFDF_TERMS_FILE    = C_FILE+fileIns+".qtfdf";
    QTFDF_R_TERMS_FILE  = R_FILE+fileIns+".qtfdf";

    CACHE_FILE_INFO     = C_FILE+fileIns+".stats";
    RCACHE_FILE_INFO    = R_FILE+fileIns+".stats";

    ALL_TERMS_FILE      = C_FILE+fileIns+".allterms";


    cout << endl;
    cout << "***************** INITIALISATION *****************" 	<< endl;
    cout << "Synthetic file.........: " << INFILE_NAME 			    << endl;
    cout << "LP file................: " << filename 				<< endl;
    cout << "Format.................: " << fileformat 				<< endl;
    cout << "Cache size (kB)........: " << CACHE_SIZE_IN_BYTES 		<< endl;
    cout << "Cache file.............: " << CACHE_TERMS_FILE 		<< endl;
    cout << "Ricardo cache file.....: " << R_CACHE_TERMS_FILE 		<< endl;
    cout << "Posting entry size (kb): " << NUM_BYTES_PER_POSTING 	<< endl;
    _cfg->destroy();
}

void process(){

	  try {
		/* Synthesize from generated file              */
		doSynthesize();

	    /* Solve the COP to select terms for our cache */
		std::cout << "Cache size in bytes: " << CACHE_SIZE_IN_BYTES << std::endl;
    	solveLP(vals, CACHE_SIZE_IN_BYTES);

	    /* Use baseline method */
	    doRicardosMethod(vals);

    	/* Calculate the overlap between caches        */
        overlap();
        /* Write the cache terms to file               */
        cache::aux::writecacheterms(termcache         , CACHE_TERMS_FILE  );
        cache::aux::writeQTFDFterms(QTFDF_TERMCACHE   , QTFDF_TERMS_FILE  );
  	    cache::aux::writecacheterms(ricardoCache      , R_CACHE_TERMS_FILE);
  	    cache::aux::writeQTFDFterms(QTFDF_RICARDOCACHE, QTFDF_R_TERMS_FILE);


	    /* Write the cache parameter file              */
	    //cache::aux::writeCacheParameterFile(CACHE_PARM_FILE, queryRepName, CACHE_TERMS_FILE, R_CACHE_TERMS_FILE, false, countQuery, countTotalQueryHits, NUM_TERMS_IN_HIT, NOF_QUERIES);
	  } catch( lemur::api::Exception& e ) {
	    LEMUR_ABORT(e);
	  }
}

int main( int argc, char** argv ) {
	parse_configuration(argv[1]);
	process();

/*
  system("./evaluate.sh");
*/
  return EXIT_SUCCESS;
}
