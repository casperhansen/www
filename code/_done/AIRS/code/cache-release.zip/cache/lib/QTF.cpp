#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <set>
#include <map>
#include <algorithm>
#include <ctime>
#include <boost/regex.hpp>
#include "../include/aux.hpp"

void calculateFQT( indri::collection::Repository& r, const char * filename ) {
  ofstream myfile;
  myfile.open(filename);
  indri::collection::Repository::index_state state = r.indexes();
  indri::index::Index* index = (*state)[0];
  indri::index::VocabularyIterator* iter = index->vocabularyIterator();
  iter->startIteration();
  int vc = 0;
  int qc = 0;
  boost::regex re("[\\s\n\t]+"); // The split tokens
  /**
   * Loop over the vocabulary
   */
  while( !iter->finished() ) {
    indri::index::DiskTermData* entry = iter->currentEntry();
    indri::index::TermData* termData = entry->termData;
    // Convert to string
    std::string	str(termData->term);
    std::vector< std::string > terms;

    // We make the EXPLICIT assumption that queries can be split on one or more whitespaces, newlines or tabs
    boost::sregex_token_iterator i(str.begin(), str.end(), re, -1);
    boost::sregex_token_iterator j;
    while (i != j) {
    	 terms.push_back(*i++);
    }

    std::vector< std::string >::iterator it;

    for(it = terms.begin(); it != terms.end(); it++){
    	std::string queryterm = *it;
		queryterm = cache::aux::fixString(queryterm);
		queryterm  = r.processTerm(queryterm);
		// Counts the number of documents that termData->term exists in
		unsigned int count = termData->corpus.documentCount;
		myfile << count << endl;
		/* Put the term and its frequency amongst all the queries in a map. We will use this when calculating the hit rate*/
    }
    iter->nextEntry();
  }
  myfile.flush();
  myfile.close();
  delete iter;
}

int main(int argc, char ** argv){
	indri::collection::Repository r;
	r.openRead(argv[1]);
	calculateFQT(r, argv[2]);
	r.close();
}
