/*
 * PostingListLenghts.cpp
 *
 * Calculates the length of each terms posting list in the specified index. Tests the claim made by
 * Ricardo et al. in "Design Trade-Offs for Search Engine Cachine"
 *
 * Usage:
 * ./PostingListLengths <loc-to-index>
 *
 * Author: Casper Petersen
 * November 2014
 * All rights reserved
 */

#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <map>
#include <time.h>
/**
 * Extracts the vocabulary of a repository and counts the number of documents each term in the vocabulary
 * is a part of.
 *
 * The repository is assumed to be the query repository, and returns, for each term in each query:
 * (a) the term and (b) the number of queries (documents more generally) the term is found in
 *
 */
void printPostingListLengths( indri::collection::Repository& r ) {
	  indri::collection::Repository::index_state state = r.indexes();
	  indri::index::Index* index = (*state)[0];
//	  std::cout << "Found" << " " << index->termCount() << " terms in " << index->documentCount() << " documents " << std::endl;
	  indri::index::VocabularyIterator* iter = index->vocabularyIterator();
	  indri::index::DocListIterator* citer;
	  iter->startIteration();
	  /**
	   * Loop over the vocabulary
	   */
	  while( !iter->finished() ) {
	    indri::index::DiskTermData* entry = iter->currentEntry();
	    indri::index::TermData* termData = entry->termData;

	    citer = index->docListIterator( termData->term );
		citer->startIteration();
		int doc = 0;
		for(citer->startIteration(); citer->finished() == false; citer->nextEntry() ) {
			doc++;
		}
		//cout << voc_counter << " :: " << termData->term << " :: "<<doc << endl;
		cout << doc << endl;
	    iter->nextEntry();
	  }
	  delete iter;
	  delete citer;
}

int main( int argc, char** argv ) {
  try {
    indri::collection::Repository queryIndex;
    std::string queryRepName = argv[1];
    queryIndex.openRead( queryRepName );
    printPostingListLengths(queryIndex);
    queryIndex.close();
    return 0;
  } catch( lemur::api::Exception& e ) {
    LEMUR_ABORT(e);
  }
}
