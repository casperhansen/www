#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <set>
#include <map>
#include <algorithm>
#include <ctime>
#include "../include/aux.hpp"

void print_document_vector( indri::collection::Repository& r, const char * filename ) {
  indri::server::LocalQueryServer local(r);
  UINT64 docCount = local.documentCount();
  std::cout << "Found " << docCount << " documents" << std::endl;
  std::vector<lemur::api::DOCID_T> documentIDs;

  for(int i=0;i<docCount; i++)
	  documentIDs.push_back(i+1);

  indri::server::QueryServerVectorsResponse* response = local.documentVectors( documentIDs );
  map<std::string, int> mymap;
  if( response->getResults().size() ) {
	size_t resultsize = response->getResults().size();
	for(size_t j=0; j<resultsize; j++){
		indri::api::DocumentVector* docVector = response->getResults()[j];
		std::string query = "";
		for(size_t i=0; i<docVector->positions().size()-1; i++ ) {
		  int position      = docVector->positions()[i];
		  std::string& stem = docVector->stems()[position];
		  query             = query + stem + " ";
		}
		int position        = docVector->positions()[docVector->positions().size()-1];
		std::string& stem   = docVector->stems()[position];
		query               = query + stem;
		bool is_in 			= mymap.find(query) != mymap.end();
		if(is_in){
			mymap[query]++;
		}else{
			mymap[query] = 1;
		}
		delete docVector;

		if((j % 200000) == 0){
			std::cout << "Finished " << j << " documents" << std::endl;
		}
	}
	std::cout << "***************************************************" << std::endl;
	std::cout << "*             FINISHED ALL DOCUMENTS              *" << std::endl;
	std::cout << "***************************************************" << std::endl;
  }
  delete response;
  int counter      = 0;
  int totalcounter = 0;

  ofstream myfile;
  myfile.open(filename);
  map<std::string, int>::iterator it;
  for(it = mymap.begin(); it != mymap.end(); ++it){
	  myfile << it->second << endl;
	  if(it->second == 1){
		  counter++;
	  }
	  totalcounter++;
  }
  std::cout << "Out of " << totalcounter << " queries, there were " << counter << " singletons (" << 100*(counter/(double)totalcounter) << "%)" << std::endl;

  myfile.flush();
  myfile.close();
}

int main(int argc, char ** argv){
	indri::collection::Repository r;
	r.openRead(argv[1]);
	print_document_vector(r, argv[2]);
	return EXIT_SUCCESS;
}
