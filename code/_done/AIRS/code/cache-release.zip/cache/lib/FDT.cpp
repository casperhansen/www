#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <map>
#include <time.h>
#include <set>
#include <cmath>
#include <limits>
#include <iterator>
#include "../include/aux.hpp"

int main(int argc, char ** argv){
	// Calculate F_D(T) for all terms in the vocabulary
    indri::collection::Repository r;

    // Open the index
    r.openRead( argv[1] );
    indri::collection::Repository::index_state state = r.indexes();
    indri::index::Index* index = (*state)[0];
    indri::index::VocabularyIterator* iter = index->vocabularyIterator();
    int voccounter = 0;
    iter->startIteration();
    indri::index::DocListIterator* citer;
	ofstream myfile;
	myfile.open(argv[2]);
    while( !iter->finished() ) {
       indri::index::DiskTermData* entry = iter->currentEntry();
       indri::index::TermData* termData = entry->termData;
       std::string stem(termData->term);
       voccounter++;
	   citer = index->docListIterator( stem );
	   int doc = 0;
	   /*
		* We risk that the stem from the query index does not match anything in the collection index.
		* This means the collection value will be 0. Otherwise we count F_d(t)
		*/

	   if (citer != NULL){
		   citer->startIteration();
		   for( citer->startIteration(); citer->finished() == false; citer->nextEntry() ) {
			    doc++;
		   }
	   }
	   myfile << stem << "," << doc << endl;

	   if((voccounter % 1000000) == 0){
		   std::cout << "Completed " << voccounter << " terms" << std::endl;
	   }
       iter->nextEntry();
    }
    myfile << flush;
    myfile.close();
    std::cout << "Total terms in vocabulary: " << voccounter << std::endl;
}
