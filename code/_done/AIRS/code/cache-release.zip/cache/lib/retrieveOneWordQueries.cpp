/*
 * retrieveOneWordQueries.cpp
 *
 *  Created on: Nov 25, 2014
 *      Author: casper
 */

#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <map>
#include <set>
#include <boost/regex.hpp>
#include "../include/aux.hpp"
#include "../include/FileUtils.hpp"

// Initializations
std::set<std::string> querySet;
std::vector<string> queries;
string startDEL = "<TEXT>";
string stopDEL =  "</TEXT>";
boost::regex expression("<TEXT>(.*)</TEXT>");
boost::smatch match;

bool invalidChar (char c){
    return !(c>=0 && c <128);
}

void writeQueries(std::string writeFile){
	//<DOC> <DOCNO>1</DOCNO> <TEXT> document content </TEXT> </DOC>
	int qcounter = 1;
	std::string fpath = cache::fileutils::getFilePath(writeFile);
	std::string fname = cache::fileutils::getFileName(writeFile, false);
	const char * wtxtfile = (fpath+fname+"_trec").c_str();
	ofstream wfile;
	wfile.open(wtxtfile);

	std::vector<std::string>::iterator it;
	for (it = queries.begin(); it != queries.end(); ++it) {
		string str(*it);
		str.erase(remove_if(str.begin(),str.end(), invalidChar), str.end());
		str.erase(std::remove(str.begin(), str.end(), '\n'), str.end());

		wfile << "<DOC>\n";
		wfile << "<DOCNO>" << qcounter << "</DOCNO>\n";
		wfile << "<TEXT>\n";
		wfile << str << "\n";
		wfile << "</TEXT>\n";
		wfile << "</DOC>\n";
		qcounter++;
	}
/*
	for(std::vector<string>::iterator it = queries.begin(); it != queries.end(); ++it) {
		string str(*it);
		wfile << "<DOC>\n";
		wfile << "<DOCNO>" << qcounter << "</DOCNO>\n";
		wfile << "<TEXT>\n";
		wfile << str << "\n";
		wfile << "</TEXT>\n";
		wfile << "</DOC>\n";
		qcounter++;
	}
*/
	wfile.close();
}

void fetch_onewordqueries( indri::collection::Repository& r, int dlenghts) {
	  indri::collection::Repository::index_state state = r.indexes();
	  indri::collection::CompressedCollection* collection = r.collection();
	  indri::index::Index* index = (*state)[0];
	  UINT64 totalDocs = index->documentCount();
	  int j = 0;
	  for(UINT64 i = 1; i <= totalDocs; i++){
		  if((j+1) % 1000 == 0){
			  std::cout << "Parsed " << (j+1) << " docs" << std::endl;
		  }
		  // Loop over documents
		  if(index->documentLength(i) == dlenghts){
			 // We have found a one-word query. Now we need to get it
			  indri::api::ParsedDocument* document = collection->retrieve( i );
			  std::string content = document->text;
			  //std::cout << content << endl;
			  if (boost::regex_search(content, match, expression)){
				  querySet.insert(std::string(match[1].first, match[1].second));
				  queries.push_back(std::string(match[1].first, match[1].second));
			  }else{
				  cout << "Did not find a match for  " << content << endl;
				  exit(EXIT_FAILURE);
			  }
			  delete document;
		  }
	  }
}

int main(int argc, char ** argv){
    indri::collection::Repository index;
    index.openRead( argv[1] );
    int doclen = atoi(argv[2]);
    fetch_onewordqueries(index, doclen);
    cout << "Number of "<< doclen<<"-word queries " << queries.size() << endl;
    cout << "Number of unique "<<doclen<<"-word queries " << querySet.size() << endl;
	//writeQueries("/home/casper/popular.queries");
    index.close();
}


