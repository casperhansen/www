/*
 * FQFDT.cpp
 *
 * This class calculates the F_Q(t) and F_D(t) from "The Impact of Caching on Search Engines"
 * - F_Q(t) is the number of queries where term t occurs.
 * - F_D(t) is the number of documents where term t occurs.
 *
 * Assumptions:
 * 1 - Both queries and collection(s) are indexed (to separate indexes)
 *
 * Usage:
 * ./FQFDT <loc-to-query-index> <loc-to-collection-index1> ... <loc-to-collection-index2>
 *
 * Author: Casper Petersen
 * November 2014
 * All rights reserved
 */

#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include "symphony.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <map>
#include <time.h>
#include <set>
#include <cmath>
#include <cstring>
#include <limits>
#include <iterator>
#include <config4cpp/Configuration.h>
#include <boost/regex.hpp>
#include "../include/aux.hpp"
typedef std::pair<std::string, double > TermFreq;
typedef std::string Variable;
typedef std::string Term;

/* 09-02-2015
 * Added Query and Queries to contain the processed queries.
 * QUERYLOG is initialized here. Each query is created locally.
 */
typedef std::vector<std::string> Query;
typedef std::vector< Query > Queries;
Queries QUERYLOG;

// Default file format
std::string fileformat = "LP";

// Default cutoff (no cutoff)
int cutoff = -1;

// Default map
std::vector< TermFreq > mapping;

//Default number of bytes we assume each posting takes
int NUM_BYTES_PER_POSTING = 0;
int NUM_TERMS_IN_HIT      = 0;
int NOF_QUERIES           = 0;

//Default number of bytes in cache (cache size is a mandatory argument)
int CACHE_SIZE_IN_BYTES = 0;

//Default file to write the cache terms to
std::string CACHE_TERMS_FILE, R_CACHE_TERMS_FILE, QTFDF_TERMS_FILE, QTFDF_R_TERMS_FILE, C_FILE, R_FILE, Q_REPO = "";
std::string CACHE_FILE_INFO, RCACHE_FILE_INFO = "";
std::string ALL_TERMS_FILE = "";

// Whether to use alternative (see FQFDT.parameters)
std::string CACHE_PARM_FILE;

// Default initializations
int countQuery;          // How many queries occur at least twice?
int countTotalQueryHits; // What is the total number of hits?
std::string queryRepName,collectionName;
std::string filename,rfilename;
std::vector<                   std::string > collections;
std::map<Variable,    Term                 > cachemapping;
//std::map<Variable,    cache::aux::QTFDFOBJ*> COP_t2qtfdf;
std::map<Variable,    cache::aux::QTFDFOBJ*> TERM_TO_QTFDFOBJ;
std::vector<          cache::aux::QTFDFOBJ*> vals;
std::set<             cache::aux::QTFDFOBJ*> QTFDF_TERMCACHE;
std::set<             cache::aux::QTFDFOBJ*> QTFDF_RICARDOCACHE;
std::set<             std::string          > termcache, ricardoCache;
std::map<std::string, int                  > cmaps;


// Integer to string
#define SSTR( x ) dynamic_cast< std::ostringstream & >( \
        ( std::ostringstream() << std::dec << x ) ).str()

inline const char * const BoolToString(const bool b){
  return b ? "true" : "false";
}

using namespace config4cpp;


/* Construct the queries. We do this from the index to ensure no formatting or stemming errors */
/*
void constructQueries(indri::collection::Repository& r){
    indri::server::LocalQueryServer local(r);
    indri::collection::Repository::index_state state = r.indexes();
    UINT64 docCount = local.documentCount();
    std::vector<lemur::api::DOCID_T> documentIDs;
    for(int i = 0; i < docCount; i++){
    	lemur::api::DOCID_T documentID = (i+1);
        documentIDs.push_back(documentID);
        indri::server::QueryServerVectorsResponse* response = local.documentVectors( documentIDs );
        if( response->getResults().size() ) {
        	Query query;
            indri::api::DocumentVector* docVector = response->getResults()[0];
            size_t posSize  = docVector->positions().size();

            for( size_t i=0; i<posSize; i++ ) {
              int position = docVector->positions()[i];
              const std::string& stem = docVector->stems()[position];
              query.push_back(r.processTerm(stem));
            }
            QUERYLOG.push_back(query);
            delete docVector;
        }
        delete response;
    	documentIDs.clear();
    }
}
*/

/**
 * Extracts the vocabulary of a repository and counts the number of documents each term in the vocabulary
 * is a part of.
 *
 * This function outputs F_q(t) as pairs of <query, count>
 *
 * The repository is assumed to be the query repository, and returns, for each term in each query:
 * (a) the term and (b) the number of queries (documents more generally) the term is found in.
 * Notice that we assume that there are no empty queries. Empty queries will cause undefined behaviour.
 *
 */
void calculateFQT( indri::collection::Repository& r ) {
  int vc = 0;
  int qc = 0;
  boost::regex re("[\\s\n\t]+"); // The split tokens

  vector< TermFreq > query;
  indri::collection::Repository::index_state state = r.indexes();
  indri::index::Index* index = (*state)[0];
  /* The vocabularyIterator iterates over the unique terms in the index */
  indri::index::VocabularyIterator* iter = index->vocabularyIterator();
  iter->startIteration();
  while( !iter->finished() ) {
    indri::index::DiskTermData* entry = iter->currentEntry();
    indri::index::TermData* termData = entry->termData;
    // Convert to string
    std::string	str(termData->term);
    std::vector< std::string > terms;

    // We make the EXPLICIT assumption that queries can be split on one or more whitespaces, newlines or tabs
    boost::sregex_token_iterator i(str.begin(), str.end(), re, -1);
    boost::sregex_token_iterator j;
    while (i != j) {
    	 terms.push_back(*i++);
    }
    std::vector< std::string >::iterator it;
    for(it = terms.begin(); it != terms.end(); it++){
    	std::string queryterm = *it;
    	/* Process all terms uniformly */
		queryterm             = cache::aux::fixString(queryterm);
		queryterm             = r.processTerm(queryterm);

		/* Store the query term */
		TermFreq val;
		val.first             = queryterm;

		/* Counts the number of queries that termData->term exists in */
		val.second            = termData->corpus.documentCount;
		/* Put the term and its frequency amongst all the queries in a map. We will use this when calculating the hit rate*/
		query.push_back(val);
		qc++;
    }
    /* Put the query into the QUERYLOG container */
    /* QUERYLOG contains vectors of strings. Each string in each vector is a query term processed using indri */

    vc++;
    iter->nextEntry();
  }
  delete iter;
  cutoff = vc;

  std::cout << endl;
  cout << "***************** STEP 1 *****************" << endl;
  std::cout << "Found " << index->termCount() << " terms ("<< vc << " unique) in " << index->documentCount() << " queries " << std::endl;
  //cout << "******************************************" << endl;
  NOF_QUERIES = (int)index->documentCount();
  mapping = query;
}

void FQFDT() {
  // cmaps: The map holding the <query,collectionfrequency> count.
  std::map<std::string, int> cmaps;

  // N is the number of collections specified in the in the parameter file
  int N = (int)collections.size();

  // M is the map of <query,count> pairs. Query is given in ASCII
  int M = (int)mapping.size();
  for(size_t i=0; i<N; i++){
	  indri::collection::Repository cIndex;
	  cIndex.openRead(collections[i]);
	  indri::server::LocalQueryServer local(cIndex);

	  /*
	   * Loop over all query terms
	   * Here we calculate F_d(t) (document collection)
	   */

	  for(int j = 0; j < M; j++){
		  std::pair<std::string, int> val = mapping.at(j);
		  //std::string stem = val.first;
		  int doc = (int)local.documentCount(val.first);

		  if (cmaps.find(val.first) != cmaps.end()){
			  cmaps[val.first] += doc;
		  }else{
			  cmaps[val.first] = doc;
		  }
	  }
	  cIndex.close();
  }
 /*
  * The stem is the query term in question.
  * The score is the F_q(t)/F_d(t) from Ricardo's paper
  * The val is the F_q(t) from Ricardo's paper
  * The collectionval is the F_d(t) from Ricardo's paper
  */

  for(int k=0;k<M;k++){
	  std::pair<std::string, int> entry = mapping.at(k);
	  std::string stem  = entry.first;
	  int FQT           = entry.second;
	  int FDT           = cmaps[stem];
	  //termFreq[stem]    = cache::aux::FQTFDT(FQT,FDT);
	 /*
	  * If (val > 2) check added 03-12-2014.
	  * Val is the number of queries that stem occurs in. A cache hit can only happen for queries
	  * that occur more than once.
	  *
	  * If (NUM_BYTES_PER_POSTING*collectionval <= CACHE_SIZE_IN_BYTES) added 08-12-2014
	  * We filter entries away that cannot be in the cache to begin with. This is to ensure
	  * that Ricardo's method is not at a disadvantage w.r.t. sorting the entries.
	  */
	  if((FQT >= 2) && (NUM_BYTES_PER_POSTING*FDT <= CACHE_SIZE_IN_BYTES)){
		  countQuery++;
		  countTotalQueryHits += FQT;
		  // Set score to the lowest machine precision possible.
		  // Avoid setting it to 0 as SYMPHONY may include it regardless. This value is a possible weight
		  float score      = std::numeric_limits<float>::epsilon();
		  if(FDT > 0){
			 // If collectionval is greater than 0 we can calculate an actual value.
			 score      = (float)FQT/(float)FDT;
		  }else{
			  // This way the constraint for this variables can never be chosen.
			  FDT = 1+CACHE_SIZE_IN_BYTES;
		  }
		  std::cout << "Stem: " << stem << ", Score: " << score << ", FQT: " << FQT << ", FDT: " << FDT << std::endl;

		  cache::aux::QTFDFOBJ * qtfobj = new cache::aux::QTFDFOBJ(stem, score, FQT, FDT*NUM_BYTES_PER_POSTING);
		  vals.push_back(qtfobj);
		  /* We need the colval information when we free cache space in any subsequent iteration */
		  TERM_TO_QTFDFOBJ[stem] = qtfobj;
	  }
  }

 /*
  * 03-12-2014:
  * Because we now only consider query terms occuring twice or more, the cutoff has to be adjusted.
  */
  if(cutoff > vals.size()){
	  cutoff = (int)vals.size();
  }

  /*
   * Sort. Makes no difference if cutoff=-1 is specified.
   * There is no need for FQFDT to sort for FQFDT only for Ricardo's. HOWEVER, if we specify a cutoff
   * this needs to be sorted. Put in an if-check to ensure we don't pre-sort before passing it to Ricardo's
   * method to accurately time each method
   */
  if(cutoff != vals.size()){
	  std::sort(vals.begin(), vals.end(), cache::aux::ge_queryfreq());
	  // Erase everything after the cutoff
	  vals.erase(vals.begin()+cutoff, vals.end());
  }

 /*
  * Construct the hashmap of <x?,term>. This is the mapping between
  * variables and terms that is used after solving the LP problem
  */
  int cutcounter = 0;
  std::string var = "";
  for(std::vector<cache::aux::QTFDFOBJ * >::iterator it = vals.begin(); it != vals.end(); ++it) {
      if(cutcounter < cutoff){
    	  cache::aux::QTFDFOBJ * obj   = *it;
    	  var                          = "x"+SSTR(cutcounter);
    	  cachemapping[var]            = obj->stringValue;
    	  //COP_t2qtfdf[var]             = obj;
    	  cutcounter++;
      }
  }
  cache::aux::writefile(fileformat,vals,cutoff,filename,CACHE_SIZE_IN_BYTES,false);
  cout << endl;
  cout << "***************** STEP 2 *****************" << endl;
  cout << "Found " << countQuery << " terms occurring two or more times" << endl;
  cout << "******************************************" << endl;
}


void doRicardosMethod(vector<cache::aux::QTFDFOBJ *>& v){
	  // Time sorting. clock measures the CPU clock time (see doc for time.h)
	  std::sort(v.begin(), v.end(), cache::aux::ge_score());
	  ofstream myfile;
	  myfile.open(RCACHE_FILE_INFO.c_str());

	  std::string strval = "";
	  int acc            = 0;
	  int tcounter       = 0;
	  int poscounter     = 0;
	  for(std::vector<cache::aux::QTFDFOBJ * >::iterator it = v.begin(); it != v.end(); ++it) {
		  if((acc+(*it)->colval <= CACHE_SIZE_IN_BYTES) && (tcounter <= cutoff)){
			  cache::aux::QTFDFOBJ * obj = *it;
			  strval                     = obj->stringValue;
			  cache::aux::QTFDFOBJ * t   = new cache::aux::QTFDFOBJ(obj->stringValue, (float)obj->score, obj->queryval, obj->colval);
			  QTFDF_RICARDOCACHE.insert(t);
			  ricardoCache.insert(strval);
			  acc += obj->colval; // colval is the F_d(t) times the number of bytes per posting
			  tcounter++;
			  myfile << SSTR(poscounter) << "," << obj->stringValue << "," << obj->queryval << "," << obj->colval << endl;
			  poscounter++;
		  }
	  }
	  myfile.flush();
	  myfile.close();
	  cout << endl;
	  cout << "***************** STEP 4 *****************"                          << endl;
	  cout << "Ricardo's method:       " 						 				    << endl;
	  cout << "Found.................: " << tcounter 				  << " terms"   << endl;
	  cout << "Left-over cache space.: " << (CACHE_SIZE_IN_BYTES-acc) << " bytes"   << endl;
	  cout << "Inserted..............: " << QTFDF_RICARDOCACHE.size() << " terms"   << endl;
}

void overlap(){
	// Loop over Ricardo's terms to find overlap
	std::string term;
	bool is_in;
	int intersection = 0;
	std::set<std::string>::iterator it;
	for(it = ricardoCache.begin(); it != ricardoCache.end(); ++it){
		term  = *it;
		is_in = termcache.find(term) != termcache.end();
		if(is_in){
			intersection++;
		}
	}
	/* Overlap is not "accurate" as it depends on which set we loop over. The overlap
	 * or Szymkiewicz-Simpson coefficient may be a better choice
	 */
	double overlap_coeff = intersection/((double)min(ricardoCache.size(), termcache.size()));
	cout << endl;
	cout << "***************** STEP 5 *****************" << endl;
	cout << "Found " << intersection << " terms in both caches (" << ((int) 100*((double)(intersection)/(double)(termcache.size()))) << "%)" << endl;
	cout << "Overlap coefficient............: " << overlap_coeff       << endl;
	cout << "Total terms in our cache.......: " << termcache.size()    << endl;
	cout << "Total terms in Ricardo's cache.: " << ricardoCache.size()  << endl;
	cout << endl;
}

void solveLP(std::vector<cache::aux::QTFDFOBJ *>& myvals, int CACHEVAL){

   /*
    * Load into argv-style array
    */

    std::vector<std::string> ols;
    ols.push_back("program"); // Can be anything. Does not matter

    /*
     * Uncomment and change four to specify the number of threads allocated to the problem
     */
    ols.push_back("-p");	  // see https://github.com/coin-or/SYMPHONY
    ols.push_back("1");
	ols.push_back("-L");	  // Solve files in the LP format
    ols.push_back(filename);
    cout << endl;
    cout << "***************** STEP 3 *****************" << endl;
    cout << "Solving.....: " << filename 				 << endl;
    cout << "Cache size..: " << CACHEVAL 				 << endl;
    cout << "Vals size...: " << myvals.size() 			 << endl;
	int N = (int)ols.size();
	char **cLineStrings = new char*[N];

	for (int i = 0; i < ols.size(); ++i){
		cLineStrings[i] = (char *)ols[i].c_str();
	}

  /*
   * Define the result array. Must be at least the same number of variables
   */
	double * result = new double[cutoff];

   /*
    * Set up the environment for the solver
 	*/
	sym_environment *env = sym_open_environment();
	sym_parse_command_line(env, N, cLineStrings);
	sym_load_problem(env);
	sym_set_int_param(env, "verbosity"          , -3   );
    sym_set_int_param(env, "max_axtive_nodes"   , 40   );
    sym_set_int_param(env, "node_selection_rule",  3   ); // LOWEST_LP_FIRST, 1: HIGHEST_LP_FIRST, 2: BREADTH_FIRST_SEARCH, 3: DEPTH_FIRST_SEARCH
    sym_set_dbl_param(env, "gap_limit"          , -1.0 );
    sym_set_int_param(env, "time_limit"         , -1.0 );
    sym_set_int_param(env, "find_first_feasible", FALSE);
    sym_set_int_param(env, "do_branch_and_cut"  , TRUE );
    sym_set_int_param(env, "problem_type"       ,  0   );
    sym_set_int_param(env, "prep_level"         ,  5   );

    //sym_set_int_param(env, "node_limit", -1); // No limit on the number of nodes to process
    //sym_set_int_param(env, "time_limit", -1); // No limit on the time the program can use to find a solution

    sym_solve(env);
    int termcode = sym_get_status(env);
    switch(termcode){
        case  227: std::cout << "TermCode: "  << termcode << " => TreeManager found OPTIMAL solution and stopped" << std::endl;
                   break;
        case  228: std::cout << "TermCode: "  << termcode << " => TreeManager stopped after reaching the predefined time limit" << std::endl;
                   break;
        case  229: std::cout << "TermCode: "  << termcode << " => TreeManager stopped after reaching the predefined node limit" << std::endl;
                   break;
        case  231: std::cout << "TermCode: "  << termcode << " => TreeManager stopped after reaching the predefined target gap" << std::endl;
                   break;
        case  232: std::cout << "TermCode: "  << termcode << " => TreeManager stopped after finding first feasible solution" << std::endl;
                   break;
        case -250: std::cout << "TermCode: "  << termcode << " => Error: TM stopped. User didn't select branching candidate in user_select_candidates() callback" << std::endl;
                   break;
        case -251: std::cout << "TermCode: "  << termcode << " => Error: TM stopped after getting an invalid return code" << std::endl;
                   break;
        case -252: std::cout << "TermCode: "  << termcode << " => Error: TM stopped due to some numerical difficulties" << std::endl;
                   break;
        case -253: std::cout << "TermCode: "  << termcode << " => Error: TM stopped due to communication error" << std::endl;
                   break;
        case -275: std::cout << "TermCode: "  << termcode << " => Error: TM stopped. User error detected in user callback" << std::endl;
                   break;
        case -100: std::cout << "TermCode: "  << termcode << " => Error: TM stopped. User error detected in one of several user functions" << std::endl;
                   break;
    }

    sym_get_col_solution(env,result);
    sym_close_environment(env);
    ofstream myfile;
    myfile.open(CACHE_FILE_INFO.c_str());
    int poscounter = 0;
    // Check if we have a solution at all
    Variable str = "";
    bool solutionfound  = false;
	map<std::string,                 Term  >::iterator p;
	map<std::string, cache::aux::QTFDFOBJ *>::iterator pp;
	int found_counter = 0;
    int cache_fill    = 0;
    for(int i=0; i<cutoff; i++){
		if(*(result+i) > 0){ // We have a result! Current variable is to be included
			solutionfound = true;
			// Construct variable
			str = "x"+SSTR(i);

			p  = cachemapping.find(str);
			//pp = COP_t2qtfdf.find(str);
			if ( p == cachemapping.end() ) {
			  // This should never happen!
				cout << "Something terrible has happened for term " << str << " (not found in cachemapping) after solving the LP problem! Aborting..." << endl;
				exit(EXIT_FAILURE);
			} else {
				// We have found a match. Insert the cache term
				std::string obj = p->second;
				termcache.insert(obj);
				bool iss = TERM_TO_QTFDFOBJ.find(obj) != TERM_TO_QTFDFOBJ.end();
				if(iss){
					cache_fill += TERM_TO_QTFDFOBJ[obj]->colval;
				}
				myfile << SSTR(poscounter) << "," <<  TERM_TO_QTFDFOBJ[obj]->stringValue << "," << TERM_TO_QTFDFOBJ[obj]->queryval << "," << TERM_TO_QTFDFOBJ[obj]->colval << endl;
				found_counter++;
				poscounter++;
			}
/*
			if( pp != COP_t2qtfdf.end()){
				cache::aux::QTFDFOBJ * qobj = pp->second;
				cache::aux::QTFDFOBJ * t    = new cache::aux::QTFDFOBJ(qobj->stringValue,(float)qobj->score,qobj->queryval,qobj->colval);
				QTFDF_TERMCACHE.insert(t);
			}
*/
		}
    }
    myfile.flush();
    myfile.close();
    //std::cout << "Inserted objects: " << found_counter << std::endl;
    // Determine how much of the cache the principled approached managed to fill out
    std::map<int,std::string> term_;
    int _acc = 0;
    int ctr  = 0;
	for(std::vector<cache::aux::QTFDFOBJ *>::iterator it = vals.begin(); it != vals.end(); ++it) {
		if(termcache.find((*it)->stringValue) != termcache.end()){
			term_[(*it)->colval] = (*it)->stringValue;
			ctr++;
		}
	}
	_acc = cache_fill;
	//std::cout << "Term cache size: " << termcache.size() << endl;
	//std::cout << "_acc: Found " << ctr << " terms, worth: " << _acc << " bytes "<< std::endl;

	/*
	 * Very rarely the _acc is larger. This happens if the best solution found was obtained by a relaxation of a constraint
	 * that could not be satisfied further.
	 * We remedy this by removing terms until the constraint is met
	 */

	if(_acc > CACHEVAL){
	    int diff    = _acc - CACHEVAL;
	    bool foundc = term_.find(diff) != term_.end(); /* Can we find a term with the discrepancy in the cache? */
	    if(foundc){
	        std::string offkey = term_[diff]; /* Get the term */
	        termcache.erase(offkey);	      /* Erase the term */
	        _acc -= diff;                     /* Decrement _acc */
	        found_counter--;
	    }else{
	    	/* Could not find the difference */
	    	for(int j = 1; j < 1000; j++){
	    		if((j*NUM_BYTES_PER_POSTING) >= diff){ /* Find the term with the smallest weight strictly larger than the diff in multiples of the NUM_POSTINGS_IN_BYTES size*/
	    			bool wasFound = term_.find(diff) != term_.end(); /* Can we find a term with that weight? */
	    			if(wasFound){
	    		        std::string offkey = term_[(j*NUM_BYTES_PER_POSTING)]; /* Get the term */
	    		        termcache.erase(offkey);	      /* Erase the term */
	    		        _acc -= diff;                     /* Decrement _acc */
	    		        found_counter--;
	    			   break;
	    			}
	    		}
	    	}
	    }
	}

    if(!solutionfound){
    	cout << "No variables were non-zero. No solution obtained!" << endl;
    	exit(EXIT_FAILURE);
    }
    cout << "Solution found! "													    << endl;
    cout << "Found.................: " << termcache.size()            << " terms" 	<< endl;
    cout << "Left-over cache space.: " << (CACHEVAL-_acc)             << " bytes"   << endl;
}

std::string getFileID(std::string qRn, int _cachesize){
   	std::string fileIns =  "-qindex="+qRn+"-csize="+SSTR(_cachesize)+
	           	   	   	   "-POSTING_BYTES="+SSTR(NUM_BYTES_PER_POSTING);
   	return fileIns;
}

void parse_configuration(const char * configFile){
	Configuration *  _cfg       = Configuration::create();
	const char *     _scope     = "";
	const char *     _cname     = "";
    const char *     _cachesize = "";

    try {
        _cfg->parse(configFile);
        queryRepName          = _cfg->lookupString( _scope, "queryindex"      );
        _cname                = _cfg->lookupString( _scope, "collectionindex" );
        filename              = _cfg->lookupString( _scope, "lpfilename"      );
        _cachesize 			  = _cfg->lookupString( _scope, "cachesize"       );
        CACHE_TERMS_FILE      = _cfg->lookupString( _scope, "cachefile"       );
        R_CACHE_TERMS_FILE    = _cfg->lookupString( _scope, "ricardocachefile");
        CACHE_PARM_FILE       = _cfg->lookupString( _scope, "cacheParmFile"   );
        NUM_BYTES_PER_POSTING = _cfg->lookupInt(    _scope, "postingsize"     );
        NUM_TERMS_IN_HIT      = _cfg->lookupInt(    _scope, "noftermsinhit"   );
    } catch(const ConfigurationException & ex) {
        cerr << ex.c_str() << endl;
        _cfg->destroy();
    }
    collections.push_back(_cname);
    collectionName      = _cname;
    CACHE_SIZE_IN_BYTES = atoi(_cachesize);

    std::string tmp = "";

    int idx = (int)queryRepName.find_last_of("\\/");
   	std::string qRn = queryRepName;
   	if (std::string::npos != idx){
   	    std::string fullpath(queryRepName.substr(0,idx));
   	    idx = (int)fullpath.find_last_of("\\/");
   		if (std::string::npos != idx){
   		    std::string tmp(fullpath.substr(idx+1));
   		    qRn = tmp;
   		}
   	}
   	Q_REPO 				= qRn;
   	/* Added 02-02-2015. Allows us to "reset" the qtfdf files that will print the QTFDF terms */

   	size_t lastindex           = CACHE_TERMS_FILE.find_first_of("-");
   	std::string CACHE_RAWNAME  = CACHE_TERMS_FILE.substr(0, lastindex);

   	lastindex                  = R_CACHE_TERMS_FILE.find_first_of("-");
   	std::string RCACHE_RAWNAME = R_CACHE_TERMS_FILE.substr(0, lastindex);

   	C_FILE 				= CACHE_RAWNAME;
   	R_FILE 				= RCACHE_RAWNAME;
   	std::string fileIns = getFileID(qRn, CACHE_SIZE_IN_BYTES);
   	/* Cache files */
    CACHE_TERMS_FILE    = C_FILE+fileIns+".cache";
    R_CACHE_TERMS_FILE  = R_FILE+fileIns+".cache";
    /* QTFDF files */
    QTFDF_TERMS_FILE    = C_FILE+fileIns+".qtfdf";
    QTFDF_R_TERMS_FILE  = R_FILE+fileIns+".qtfdf";

    CACHE_FILE_INFO     = C_FILE+fileIns+".stats";
    RCACHE_FILE_INFO    = R_FILE+fileIns+".stats";

    ALL_TERMS_FILE      = C_FILE+fileIns+".allterms";


    cout << endl;
    cout << "***************** INITIALISATION *****************" 	<< endl;
    cout << "Query index............: " << queryRepName 			<< endl;
    cout << "Collection index.......: " << _cname 					<< endl;
    cout << "LP file................: " << filename 				<< endl;
    cout << "Cache size (kB)........: " << CACHE_SIZE_IN_BYTES 		<< endl;
    cout << "Cache file.............: " << CACHE_TERMS_FILE 		<< endl;
    cout << "Ricardo cache file.....: " << R_CACHE_TERMS_FILE 		<< endl;
    cout << "Posting entry size (kb): " << NUM_BYTES_PER_POSTING 	<< endl;
    _cfg->destroy();
}

void process(int csize){
	  //clock_t tStart;
	  try {
	    indri::collection::Repository queryIndex;

	    // Open the index
	    queryIndex.openRead( queryRepName );

		//constructQueries( queryIndex );

	    // Calculate FQT from the query index
	    //tStart = clock();
	    calculateFQT( queryIndex );
	    //printf("F_q(t) calculated: %.2fs\n", (double)(clock() - tStart)/CLOCKS_PER_SEC);

	    // Calculate the F_d(t) and QTFDF.
	    //tStart = clock();
	    FQFDT();
	    //printf("FQFDT calculated: %.2fs\n", (double)(clock() - tStart)/CLOCKS_PER_SEC);

	    /* Solve the COP to select terms for our cache */
    	solveLP(vals, csize);

	    /* Use baseline method */
	    doRicardosMethod(vals);

    	/* Calculate the overlap between caches */
        overlap();

        /* Write the cache terms to file */
        cache::aux::writecacheterms(termcache         , CACHE_TERMS_FILE  );
  	    cache::aux::writecacheterms(ricardoCache      , R_CACHE_TERMS_FILE);
  	    //cache::aux::writeQTFDFterms(QTFDF_TERMCACHE   , QTFDF_TERMS_FILE  );
  	    //cache::aux::writeQTFDFterms(QTFDF_RICARDOCACHE, QTFDF_R_TERMS_FILE);


	    /* Write the cache parameter file */
	    cache::aux::writeCacheParameterFile(CACHE_PARM_FILE, queryRepName, CACHE_TERMS_FILE, R_CACHE_TERMS_FILE, false, countQuery, countTotalQueryHits, NUM_TERMS_IN_HIT, NOF_QUERIES);

	    /* Close the index */
	    queryIndex.close();
	  } catch( lemur::api::Exception& e ) {
	    LEMUR_ABORT(e);
	  }
}

int main( int argc, char** argv ) {
  /* Parse configuration file */
  parse_configuration(argv[1]);

  std::cout << "***************************************************************" << std::endl;
  std::cout << "*                 STARTING CACHING EXPERIMENT                 *" << std::endl;
  std::cout << "***************************************************************" << std::endl;

  /* Process */
  process(CACHE_SIZE_IN_BYTES);

  /* Evaluate */
  system("./evaluate.sh");
  return EXIT_SUCCESS;
}
