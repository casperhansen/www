#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <map>
#include <time.h>
#include <set>
#include <cmath>

#define SSTR( x ) dynamic_cast< std::ostringstream & >( \
        ( std::ostringstream() << std::dec << x ) ).str()

std::string toTrecFormat(std::string& query, int docnr){
	std::string str;
	str = str.append("<DOC>\n");
	str = str.append("<DOCNO>").append(SSTR(docnr)).append("</DOCNO>\n");
	str = str.append("<TEXT>\n");
	str = str.append(query).append("\n");
	str = str.append("</TEXT>\n");
	str = str.append("</DOC>");
	return str;
}

int main(int argc, char ** argv){
	std::string line;
	std::ifstream infile (argv[1]);

	std::ofstream outfile;
	outfile.open(argv[2]);

	int docid = 1;
	if (infile.is_open()){
	    while (getline (infile,line)) {
	    	outfile << toTrecFormat(line, docid) << std::endl;
	    	docid++;
	    }
	}
	outfile.flush();
	outfile.close();
	infile.close();
}
