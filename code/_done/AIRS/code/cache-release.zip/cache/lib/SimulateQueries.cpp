/*
 * SimulateQueries.cpp
 *
 * DO NOT USE THIS FILE ON LARGE INDEXES
 *
 */
#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <map>
#include <time.h>
#include <set>
#include <cmath>
#include <limits>
#include <iterator>
#include <config4cpp/Configuration.h>

// Initialize bi-gram map
std::map <std::string, int > BIGRAMS;
std::map <std::string, int > PRUNED_BIGRAMS;
const int BIGRAM_FREQUENCY_CUTOFF = 20;

// Initialise variables
std::string COLLECTION,OUTPUT_FILE,METHOD;
int QUERY_LENGTH;

// Integer to string
#define SSTR( x ) dynamic_cast< std::ostringstream & >( \
        ( std::ostringstream() << std::dec << x ) ).str()

// Namespaces
using namespace config4cpp;

void extractBiGrams(indri::collection::Repository& r) {
  indri::server::LocalQueryServer local(r);
  UINT64 docCount = local.documentCount();
  std::cout << std::endl;
  std::cout << "*************** Extracting bi-grams ***************" << endl;
  std::cout << "Found " << docCount << " documents" << std::endl;
/*
  std::vector<lemur::api::DOCID_T> documentIDs;
  for(int i = 0; i<docCount; i++){
	  lemur::api::DOCID_T documentID = (i+1);
	  documentIDs.push_back(documentID);
  }
  */
  int bigramcounter = 0;
  int docCounter = 0;
  std::vector<lemur::api::DOCID_T> documentIDs;
  lemur::api::DOCID_T documentID;
  for(int i=0; i<docCount; i++){
	  documentID = i+1;
	  documentIDs.push_back(documentID);
	  if((i%10000) == 0){
		  std::cout << "Completed " << i << " documents" << std::endl;
	  }
	  indri::server::QueryServerVectorsResponse* response = local.documentVectors( documentIDs );
	  if( response->getResults().size() ) {
	    indri::api::DocumentVector* docVector = response->getResults()[0];
	    bigramcounter += docVector->positions().size()-1;
/*
	    for( size_t j=0; j<docVector->positions().size()-1; j++ ) {
	      int pos1 = docVector->positions()[j];
	      int pos2 = docVector->positions()[j+1];
	      std::string stem1 = docVector->stems()[pos1];
		  std::string stem2 = docVector->stems()[pos2];
	      std::string bigram = stem1+" "+stem2;
	      //cout << "Stem1: " << stem1 << " :: Stem2: " << stem2 << " :: Bigram: " << bigram << endl;
	      if ( BIGRAMS.find(bigram) == BIGRAMS.end() ) {
	        BIGRAMS[bigram] = 1;
	      } else {
	        BIGRAMS[bigram]++;
	      }
	   }
*/
	   delete docVector;
	  }
	  docCounter++;
	  documentIDs.clear();
	  delete response;
  }
  std::cout << "Total bigrams: " << bigramcounter << endl;
/*
  std::cout << "Parsed all documents " << std::endl;
  std::cout << "Total bigrams found " << BIGRAMS.size() << std::endl;

  typedef std::map<std::string, int>::iterator itr;
  for(itr iterator = BIGRAMS.begin(); iterator != BIGRAMS.end(); iterator++) {
      std::string bg = iterator->first;
  	  int frequency  = iterator->second;
  	  if(frequency > BIGRAM_FREQUENCY_CUTOFF){
  		 PRUNED_BIGRAMS[bg]=frequency;
  	     //BIGRAMS.erase(bg);
  	  }
 }
 std::cout << "After pruning bigrams " << PRUNED_BIGRAMS.size() << std::endl;
*/
}

// Begin functions
void parse_configuration(const char * configFile){
	Configuration *  _cfg       = Configuration::create();
	const char *     _scope     = "";
	const char *     _cname     = "";
    const char *     _cachesize = "";
    const char *     _cutoff    = "";

    try {
        _cfg->parse(configFile);
        COLLECTION   = _cfg->lookupString(_scope, "collection");
        OUTPUT_FILE  = _cfg->lookupString(_scope, "output");
        METHOD       = _cfg->lookupString(_scope, "method");
        //QUERY_LENGTH = _cfg->lookupInt(_scope, "querylength");

    } catch(const ConfigurationException & ex) {
        std::cerr << ex.c_str() << std::endl;
        _cfg->destroy();
    }

    std::cout << std::endl;
    std::cout << "***************** INITIALISATION *****************" << std::endl;
    std::cout << "Collection..: " << COLLECTION << std::endl;
    std::cout << "Output file.: " << OUTPUT_FILE << std::endl;
    std::cout << "Query length: " << QUERY_LENGTH << std::endl;
    std::cout << "Method......: " << METHOD << std::endl;
    _cfg->destroy();
}

int main(int argc, char ** argv){
	// Where to sample - Some large collection
	// How to sample?  - Leif & Colin ECIR'13? Leif 2009
	// How many to sample? - Variable parameter
	// Length of queries? - Variable parameter

	/*
	 * Leif's method:
	 * 1 - Initialize the empty query set q = {}
	 * 2 - Select the document d to be the known item with probability p(d)
	 * 3 - Select the query length k with probability p(k)
	 * 4 - Repeat k times:
	 * 5 - 		Select a term t from the document model of d with probability p(t | \Sigma_d) (the topic model)
	 * 6 - 		Add t to the query set q
	 * 7 - Record d and q to define the known-item query set
	 *
	 * Step 2 -> p(d) can be set to be uniform.
	 * Step 3 -> p(k) /can/ be selected by fitting
	 * Step 5 -> p(t | \Sigma_d) = (1-\lambda)p(t|d) + \lambda p(t)
	 *           - p(t) = is the probability of t in the collection.
	 *           - p(t | \Sigma_d) = three different options -- see Query Side Evaluation
	 *
	 * Leif's ECIR2014 method (Efficiently Estimating Retrievability Bias):
	 * 1 - Extract bigrams from some collections, and keep only those occurring more than k = 20 times
	 */
	parse_configuration(argv[1]);

    indri::collection::Repository index;
    // Open the index
    index.openRead( COLLECTION );
    if(METHOD.compare("simple") == 0){
    	extractBiGrams(index);
    }else{

    }
	index.close();
}

