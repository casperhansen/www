#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <map>
#include <set>
#include <boost/regex.hpp>
boost::regex expression("<TEXT>(.*)</TEXT>");
boost::smatch match;

void printIndex( indri::collection::Repository& r, char * pw) {
	  indri::collection::Repository::index_state state = r.indexes();
	  indri::collection::CompressedCollection* collection = r.collection();
	  indri::index::Index* index = (*state)[0];
	  UINT64 totalDocs = index->documentCount();
	  int j = 0;
	  std::ofstream outfile;
	  outfile.open(pw);
	  for(UINT64 i = 1; i <= totalDocs; i++){
		  if((j+1) % 10000 == 0){
			  std::cout << "Parsed " << (j+1) << " docs" << std::endl;
		  }
			 // We have found a one-word query. Now we need to get it
			  indri::api::ParsedDocument* document = collection->retrieve( i );
			  std::string content = document->text;
			  //std::cout << content << endl;
			  if (boost::regex_search(content, match, expression)){
				  outfile << std::string(match[1].first, match[1].second) << endl;
				  //querySet.insert(std::string(match[1].first, match[1].second));
				  //queries.push_back(std::string(match[1].first, match[1].second));
			  }else{
				  cout << "Did not find a match for  " << content << endl;
				  exit(EXIT_FAILURE);
			  }
			  delete document;
	  }
	  outfile.flush();
	  outfile.close();
}


int main(int argc, char ** argv){
	/*
	 * First argument is the location of the index
	 * Second argument is the location of where the printed index should be put.
	 *
	 * This file is ONLY intended to be used for 1word queries experimented with as part of the sigir2015
	 * cache paper. Use at own risk otherwise.
	 *
	 * The file prints the TEXT part of all Indri postings.
	 */
    indri::collection::Repository index;
    index.openRead(        argv[1] );
    printIndex(     index, argv[2] );
    index.close();
	return EXIT_SUCCESS;
}
