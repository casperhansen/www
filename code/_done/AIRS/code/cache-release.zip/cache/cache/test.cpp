/*
 * cache.cpp
 *
 *  Created on: Nov 24, 2014
 *      Author: casper
 */
#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include "indri/Transformation.hpp"
#include "indri/NormalizationTransformation.hpp"
#include "indri/UTF8CaseNormalizationTransformation.hpp"
#include "indri/UTF8Transcoder.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <set>
#include <map>
#include <algorithm>
#include <boost/regex.hpp>
#include <config4cpp/Configuration.h>
#include "../include/aux.hpp"
std::vector<indri::parse::Transformation*> _transformations;
std::set<std::string> termsSeen;
std::string TERM_FILE_OURS;
std::string TERM_FILE_RICARDO;
std::string INDEX;
std::set<std::string> CACHE, RCACHE;
bool useAlt;
int countQueries, totalhits, HITS_REQ, OUR_CACHE_HIT, RICARDO_CACHE_HIT;

string startDEL = "<TEXT>";
string stopDEL =  "</TEXT>";
boost::regex expression("<TEXT>(.*)</TEXT>");
boost::smatch match;

using namespace config4cpp;

/*
 * 08-12-2014: Added noftermsprhit. This parameter specified the number of terms per query
 *             that must be matched in the cache before we say there is a hit.
 */


void cacheMatch(std::vector<std::string> query, bool ours){
	std::vector<std::string>::iterator it;
	// How many terms is in the query?
	int querylen               = query.size();
	int termhits               = 0;
	bool cont                  = true;
	// Loop over individual query words
	for(it = query.begin(); it != query.end(); ++it){
		if(!cont){
			break; // Exit current query
		}
		//const bool is_in = CACHE.find(*it) != CACHE.end();
		bool is_in;
		if(ours){
			is_in = CACHE.find(*it) != CACHE.end();
		}else{
			is_in = RCACHE.find(*it) != RCACHE.end();
		}
    	if(is_in){
    		termhits++;
    		    // We have matched the correct number of terms
    		if(termhits == HITS_REQ){
    			if(ours){
    				OUR_CACHE_HIT++;
    			}else{
    				RICARDO_CACHE_HIT++;
    			}
    		    cont = false;
    			break;
    		}else{
    			//termhits is smaller than the hits req. Need to check that the query has more terms
    			if(termhits == querylen){
    			   /*
    			    * We have hit as many terms as there is in the query.
    			    * In other words, the specified minimum number of hits is larger than the query length
    			    */
    				//cache_hit_counter++;
        			if(ours){
        				OUR_CACHE_HIT++;
        			}else{
        				RICARDO_CACHE_HIT++;
        			}
    				cont = false;
    				break;
    			}else{
    			   /*
    			    * We have a term hit but there are more terms to consider
    			    */
    			}
    		}
    	}else{
    		// Term not in cache
    	}
	}
}


void parse_configuration(const char * configFile){
	Configuration *  _cfg       = Configuration::create();
	const char *     _scope     = "";
    try {
        _cfg->parse(configFile);
        TERM_FILE_OURS    = _cfg->lookupString(_scope, "ourMethod");
        TERM_FILE_RICARDO = _cfg->lookupString(_scope, "ricardoMethod");
        INDEX     		  = _cfg->lookupString(_scope, "index");
        useAlt			  = _cfg->lookupBoolean(_scope, "useAlt");
        countQueries      = _cfg->lookupInt(_scope, "queries");
        totalhits         = _cfg->lookupInt(_scope, "totalhits");
        HITS_REQ          = _cfg->lookupInt(_scope, "noftermsprhit");

    } catch(const ConfigurationException & ex) {
        cerr << ex.c_str() << endl;
        _cfg->destroy();
    }

    cout << endl;
    cout << "***************** INITIALISATION *****************" << endl;
    cout << "Term file (ours): " << TERM_FILE_OURS << endl;
    cout << "Term file (Ricardo): " << TERM_FILE_RICARDO << endl;
    cout << "Index: " << INDEX << endl;
    cout << "useAlt: " << useAlt << endl;
    cout << "queries: " << countQueries << endl;
    cout << "total hits: " << totalhits << endl;
    _cfg->destroy();
}

/*
 * Loads the cache (HashSet) with the terms from the file specified in the configuration file.
 */

void loadCache(std::string cachef){
	  std::string line;
	  std::ifstream myfile (cachef.c_str());
	  int our_querycounter,r_querycounter,linecounter = 0;
	  if (myfile.is_open()){
		  while (getline (myfile,line)) {
			  line = cache::aux::fixString(line);
			  CACHE.insert(line);
			  our_querycounter++;
		  }
		  myfile.close();
	  }else{
		  cout << "Unable to open file" << endl;
		  exit(EXIT_FAILURE);
	  }
   	  cout << CACHE.size()  << " queries loaded into our cache ("<< linecounter << ")" << endl;
}

void _doCacheExperiment(){
	indri::collection::Repository r;
	r.openRead("/home/casper/indexes/msn1wordqueries/");
    indri::collection::Repository::index_state state = r.indexes();

    std::set<std::string>::iterator cacheit;
    std::string stem;
    for(cacheit = CACHE.begin(); cacheit != CACHE.end(); ++cacheit){
        indri::index::Index* index = (*state)[0];
        indri::thread::ScopedLock( index->iteratorLock() );
        stem = r.processTerm(*cacheit);
        indri::index::DocListIterator* iter = index->docListIterator( stem );
        if (iter == NULL){
        	continue;
        }

        iter->startIteration();

        int doc = 0;
        indri::index::DocListIterator::DocumentData* entry;

        for( iter->startIteration(); iter->finished() == false; iter->nextEntry() ) {
          entry = iter->currentEntry();
          doc++;
        }

    	std::size_t found = stem.find("fabl");
    	if (found!=std::string::npos)
    	    std::cout << stem << "," << doc << std::endl;

        OUR_CACHE_HIT += doc;
        delete iter;
    }
    std::cout << "Using processTerm there were: " << OUR_CACHE_HIT << " hits!" << std::endl;

/*
    indri::collection::CompressedCollection* collection = r.collection();
    UINT64 docCount = local.documentCount();
    for(int documentID = 0; documentID < docCount; documentID++){
        indri::api::ParsedDocument* document = collection->retrieve( documentID + 1 );
        std::string ss = document->getContent();
        if (boost::regex_search(document->getContent(), match, expression)){
        	std::string str = std::string(match[1].first, match[1].second);
        	str = cache::aux::fixString(str);

        	std::string stem = r.processTerm( str );
        	std::size_t found = str.find("fabl");
        	if (found!=std::string::npos)
        	    std::cout << str << std::endl;
        	bool is_in = CACHE.find(stem) != CACHE.end();
        	if(is_in){
        		OUR_CACHE_HIT++;
        	}
        }
    }

*/
    r.close();
}

void doCacheExperiment(){
    indri::collection::Repository r;
    r.openRead( INDEX );
    std::map<std::string, int> myMap;
    indri::server::LocalQueryServer local(r);
    indri::collection::CompressedCollection* collection = r.collection();
    UINT64 docCount = local.documentCount();
    std::cout << std::endl;
    std::cout << "INFO: Iterating over " << docCount << " documents" << std::endl;
    int cache_hit_counter = 0;
    for(int documentID = 0; documentID < docCount; documentID++){
        indri::api::ParsedDocument* document = collection->retrieve( documentID + 1 );
        std::string ss = document->getContent();
        if (boost::regex_search(document->getContent(), match, expression)){
        	std::string str = std::string(match[1].first, match[1].second);
        	str = cache::aux::fixString(str);
        	bool is_in = CACHE.find(str) != CACHE.end();
        	std::size_t found = str.find("fabl");
        	if (found!=std::string::npos)
        	    std::cout << str << found << std::endl;
        	if(is_in){
        		OUR_CACHE_HIT++;
        		if(myMap.find(str) != myMap.end()){
        		   myMap[str]++;
        		}else{
        		   myMap[str] = 1;
        		}
        	}
        	//std::cout << str << endl;
        	//std::vector<std::string> query;
        	// We split the query on whitespaces (to allow multi-word queries to matches against the cache
        	//cache::aux::split(str,' ', query);
        	//cacheMatch(query, true);
        	//cacheMatch(query, false);
        }else{
        	std::cout << "No match" << std::endl;
        }
        delete document;
    }
    std::cout << "****************** STATUS ******************" << std::endl;
    std::cout << "Processed: " << countQueries << ", totaling " << totalhits << " hits" << std::endl;
    std::cout << "Hits in our cache: " << OUR_CACHE_HIT << std::endl;
    r.close();
/*
    std::map<std::string, int>::iterator it;
    for(it = myMap.begin(); it != myMap.end(); ++it){
    	std::cout << (*it).first << "," << (*it).second << endl;
    }
*/
}

struct QTFDFOBJ
{
	double score;
	std::string stringValue;
	int queryval;
	int colval;

	QTFDFOBJ(const std::string& s, double k, int qval, int collectionval) : score(k), stringValue(s), queryval(qval), colval(collectionval) {}
	QTFDFOBJ() : score(), stringValue(), queryval(), colval() {};
/*
	bool operator < (const QTFDFOBJ& str) const
	{
		return (score > str.score);
	}
*/
};




int main(int argc, char ** argv){

    indri::collection::Repository r;
    r.openRead( "/home/casper/indexes/msn1wordqueries/" );
    int f[3] = {13119,152829,152830};
    //r.openRead( "/home/casper/indexes/test2/" );
    indri::server::LocalQueryServer local(r);
    indri::collection::Repository::index_state state = r.indexes();
    indri::index::Index* index = (*state)[0];

    UINT64 docCount = 3;//local.documentCount();
    std::vector<lemur::api::DOCID_T> documentIDs;
    for(int i = 0; i < docCount; i++){
    	lemur::api::DOCID_T documentID = f[i];
        documentIDs.push_back(documentID);
        indri::server::QueryServerVectorsResponse* response = local.documentVectors( documentIDs );

        if( response->getResults().size() ) {
            indri::api::DocumentVector* docVector = response->getResults()[0];
            for( size_t i=0; i<docVector->positions().size(); i++ ) {
              int position = docVector->positions()[i];
              const std::string& stem = docVector->stems()[position];

              std::cout << i << " " << position << " " << stem << std::endl;
            }

            delete docVector;
          }

        delete response;
    	documentIDs.clear();
    }


/*
    indri::thread::ScopedLock( index->iteratorLock() );
    indri::collection::CompressedCollection* collection = r.collection();
    boost::regex re("[\\s\n\t]+"); // The split tokens
   	std::vector< std::string > terms;

    _transformations.push_back( new indri::parse::NormalizationTransformation() );
    _transformations.push_back( new indri::parse::UTF8CaseNormalizationTransformation() );

    indri::index::DocListFileIterator* iter = index->docListFileIterator();
    iter->startIteration();
      int docNr = 1;
      while( !iter->finished() ) {
    	std::cout << "DocNr " << docNr << std::endl;
    	std::cout << std::endl;
        indri::index::DocListFileIterator::DocListData* entry = iter->currentEntry();
        entry->iterator->startIteration();

        while( !entry->iterator->finished() ) {
              indri::index::DocListIterator::DocumentData* doc = entry->iterator->currentEntry();
              std::cout << "\t" << doc->document << " " << doc->positions.size();
              for( size_t i=0; i<doc->positions.size(); i++ ) {
                std::cout << " " << doc->positions[i];
              }
              std::cout << std::endl;

              entry->iterator->nextEntry();
        }

        iter->nextEntry();
        docNr++;
      }
      delete iter;
*/
/*
    for(int i = 0; i < 3; i++){
    	indri::api::ParsedDocument* document = collection->retrieve( f[i] );
    	//std::cout << document->text << std::endl;
    	if (boost::regex_search(document->getContent(), match, expression)){
    	   	std::string str = std::string(match[1].first, match[1].second);
    	   	std::string stem = cache::aux::fixString(str);
    	   	//std::cout << str2 << std::endl;
    	   	std::vector<std::string> terms;
    	    boost::sregex_token_iterator i(stem.begin(), stem.end(), re, -1);
    	    boost::sregex_token_iterator j;
    	    while (i != j) {
    	         //std::cout << *i << std::endl;
    	    	 //terms.push_back(*i++);
    	    	  std::string t = *i;
    	    	  string s = r.processTerm(t);
    	    	  std::cout << s << std::endl;
    	    	  i++;
    	    }
    	}
    }

*/
/*
	std::map<int, Dummy> Map;
    Dummy DummyInstance = { 1 };

	std::map<string, QTFDFOBJ> myMap;

	std::string tmp[10];

	for(int i = 0; i < 10; i++){
		tmp[i] = "x"+SSTR(i);
	}

	for(int j = 0; j < 10; j++){
		myMap[tmp[j]] = QTFDFOBJ(tmp[j],1.2,j+1,j+2);
	}

	std::map<std::string, QTFDFOBJ>::iterator it;
	for(it = myMap.begin(); it != myMap.end(); ++it){
		QTFDFOBJ ob     = it->second;
		std::cout << it->first << ", " << ob.stringValue << ", " << ob.score << ", " << ob.queryval << ", " << ob.colval << std::endl;
	}
*/
    //map["b"] = cache::aux::QTFDFOBJ("b",0.2,2,2);
    //map["c"] = cache::aux::QTFDFOBJ("c",0.3,3,3);

/*
	if(argc != 2){
		cout << "A parameter file specifying the term file and the index must be specified " << endl;
		exit(EXIT_FAILURE);
	}
	parse_configuration(argv[1]);
	std::cout << endl;
	std::cout << "*****************************************" << endl;
	std::cout << "*             Method results            *" << endl;
	std::cout << "*****************************************" << endl;
	loadCache(TERM_FILE_OURS);
	//loadCache(TERM_FILE_RICARDO, false);
    std::cout << "***** -> CACHE \"WARM UP\" COMPLETED <- *****" << endl;
	_doCacheExperiment();
	std::cout << "*****************************************" << endl;
*/
	return EXIT_SUCCESS;
}
