/*
 * cache.cpp
 *
 *  Created on: Nov 24, 2014
 *      Author: casper
 */
#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <set>
#include <algorithm>
#include <config4cpp/Configuration.h>
#include "../include/aux.hpp"
std::set<std::string> termsSeen;
std::string TERM_FILE_OURS;
std::string TERM_FILE_RICARDO;
std::string INDEX;
std::set<std::string> CACHE, RCACHE;
indri::collection::Repository r;
bool useAlt;
int countQueries, totalhits, HITS_REQ, OUR_CACHE_HIT, RICARDO_CACHE_HIT, OUR_TOTAL_QUERIES, RICARDO_TOTAL_QUERIES, TOTAL_QUERIES = 0;

string startDEL = "<TEXT>";
string stopDEL =  "</TEXT>";
//boost::regex expression("<TEXT>(.*)</TEXT>");
//boost::smatch match;

using namespace config4cpp;

void matchQueryAgainstCache(std::vector<std::string>& query){
	std::vector<std::string>::iterator it;
    std::string qt;

    int querylen               = query.size();
	int termhits               = 0;
	for(it = query.begin(); it != query.end(); ++it){
		qt = *it;
		qt = cache::aux::fixString(qt);
		qt = r.processTerm(qt);
		bool is_in = CACHE.find(qt) != CACHE.end();
		if(is_in){
		   termhits++;
		   if(termhits == HITS_REQ){
			  // We have a query hit!
			   //std::cout << "Ours: Matched \"" << qt << "\" in query" << std::endl;
			   OUR_CACHE_HIT++;
			  /* Break from for loop*/
			  break;
		   }else{
			  /* We found a term in the cache, but need more hits before we have a cache hit*/
		   }
		}else{
			/* qt not found in the cache */
		}
	}
	/* Do the same thing for terms in baseline cache -- reset termhits */
	termhits               = 0;
	for(it = query.begin(); it != query.end(); ++it){
		qt = *it;
		qt = cache::aux::fixString(qt);
		qt = r.processTerm(qt);
		bool is_in = RCACHE.find(qt) != RCACHE.end();
		if(is_in){
		   termhits++;
		   if(termhits == HITS_REQ){
			  // We have a query hit!
			   RICARDO_CACHE_HIT++;
			   //std::cout << "Ricardo's: Matched \"" << qt << "\" in query" << std::endl;
			  /* Break from for loop*/
			  break;
		   }else{
			  /* We found a term in the cache, but need more hits before we have a cache hit*/
		   }
		}else{
			/* qt not found in the cache */
		}
	}
}

/*
 * 08-12-2014: Added noftermsprhit. This parameter specified the number of terms per query
 *             that must be matched in the cache before we say there is a hit.
 */
void parse_configuration(const char * configFile){
	Configuration *  _cfg       = Configuration::create();
	const char *     _scope     = "";
    try {
        _cfg->parse(configFile);
        TERM_FILE_OURS    = _cfg->lookupString(_scope, "ourMethod");
        TERM_FILE_RICARDO = _cfg->lookupString(_scope, "ricardoMethod");
        INDEX     		  = _cfg->lookupString(_scope, "index");
        useAlt			  = _cfg->lookupBoolean(_scope, "useAlt");
        countQueries      = _cfg->lookupInt(_scope, "queries");
        totalhits         = _cfg->lookupInt(_scope, "totalhits");
        HITS_REQ          = _cfg->lookupInt(_scope, "noftermsprhit");
        TOTAL_QUERIES     = _cfg->lookupInt(_scope, "queriestotal");
    } catch(const ConfigurationException & ex) {
        cerr << ex.c_str() << endl;
        _cfg->destroy();
    }

    cout << endl;
    cout << "***************** INITIALISATION *****************" << endl;
    cout << "Term file (ours): " << TERM_FILE_OURS << endl;
    cout << "Term file (Ricardo): " << TERM_FILE_RICARDO << endl;
    cout << "Index: " << INDEX << endl;
    cout << "useAlt: " << useAlt << endl;
    cout << "queries: " << countQueries << endl;
    cout << "Total queries: " << TOTAL_QUERIES << endl;
    cout << "total hits: " << totalhits << endl;
    _cfg->destroy();
}

/*
 * Loads the cache (HashSet) with the terms from the file specified in the configuration file.
 */

void loadCache(std::string cachef, bool is_ours){
	  std::string line;
	  std::ifstream myfile (cachef.c_str());
	  int our_querycounter,r_querycounter,linecounter = 0;
	  if (myfile.is_open()){
		  while (getline (myfile,line)) {
			  line = cache::aux::fixString(line);
			  if(is_ours){
				  CACHE.insert(line);
				  our_querycounter++;
				  //std::cout << "Inserted " << line << " into our cache" << std::endl;
			  }else{
				  RCACHE.insert(line);
				  r_querycounter++;
				  //std::cout << "Inserted " << line << " into Ricardo's cache" << std::endl;
			  }
			  linecounter++;
		  }
		  myfile.close();
	  }else{
		  cout << "Unable to open file" << endl;
		  exit(EXIT_FAILURE);
	  }
      if(is_ours){
    	  cout << CACHE.size()  << " terms loaded into our cache ("<< linecounter << ")" << endl;
    	  OUR_TOTAL_QUERIES = linecounter;
      }else{
    	  cout << RCACHE.size() << " terms loaded into Ricardo's cache ("<< linecounter << ")" << endl;
    	  RICARDO_TOTAL_QUERIES = linecounter;
      }
}

void _doCacheExperiment(){
    r.openRead( INDEX );
    indri::server::LocalQueryServer local(r);
    indri::collection::Repository::index_state state = r.indexes();
    UINT64 docCount = local.documentCount();
    int op = 5*(int)floor(docCount/100.0);
    if(op == 0){
       op = 1;
    }
    std::vector<lemur::api::DOCID_T> documentIDs;
    for(int i = 0; i < docCount; i++){
    	lemur::api::DOCID_T documentID = (i+1);
        documentIDs.push_back(documentID);
        // Fetch the query (a list of terms)
        indri::server::QueryServerVectorsResponse* response = local.documentVectors( documentIDs );

        if( response->getResults().size() ) {
        	std::vector< std::string > query;
            indri::api::DocumentVector* docVector = response->getResults()[0];
            // Assemble the terms to a query
            for( size_t i=0; i<docVector->positions().size(); i++ ) {
              int position = docVector->positions()[i];
              std::string& stem = docVector->stems()[position];
              query.push_back(stem);
            }
            delete docVector;
            matchQueryAgainstCache(query);

            if((i % op) == 0){
            	std::cout << cache::aux::getTime() << " - Completed " << (i+1) << " queries " << std::endl;
            }
        }
        delete response;
    	documentIDs.clear();
    }
    r.close();
    std::cout << "COMPLETE!" << endl;std::cout << endl;

    std::cout << "**************************** Results ****************************"                                     << std::endl;
    std::cout << "Total number of queries in the query log....................: " << TOTAL_QUERIES                       << std::endl;
    std::cout << "Number of queries occurring more than twice in the query log: " << countQueries                        << std::endl;
    std::cout << "The " << countQueries << " queries would generate............................: " << totalhits << " hits in total"   << std::endl;
    std::cout << "Our cache was loaded with:..................................: " << OUR_TOTAL_QUERIES << " terms"       << std::endl;
    std::cout << "Ricardo's cache was loaded with.............................: " << RICARDO_TOTAL_QUERIES << " terms"   << std::endl;
    std::cout << "Query hits (our method).....................................: " << OUR_CACHE_HIT                       << std::endl;
    std::cout << "Query hits (Ricardo's method)...............................: " << RICARDO_CACHE_HIT                   << std::endl;
    std::cout << "Difference..................................................: " << (OUR_CACHE_HIT - RICARDO_CACHE_HIT) << std::endl;
}

int main(int argc, char ** argv){
	if(argc != 2){
		cout << "A parameter file specifying the term file and the index must be specified " << endl;
		exit(EXIT_FAILURE);
	}
	parse_configuration(argv[1]);
	std::cout << endl;
	std::cout << "*****************************************" << endl;
	std::cout << "*             Method results            *" << endl;
	std::cout << "*****************************************" << endl;
	loadCache(TERM_FILE_OURS,    true );
	loadCache(TERM_FILE_RICARDO, false);
	std::cout << std::endl;
    std::cout << "*****************************************" << endl;
    std::cout << "*       Firing queries at index...      *" << endl;
    std::cout << "*****************************************" << endl;
	_doCacheExperiment();
	std::cout << "*****************************************" << endl;

	return EXIT_SUCCESS;
}
