#!/bin/bash
./cache/cache /home/casper/cachefile.parm
