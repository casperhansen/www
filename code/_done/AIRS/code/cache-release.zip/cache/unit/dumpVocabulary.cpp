/*
 * dumpVocabulary.cpp
 *
 * Dumps the vocabulary of an INDEX to a FILE both specified by arguments to the program.
 *
 * Input:
 * INDEX - Absolute path to an Indri index
 * FILE  - Absolute path to output file.
 *
 * Usage:
 * ./dumpVocabulary /home/tmp/index/ /home/tmp/out.txt
 *
 *  Created on: Apr 23, 2015
 *      Author: casper
 */

#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <map>
#include <time.h>
#include <set>
#include <cmath>
#include <cstring>
#include <limits>
#include <iterator>
#include "../include/aux.hpp"

/**
 * Extracts the vocabulary of a repository and counts the number of documents each term in the vocabulary
 * is a part of.
 *
 * This function outputs F_q(t) as pairs of <query, count>
 *
 * The repository is assumed to be the query repository, and returns, for each term in each query:
 * (a) the term and (b) the number of queries (documents more generally) the term is found in.
 * Notice that we assume that there are no empty queries. Empty queries will cause undefined behaviour.
 *
 */

// Integer to string
#define SSTR( x ) dynamic_cast< std::ostringstream & >( \
        ( std::ostringstream() << std::dec << x ) ).str()

void dumpVocabulary( indri::collection::Repository& r, const char * filename ) {
  indri::collection::Repository::index_state state = r.indexes();
  indri::index::Index* index = (*state)[0];
  /* The vocabularyIterator iterates over the unique terms in the index */
  indri::index::VocabularyIterator* iter = index->vocabularyIterator();
  iter->startIteration();
  int vcounter = 0;
  /**
   * Loop over the vocabulary. I.e. all the query terms
   */
  ofstream myfile;
  myfile.open (filename);

  while( !iter->finished() ) {
    indri::index::DiskTermData* entry = iter->currentEntry();
    indri::index::TermData* termData = entry->termData;

    myfile << termData->term << std::endl;
	iter->nextEntry();
	vcounter++;
	if((vcounter % 1000000) == 0){
		std::cout << "Finished processing " << SSTR(vcounter) << " terms" << std::endl;
	}
  }
  myfile.flush();
  myfile.close();
  std::cout << "Finished processing. Counted " << SSTR(vcounter) << " terms" << std::endl;
  delete iter;

}

int main( int argc, char** argv ) {
    indri::collection::Repository collection;

    // Open the index
    collection.openRead( argv[1] );
    // Dump the index
    dumpVocabulary(collection, argv[2]);
    // Close the index
    collection.close();
    return EXIT_SUCCESS;
}
