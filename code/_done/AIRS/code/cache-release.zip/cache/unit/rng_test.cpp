#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include <config4cpp/Configuration.h>
#include <boost/random/linear_congruential.hpp>      /* PRNGs                   Boost  */
#include <boost/random/uniform_int.hpp>              /* PRNGs                   Boost  */
#include <boost/random/uniform_real.hpp>             /* PRNGs                   Boost  */
#include <boost/random/variate_generator.hpp>        /* PRNGs                   Boost  */
#include <boost/filesystem.hpp>
#include "../include/aux.hpp"

double fRand(double fMin, double fMax)
{
    double f = (double)rand() / (RAND_MAX + 1.0);
    return fMin + f * (fMax - fMin);
}

int main(int argc, char ** argv){
	srand (time(NULL));
	int c = 0;
	double threshold = 0.44;
	for(int i = 0; i < 1000000; i++){
/*
		double p = (double)rand()/((double)RAND_MAX + 1.);
		while(p == 0.0){
			   p = (double)rand()/((double)RAND_MAX + 1.);
		}
*/
		double p = fRand(0.0, 0.75);
		if(p > threshold) c++;
		if(p > 0.75) std::cerr << "KILL!" << std::endl; exit(EXIT_FAILURE);
    }
	std::cout << c << std::endl;
	exit(EXIT_FAILURE);
}
