#include <iostream>
#include <string>
#include <sstream>
#include <algorithm>
#include <iterator>
#include <vector>
#include <boost/algorithm/string.hpp>
#include <boost/regex.hpp>

using namespace std;

int main() {
    // Compile: g++ -std=c++11 stringsplit_test.cpp -lboost_system -lboost_regex -o stringsplit_test
    string sentence = "And I       feel fine...";
    istringstream iss(sentence);
    copy(istream_iterator<string>(iss),
         istream_iterator<string>(),
         ostream_iterator<string>(cout, "\n"));

    vector<string> tokens{istream_iterator<string>{iss},
                          istream_iterator<string>{}};
    std::vector< std::string >::iterator it;
    for(it = tokens.begin(); it != tokens.end(); ++it){
    	std::cout << *it << std::endl;
    }

    std::cout << "Boost::split" << std::endl;

    std::vector<std::string> strs;
    boost::split(strs, sentence, boost::is_any_of("\t\n "));
    std::vector< std::string >::iterator itr;
    for(itr = strs.begin(); itr != strs.end(); ++itr){
    	std::cout << *itr << std::endl;
    }

    std::cout << "Boost::regexp" << std::endl;

    boost::regex re("[\\s\n\t]+");
    boost::sregex_token_iterator i(sentence.begin(), sentence.end(), re, -1);
    boost::sregex_token_iterator j;
      while (i != j) {
         std::cout << *i++ << std::endl;
      }
}
