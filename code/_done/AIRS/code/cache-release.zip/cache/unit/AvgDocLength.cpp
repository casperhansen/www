#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <set>
#include <map>
#include <algorithm>
#include <ctime>
#include "../include/aux.hpp"

int main(int argc, char ** argv){
    indri::collection::Repository r;
    r.openRead( argv[1] );
    indri::collection::Repository::index_state state = r.indexes();
    indri::index::Index* index = (*state)[0];
    std::string filename = "/home/casper/cweb09.doclengths";
	ofstream myfile;
	myfile.open(filename.c_str());
    indri::server::LocalQueryServer local(r);
    UINT64 docCount = local.documentCount();
    std::cout << "Found " << docCount << " documents" << std::endl;


    for(int i = 0; i < docCount; i++){
    	myfile << index->documentLength( (i+1) ) << std::endl;

    	if((i+1) % 100000 == 0){
    		time_t rawtime;
    		  struct tm * timeinfo;
    		  char buffer[80];

    		  time (&rawtime);
    		  timeinfo = localtime(&rawtime);

    		  strftime(buffer,80,"%d-%m-%Y %I:%M:%S",timeinfo);
    		  std::string str(buffer);

    		std::cout << str << " :: Parsed " << (i+1) << " documents" << std::endl;
    	}
    }
    myfile.close();
    r.close();
}
