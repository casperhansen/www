/*
 * cache.cpp
 *
 *  Created on: Nov 24, 2014
 *      Author: casper
 */
#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <set>
#include <algorithm>
#include <boost/regex.hpp>
#include <config4cpp/Configuration.h>
#include "../include/aux.hpp"
std::set<std::string> termsSeen;
std::string TERM_FILE_OURS;
std::string TERM_FILE_RICARDO;
std::string INDEX;
std::set<std::string> CACHE, RCACHE;
indri::collection::Repository r;
bool useAlt;
int countQueries, totalhits, HITS_REQ, OUR_CACHE_HIT, RICARDO_CACHE_HIT, OUR_TOTAL_QUERIES, RICARDO_TOTAL_QUERIES, TOTAL_QUERIES = 0;

int ourZeroCounter        = 0;
int ricZeroCounter        = 0;
int ourOneCounter         = 0;
int ricOneCounter         = 0;
int ourTwoCounter         = 0;
int ricTwoCounter         = 0;
int ourThreeCounter       = 0;
int ricThreeCounter       = 0;
int ourFourCounter 		  = 0;
int ricFourCounter 		  = 0;
int ourFiveCounter 		  = 0;
int ricFiveCounter 		  = 0;
int ourSixCounter 		  = 0;
int ricSixCounter 		  = 0;
int ourSevenOrMoreCounter = 0;
int ricSevenOrMoreCounter = 0;
int ourTotalCounter       = 0;
int ricTotalCounter       = 0;
int OUR_SPILL_TERM_CTR    = 0;
int RIC_SPILL_TERM_CTR    = 0;

using namespace config4cpp;

void overlap(std::vector<std::string>& query){

    std::vector<std::string>::iterator it;
	int ourCounter = 0;
	int ricCounter = 0;
	std::string qt;

	for(it = query.begin(); it != query.end(); ++it){
		qt = *it;
		qt = cache::aux::fixString(qt);
		qt = r.processTerm(qt);
    	bool our_is_in = CACHE.find(qt) != CACHE.end();   /* FOUND */
    	bool ric_is_in = RCACHE.find(qt) != RCACHE.end(); /* FOUND */
    	if(our_is_in){
    		ourCounter++;
    	}
    	if(ric_is_in){
    		ricCounter++;
    	}
    }
	switch(ourCounter){
		case 0:  ourZeroCounter++;        break;
		case 1:  ourOneCounter++;         break;
		case 2:  ourTwoCounter++;   	  OUR_SPILL_TERM_CTR++;   break;
		case 3:  ourThreeCounter++; 	  OUR_SPILL_TERM_CTR +=2; break;
		case 4:  ourFourCounter++;  	  OUR_SPILL_TERM_CTR +=3; break;
		case 5:  ourFiveCounter++;  	  OUR_SPILL_TERM_CTR +=4; break;
		case 6:  ourSixCounter++;   	  OUR_SPILL_TERM_CTR +=5; break;
		default: ourSevenOrMoreCounter++; OUR_SPILL_TERM_CTR +=6; break;
	}

	switch(ricCounter){
		case 0: ricZeroCounter++;         break;
		case 1: ricOneCounter++;          break;
		case 2: ricTwoCounter++;          RIC_SPILL_TERM_CTR++;   break;
		case 3: ricThreeCounter++;        RIC_SPILL_TERM_CTR +=2; break;
		case 4: ricFourCounter++;         RIC_SPILL_TERM_CTR +=3; break;
		case 5: ricFiveCounter++;         RIC_SPILL_TERM_CTR +=4; break;
		case 6: ricSixCounter++;          RIC_SPILL_TERM_CTR +=5; break;
		default: ricSevenOrMoreCounter++; RIC_SPILL_TERM_CTR +=6; break;
	}
}

/*
 * Loads the cache (HashSet) with the terms from the file specified in the configuration file.
 */

void loadCache(std::string cachef, bool is_ours){
	  std::cout << cachef << std::endl;
	  std::string line;
	  std::ifstream myfile (cachef.c_str());
	  int our_querycounter,r_querycounter,linecounter = 0;
	  if (myfile.is_open()){
		  while (getline (myfile,line)) {
			  std::vector<std::string> tokens;
			  cache::aux::split(line, ',', tokens);
			  std::string token = tokens.at(0);
			  token = cache::aux::fixString(token);
			  if(is_ours){
				  CACHE.insert(token);
				  our_querycounter++;
				  //std::cout << "Inserted " << token << " into our cache" << std::endl;
			  }else{
				  RCACHE.insert(token);
				  r_querycounter++;
				  //std::cout << "Inserted " << token << " into Ricardo's cache" << std::endl;
			  }
			  linecounter++;
		  }
		  myfile.close();
	  }else{
		  cout << "Unable to open file" << endl;
		  exit(EXIT_FAILURE);
	  }
      if(is_ours){
    	  cout << CACHE.size()  << " terms loaded into our cache ("<< linecounter << ")" << endl;
    	  OUR_TOTAL_QUERIES = linecounter;
      }else{
    	  cout << RCACHE.size() << " terms loaded into Ricardo's cache ("<< linecounter << ")" << endl;
    	  RICARDO_TOTAL_QUERIES = linecounter;
      }
}

void _doCacheExperiment(){
    r.openRead( INDEX );
    indri::server::LocalQueryServer local(r);
    indri::collection::Repository::index_state state = r.indexes();
    UINT64 docCount = local.documentCount();
    int op = 2*(int)floor((double)docCount/100);
    int percentagecounter = 0;
    std::vector<lemur::api::DOCID_T> documentIDs;
    for(int i = 0; i < docCount; i++){
    	lemur::api::DOCID_T documentID = (i+1);
        documentIDs.push_back(documentID);
        indri::server::QueryServerVectorsResponse* response = local.documentVectors( documentIDs );
        if( response->getResults().size() ) {
        	std::vector< std::string > query;
            indri::api::DocumentVector* docVector = response->getResults()[0];
            for( size_t i=0; i<docVector->positions().size(); i++ ) {
              int position = docVector->positions()[i];
              const std::string& stem = docVector->stems()[position];
              query.push_back(stem);
            }
            delete docVector;
            overlap(query);
        }
        delete response;
    	documentIDs.clear();
    }
    std::cout << " COMPLETE!" << endl;std::cout << endl;
    std::cout << endl;
    r.close();
    std::cout << "****************************************************************************" << std::endl;
    std::cout << "*                               Results                                    *" << std::endl;
    std::cout << "****************************************************************************" << std::endl;
    std::cout << "Ours:"<< std::endl;
    std::cout << "----------------------------------------------------------------------------"<< std::endl;
    std::cout << "0 hits.: " << ourZeroCounter       	 << std::endl;
    std::cout << "1 hit..: " << ourOneCounter        	 << std::endl;
    std::cout << "2 hits.: " << ourTwoCounter        	 << std::endl;
    std::cout << "3 hits.: " << ourThreeCounter      	 << std::endl;
    std::cout << "4 hits.: " << ourFourCounter       	 << std::endl;
    std::cout << "5 hits.: " << ourFiveCounter       	 << std::endl;
    std::cout << "6 hits.: " << ourSixCounter        	 << std::endl;
    std::cout << "7+ hits: " << ourSevenOrMoreCounter	 << std::endl;
    std::cout << "Wasted terms: "  << OUR_SPILL_TERM_CTR << std::endl;
    std::cout << "Total..: " << ourTotalCounter      	 << std::endl;
    std::cout << "****************************************************************************"<< std::endl;
    std::cout << "Ricardo:"  << std::endl;
    std::cout << "----------------------------------------------------------------------------"<< std::endl;
    std::cout << "0 hits.: " << ricZeroCounter        	 << std::endl;
    std::cout << "1 hit..: " << ricOneCounter         	 << std::endl;
    std::cout << "2 hits.: " << ricTwoCounter          	 << std::endl;
    std::cout << "3 hits.: " << ricThreeCounter       	 << std::endl;
    std::cout << "4 hits.: " << ricFourCounter        	 << std::endl;
    std::cout << "5 hits.: " << ricFiveCounter        	 << std::endl;
    std::cout << "6 hits.: " << ricSixCounter         	 << std::endl;
    std::cout << "7+ hits: " << ricSevenOrMoreCounter 	 << std::endl;
    std::cout << "Wasted terms: " << RIC_SPILL_TERM_CTR << std::endl;
    std::cout << "Total..: " << ricTotalCounter          << std::endl;
    std::cout << "****************************************************************************"<< std::endl;
}

/*
 * 08-12-2014: Added noftermsprhit. This parameter specified the number of terms per query
 *             that must be matched in the cache before we say there is a hit.
 */
void parse_configuration(const char * configFile){
	Configuration *  _cfg       = Configuration::create();
	const char *     _scope     = "";
    try {
        _cfg->parse(configFile);
        TERM_FILE_OURS    = _cfg->lookupString(_scope, "ourMethod");
        TERM_FILE_RICARDO = _cfg->lookupString(_scope, "ricardoMethod");
        INDEX     		  = _cfg->lookupString(_scope, "index");
        HITS_REQ          = 1;
    } catch(const ConfigurationException & ex) {
        cerr << ex.c_str() << endl;
        _cfg->destroy();
    }

    cout << endl;
    cout << "***************** INITIALISATION *****************" << endl;
    cout << "Term file (ours): "    << TERM_FILE_OURS    << endl;
    cout << "Term file (Ricardo): " << TERM_FILE_RICARDO << endl;
    cout << "Index: "               << INDEX             << endl;
    _cfg->destroy();
}

int main(int argc, char ** argv){
	// Input are *.prints
	if(argc != 2){
		cout << "A parameter file specifying the term file and the index must be specified " << endl;
		exit(EXIT_FAILURE);
	}
	parse_configuration(argv[1]);
	std::cout << endl;
	std::cout << "*****************************************" << endl;
	std::cout << "*             Method results            *" << endl;
	std::cout << "*****************************************" << endl;
	loadCache(TERM_FILE_OURS,    true );
	loadCache(TERM_FILE_RICARDO, false);
    std::cout << "*******  CACHE WARM UP COMPLETED ********" << endl;
    std::cout << std::endl;
	_doCacheExperiment();
	std::cout << "*****************************************" << endl;

	return EXIT_SUCCESS;
}
