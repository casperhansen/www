#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <set>
#include <algorithm>
#include <iterator>
using namespace std;
int main(int argc, char ** argv){
	std::string line;
	std::ifstream myfile (argv[1]);
	if (myfile.is_open()){
	    while (getline (myfile,line)) {
	    	bool f = line.find(",", 0) != std::string::npos;
	    	size_t  pos = line.find(",", 0); //store the position of the delimiter
	    	std::string temp = line.substr(0, pos);      //get the token
	    	int val          = atoi((line.substr(pos+1).c_str()));
		}
	}
	myfile.close();
	return 1;
}
