/*
 * term_test.cpp
 *
 *  Created on: Dec 16, 2014
 *      Author: casper
 */
#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include "indri/QueryEnvironment.hpp"
#include "indri/QueryExpander.hpp"
#include "indri/TFIDFExpander.hpp"
#include <iostream>
#include <math.h>
#include <stdio.h>
#include <sstream>
#include <string>
#include <algorithm>
#include <vector>
#include <stdlib.h>
#include <iomanip>
#include <iostream>
#include <map>
#include "indri/count_iterator"
#include <fstream>
#include <sstream>
#include <set>
#include <cmath>

int main(int argc, char ** argv){
	 std::string myindex = "/home/casper/indexes/qtfdf/nyt/";
	 indri::collection::Repository r;
	 r.openRead( myindex );
	 indri::server::LocalQueryServer local(r);
	 UINT64 termCount = local.termCount();
	 UINT64 stemCount = local.stemCount("scuba");
	 UINT64 termCountUnique = local.termCountUnique();
	 std::cout << "Total term: " << termCount << std::endl;
	 std::cout << "Total unique terms: " << termCountUnique << std::endl;
	 std::cout << "\"Scuba\" occurred: " << stemCount << " times" << std::endl;

	 // Query contains the query terms
	 std::vector< std::string > document;
	 // topdocs contains the X highest weighted terms from the PRF set. The two vectors are most likely of different length
	 std::vector< std::string > documents;
	 // Dvec is the |V| vector for the X highest weighted terms from D\{d}
	 unsigned short Dvec[termCountUnique];
	 // dvec is the |V| vector for the X highest weighted terms from d
	 unsigned short dvec[termCountUnique];

	 indri::collection::Repository::index_state state = r.indexes();
	 indri::index::Index* index = (*state)[0];
	 indri::index::VocabularyIterator* iter = index->vocabularyIterator();
	 iter->startIteration();
	 int loc = 0;
	 while( !iter->finished() ) {
	     indri::index::DiskTermData* entry = iter->currentEntry();
	     indri::index::TermData* termData = entry->termData;
	     std::string str(termData->term);
	     if(std::find(document.begin(), document.end(), str) != document.end()){
	    	dvec[loc] = 1;
	     }

	     if(std::find(documents.begin(), documents.end(), str) != documents.end()){
	    	Dvec[loc] = 1;
	     }

		 loc++;
	     iter->nextEntry();
	 }

	 //Calculate cosine similarity
	 double denom_doc,denom_docs, nom = 0.0;
	 for(int i = 0; i<termCountUnique; i++){
		 denom_doc  += pow((double)dvec[loc],2.0);
		 denom_docs += pow((double)Dvec[loc],2.0);
		 nom        += dvec[loc]*Dvec[loc];
	 }
	 double denom  = sqrt(denom_doc) * sqrt(denom_docs);
	 double cosine = nom/denom;

     std::cout << "Found " << loc << " unique terms using vocabulary iterator" << std::endl;

	 r.close();
}


