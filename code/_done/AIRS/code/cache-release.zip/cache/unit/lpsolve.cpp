#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include <stdio.h>
#include <stdlib.h>
#include "lpsolve/lp_lib.h"
#include <iostream>

// To compile see the lpsolveMakefile.app
int main(void) {
  std::string fp  = "/home/casper/problem.lp_solve";
  std::string lpz = "test model";


  char * filepath = &fp[0];
  char * _lp      = &lpz[0];

  lprec *lp;
  /* Read LP model */

  lp = read_LP(filepath, NORMAL, _lp);
  if(lp == NULL) {
    fprintf(stderr, "Unable to read model\n");
    return(1);
  }
  int solvestat = solve(lp);
  int Ncolumns  = get_Ncolumns(lp);
  double * vars = new double[Ncolumns];
  get_variables(lp,vars);

  for(int i=0; i<Ncolumns; i++){
  	if(*(vars+i) > 0){ // We have a result! Current variable is to be included
  	  std::cout << "x" << i << "," << vars[i] << std::endl;
  	}
  }
  double objval = get_objective(lp);
  std::cout << "Value of objective function: " << objval << std::endl;
  delete_lp(lp);
  return(0);
}
