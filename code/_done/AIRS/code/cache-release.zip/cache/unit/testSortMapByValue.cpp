#include <iostream>
#include <fstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <set>
#include <stdlib.h>
#include <sstream>
#include <iomanip>      // std::setprecision
#include <algorithm>
#include <utility>
#include <sstream>
#include <map>
#include <time.h>
#include <cmath>
#include <limits>
#include <iterator>
#include <random>
#include <ctime>
#include <cctype>

template<typename A, typename B>
std::pair<B,A> flip_pair(const std::pair<A,B> &p)
{
    return std::pair<B,A>(p.second, p.first);
}

template<typename A, typename B>
std::multimap<B,A> flipAndSortmap(const std::map<A,B> &src)
{
    std::multimap<B,A> dst;
    //std::transform(src.begin(), src.end(), std::inserter(dst, dst.begin()),
    //               flip_pair<A,B>);
    std::transform(src.begin(), src.end(), std::inserter(dst, dst.begin()),
                       flip_pair<A,B>);
    return dst;
}

int main(void) {
	/* Compile using: g++ -std=c++11 testSortMapByValue.cpp -o testSortMapByValue
	 */
    std::map<std::string, int> src;
    src["hej"] = 2;
    src["med"] = 5;
    src["dig"] = 3;
    src["casper"] = 2;
    std::multimap<int, std::string> dst = flipAndSortmap(src);
    // dst is now sorted by what used to be the value in src!
    std::multimap<int, std::string>::reverse_iterator it;
    for(it = dst.rbegin(); it != dst.rend(); ++it){
    	std::cout << it->first << ", " << it->second << std::endl;
    }
}
