#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include "indri/QueryEnvironment.hpp"
#include "indri/QueryExpander.hpp"
#include "indri/TFIDFExpander.hpp"
#include <iostream>
#include <math.h>
#include <stdio.h>
#include <sstream>
#include <string>
#include <algorithm>
#include <vector>
#include <stdlib.h>
#include <iomanip>
#include <iostream>
#include <map>
#include "indri/count_iterator"
#include <fstream>
#include <sstream>
#include <set>
#include <cmath>

int main(int argc, char ** argv){
	std::string term = "scuba";
	indri::collection::Repository r;
	r.openRead("/home/casper/indexes/qtfdf/nyt/");
	indri::collection::Repository::index_state state = r.indexes();
	indri::index::Index* index = (*state)[0];
	indri::index::VocabularyIterator* iter = index->vocabularyIterator();
	iter->startIteration();
	while( !iter->finished() ) {
	    indri::index::DiskTermData* entry = iter->currentEntry();
	    indri::index::TermData* termData = entry->termData;
	    std::string str(termData->term);
	    if(term.compare(str) == 0){
	    	INT64 termCount = termData->corpus.documentCount;
	    	std::cout << "Found " << term << " in " << termCount << " documents" << std::endl;
	    	break;
	    }
	    iter->nextEntry();
	}
}


