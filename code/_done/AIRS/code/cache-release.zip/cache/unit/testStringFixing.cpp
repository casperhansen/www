/*
 * testStringFixing.cpp
 *
 *  Created on: Dec 8, 2014
 *      Author: casper
 */

#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <set>
#include <algorithm>
#include "../include/aux.hpp"

int main(int argc, char ** argv){
	std::string query = "hej med dig12    1    ";
	std::cout << cache::aux::fixString(query) << std::endl;
}
