#include <iostream>
#include <string>
#include <sstream>
#include <algorithm>
#include <iterator>
#include <vector>


int main(int argc, char ** argv){
	std::string str = "/home/casper/indexes/msn1wordqueries/";
	int idx = str.find_last_of("\\/");
	std::string bTmp = str;
	if (std::string::npos != idx){
	    std::string fullpath(str.substr(0,idx));
	    idx = fullpath.find_last_of("\\/");
		if (std::string::npos != idx){
		    std::string tmp(fullpath.substr(idx+1));
		    bTmp = tmp;
		}
	}
    std::cout << bTmp << std::endl;
	return 1;
}
