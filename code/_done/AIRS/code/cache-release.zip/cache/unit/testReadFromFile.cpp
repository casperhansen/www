#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <map>
#include <time.h>
#include <set>
#include <cmath>


int main(int argc, char ** argv){
	std::string line;
	std::ifstream myfile (collectionName.c_str());
	int linecounter = 0;
	if (myfile.is_open()){
	    while (getline (myfile,line)) {
	    	if(linecounter > 10){
	    		break;
	    	}
	    	size_t  pos = line.find(",", 0); //store the position of the delimiter
	    	std::string temp = line.substr(0, pos);      //get the token
	    	int val          = atoi((line.substr(pos+1).c_str()));
	    	std::cout << "Term: " << temp << ", Value: " << val << std::endl;
	    	linecounter++;
		}
	}
	myfile.close();
}
