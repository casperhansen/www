function ret = pargetBitStrings3(K, cutoff)
%
% UPDATE
% This is an updated version using the input from meeting on 01-04-2015
%
% Only the fat nodes are affected. 
% Step 1 : Identify all the fat nodes. A fat node is a node with a degree >
%          M = ceil((ceil(n * log_2(n))^(1/alpha)). Assign to each fat node
%          a unique id 0 <= i < M 
% Step 2 : Loop over the nodes. For each fat node, allocate M bits and loop
%          over its neighbours.
% Step 3 : For each neighbour that is fat, get that nodes id, k, (which is its
% index) and put a 1 in index k for the node we are looping over.
%
% This creates a binary vector of length M for each fat node. There is a 
% '1' in those locations where a fat neighbor of the current node resides.
%

% Casper Petersen, Noy Rotbart, Jakob Grue Simonsen and Christian Wulff-Nielsen
% Copyright 2015

%% Step 1

nodes        = K(:,1);         % All nodes <- as the graph is undirected the reverse edge is also present
[qnodes,C,~] = unique(K(:,1)); % Only the unique values
N            = numel(qnodes);  % Number of unique values
C            = [C;numel(nodes)+1];

% Degree of each node
[vals, bins] = hist(nodes, unique(nodes));
vals         = vals(:); 
bins         = bins(:);
nodedegrees  = [bins, vals, zeros(numel(vals),1)];                    % The map
clear bins; clear vals; 
%return
%cutoff               = ceil(N^(1/alpha) * log2(N)^(1 - 1/alpha)); 
idx                = nodedegrees(:,2) >= cutoff;
if(isempty(idx))
   warning('There were no fat nodes found larger than %d\n', cutoff); 
   pause
end
fatNids            = 1:numel(find(idx));
nodedegrees(idx,3) = fatNids(:);
%% Step 2

% Set the degree cutoff.          - Its is the alpha root of the number of nodes N
nofbits      = ceil(log2(N));     % Number of bits
bitstrings   = zeros(N,1);        % Size of bitstring, thin/fat, 
fatthin      = zeros(N,1);
nodedeg      = zeros(N,1);
nodeid       = [1:N]';
% We set the node ids equal to their label.
parfor i = 1 : N
    isfat = 0;
    idx_low   = C(i);      %find(qnodes(i) == nodes(:,1), 1, 'first');
    idx_high  = C(i+1) - 1;    %find(qnodes(i) == nodes(:,1), 1, 'last');
    % Get subset of nodes where the node id in column 1 are identical
    subset    = K(idx_low:idx_high,:);
    % Determine if node is thin or fat
    vi        = subset(1,1);    % They are all identical in the first column
    viN       = subset(:,2);    % Neighbour list of v_i
    M         = numel(viN);     % The degree of v_i = size of its neighbour list
    nodedeg(i,1) = M;
    bitstring = 0;
    if M > cutoff %
       isfat = 1;
       % The node is fat 
       bitstring = 1;
       % Remove the thin nodes
       vs = zeros(1,cutoff);
       for j = 1 : M
           idx                 = find(viN(j)==nodedegrees(:,1),1); 
           neighbourNodeDegree = nodedegrees(idx,2);          % Degree of v_j
           if neighbourNodeDegree > cutoff
              % v_j is fat. Add it to list of neighbour nodes
              vs ( nodedegrees(idx,3) ) = 1;
           end
       end
       % Concat with the identifier to 
       bitstring = [bitstring, vs];
    else
       % It is a thin node 
       % Get bit representation of v_i and concat
        bitstring = [bitstring, de2bi(vi,nofbits,'left-msb')]; % The bitstring of v_i
        for j = 1 : M
            % Get bit representation of v_j and concat
            bitstring = [bitstring, de2bi(viN(j),nofbits,'left-msb')];
        end
    end
    % How many bits for this label
    bitstrings(i,1) = size(bitstring, 2);
    fatthin(i,1)    = isfat;
end
%toc;

fatnodesIDX  = fatthin(:,1) == 1;
thinnodesIDX = fatthin(:,1) == 0;

fats         = bitstrings(fatnodesIDX, 1);
thins        = bitstrings(thinnodesIDX,1);

largest_fat  = max(fats);
largest_thin = max(thins);

if(largest_fat > largest_thin)
    overall_fat = 'fat';
else
    overall_fat = 'thin';
end

[V,idx] = max(bitstrings);
ret = {V, fatthin(idx), nodedeg(idx), nodeid(idx), bitstrings};

end

