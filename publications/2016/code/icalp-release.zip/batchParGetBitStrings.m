% Main function
%
% The 'plfit' calls require the power-law package by Aaron Clauet et al (from http://tuvalu.santafe.edu/~aaronc/powerlaws/)
%
% Casper Petersen, Noy Rotbart, Jakob Grue Simonsen, Christian Wulff-Nielsen
% Copyright 2015

function tmp = batchParGetBitStrings(data, barriervalues)

barriervalues = 150:2:200;

[vals, ~] = hist(data(:,1), unique(data(:,1)));
fprintf('Max degree: %d\n', max(vals));
for i = 1 : numel(barriervalues)
    val = pargetBitStrings3(data, barriervalues(i));
    V     = val{1};
    isfat = val{2};
    deg   = val{3};
    id    = val{4};    
    %if(isfat == 1)
    %   var = 'fat'; 
    %else
    %   var = 'thin'; 
    %end
    bitstrings     = val{5};
    total_size     = sum(bitstrings);
    [alpha,xmin,L] = plfit(bitstrings);
    [alpha_cutoff, xmin_cutoff, l_cutoff] = plfit(bitstrings, 'xmin', min(bitstrings));
    fprintf('%d,%d,%d,%d,%d,%d,%1.3f,%1.3f\n', barriervalues(i), V, isfat, deg, id, total_size, alpha, alpha_cutoff);
    tmp{i} = bitstrings;
end
end
