function ret = pargetBitStrings2(K, cutoff)
% If a node is fat, we are only interested in the fat nodes in its
% neighbourlist

% If a node is thin we include both thin and fat

% Example: If a node V_i with label 20 is thin and has the following nodes
% in its edgelist with labels = {10,5,9} the bit string is concatenated by
% the following:
% 0/1 CONCAT id(l(V_i)) CONCAT N[V_i]
% where 0 (thin) or 1(fat) l(V_i) is the label of node V_i and id is the
% bit representation of the label (the label is an integer. N[V_i] is the
% neighbour list of V_i. Each V_i is converted to its bit-representation
% and concatenated. In the example above:
% 1 CONCAT 10100 CONCAT [1010 CONCAT 101 CONCAT 1001]
% 
% As there are N nodes we need ceil(log2(N)) bits to represent the largest
% label. Hence if we have N = 20 nodes the above becomes:
% 1 CONCAT 10100 CONCAT [01010 CONCAT 00101 CONCAT 01001]
% for a total bitstring of 110100010100010101001
%
%

% Assume that the data input is a K x 2 matrix representing a edge list.
% At location i in the first column is the node_id of one vertex. At
% location i in the secind column is the node_id of another vertex. Only
% the first column has vertices in ascending order of id.
%K            = loaddatasets;

% Casper Petersen, Noy Rotbart, Jakob Grue Simonsen and Christian Wulff-Nielsen
% Copyright 2015

nodes        = K(:,1);         % All nodes <- as the graph is undirected the reverse edge is also present
[qnodes,C,~] = unique(K(:,1)); % Only the unique values
N            = numel(qnodes);  % Number of unique values
C            = [C;numel(nodes)+1];
% Degree of each node
[vals, bins] = hist(nodes, unique(nodes));
vals         = vals(:); 
bins         = bins(:);
nodedegrees  = [bins, vals];                    % The map
clear bins; clear vals; 

% Set the degree cutoff. Its is the alpha root of the number of nodes N
nofbits      = ceil(log2(N));     % Number of bits
bitstrings   = zeros(N,1);        % Size of bitstring, thin/fat, 
fatthin      = zeros(N,1);
nodedeg      = zeros(N,1);
nodeid       = [1:N]';
%C
% We set the node ids equal to their label.
parfor i = 1 : N
    isfat = 0;
    idx_low   = C(i);      %find(qnodes(i) == nodes(:,1), 1, 'first');
    idx_high  = C(i+1) - 1;    %find(qnodes(i) == nodes(:,1), 1, 'last');
    % Get subset of nodes where the node id in column 1 are identical
    %[idx_low, idx_high]
    subset    = K(idx_low:idx_high,:);
    %fprintf('Node %d\n', i);
    %subset
    % Determine if node is thin or fat
    vi        = subset(1,1);    % They are all identical in the first column
    viN       = subset(:,2);    % Neighbour list of v_i
    M         = numel(viN);     % The degree of v_i = size of its neighbour list
    nodedeg(i,1) = M;
    bitstring = 0;
    if M > cutoff %
       isfat = 1;
       %fprintf('.....is fat\n');
       % The node is fat 
       bitstring = 1;
       % Remove the thin nodes
       vs = [];
       for j = 1 : M
           idx                 = find(viN(j)==nodedegrees(:,1),1); 
           %[viN(j), idx]
           neighbourNode       = nodedegrees(idx,1);          % v_j
           neighbourNodeDegree = nodedegrees(idx,2);          % Degree of v_j
           if neighbourNodeDegree > cutoff
              % v_j is fat. Add it to list of neighbour nodes
              vs = [vs, neighbourNode]; 
              %fprintf('%d was a fat neighbour of %d\n', neighbourNode, i);
           end
       end
       % Update neighbour list and number of neighbours
       viN = vs;
       M   = numel(viN);
    end

    % Get bit representation of v_i and concat
    bitstring = [bitstring, de2bi(vi,nofbits,'left-msb')]; % The bitstring of v_i
    for j = 1 : M
        % Get bit representation of v_j and concat
        bitstring = [bitstring, de2bi(viN(j),nofbits,'left-msb')];
    end
    %bitstring
    %pause
    % How many bits for this label
    bitstrings(i,1) = size(bitstring, 2);
    fatthin(i,1)    = isfat;
end
%toc;

fatnodesIDX  = fatthin(:,1) == 1;
thinnodesIDX = fatthin(:,1) == 0;

fats         = bitstrings(fatnodesIDX, 1);
thins        = bitstrings(thinnodesIDX,1);

largest_fat  = max(fats);
largest_thin = max(thins);

if(largest_fat > largest_thin)
    overall_fat = 'fat';
else
    overall_fat = 'thin';
end

[V,idx] = max(bitstrings);
ret = {V, fatthin(idx), nodedeg(idx), nodeid(idx), bitstrings};

%large = max(bitstrings);
%fprintf('Average length of bitstring: %1.5f\n', mean(bitstrings));
%fprintf('Maximum length of bitstring: %1.5f\n', max(bitstrings));
%fprintf('Largest bitstring for fat nodes: %1.5f\n', largest_fat);
%fprintf('Largest bitstring for thin nodes: %1.5f\n', largest_thin);
%fprintf('The largest label for barrier %d was %d and was a %s node\n', cutoff, max(bitstrings), overall_fat);
end
