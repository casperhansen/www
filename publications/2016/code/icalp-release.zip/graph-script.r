require(igraph)
require(Rmpfr)

degwww <- function(inpath,outpath,ds=TRUE){
	ghat  <- read.graph(inpath, format="edgelist",directed=ds);
	if(ds == TRUE){
		cat("Input graph was directed. Undirecting....");
		ghat  <- as.undirected(ghat);
	}
	dgs   <- degree(ghat,v=V(ghat));
	idx   <- dgs > 0;
	dgs   <- dgs[idx]
	n     <- length(dgs);
	write(dgs, file=outpath, ncolumns = 1);
	nList <- list("degrees" = dgs, "n" = n, "maxdegree" = max(dgs));
	
	return(nList);
}

calcRest <- function(alpha, n, maxdeg){
	C      <- 1/zeta(alpha);
	t      <- C/(alpha - 1);
	CPrime <- (t + floor((C*n)^(1/alpha))/(n^(1/alpha)) + 5)^alpha + t; # Cprime - See just before Def. 1
	vx     <- (CPrime*n)^(1/alpha)*log2(n)^(1 - (1/alpha)) + 2*log2(n) + 1; # Theorem 2
	threshold <- ceiling((C*n/(alpha - 1))^(1/alpha));	# See Section 7.1 for this definition
	
	# Calculate the stuff (to the extend that it is possible) for Table 2
	
	# Predicted threshold = threshold
	
	# Empirical threshold (dont know)
	emp_threshold <- 0;
	
	# Label diff
	# ldiff <- ((predicted-empirical)/predicted) * 100;
	ldiff <- 0;
	
	# Threshold diff
	# NO PERFORMANCE INDICATOR III
	tdiff <- 0;	

	# Upper bound
	ub <- upperbound(alpha, C, n);

	# CSparse
	Csparse <- csparse(C,n);

	# Bounded Degree
	bdegree <- boundeddegree(maxdeg, n);
	
	# AKTZ
	aktzval <- aktz(n);
	
	nList <- list("C" = C, "Cprime" = CPrime, "labelingscheme" = vx, "alpha" = alpha, "pred_threshold" = threshold, "emp_threshold" = emp_threshold,  "label_diff" = ldiff, "threshold_diff" = tdiff, "upper_bound" = ub, "csparse" = Csparse, "bounded_degree" = bdegree, "aktz" = aktzval);
}

upperbound <- function(alpha, C, n){
	v <- ceiling((C * n/(alpha - 1))^(1/alpha) * ceiling(log2(n)) + 2 * ceiling(log2(n)) + 1);
	return(v);
}

csparse <- function(C,n){
	v <- ceiling(sqrt(2 * C * n) * ceiling(log2(n)) + 2 * ceiling(log2(n)) + 1);
	return(v)
}

boundeddegree <- function(maxdeg, n){
	v <- ceiling(maxdeg/2)*ceiling(log2(n));
	return(v)
}

aktz <- function(n){
	v <- ceiling(n/2) + 6;
	return(v)
}

looper <- function(x,n,degs){
  xlow = x-40;
  xhigh = x+40;

  for(i in xlow:xhigh){
	a <- ceiling(i*log2(n));
	b <- sum(degs > i);
	cat(i,a,"0\n");
	cat(i,b,"1\n");
  }
}

loopersingle <- function(x,n,degs){
	a <- ceiling(x*log2(n));
	b <- sum(degs > x);
	cat(x,a,"0\n");
	cat(x,b,"1\n");
}

looper2 <- function(x,xlow,xhigh,n,degs){
  for(i in xlow:xhigh){
        a <- ceiling(i*log2(n));
        b <- sum(degs > i);
        cat(i,a,"0\n");
        cat(i,b,"1\n");
  }
}
