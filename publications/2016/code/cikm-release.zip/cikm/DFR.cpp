/*
 * DFR.cpp
 *
 * Scores documents according to:
 * "Relevance Weighting using Withing-document Term Statistics"
 * by Kai Hui, Ben He, Tiejian Luo and Bin Wang, CIKM 2011
 *
 * COMPILATION:
 * - Compile with the makefile found in the same library as 'make -f DFR.app'
 *
 * USAGE:
 * ./DFR <path-to-config-file> -- See the PConfig.hpp
 *
 * CHANGELOG (Major changes only):
 * 05-06-2015: Created
 * 13-06-2015: Added logging
 *
 *  Created on: Jun 02, 2015
 *      Author: casper
 */

#include "include/ScoreModel.hpp"	// Models
#include "include/aux.hpp"			// Helper
#include "include/Score.hpp"		// Scoring
#include "include/PConfig.hpp"		// Parse
#include "include/Write.hpp"		// I/O
#include "include/easylogging++.h"	// Logging
#include "include/TrecEval.hpp"		// Trec-eval (called outside)
#include "include/CV.hpp"			// Cross-validation
#include "include/CVModel.hpp"		// Optimise model through CV
#include "include/CVModel2.hpp"		// Optimise model through CV

INITIALIZE_EASYLOGGINGPP

int main(int argc, char ** argv){
	PConfig config;
	if(argc == 1){
		// If no input is given we print the help()
		config.printHelp();
		exit(EXIT_SUCCESS);
	}
	config.parse_configuration(argv[1]);

	// Load configuration from file
	el::Configurations conf(config.getLoggerLocation());
	// Reconfigure single logger
	el::Loggers::reconfigureLogger("default", conf);
	// Actually reconfigure all loggers instead
	el::Loggers::reconfigureAllLoggers(conf);
	// Now all the loggers will use configuration from file
	std::cout << std::endl;
	std::cout << "*********************** INPUT ***********************" << std::endl;
	std::cout << "Query index..........: " << config.getQueryIndex()			 << std::endl;
	std::cout << "Query field..........: " << config.getQueryField()          << std::endl;
	std::cout << "Collection index.....: " << config.getCollectionIndex() 	 << std::endl;
	std::cout << "Cutoff...............: " << config.getCutoff()          	 << std::endl;
	std::cout << "Laplace norm (c).....: " << config.getLaplaceNorm()       	 << std::endl;
	std::cout << "BM25 norm (b)........: " << config.getBm25Norm()            << std::endl;
	std::cout << "Number of folds......: " << config.getNumberOfFolds()      << std::endl;
	std::cout << "Model................: " << config.getModel()           	 << std::endl;
	std::cout << "Parameter 1..........: " << config.getFirstParameter()      << std::endl;
	std::cout << "Parameter 2..........: " << config.getSecondParameter()     << std::endl;
	std::cout << "Parameter 3..........: " << config.getThirdParameter()      << std::endl;
	std::cout << "********************* LOCATIONS *********************" << std::endl;
	std::cout << "Output file location.: " << config.getRetrievalResults()	 << std::endl;
	std::cout << "Qrels location.......: " << config.getQrelsLoc()        	 << std::endl;
	std::cout << "Logger configuration.: " << config.getLoggerLocation()  	 << std::endl;
	std::cout << "Number of trials.....: " << config.getNofTrials()           << std::endl;
	std::cout << "Performance measure..: " << config.getPerformanceMeasure()  << std::endl;
	std::cout << std::endl;
	LOG(INFO) << "*********************** INPUT ***********************";
	LOG(INFO) << "Query index..........: " << config.getQueryIndex() 	 	;
	LOG(INFO) << "Query field..........: " << config.getQueryField()         ;
	LOG(INFO) << "Collection index.....: " << config.getCollectionIndex() 	;
	LOG(INFO) << "Cutoff...............: " << config.getCutoff()          	;
	LOG(INFO) << "CNORM................: " << config.getLaplaceNorm()       	;
	LOG(INFO) << "BNORM................: " << config.getBm25Norm()           ;
	LOG(INFO) << "Number of folds......: " << config.getNumberOfFolds()     ;
	LOG(INFO) << "Model................: " << config.getModel()           	;
	LOG(INFO) << "Parameter 1..........: " << config.getFirstParameter()     ;
	LOG(INFO) << "Parameter 2..........: " << config.getSecondParameter()    ;
	LOG(INFO) << "Parameter 3..........: " << config.getThirdParameter()     ;
	LOG(INFO) << "********************* LOCATIONS *********************";
	LOG(INFO) << "Output file location.: " << config.getRetrievalResults()	;
	LOG(INFO) << "Qrels location.......: " << config.getQrelsLoc()        	;
	LOG(INFO) << "Logger configuration.: " << config.getLoggerLocation()  	;
	LOG(INFO) << "Number of trials.....: " << config.getNofTrials()          ;
	LOG(INFO) << "Performance measure..: " << config.getPerformanceMeasure() ;
	Score * s;

	// Get the model parameters

	// Set the model to use
	//s->setScoreModel(config.getModel(), parms);

	/*
	std::vector<double> vg = s->getScoreModelParameterBounds(1);
	std::cout <<  vg.size() << std::endl;
	for(int i = 0; i < vg.size(); i++){
		std::cout << "vg["<<i<<"] : " << vg.at(i) << std::endl;
	}
	return EXIT_FAILURE;
    */
	// Load the queries from the query index
	//s->loadQueries(config.getQueryIndex(), config.getQueryField(), config.getDebugLevel());
	//s->printGetQueryRep();
//	s->printPooledQueryTerms();

	/* Load the inverted lists from the document index (last argument is whether to use sequential or parallel).
	 * For this task the sequential method is substantially quicker due to the scoped lock.
	 */
	//s->loadInvertedIndex(config.getCollectionIndex(), config.getLaplaceNorm(), config.getBm25Norm(), config.getDebugLevel(), false);
	//s->printQTermsInvLists();
	//std::string str = s->getRandomPooledQueryTerim();
	//s->printQTermsInvLists(str);

	//std::vector<std::string> myEmptyVector;
	//s->parscore(config.getDebugLevel(), myEmptyVector);
	//s->printParScoredQueries();

	//s->init(config.getCollectionIndex());

	double tStart = clock();
	CVModel * cvm   = new CVModel(config, s);
	//CVModel2 * cvm2 = new CVModel2(config, s);
	cvm->xvalidate(config.getNumberOfFolds());
	//cvm2->xvalidate(config.getNumberOfFolds());
	double tEnd    = (double)(clock() - tStart)/CLOCKS_PER_SEC;
	std::cout << "Done! (" << tEnd << " seconds)" << std::endl;
	return EXIT_SUCCESS;
}


