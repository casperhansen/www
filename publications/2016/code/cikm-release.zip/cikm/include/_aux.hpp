/*
 * aux.hpp
 *
 *  Created on: Nov 18, 2014
 *      Author: casper
 */

#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <unordered_map>
#include <map>
#include <time.h>
#include <set>
#include <cmath>
#include <cstring>
#include <limits>
#include <iterator>
#include <iomanip>      // std::setprecision
#include <algorithm>
#include <utility>
#include <ctime>
#include <cctype>
#include "omp.h"
#include <chrono>		// For timing



#ifndef AUX_HPP_
#define AUX_HPP_

#define SSTR( x ) dynamic_cast< std::ostringstream & >( \
        ( std::ostringstream() << std::dec << x ) ).str()

const std::string MAP     = "map";
const std::string MRR     = "recip_rank";
const std::string PATTEN  = "P_10";
const std::string NDCG    = "ndcg";
const std::string NDCGTEN = "ndcg_cut_10";

namespace idx{
	class DocIDFreq{
		private:
		unsigned short int FREQ  =    0;
			float LAPLACE_NORM   = -1.0; // Eqn. 42
/*
			double ELITE_SET      =  0.0; // n: Size of t's elite set
			double F              =  0.0; // F: Total occurrences of t in elite set (defined as all documents where t occurs)
			double LAW_OF_SUCC_L2 = -1.0; // Eqn. 21 when LaPlace (logarithmic) tf smoothing is applied
			double BERN_RATIO_L2  = -1.0; // Eqn. 27 when LaPlace (logarithmic) tf smoothing is applied
			double LAW_OF_SUCC_B  = -1.0; // Eqn. 21 when ratio of BM25 tf smoothing is applied
			double BERN_RATIO_B   = -1.0; // Eqn. 27	when ratio of BM25 tf smoothing is applied
*/
			std::string EXT_ID;
		public:
			DocIDFreq();
			DocIDFreq(unsigned short int freq, std::string ext_id, float laplace_norm){
				FREQ         = freq;
				EXT_ID       = ext_id;
				LAPLACE_NORM = laplace_norm; // Laplace Term Normalisation Component
/*
				ELITE_SET    = 0;
				F            = 0;
*/
				// Calculate P_2
/*
				LAW_OF_SUCC_L2 = 1.0/(1.0 + (FREQ*LAPLACE_NORM));             // (FREQ*LAPLACE_NORM) = tfn * laplace term normalisation
				LAW_OF_SUCC_B  = 1.0/(1.0 + (FREQ*BM25_NORM));				  // (FREQ*LAPLACE_NORM) = tfn * bm25 term normalisation
				BERN_RATIO_L2  = (F + 1.0)/(ELITE_SET * (FREQ*LAPLACE_NORM)); // (FREQ*LAPLACE_NORM) = tfn * laplace normalisation
				BERN_RATIO_B   = (F + 1.0)/(ELITE_SET * (FREQ*BM25_NORM));    // (FREQ*LAPLACE_NORM) = tfn * bm25 term normalisation
*/
			}
			~DocIDFreq(){};

			unsigned short int getTermFreq(){
				return FREQ;
			}
/*
			double getSizeOfEliteSet(){
				return ELITE_SET;
			}

			double getTermOccurrencesInEliteSet(){
				return F;
			}
*/
			std::string getExternalDocID(){
				return EXT_ID;
			}

			float getNormTerm(){
				// Return LaPlace normalisation
			    //if(LAPLACE_NORM > -1.0){
			    	return LAPLACE_NORM;
			    //}
/*
			    // Return BM25 normalisation
			    if(BM25_NORM > -1.0){
			    	return BM25_NORM;
			    }
			    // Return 1.0 i.e. use raw term frequencies
			    return 1.0;
*/
			}
/*
			double getP2Norm(){
				if(LAPLACE_NORM > -1.0){
					// We are using logarithmic term normalisation. What P_2 normalisation?
					if(LAW_OF_SUCC_L2 > -1.0){
						return LAW_OF_SUCC_L2;
					}
					if(LAW_OF_SUCC_B > -1.0){
						return LAW_OF_SUCC_B;
					}
					return 0.0;
				}
				if(BM25_NORM > -1.0){
					// We are using BM25 term normalisation. What P_2 normalisation?
					if(BERN_RATIO_L2 > -1.0){
						return BERN_RATIO_L2;
					}
					if(BERN_RATIO_B > -1.0){
						return BERN_RATIO_B;
					}
					return 0.0;
				}

				std::cerr << "Neither LaPlace norm or BM25 norm was set. This is an error!" << std::endl;
				exit(EXIT_FAILURE);
			}
*/
		};


		class IndexObject {
		private:
			std::string TERM;
			std::vector<DocIDFreq *> VALS;
		public:
			IndexObject();
			IndexObject(const std::string term, const std::vector<DocIDFreq *> v){
				 TERM = term;
				 VALS = v;
			}
			~IndexObject(){};
			std::string getTerm(){
				return TERM;
			}

			std::vector<DocIDFreq *> getVals(){
				return VALS;
			}
		};

		class QUERYOBJECT {
		private:
			std::string queryid;
			std::vector<std::string> qterms;
			std::string scoreModel;
			map<std::string, int> queryfreq;
			double score;
			~QUERYOBJECT(){};
		public:
			/* *_query contains the query terms of the specificed query */
			QUERYOBJECT();
			QUERYOBJECT(const std::vector<std::string> _qterms, std::string _queryid, std::string _scoreModel, map<std::string, int> _queryfreq){
				scoreModel = _scoreModel;
				queryid    = _queryid;
				qterms     = _qterms;
				queryfreq  = _queryfreq;
				score      = 0.0;
			}

			std::string toString(){
				std::string ret = "";
				std::vector<std::string>::iterator it;
				for(it = qterms.begin(); it != qterms.end(); ++it){
					ret = ret + (*it) + " ";
				}
				return ret;
			}

			std::vector<std::string> getQueryTerms(){
				return qterms;
			}

			void setScoreModel(std::string _scoreModel){
				scoreModel = _scoreModel;
			}

			std::string getScoreModel(){
				return scoreModel;
			}

			void setScore(double _score){
				score = _score;
			}

			double getScore(){
				return score;
			}

			std::string getQueryID(){
				return queryid;
			}

			int getQueryTermFrequency(std::string term){
				bool found = queryfreq.find(term) != queryfreq.end();
				if(found){
					return queryfreq[term];
				}
				return -1;
			}
		};

		/*
		 * The following two template sorts a map by its values in increasing order.
		 * Use a reverse_iterator to iterate over the map in reverse
		 */
		template<typename A, typename B>
		std::pair<B,A> flip_pair(const std::pair<A,B> &p)
		{
		    return std::pair<B,A>(p.second, p.first);
		}

		template<typename A, typename B>
		std::multimap<B,A> flipAndSortmap(const std::map<A,B> &src)
		{
		    std::multimap<B,A> dst;
		    std::transform(src.begin(), src.end(), std::inserter(dst, dst.begin()),
		                   flip_pair<A,B>);
		    return dst;
		}

		template<typename A, typename B>
		std::multimap<B,A> flipAndSortUnorderedmap(const std::unordered_map<A,B> &src)
		{
		    std::multimap<B,A> dst;
		    std::transform(src.begin(), src.end(), std::inserter(dst, dst.begin()),
		                   flip_pair<A,B>);
		    return dst;
		}

		/*
		 * FUNCTIONS
		 */
/*
		void getInvLists(indri::collection::Repository & r,
						  std::set<std::string> qTerms   ,
						  double c,
						  double b);
*/
		void getInvLists(indri::collection::Repository & r,
							 std::set<std::string> qTerms   ,
							 double c,
							 double b,
							 std::unordered_map<std::string, vector<idx::DocIDFreq * > >	& tlist,
							 std::unordered_map<std::string, std::tuple<unsigned int, unsigned int, std::vector<double> > > & eliteset,
							 std::string modelest);

		void getInvLists2(indri::collection::Repository & r,
							 std::set<std::string> qTerms   ,
							 std::unordered_map<std::string, vector<idx::DocIDFreq * > >	& tlist,
							 std::unordered_map<std::string, std::tuple<unsigned int, unsigned int, std::vector<double> > > & eliteset,
							 std::string modelest);
/*
		std::vector<IndexObject*> pargetInvLists(indri::collection::Repository & r,
												 std::vector<std::string> qTerms,
												 double c,
												 double b);
*/
		//std::unordered_map<std::string, vector<idx::DocIDFreq * >> * getInvertedIndex();
		std::set<double> * getTFNPointer();

		std::vector<std::string> split(const std::string &s, char delim, std::vector<std::string> &elems);

		std::string printTime();

		void calcDocLengths(std::string collection);

		constexpr unsigned int str2int(const char* str, int h = 0)
		{
		    return !str[h] ? 5381 : (str2int(str, h+1)*33) ^ str[h];
		}
}
#endif /* AUX_HPP_ */
