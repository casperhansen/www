/*
 * TrecEval.hpp
 *
 *  Created on: Jun 23, 2015
 *      Author: casper
 */

#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <iostream>
#include <sstream>
#include <vector>
#include <map>

#ifndef TRECEVAL_HPP_
#define TRECEVAL_HPP_

class TrecEval{
public:
	std::map<std::string, double> evaluate(std::string qrels, std::string results);

	void setEvaluationResult(std::vector<double> d){
		evalres = d;
	}

	std::vector<double> getEvaluationResult(){
		return evalres;
	}

private:
	std::vector<double> evalres;
};


#endif /* TRECEVAL_HPP_ */
