/*
 * CV.hpp
 *
 *  Created on: Aug 27, 2015
 *      Author: casper
 */


#include "aux.hpp"


#ifndef CV_HPP_
#define CV_HPP_

	class Fold{
		private:
			std::vector<std::string> FOLD;
		public:

			Fold(){};

			void setFold(std::vector<std::string> f){
				FOLD = f;
			}

			std::vector<std::string> getFold(){
				return FOLD;
			}
	};

	class CV{
	protected:

	private:
		/* Constants */
		std::string INDEX;
		map<Fold *, Fold *> traintest;
		/* Functions */
		map<Fold *, Fold *> doFolding(std::string index, double nof_folds){
			/* Open index */
			indri::collection::Repository r;
			r.openRead( index );

			indri::server::LocalQueryServer local(r);
			double docCount = (double)local.documentCount();

			r.close();

			if(nof_folds == docCount){
				std::cerr << "Warning: There is only 1 document per fold" << std::endl;
			}

			if(nof_folds > docCount){
				std::cout << "Number of queries for cross-validation ("<< docCount << ") is smaller than the number of folds ("<< nof_folds <<")." << std::endl;
				exit(EXIT_FAILURE);
			}

			int NOF_QUERIES_PER_FOLD = docCount/nof_folds;

			if((NOF_QUERIES_PER_FOLD % 1) != 0){
				NOF_QUERIES_PER_FOLD = floor(NOF_QUERIES_PER_FOLD);
			}

//			std::cout << "Number of queries per fold " << NOF_QUERIES_PER_FOLD << std::endl;

			std::vector<int> counts;
			for(int i = 0; i < nof_folds; i++){
				counts.push_back(NOF_QUERIES_PER_FOLD);
			}

			int MISSING_QUERIES = docCount - (nof_folds * NOF_QUERIES_PER_FOLD);

//			std::cout << "There were " << MISSING_QUERIES << " queries not allocated" << std::endl;

			for(int i = 0; i < MISSING_QUERIES; i++){
				counts[i] = counts[i] + 1;
			}

			/* Shuffle the indices */
			std::vector<std::string> indices;

  		    for (int i=0; i<docCount; i++){
  		    	indices.push_back( SSTR(i+1) ); // So queries start with 1
  		    }

  		    std::srand(std::time(0)); // Uncomment to get the same folds every time.
  		    std::random_shuffle( indices.begin(), indices.end() );
/*
  		    std::vector<std::string>::iterator indices_itr;
  		    for(indices_itr = indices.begin(); indices_itr != indices.end(); ++indices_itr){
  		    	std::cout << (*indices_itr) << ", ";
  		    }
  		    std::cout << std::endl;
*/
			std::vector<int> limits;
			limits.push_back(0);
			int cumsum = 0;
			/*
			 * 'counts' contains the number of queries per fold.
			 * limits will contain the low/high query id or each fold.
			 * THIS ASSUMES THAT QUERY IDS ARE ALLOCATED SEQUENTIALLY AND WITH NO GAPS!
			 *
			 * However, because that is how Indri assigns doc ids, there will be no gaps.
			 * This does, however, mean that once the documents have been scored, the original docids
			 * must be fetched so trec_eval can be used.
			 *
			 * See Score::loadQueries in Score.cpp
			 */
			for(int j = 0; j<counts.size(); j++){
				cumsum += counts[j];
				limits.push_back(cumsum);
			}
/*
			std::cout << "Printing limits" << std::endl;
			std::vector<int>::iterator ii;
			for(ii = limits.begin(); ii != limits.end(); ++ii){
				std::cout << (*ii) << ", ";
			}
			std::cout << std::endl;
*/
			map<int, Fold *> FOLDS;
			for(int i = 0; i < limits.size()-1; i++){
				int low  = limits[i]; int high = limits[i+1];
				std::vector<std::string> curr_Fold;
//				std::cout << "Printing for low: " << low << ", and high: " << high << std::endl;
				for(int j = low; j < high; j++){
					std::string testquery = indices[j];
//					std::cout << "Testquery: " << testquery << std::endl;
					curr_Fold.push_back(testquery);
				}
				Fold * f = new Fold();
				f->setFold(curr_Fold);
				FOLDS[i] = f;
			}

			/* Now construct the <test, <train>> setup */

			for(int testfold = 0; testfold < FOLDS.size(); testfold++){
				vector<std::string> trainqueries;
				for(int trainfold = 0; trainfold < FOLDS.size(); trainfold++){
					if(trainfold != testfold){
//						std::cout << "Trying to insert..." << std::endl;
//						std::cout << "Size of trainqueries: " << trainqueries.size() << std::endl;
						std::vector<std::string>::iterator itr;
						std::vector<std::string> ff = FOLDS[trainfold]->getFold();
						for(itr = ff.begin(); itr != ff.end(); ++itr){
							trainqueries.push_back(*itr);
						}
//						trainqueries.insert(trainqueries.end(),
//								            std::make_move_iterator(FOLDS[trainfold]->getFold().begin()),
//								            std::make_move_iterator(FOLDS[trainfold]->getFold().end()) );
						//std::cout << "Succes!" << std::endl;
					}
				}
/*
				std::vector<int>::iterator it;
				for(it = trainqueries.begin(); it != trainqueries.end(); ++it){
					std::cout << *it << " ";
				}
				std::cout << std::endl;
*/
				Fold * f = new Fold();
				f->setFold(trainqueries);
				traintest[FOLDS[testfold]] = f;
			}
			return traintest;
		}

		void checkNofFolds(int nof_folds){
			if(nof_folds < 2){
				std::cout << "Specified number of folds: " << nof_folds << " not allowed. Minimum is 2" << std::endl;
				exit(EXIT_FAILURE);
			}
		}

	public:
		CV(std::string index){INDEX = index;};

		/* Default is three fold cross validation */
		map<Fold *,Fold *> createfolds(){
			return doFolding(INDEX, 3);

		}

		map<Fold *,Fold *> createfolds(int nof_folds){
			checkNofFolds(nof_folds);
			return doFolding(INDEX, nof_folds);
		}

		void printCrossFolds(){
			map<Fold *, Fold *>::iterator it;

			for(it = traintest.begin(); it != traintest.end(); ++it){
				Fold * f1 = it->first;
				Fold * f2 = it->second;

				std::vector<std::string> testing  = f1->getFold();
				std::vector<std::string> training = f2->getFold();
				std::cout << std::endl;
				std::cout << "Printing testing fold" << std::endl;
				std::vector<std::string>::iterator testitr;
				for(testitr = testing.begin(); testitr != testing.end(); ++testitr){
					std::cout << (*testitr) << ",";
				}
				std::cout << std::endl;

				std::cout << "Printing training fold" << std::endl;
				std::vector<std::string>::iterator trainitr;
				for(trainitr = training.begin(); trainitr != training.end(); ++trainitr){
					std::cout << (*trainitr) << ",";
				}

			}
			std::cout << std::endl;
		}
	};

#endif /* CV_HPP_ */
