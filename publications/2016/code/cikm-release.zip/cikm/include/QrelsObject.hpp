/*
 * QrelsObject.hpp
 *
 *  Created on: Nov 14, 2015
 *      Author: casper
 */

#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <unordered_map>
#include <map>
#include <set>
#include <cmath>
#include <cstring>
#include <limits>
#include <iterator>
#include <iomanip>      // std::setprecision
#include <algorithm>
#include <utility>
#include <ctime>
#include <cctype>

#ifndef QRELSOBJECT_HPP_
#define QRELSOBJECT_HPP_

namespace Qrels{
	class Object{

	private:
		std::map<std::string, int>  QID_TO_DOC_AND_RELSCORE;
		int NUM_REL_DOCS;

	public:
		Object(std::map<std::string, int>  st, int num_rel_docs){
			QID_TO_DOC_AND_RELSCORE = st;
			NUM_REL_DOCS            = num_rel_docs;
		};
		~Object(){};

		std::map<std::string, int> getQidToDocAndRelScore(){
			return QID_TO_DOC_AND_RELSCORE;
		}

		int getNumRelDocs(){
			return NUM_REL_DOCS;
		}
	};
}


#endif /* QRELSOBJECT_HPP_ */
