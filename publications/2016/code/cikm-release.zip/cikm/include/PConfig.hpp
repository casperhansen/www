/*
 * ParseConfig.hpp
 *
 * Reads a file of the form:
 *
 * <key> = "<val>";
 *
 * Notice that <val> must be enclosed in double quotes and each line semi-colon terminated.
 *
 * DEPENDENCY:
 * This file requires the config4cpp library.
 *
 * EXAMPLE:
 * queryindex = "/home/laptop/indexes/test-queries/";
 * collection = "/home/laptop/indexes/test-documents/";
 * cutoff = "-1";
 * outputloc =  "/home/laptop/results.txt";
 * model = "PL2";
 * run_id = "run-1";
 * logger = "/home/laptop/DFR/logger.config";
 *
 *
 *  Created on: Jun 22, 2015
 *      Author: Casper Petersen
 */

#include <config4cpp/Configuration.h>
#include <map>
#include <stdio.h>
#include <string.h>

#ifndef PCONFIG_HPP_
#define PCONFIG_HPP_

		class PConfig{
			private:
				std::string QUERY_INDEX       = "";
				std::string QUERY_FIELD       = "";
				std::string COLLECTION_INDEX  = "";
				std::string OUTPUTLOCATION    = "";
				std::string MODEL 			  = "";
				std::string LOGGER_PATH       = "";
				std::string QRELS_LOCATION    = "";
				std::string PERFORMANCE       = "";
				std::string MODEL_TO_ESTIMATE = "";
				std::string PARAMETER_FILE    = "";
				int NUM_OF_THREADS            = -1;
				int CUTOFF  				  = -1;
				int FOLDS                     =  0;
				int NTRIALS                   =  0;
				double CNORM                  = -1.0;
				double BNORM                  = -1.0;
				double P1                     = -1.0;
				double P2                     = -1.0;
				double P3                     = -1.0;
				bool   USE_LAPLACE            = false;
				bool   LAMBDA                 = "";
			public:
				void parse_configuration(char * configFile){
					config4cpp::Configuration *  cfg = config4cpp::Configuration::create();
					const char *  _scope          	 = "";
					std::string p1;
					std::string p2;
					std::string p3;
					std::string cn;
					std::string bn;
				    try {
				        cfg->parse(configFile);

				        QUERY_INDEX    		   = cfg->lookupString(  _scope, "queryindex"    );
				        QUERY_FIELD            = cfg->lookupString(  _scope, "queryfield"    );
				        COLLECTION_INDEX  	   = cfg->lookupString(  _scope, "collection"    );
				        CUTOFF				   = cfg->lookupInt(     _scope, "cutoff"        );
				        OUTPUTLOCATION         = cfg->lookupString(  _scope, "outputloc"     );
				        MODEL       		   = cfg->lookupString(  _scope, "model"         );
				        MODEL_TO_ESTIMATE      = cfg->lookupString(  _scope, "model_estimate");
				        LOGGER_PATH            = cfg->lookupString(  _scope, "logger"        );
				        QRELS_LOCATION         = cfg->lookupString(  _scope, "qrels"         );
				        PERFORMANCE            = cfg->lookupString(  _scope, "performance"   );
				        PARAMETER_FILE         = cfg->lookupString(  _scope, "parameter_file");
				        FOLDS                  = cfg->lookupInt(     _scope, "folds"         );
				        NTRIALS                = cfg->lookupInt(     _scope, "ntrials"       );
				        NUM_OF_THREADS         = cfg->lookupInt(     _scope, "num_threads"   );
				        USE_LAPLACE            = cfg->lookupBoolean( _scope, "uselaplace"    );
				        LAMBDA                 = cfg->lookupBoolean( _scope, "useFtlambda"   );
				        cn                     = cfg->lookupString(  _scope, "cnorm"         );
				        bn                     = cfg->lookupString(  _scope, "bnorm"         );
				        p1                     = cfg->lookupString(  _scope, "parm1"         );
				        p2                     = cfg->lookupString(  _scope, "parm2"         );
				        p3                     = cfg->lookupString(  _scope, "parm3"         );
				    } catch(const config4cpp::ConfigurationException & ex) {
				        std::cerr << ex.c_str() << std::endl;
				        cfg->destroy();
				    }
				    /* Cast the parameters to double */
					std::istringstream i(p1);
					i >> P1;
					std::istringstream j(p2);
					j >> P2;
					std::istringstream k(p3);
					k >> P3;
					std::istringstream m(cn);
					m >> CNORM;
					std::istringstream n(bn);
					n >> BNORM;

					/* Destroy the cfg */
				    cfg->destroy();
				}
				std::string getQueryIndex(){
					return QUERY_INDEX;
				}

				std::string getCollectionIndex(){
					return COLLECTION_INDEX;
				}

				std::string getRetrievalResults(){
					return OUTPUTLOCATION;
				}

				std::string getModel(){
					return MODEL;
				}

				std::string getLoggerLocation(){
					return LOGGER_PATH;
				}

				std::string getQrelsLoc(){
					return QRELS_LOCATION;
				}

				std::string getQueryField(){
					return QUERY_FIELD;
				}

				std::string getPerformanceMeasure(){
					return PERFORMANCE;
				}

				std::string getModelToEstimate(){
					return MODEL_TO_ESTIMATE;
				}

				std::string getParameterFile(){
						return PARAMETER_FILE;
				}

				bool getLambdaType(){
					return LAMBDA;
				}

				int getCutoff(){
					return CUTOFF;
				}

				int getNumberOfFolds(){
					return FOLDS;
				}

				int getNofTrials(){
					return NTRIALS;
				}

				int getNofThreads(){
					return NUM_OF_THREADS;
				}

				double getFirstParameter(){
					return P1;
				}

				double getSecondParameter(){
					return P2;
				}

				double getThirdParameter(){
					return P3;
				}

				double getLaplaceNorm(){
					return CNORM;
				}

				double getBm25Norm(){
					return BNORM;
				}

				bool useLaplace(){
					return USE_LAPLACE;
				}

				void setRetrievalResults(std::string & s){
					OUTPUTLOCATION = s;
				}

				void printHelp(){
						std::cout << "DFR:" << std::endl;
						std::cout << "Implementing the Relevance Weighting using Within-document Term Statistics" << std::endl;
						std::cout << std::endl;
						std::cout << "COMPILATION:"    		<< std::endl;
						std::cout << "make -f DFR.app" 		<< std::endl;
						std::cout << std::endl;
						std::cout << "USAGE:"          		<< std::endl;
						std::cout << "./DFR config.parm" 	<< std::endl;
						std::cout << std::endl;
						std::cout << "INPUT:"               << std::endl;
						std::cout << "A <key>=\"<parm>\"; list. Each <parm> must be enclosed in double-quotes and every line must be semi-colon terminated" << std::endl;
						std::cout << "Valid keys, semantics and type are:"								        		 << std::endl;
						std::cout << "queryindex : The location of the INDRI index holding the indexed queries (STRING)" << std::endl;
						std::cout << "queryfield : The name of the field of a TREC query file to use as query  (STRING)" << std::endl;
						std::cout << "collection : The location of the INDRI index holding the collection      (STRING)" << std::endl;
						std::cout << "stopwords  : The location of the INDRI index holding the stopwords.      (STRING)" << std::endl;
						std::cout << "qrels      : The location of the TREC qrels                              (STRING)" << std::endl;
						std::cout << "cutoff     : How any documents to retrieve for each query                (INT)"	 << std::endl;
						std::cout << "outputloc  : Where to write the scoring results to be used in trec_eval  (STRING)" << std::endl;
						std::cout << "model      : What scoring model to use                                   (STRING)" << std::endl;
						std::cout << "runid      : The runid for the (identical to indri)                      (STRING)" << std::endl;
						std::cout << "logger     : The location of the configuration file for easylogging++.h  (STRING)" << std::endl;
						std::cout << std::endl;
						std::cout << "MODELS:"																			 << std::endl;
						std::cout << "WL2d: Weibull model." 														 	 << std::endl;
						std::cout << "    Values for PARM1 (k - shape) and PARM2 (lambda - scale) must be specified" 	 << std::endl;
						std::cout << "PL2d: Poisson model." 															 << std::endl;
						std::cout << "    Value for PARM1 (lambda - shape) must be specified" 							 << std::endl;
						std::cout << "GL2d: Gamma model." 																 << std::endl;
						std::cout << "    Values for PARM1 (alpha - shape) and PARM2 (lambda - scale) must be specified" << std::endl;
						std::cout << "EL2d: Exponential model." 														 << std::endl;
						std::cout << "    Value for PARM1 (lambda - shape) must be specified" 							 << std::endl;
						std::cout << "RL2d: Rayleigh model." 															 << std::endl;
						std::cout << "    Value for PARM1 (sigma - shape) must be specified" 							 << std::endl;
						std::cout << "PLAWL2d: Power law model." 														 << std::endl;
						std::cout << "    Value for PARM1 (alpha - scale) must be specified" 							 << std::endl;
						std::cout << "CHIL2d: Chi-square model." 														 << std::endl;
						std::cout << "    Value for PARM1 (n - shape) must be specified" 								 << std::endl;
					    std::cout << std::endl;
						std::cout << "MODEL PARAMETERS:" 																 << std::endl;
						std::cout << "Model parameters are specified identical to other parameters: " 					 << std::endl;
						std::cout << "Parm1: The value of the first parameter    (DOUBLE)" 								 << std::endl;
						std::cout << "Parm2: The value of the second parameter   (DOUBLE)" 								 << std::endl;
						std::cout << "Parm3: The value of the third parameter    (DOUBLE)" 								 << std::endl;
						std::cout << "Default values for all parameters are -1.0"				 						 << std::endl;
						std::cout << std::endl;
				}
		};

#endif /* PARSECONFIG_HPP_ */
