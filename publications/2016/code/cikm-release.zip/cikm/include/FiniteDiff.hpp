/*
 * FiniteDiff.hpp
 *
 *  Created on: Jul 3, 2015
 *      Author: casper
 */

#ifndef FINITEDIFF_HPP_
#define FINITEDIFF_HPP_

/*
 * Declare the finite difference schemes. For higher order functions they are analogous to partial derivatives
 */
class FiniteDifference
{
protected:
	virtual ~FiniteDifference(){};
	std::string SCHEME_TYPE;

public:
	virtual double evaluate();

	void setScheme(std::string s){
		SCHEME_TYPE = s;
	}

	std::string getScheme(){
		return SCHEME_TYPE;
	}
};


#endif /* FINITEDIFF_HPP_ */
