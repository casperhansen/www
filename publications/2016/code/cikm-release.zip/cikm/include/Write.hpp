/*
 * Write.hpp
 *
 *  Created on: Jun 23, 2015
 *      Author: casper
 */

#ifndef WRITE_HPP_
#define WRITE_HPP_

class TRECResults{
public:
	TRECResults(){};
	void write(std::map<std::string, std::multimap<float, std::string> > res,                const char * loc, int cutoff, std::string run_id);
	bool write(std::vector<std::pair<std::string, std::multimap<float, std::string> > > * res, const char * loc, int cutoff, std::string run_id);
private:

};


#endif /* WRITE_HPP_ */
