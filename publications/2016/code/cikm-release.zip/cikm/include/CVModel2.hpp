#include "aux.hpp"
#include "CV.hpp"
#include "Score.hpp"
#include "ScoreModel.hpp"
#include "PConfig.hpp"
#include "Write.hpp"		// I/O
#include "TrecEval.hpp"		// Trec-eval (called outside)
#include "CV.hpp"			// Cross-validation

/*
const int MAP_INDEX 		= 0;
const int BPREF_INDEX 		= 1;
const int P_AT_TEN_INDEX 	= 2;
const int NDCG_INDEX 		= 3;
const int NDCT_AT_TEN_INDEX = 4;
*/

typedef map<Fold *,Fold *> CVFOLDS; // Contains <test-queries, train-queries>
typedef std::vector<std::string> FOLD;
typedef std::vector<double> RESULT;
typedef std::vector<double> BOUNDS;
typedef std::vector<double> PARAMETER;

#ifndef CVMODEL2_HPP_
#define CVMODEL2_HPP_

class CVModel2{
	/*
	 * Cross-validate model

	void CV(){
		Score * s;
		TRECResults * r;
		TrecEval * t;

		doCV(s, CONFIG, 5);
	}
*/

	private:
		PConfig CONFIG;
		Score * S;
    	//void doCV(Score *, PConfig, int);

		PConfig getConfig(){
			return CONFIG;
		}

		Score * getScore(){
			return S;
		}

		void doCV(Score *, PConfig, int);

	public:

		void xvalidate(int x){
			doCV(getScore(), getConfig(), x);
		}

	    CVModel2(PConfig config, Score * s){
			CONFIG = config;
			S      = s;
		};
};


#endif /* CVMODEL2_HPP_ */
