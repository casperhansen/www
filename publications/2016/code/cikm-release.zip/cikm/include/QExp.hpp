/*
 * QueryExpansion.hpp
 *
 *  Created on: Jun 29, 2015
 *      Author: casper
 */

#include "indri/QueryEnvironment.hpp"
#include "indri/Repository.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/LocalQueryServer.hpp"

#ifndef QEXP_HPP_
#define QEXP_HPP_

class QExp{
private:
	std::string tfidf(std::string& index, std::string query, std::vector<int> docids);
	std::vector<int> retrieve(std::string& index, std::string query);

public:
	std::string expand(std::string& index, std::string query);
};


#endif /* QEXP_HPP_ */
