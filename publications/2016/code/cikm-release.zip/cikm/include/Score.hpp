/*
 * Source.hpp
 *
 *  Created on: Jun 22, 2015
 *      Author: casper
 */

//#include "aux.hpp"
#include <set>
#include <map>
#include <vector>
#include "PConfig.hpp"
#ifndef SCORE_HPP_
#define SCORE_HPP_

enum DERIVATIVE {DX,DY,DZ};

class Score
{
private:
public:
	Score(){};
//	~Score(){};
	/*
	 * Prototypes
	 * loadCVQueries takes the additional parameter CVqueries. This is a vector of INDRI queryIDs i.e. consecutive
	 * numbered queries (does not correspond to the real query ids) that belongs to the training/test set.
	 */
	void loadQueries(std::string index, std::string field);
	void loadQueriesWStopwords(std::string index, std::string field,std::string stopwordfile);
	void loadCVQueries(std::string index, std::string field, std::vector<std::string> CVqueries);
	void loadInvertedIndex(std::string index, double c, double b, std::string modelest);
	void setScoreModel(std::string smname, std::vector<double> parms);
	//void score();	   //Sequential score
	void parscore(PConfig & c); //Parallel score (OpenMP)
	void parscore2(PConfig & c, std::vector<std::string>, double cval); //Parallel score (OpenMP)
	void parscore3(PConfig & c, std::vector<std::string>, double cval); //Parallel score (OpenMP)
	void init(std::string collection);
	void cleanup();
	void loadListOfNonInformativeWords(const char * s);
	void loadFile(std::string s);

	/*
	 * Print
	 */
	void printScoredQueries();
	void printParScoredQueries();
	void printPooledQueryTerms();
	void printGetQueryRep();
	void printQTermsInvLists();
	void printQTermsInvLists(std::string str);

	/*
	 * Getters
	 */
	std::map< std::string, std::multimap<float,std::string> > getScoredQueries();
	std::vector<std::pair<std::string, std::multimap<float, std::string> > > getScoredVecQueries();
	std::vector<std::pair<std::string, std::multimap<float, std::string> > > * getScoredVecQueriesPointer();
	std::set< std::string > getPooledQueryTerms();
	map<std::string, idx::QUERYOBJECT *> getQueryRep();
	//std::unordered_map<std::string, vector<idx::DocIDFreq *> > getQTermsInvLists();
	std::vector<double> getScoreModelParameterBounds(int);
	int getNofScoreModelParameters();
	std::string getScoreModelName();
	std::vector<double> getScoreModelParameters();
	std::string getRandomPooledQueryTerim();

	/*
	 * Setters
	 */
	void updateScoreModelParameters(std::vector<double>);
};

#endif /* SCORE_HPP_ */
