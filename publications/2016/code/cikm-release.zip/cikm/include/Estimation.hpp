/*
 * Distributions.hpp
 *
 *  Created on: Dec 4, 2015
 *      Author: casper
 */
#ifndef ESTIMATION_HPP_
#define ESTIMATION_HPP_

class Estimation
{
protected:
	virtual ~Estimation(){};
private:

public:
	virtual std::vector<double> estimate(std::vector<unsigned short int> & data, std::vector<double> & misc){};
};

class GEV : public Estimation
{
	std::vector<double> estimate(std::vector<unsigned short int> & data, std::vector<double> & misc){
		std::vector<double> parms;
		return parms;
	}
};

class Powerlaw : public Estimation
{
protected:
private:
public:
	std::vector<double> estimate(std::vector<unsigned short int> & data, std::vector<double> & misc){
		std::vector<double> parms;
		int n       = data.size();
		double xmin = misc.at(0);
		double ahat = 0.0;
		for(int i = 0; i < n; i++){
			ahat += log(2.0*data.at(i)); // Definition from "A fixed-point algorithm to estimate the Yule-Simon distribution parameter"
		}
		ahat = 1 + n/ahat;
		parms.push_back(ahat);
		parms.push_back(xmin);
		return parms;
	}
	// Estimate alpha
};

class Yule : public Estimation
{
	std::vector<double> estimate(std::vector<unsigned short int> & data, std::vector<double> & misc){
		std::vector<double> parms;
		Estimation * est = new Powerlaw;
		parms            = est->estimate(data, misc);
		double phat      = parms[0] - 1.0;
		parms.clear();
		parms.push_back(phat);
		return parms;
	}
};

class YuleAlt : public Estimation
{
/*
 * This is an implementation of Algorithm 1 from "A fixed-point algorithm to estimate the Yule-Simon distribution parameter"
 */
	std::vector<double> estimate(std::vector<unsigned short int> & data, std::vector<double> & misc){
		std::vector<double> parms;
		double N  = data.size();
		double p0 = 0.0;
		double p1 = 0.0;
		bool f    = false;

		while(!f){
			double s = 0.0;
			for(int i = 0; i < N; i++){
				for(int j = 0; j < data.at(i); j++){
					s += 1/(p0 + j);
				}
			}
			p1 = N/s;
			f  = abs(p1 - p0) < 0.00001;
			p0 = p1;
		}
		parms.push_back(p1);
		return parms;
	}
};

class EstimationFactory{
private:
	Estimation * est;
public:
	Estimation * getEstimator(std::string description){
		if(description.compare("powerlaw") == 0){
			est = new Powerlaw;
		}else if(description.compare("yule") == 0){
			est = new Yule;
		}else{
			//gev
			est = new GEV;
		}

		return est;
	}
};

#endif /* DISTRIBUTIONS_HPP_ */
