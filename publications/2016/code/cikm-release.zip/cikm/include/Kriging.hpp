/*
 * Kriging.hpp
 *
 *  Created on: Oct 24, 2015
 *      Author: casper
 */
#include "splinter/datatable.h"
#include "splinter/bsplineapproximant.h"
#include "splinter/psplineapproximant.h"
#include "splinter/rbfapproximant.h"
#include "splinter/polynomialapproximant.h"

#ifndef KRIGING_HPP_
#define KRIGING_HPP_
	class Kriging{
	// Variables

	public:
		// Number of trials from which the B-spline interpolations will be done
		void train(int, int) = 0;
		void eval(int SPLINE_TYPE) = 0;
	private:


	protected:

	};

#endif /* KRIGING_HPP_ */
