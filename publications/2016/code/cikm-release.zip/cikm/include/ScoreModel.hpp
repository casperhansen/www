/*
 * ScoreModels.hpp
 *
 * As all data we occupy ourselves with are positive, we restrict the range of all
 * parameters to be positive as well.
 *
 * 28-10-2015: Changed all score() calls to take three parameters: qtf, tf, norm
 *
 *  Created on: Jun 18, 2015
 *      Author: Casper
 */

#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <string>
#include <iostream>
#include <cmath>
#include <map>
#include "easylogging++.h"
#include <unordered_map>
#include <limits.h>
#include "boost/math/special_functions/beta.hpp" // For beta function for Yule distribution
#include <gsl/gsl_errno.h> // For Zeta Hurwitz calculations
#include <gsl/gsl_math.h>
#include <gsl/gsl_sf_zeta.h>
#include <gsl/gsl_sf_gamma.h>

#ifndef SCOREMODEL_HPP_
#define SCOREMODEL_HPP_

# define M_PI_          3.141592653589793238462643383279502884L /* pi */
typedef std::map<int, std::vector<double> > BOUND; /* A map that holds the lower/upper bound of each parameter */
class ScoreModel {

protected:
	/* Functions */
	virtual ~ScoreModel(){};
    /* Uninitialised variables */
    std::string MODEL;
	double STEP_SIZE;
	int NUMPARMS;
	int MODEL_ID; // God I hate that switches are not supported on strings...
	BOUND bounds;
	std::vector<double> PARMS;

	/* Initialised variables */
	double DOUBLE_INF =	20.0;//std::numeric_limits<double>::max();
	int INT_INF 	  =	20;  //std::numeric_limits<int>::max();

public:
	virtual void setParameters(std::vector<double>){};
	virtual double score(double tf) = 0;
	virtual double score(double tf, std::vector<double> parms) = 0;
	virtual void updateParameters(std::vector<double>){};

	void setModelName(std::string model){
    	MODEL = model;
    }

	void setModelID(int v){
		MODEL_ID = v;
	}

	std::vector<double> getParameters(){
		 return PARMS;
	}

	void setScoreModelParameters(std::vector<double> p){
		PARMS = p;
	}

    std::string getModelName(){
    	return MODEL;
    }

    int getModelID(){
    	return MODEL_ID;
    }

	void setNumParameters(int nofparms){
		NUMPARMS = nofparms;
	}

	int getNumParameters(){
		return NUMPARMS;
	}

    void setStepSize(double s){
    	STEP_SIZE = s;
    }

    double getStepSize(){
    	return STEP_SIZE;
    }

	std::vector<double> getParameterBounds(int pidx){
		auto search = bounds.find(pidx);
		if(search != bounds.end()){
			return search->second;
		}
		std::vector<double> s;
		return s;
	}
};

/*
 * WL2d.cpp
 *
 * Implementation of the WL2d model from
 * "Relevance Weighting using Within-document Term Statistics"
 * by Kai Hui, Ben He, Tiejian Luo, Bin Wang, CIKM 2011
 *
 */

class WL2d: public ScoreModel
{
private:
	double k;
	double lambda;

	double scoreModel(double docfreq){
		//return ((k / lambda)  *  pow((docfreq / lambda), (k - 1.0))  *  exp(-1.0 * (pow( (docfreq / lambda), k))));
		return scoreModel(docfreq, k, lambda);
		//return ((k / lambda)  *  pow((docfreq / lambda), (k - 1.0))  *  exp(-1.0 * (pow( (docfreq / lambda), k))));
	}

	/* Overload for gradient searching */
	double scoreModel(double docfreq, double k, double lambda){
		return ((k / lambda)  *  pow((docfreq / lambda), (k - 1.0))  *  exp(-1.0 * (pow( (docfreq / lambda), k))));
	}

public:
	void setParameters(std::vector<double> parms){
		if(parms.size() != 3){
			std::cerr << "(ScoreModel.hpp) - Number of parameters given to GPL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		k      = parms.at(0);
		lambda = parms.at(1);

		if(k <= 0 || lambda <= 0){
			std::cerr << "(ScoreModel.hpp) - Illegal parameter value(s) given to WL2d!" << std::endl;
			exit(EXIT_FAILURE);
		}
		// Weibull is a two parameter model, so we pop the dummy variable from the back
		parms.pop_back();
		setScoreModelParameters(parms);
		setNumParameters(parms.size());

		/* Set the lower and upper bounds */
		std::vector<double> b1;
		b1.push_back(0.1);        // Lower bound for parameter k
		b1.push_back(DOUBLE_INF); // Upper bound for parameter k
		bounds[0] = b1;

		std::vector<double> b2(b1); // Copy b1 as lambda and k have the same limits
		bounds[1] = b2;

	}

	void updateParameters(std::vector<double> p){
		if(p.size() != 2){
			std::cerr << "(ScoreModel.hpp - updateParameters) - Number of parameters given to GPL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		setScoreModelParameters(p);
		k      = p.at(0);
		lambda = p.at(1);
	}

	double score(double tf){
		return -log2(scoreModel(tf));
	}

	double score(double tf, std::vector<double> parms){
		return -log2(scoreModel(tf, parms.at(0), parms.at(1)));
	}
};


class PL2d: public ScoreModel
{
private:
	double lambda;

	double scoreModel(double tf){
		//return (tf * log2( tf / lambda) + (lambda + (1 / (12 * tf)) - tf) * log2(exp(1.0)) + 0.5 * log2(2*M_PI_*tf));
		//return (pow(lambda, tf) * exp(-lambda) / tgamma(tf+1));
		return scoreModel(tf, lambda);
	}

	double scoreModel(double tf, double lambda){
		/*
		 * Old version
		 */
		//return (tf * log2( tf / lambda) + (lambda + (1 / (12 * tf)) - tf) * log2(exp(1.0)) + 0.5 * log2(2*M_PI_*tf));
		return (pow(lambda, tf) * exp(-lambda) / tgamma(tf+1));
	}

public:

	void setParameters(std::vector<double> parms){
		if(parms.size() != 3){
			std::cout << "(ScoreModel.hpp) - Number of parameters given to PL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		lambda = parms.at(0);

		if(lambda <= 0){
			std::cout << "(ScoreModel.hpp) - Illegal parameter value(s) given to PL2d!" << std::endl;
			exit(EXIT_FAILURE);
		}

		// As every parms given as input has three parameters and Possion only has one, we pop twice
		parms.pop_back();
		parms.pop_back();
		setScoreModelParameters(parms);
		setNumParameters(parms.size());

		/* Set the lower and upper bounds */
		std::vector<double> b1;
		b1.push_back(0.1);        /* Lower bound for lambda */
		b1.push_back(DOUBLE_INF); /* Upper bound for lambda */
		bounds[0] = b1;
	}

	void updateParameters(std::vector<double> p){
		if(p.size() != 1){
			std::cerr << "(ScoreModel.hpp - updateParameters) - Number of parameters given to PL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		setScoreModelParameters(p);
		lambda = p.at(0);
	}

	/*
	 * To compute the score we use the approximation from Eqn (6) in
	 * "Probabilistic Models of Information Retrieval Based on measuring the Divergence from Randomness"
	 * by Amati & Risjbergen, ACM TOIS, Vol. 20, No. 4., 2002
	 */

	double score(double tf){
		return -log2(scoreModel(tf));
	}

	double score(double tf, std::vector<double> parms){
		return -log2(scoreModel(tf, parms.at(0)));
	}
};

class GL2d: public ScoreModel
{

private:
	double alpha;
	double lambda;

	double scoreModel(double tf){
		//return (1.0/(pow(alpha,lambda)*tgamma(lambda)) * pow(tf, (lambda - 1)) * exp(-tf/alpha));
		return scoreModel(tf, lambda, alpha);
	}

	double scoreModel(double tf, double lambda, double alpha){
		/*
		 * Old
		 * return (pow(lambda, alpha)/lgamma(alpha) * pow(tf, alpha - 1) * exp(-1.0 * lambda * tf));
		 */
		return (1.0/(pow(alpha,lambda)*tgamma(lambda)) * pow(tf, (lambda - 1)) * exp(-tf/alpha));
	}

public:
	void setParameters(std::vector<double> parms){
		if(parms.size() != 3){
			std::cout << "(ScoreModel.hpp) - Number of parameters given to GL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		alpha  = parms.at(0);
		lambda = parms.at(1);

		if(alpha <= 0 || lambda <= 0){
			std::cout << "(ScoreModel.hpp) - Illegal parameter value(s) given to GL2d!" << std::endl;
			exit(EXIT_FAILURE);
		}
		parms.pop_back();
		setScoreModelParameters(parms);
		setNumParameters(parms.size());

		/* Set the lower and upper bounds */
		std::vector<double> b1;
		b1.push_back(0.1);        /* Lower bound for alpha */
		b1.push_back(DOUBLE_INF); /* Upper bound for alpha */
		bounds[0] = b1;

		/* Set the lower and upper bounds */
		std::vector<double> b2;
		b2.push_back(0.1);        /* Lower bound for lambda */
		b2.push_back(DOUBLE_INF); /* Upper bound for lambda */
		bounds[1] = b2;
	}

	void updateParameters(std::vector<double> p){
		if(p.size() != 2){
			std::cerr << "(ScoreModel.hpp - updateParameters) - Number of parameters given to GL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		setScoreModelParameters(p);
		alpha  = p.at(0);
		lambda = p.at(1);
	}

	double score(double tf){
		return -log2(scoreModel(tf));
	}

	double score(double tf, std::vector<double> parms){
		return -log2(scoreModel(tf, parms.at(0), parms.at(1)));
	}
};

class EL2d: public ScoreModel
{

private:
	double lambda;

	double scoreModel(double tf){
		return (1/lambda * exp(-tf / lambda));
	}

	double scoreModel(double tf, double lambda){
		/*
		 * OLD
		 * return (lambda * exp(-1.0 * lambda * tf));
		 */
		return (1/lambda * exp(-tf / lambda));
	}

public:
	void setParameters(std::vector<double> parms){
		if(parms.size() != 3){
			std::cout << "(ScoreModel.hpp) - Number of parameters given to EL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		lambda = parms.at(0);

		if(lambda <= 0){
			std::cout << "(ScoreModel.hpp) - Illegal parameter value given to EL2d!" << std::endl;
			exit(EXIT_FAILURE);
		}
		parms.pop_back();
		parms.pop_back();
		setScoreModelParameters(parms);
		setNumParameters(parms.size());

		/* Set the lower and upper bounds */
		std::vector<double> b1;
		b1.push_back(0.1);        /* Lower bound for lambda */
		b1.push_back(DOUBLE_INF); /* Upper bound for lambda */
		bounds[0] = b1;
	}

	void updateParameters(std::vector<double> p){
		if(p.size() != 1){
			std::cerr << "(ScoreModel.hpp - updateParameters) - Number of parameters given to EL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		setScoreModelParameters(p);
		lambda = p.at(0);
	}

	double score(double tf){
		return -log2(scoreModel(tf));
	}

	double score(double tf, std::vector<double> parms){
		return -log2(scoreModel(tf, parms.at(0)));
	}
};

// Rayleigh distribution
class RL2d: public ScoreModel
{

private:
	double sigma;

	double scoreModel(double tf){
		return (tf / pow(sigma, 2.0)) * exp(-1.0 * (  pow(tf, 2.0) / (2*pow(sigma, 2.0))  ));
	}

	double scoreModel(double tf, double sigma){
		return (tf / pow(sigma, 2.0)) * exp(-1.0 * (  pow(tf, 2.0) / (2*pow(sigma, 2.0))  ));
	}

public:
	void setParameters(std::vector<double> parms){
		if(parms.size() != 3){
			std::cout << "(ScoreModel.hpp) - Number of parameters given to RL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		sigma = parms.at(0);
		if(sigma <= 0){
			std::cout << "(ScoreModel.hpp) - Illegal parameter value given to RL2d!" << std::endl;
			exit(EXIT_FAILURE);
		}
		parms.pop_back();
		parms.pop_back();
		//std::cout << "Size of parameters inside RL2d: " << parms.size() << std::endl;
		setScoreModelParameters(parms);
		setNumParameters(parms.size());

		/* Set the lower and upper bounds */
		std::vector<double> b1;
		b1.push_back(0.1);        /* Lower bound for sigma */
		b1.push_back(DOUBLE_INF); /* Upper bound for sigma */
		bounds[0] = b1;
	}

	void updateParameters(std::vector<double> p){
		if(p.size() != 1){
			std::cerr << "(ScoreModel.hpp - updateParameters) - Number of parameters given to RL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		setScoreModelParameters(p);
		sigma = p.at(0);
	}

	double score(double tf){
		return -log2(scoreModel(tf));
	}

	double score(double tf, std::vector<double> parms){
		return -log2(scoreModel(tf, parms.at(0)));
	}
};


class PLAWL2d: public ScoreModel
{

private:
	double alpha;
	double xmin;

	double zeta(double a_hat, double x_min){
		gsl_sf_result result;
		if(gsl_sf_hzeta_e(a_hat, x_min, &result) == GSL_SUCCESS){
			return result.val;
		}
		std::cerr << "Could not calculate zeta value for alpha: " << a_hat << ", and x_min: " << x_min << ". Returning 0 - Crash imminent." << std::endl;
		return 0.0;
	}

	double scoreModel(double tf, double x_min){
		double C = (alpha-1.0)*pow(xmin,alpha-1.0);
		if(C == 0.0){
			return 0.0;
		}
		return C*pow(tf,-alpha);
/*
 * discrete version
		double C = zeta(alpha, xmin);
		if(C == 0.0){
			return 0.0;
		}
		return (1/C * pow(tf, -alpha));
*/
	}

	double scoreModel(double tf, double alpha, double xmin){
		double C = (alpha-1.0)*pow(xmin,alpha-1.0);
		if(C == 0.0){
			return 0.0;
		}
		return C*pow(tf,-alpha);
/*
 * discrete version
		double C = zeta(alpha, xmin);
		if(C == 0.0){
			return 0.0;
		}
		return (1/C * pow(tf, -alpha));
*/
	}

public:
	void setParameters(std::vector<double> parms){
		if(parms.size() != 3){
			std::cerr << "(ScoreModel.hpp) - Number of parameters given to PLAWL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		alpha = parms.at(0);
		xmin  = parms.at(1);
		if( !(alpha > 1) ){
			std::cerr << "(ScoreModel.hpp) - Illegal parameter value given to PLAWL2d!" << std::endl;
			exit(EXIT_FAILURE);
		}
		parms.pop_back();
		setScoreModelParameters(parms);
		setNumParameters(parms.size());

		/* Set the lower and upper bounds */
		std::vector<double> b1;
		b1.push_back(1.1); /* Lower bound for alpha taken from Clauset */
		b1.push_back(3.5); /* Upper bound for alpha taken from Clauset */
		bounds[0] = b1;
	}

	void updateParameters(std::vector<double> p){
		if(p.size() != 1){
			std::cerr << "(ScoreModel.hpp - updateParameters) - Number of parameters given to PLAWL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		setScoreModelParameters(p);
		alpha = p.at(0);
		// Not varying xmin
	}

	double score(double tf){
		return -log2(scoreModel(tf, 1.0));
	}

	double score(double tf, double xmin){
		return -log2(scoreModel(tf, xmin));
	}

	double score(double tf, std::vector<double> parms){
		return -log2(scoreModel(tf, parms.at(0), 1.0));
	}
};

class CHIL2d: public ScoreModel
{

private:
	double n;

	double scoreModel(double tf){
		return ( (pow(0.5,n/2.0))  /  (tgamma(n/2.0)) * pow(tf, (n/2.0) - 1.0) * exp(-tf/2.0));
	}

	double scoreModel(double tf, double n){
		return ( (pow(0.5,n/2.0))  /  (tgamma(n/2.0)) * pow(tf, (n/2.0) - 1.0) * exp(-tf/2.0));
	}

public:
	void setParameters(std::vector<double> parms){
		if(parms.size() != 3){
			std::cout << "(ScoreModel.hpp) - Number of parameters given to CHIL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		n = parms.at(0);
		if( !(n >= 1)){
			std::cout << "(ScoreModel.hpp) - Illegal parameter value given to CHIL2d!" << std::endl;
			exit(EXIT_FAILURE);
		}
		parms.pop_back();
		parms.pop_back();
		setScoreModelParameters(parms);
		setNumParameters(parms.size());


		std::vector<double> b1;
		b1.push_back(0.0); 			   /* Lower bound for n */
		b1.push_back((double)INT_INF); /* Upper bound for n */
		bounds[0] = b1;
	}

	void updateParameters(std::vector<double> p){
		if(p.size() != 1){
			std::cerr << "(ScoreModel.hpp - updateParameters) - Number of parameters given to CHIL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		setScoreModelParameters(p);
		n = p.at(0);
	}

	double score(double tf){
		return -log2(scoreModel(tf));
	}

	double score(double tf, std::vector<double> parms){
		return -log2(scoreModel(tf, parms.at(0)));
	}
};

class LOGNL2d: public ScoreModel
{
private:
	double mu;
	double sigma;

	double scoreModel(double tf){
		/*
		 * OLD
		 * return ( 1/(tf*sigma*sqrt(2*M_PI)) * exp(-1 * ( pow(log(tf - mu),2.0)   / (2*pow(tf,2.0))   ) ));
		 */
		return ( 1/(tf*sigma*sqrt(2*M_PI)) * exp(-1 * ( pow(log(tf) - mu,2.0)   / (2*pow(sigma,2.0))   ) ));
	}

	double scoreModel(double tf, double mu, double sigma){
		/*
		 * OLD
		 *return ( 1/(tf*sigma*sqrt(2*M_PI)) * exp(-1 * ( pow(log(tf - mu),2.0)   / (2*pow(tf,2.0))   ) ));
		 */
		return ( 1/(tf*sigma*sqrt(2*M_PI)) * exp(-1 * ( pow(log(tf) - mu,2.0)   / (2*pow(sigma,2.0))   ) ));
	}


public:
	void setParameters(std::vector<double> parms){
		if(parms.size() != 3){
			std::cout << "(ScoreModel.hpp) - Number of parameters given to LOGNL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		mu    = parms.at(0);
		sigma = parms.at(1);

		// mu is defined on R+-
		if( !(sigma > 0)){
			std::cout << "(ScoreModel.hpp) - Illegal parameter value given to LOGNL2d!" << std::endl;
			exit(EXIT_FAILURE);
		}
		parms.pop_back();
		setScoreModelParameters(parms);
		setNumParameters(parms.size());

		std::vector<double> b1;
		b1.push_back(1.0);        /* Lower bound for mu. Because min(tf) = 1, there is no need to explore options below 1.0 */
		b1.push_back(DOUBLE_INF); /* Upper bound for mu. */
		bounds[0] = b1;

		std::vector<double> b2;
		b2.push_back(0.1);        /* Lower bound for sigma */
		b2.push_back(DOUBLE_INF); /* Upper bound for sigma */
		bounds[1] = b2;
	}

	void updateParameters(std::vector<double> p){
		if(p.size() != 2){
			std::cerr << "(ScoreModel.hpp - updateParameters) - Number of parameters given to LOGNL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		setScoreModelParameters(p);
		mu    = p.at(0);
		sigma = p.at(1);
	}

	double score(double tf){
		return -log2(scoreModel(tf));
	}

	double score(double tf, std::vector<double> parms){
		return -log2(scoreModel(tf, parms.at(0), parms.at(1)));
	}
};

class NORML2d: public ScoreModel
{
private:
	double mu;
	double sigma;

	double scoreModel(double tf){
		return ( 1/(sigma*sqrt(2*M_PI)) * exp(-1 * ( pow(tf - mu,2.0)   / (2*pow(sigma,2.0))   ) ));
	}

	double scoreModel(double tf, double mu, double sigma){
		return ( 1/(sigma*sqrt(2*M_PI)) * exp(-1 * ( pow(tf - mu,2.0)   / (2*pow(sigma,2.0))   ) ));
	}


public:
	void setParameters(std::vector<double> parms){
		if(parms.size() != 3){
			std::cout << "(ScoreModel.hpp) - Number of parameters given to NORML2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		mu    = parms.at(0);
		sigma = parms.at(1);

		// mu is defined on R
		if( !(sigma > 0)){
			std::cout << "(ScoreModel.hpp) - Illegal parameter value given to NORML2d!" << std::endl;
			exit(EXIT_FAILURE);
		}
		parms.pop_back();
		setScoreModelParameters(parms);
		setNumParameters(parms.size());

		std::vector<double> b1;
		b1.push_back(1.0);        /* Lower bound for mu. Because min(tf) = 1, there is no need to explore options below 1.0 */
		b1.push_back(DOUBLE_INF); /* Upper bound for mu. */
		bounds[0] = b1;

		std::vector<double> b2;
		b2.push_back(0.1);        /* Lower bound for sigma */
		b2.push_back(DOUBLE_INF); /* Upper bound for sigma */
		bounds[1] = b2;
	}

	void updateParameters(std::vector<double> p){
		if(p.size() != 2){
			std::cerr << "(ScoreModel.hpp - updateParameters) - Number of parameters given to NORML2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		setScoreModelParameters(p);
		mu    = p.at(0);
		sigma = p.at(1);
	}

	double score(double tf){
		return -log2(scoreModel(tf));
	}

	double score(double tf, std::vector<double> parms){
		return -log2(scoreModel(tf, parms.at(0), parms.at(1)));
	}
};


class GEOL2d: public ScoreModel
{
private:
	double p;

	double scoreModel(double tf){
		return ( pow(1 - p, tf) * p );
	}

	double scoreModel(double tf, double p){
		return ( pow(1 - p, tf) * p );
	}

public:
	void setParameters(std::vector<double> parms){
		if(parms.size() != 3){
			std::cout << "(ScoreModel.hpp) - Number of parameters given to GEOL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		p    = parms.at(0);

		if( !(p > 0) && (p > 1) ){
			std::cout << "(ScoreModel.hpp) - Illegal parameter value given to GEOL2d!" << std::endl;
			exit(EXIT_FAILURE);
		}
		parms.pop_back();
		parms.pop_back();
		setScoreModelParameters(parms);
		setNumParameters(parms.size());

		std::vector<double> b1;
		b1.push_back(0.01); /* Lower bound for p */
		b1.push_back(1.00); /* Upper bound for p */
		bounds[0] = b1;
	}

	void updateParameters(std::vector<double> h){
		if(h.size() != 1){
			std::cerr << "(ScoreModel.hpp - updateParameters) - Number of parameters given to GEOL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		setScoreModelParameters(h);
		p = h.at(0);
	}

	double score(double tf){
		return -log2(scoreModel(tf));
	}

	double score(double tf, std::vector<double> parms){
		return -log2(scoreModel(tf, parms.at(0)));
	}
};

// Generalized Pareto
class GPL2d: public ScoreModel
{
private:
	double k;
	double sigma;
	double theta;

	double scoreModel(double tf){
		/*
		 * OLD
		 * return ( 1/sigma * pow(1 + eps* ((tf - mu) / sigma), -(1.0/(eps + 1.0))));
		 */
		if(k != 0){
			if(k > 0){
				if(tf >= theta){
					return ( 1/sigma * pow(1 + k * ((tf - theta) / sigma), -1.0 - (1.0/k)));
				}
				return 0;
			}
			if(k < 0){
				if(theta <= tf && tf <= theta - (sigma/k)){
					return ( 1/sigma * pow(1 + k * ((tf - theta) / sigma), -1.0 - (1.0/k)));
				}
				return 0;
			}
		}
		if(tf >= theta){
			return (1/sigma * exp(-1 * ((tf - theta) / sigma )));
		}
		return 0;
	}

	double scoreModel(double tf, double k, double sigma, double theta){
		/*
		 * OLD
		 * return ( 1/sigma * pow(1 + eps* ((tf - mu) / sigma), -(1.0/(eps + 1.0))));
		 */
		if(k != 0){
			if(k > 0){
				if(tf >= theta){
					return ( 1/sigma * pow(1 + k * ((tf - theta) / sigma), -1.0 - (1.0/k)));
				}
				return 0;
			}
			if(k < 0){
				if(theta <= tf && tf <= theta - (sigma/k)){
					return ( 1/sigma * pow(1 + k * ((tf - theta) / sigma), -1.0 - (1.0/k)));
				}
				return 0;
			}
		}
		if(tf >= theta){
			return (1/sigma * exp(-1 * ((tf - theta) / sigma )));
		}
		return 0;
	}

public:
	void setParameters(std::vector<double> parms){
		if(parms.size() != 3){
			std::cout << "(ScoreModel.hpp) - Number of parameters given to GPL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		k     = parms.at(0);
		sigma = parms.at(1);
		theta = parms.at(2);

		// k and theta defined on R
		if( sigma < 0){
			std::cout << "(ScoreModel.hpp) - Illegal parameter value given to GPL2d!" << std::endl;
		}
		setScoreModelParameters(parms);
		setNumParameters(parms.size());

		std::vector<double> b1;
		b1.push_back(0.1);         /* Lower bound for k */
		b1.push_back(DOUBLE_INF);  /* Upper bound for k */
		bounds[0] = b1;

		std::vector<double> b2;
		b2.push_back(0.1);         /* Lower bound for sigma */
		b2.push_back(DOUBLE_INF);  /* Upper bound for sigma */
		bounds[1] = b2;

		std::vector<double> b3;
		b3.push_back(0.1);         /* Lower bound for theta */
		b3.push_back(DOUBLE_INF);  /* Upper bound for theta */
		bounds[2] = b3;
	}

	void updateParameters(std::vector<double> p){
		if(p.size() != 3){
			std::cerr << "(ScoreModel.hpp - updateParameters) - Number of parameters given to GPL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		setScoreModelParameters(p);
		k     = p.at(0);
		sigma = p.at(1);
		theta = p.at(2);
	}

	double score(double tf){
		return -log2(scoreModel(tf));
	}

	double score(double tf, std::vector<double> parms){
		return -log2(scoreModel(tf, parms.at(0), parms.at(1), parms.at(2)));
	}
};
/*
 *
 * | x |
 * |   | the binomial coefficient can be written in terms of the gamma function. We use the log gamma
 * | y |
 *
 * 		for speed and also take the logarithm of the remaining (1-p)^r*p^k
 *
 *
 */
class NBINL2d: public ScoreModel
{
private:
	double r;
	double p;

	double scoreModel(double tf){
		/*
		 * OLD
		 * return ( lgamma(tf + r - 1 + 1) - lgamma(tf + 1) - lgamma(tf + r - 1 - tf + 1) *
				 r * log(1 - p) + tf * log(p));
		 */

		return ( tgamma(r + tf)/(tgamma(r)*tgamma(tf + 1)) * pow(p, r) * pow(1 - p, tf));
	}

	double scoreModel(double tf, double r, double p){
		/*
		 * OLD
		 * 		return ( lgamma(tf + r - 1 + 1) - lgamma(tf + 1) - lgamma(tf + r - 1 - tf + 1) *
				 r * log(1 - p) + tf * log(p));
		 */
		return ( tgamma(r + tf)/(tgamma(r)*tgamma(tf + 1)) * pow(p, r) * pow(1 - p, tf));
	}

public:
	void setParameters(std::vector<double> parms){
		if(parms.size() != 3){
			std::cout << "(ScoreModel.hpp) - Number of parameters given to NBINL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		r = parms.at(0);
		p = parms.at(1);

		if( r <= 0){
			std::cout << "(ScoreModel.hpp) - Illegal parameter value of r given to NBINL2d!" << std::endl;
		}

		if( (p < 0.0) || (p > 1.0)){
			std::cout << "(ScoreModel.hpp) - Illegal parameter value of p given to NBINL2d!" << std::endl;
		}
		parms.pop_back();
		setScoreModelParameters(parms);
		setNumParameters(parms.size());

		std::vector<double> b1;
		b1.push_back(0.1);         /* Lower bound for r */
		b1.push_back(DOUBLE_INF);  /* Upper bound for r */
		bounds[0] = b1;

		std::vector<double> b2;
		b2.push_back(0.0);  /* Lower bound for p */
		b2.push_back(1.0);  /* Upper bound for p */
		bounds[1] = b2;
	}

	void updateParameters(std::vector<double> h){
		if(h.size() != 2){
			std::cerr << "(ScoreModel.hpp - updateParameters) - Number of parameters given to NBINL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		setScoreModelParameters(h);
		r = h.at(0);
		p = h.at(1);
	}

	double score(double tf){
		return -log2(scoreModel(tf));
	}

	double score(double tf, std::vector<double> parms){
		return -log2(scoreModel(tf, parms.at(0), parms.at(1)));
	}
};

class NAKAL2d: public ScoreModel
{
private:
	double mu;
	double  w;

	double scoreModel(double tf){
		return ( (2*pow(mu, mu))/(tgamma(mu)*pow(w, mu)) * pow(tf, 2*mu - 1) * exp(-1.0 * mu/w * pow(tf, 2.0) ) );
	}

	double scoreModel(double tf, double mu, double w){
		return ( (2*pow(mu, mu))/(tgamma(mu)*pow(w, mu)) * pow(tf, 2*mu - 1) * exp(-1.0 * mu/w * pow(tf, 2.0) ) );
	}

public:
	void setParameters(std::vector<double> parms){
		if(parms.size() != 3){
			std::cout << "(ScoreModel.hpp) - Number of parameters given to NAKAL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		mu = parms.at(0);
		w  = parms.at(1);

		if( (mu <= 0.0) || (w <= 0.0) ){
			std::cout << "(ScoreModel.hpp) - Illegal parameter values given to NAKAL2d!" << std::endl;
		}
		parms.pop_back();
		setScoreModelParameters(parms);
		setNumParameters(parms.size());

		std::vector<double> b1;
		b1.push_back(0.1);         /* Lower bound for mu */
		b1.push_back(DOUBLE_INF);  /* Upper bound for mu */
		bounds[0] = b1;

		std::vector<double> b2;
		b2.push_back(0.1);         /* Lower bound for w */
		b2.push_back(DOUBLE_INF);  /* Upper bound for w */
		bounds[1] = b2;
	}

	void updateParameters(std::vector<double> p){
		if(p.size() != 2){
			std::cerr << "(ScoreModel.hpp - updateParameters) - Number of parameters given to NAKAL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		setScoreModelParameters(p);
		mu = p.at(0);
		w  = p.at(1);
	}

	double score(double tf){
		return -log2(scoreModel(tf));
	}

	double score(double tf, std::vector<double> parms){
		return -log2(scoreModel(tf, parms.at(0), parms.at(1)));
	}
};

// Logistic distribution
class LOGL2d: public ScoreModel
{
private:
	double mu;
	double s;

	double scoreModel(double tf){
		return ( (         exp((tf - mu) / s)   ) /
				 (s * pow(1.0 + exp((tf - mu) / s),2.0)) );
	}

	double scoreModel(double tf, double mu, double s){
		return ( (         exp((tf - mu) / s)   ) /
				 (s * pow(1.0 + exp((tf - mu) / s),2.0)) );

		/*
		 * OLD
		 * 		return ( (         exp(-(tf - mu) / s)   ) /
				 (s * (1 + exp(-(tf - mu) / s))) );
		 */
	}

public:
	void setParameters(std::vector<double> parms){
		if(parms.size() != 3){
			std::cout << "(ScoreModel.hpp) - Number of parameters given to LOGL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		mu = parms.at(0);
		s  = parms.at(1);

		if(s <= 0.0){
			std::cout << "(ScoreModel.hpp) - Illegal parameter values given to LOGL2d!" << std::endl;
		}
		parms.pop_back();
		setScoreModelParameters(parms);
		setNumParameters(parms.size());

		std::vector<double> b1;
		b1.push_back(0.1);         /* Lower bound for mu */
		b1.push_back(DOUBLE_INF);  /* Upper bound for mu */
		bounds[0] = b1;

		std::vector<double> b2;
		b2.push_back(0.1);         /* Lower bound for s */
		b2.push_back(DOUBLE_INF);  /* Upper bound for s */
		bounds[1] = b2;
	}

	void updateParameters(std::vector<double> p){
		if(p.size() != 2){
			std::cerr << "(ScoreModel.hpp - updateParameters) - Number of parameters given to LOGL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		setScoreModelParameters(p);
		mu = p.at(0);
		s  = p.at(1);
	}

	double score(double tf){
		return -log2(scoreModel(tf));
	}

	double score(double tf, std::vector<double> parms){
		return -log2(scoreModel(tf, parms.at(0), parms.at(1)));
	}
};

// Inverse Gaussian distribution
class INVGL2d: public ScoreModel
{
private:
	double mu;
	double lambda;

	double scoreModel(double tf){
		return (sqrt(lambda/(2.0*M_PI_*pow(tf, 3.0))) * exp( -(lambda * pow(tf - mu, 2.0))  /  (2.0*pow(mu,2.0)* tf) ));
	}

	double scoreModel(double tf, double mu, double lambda){
		return (sqrt(lambda/(2.0*M_PI_*pow(tf, 3.0))) * exp( -(lambda * pow(tf - mu, 2.0))  /  (2.0*pow(mu,2.0)* tf) ));
	}

public:
	void setParameters(std::vector<double> parms){
		if(parms.size() != 3){
			std::cout << "(ScoreModel.hpp) - Number of parameters given to INVGL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		mu     = parms.at(0);
		lambda = parms.at(1);

		if( (mu <= 0.0) || (lambda <= 0.0) ){
			std::cout << "(ScoreModel.hpp) - Illegal parameter values given to INVGL2d!" << std::endl;
		}
		parms.pop_back();
		setScoreModelParameters(parms);
		setNumParameters(parms.size());

		std::vector<double> b1;
		b1.push_back(0.1);         /* Lower bound for mu */
		b1.push_back(DOUBLE_INF);  /* Upper bound for mu */
		bounds[0] = b1;

		std::vector<double> b2(b1); /* Lower bound for lambda */
		bounds[1] = b2;				/* Upper bound for lambda */
	}

	void updateParameters(std::vector<double> p){
		if(p.size() != 2){
			std::cerr << "(ScoreModel.hpp - updateParameters) - Number of parameters given to INVGL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		setScoreModelParameters(p);
		mu     = p.at(0);
		lambda = p.at(1);
	}

	double score(double tf){
		return -log2(scoreModel(tf));
	}

	double score(double tf, std::vector<double> parms){
		return -log2(scoreModel(tf, parms.at(0), parms.at(1)));
	}
};


class YULEL2d: public ScoreModel
{
private:
	double p;
	/*
	 * Scoring of the Yule model is implemented using real Lanczos method to approxiamte the
	 * factorial for real numbers. The specific formula given below is taken from:
	 * "A fixed-point algorithm to estimate the Yule-Simon distribution parameter"
	 * but is identical to Simon's original formulation.
	 */
	double scoreModel(double tf){
		return (p*gsl_sf_beta(tf, p + 1));
		//return (1.0 / (pow(tf,p + 1)));
		//return p*(gsl_sf_lngamma(tf) * gsl_sf_lngamma(p+1.0))/gsl_sf_lngamma(tf + p + 1.0);
		/*
		 * OLD
		 * return ( p * tgamma(tf)*tgamma(p + 1)/tgamma(tf + p));
		 */
		/*
		double C = 1.0;
		if(tf > 1){
			C = (tf - 1.0) + boost::math::beta(tf-1.0, p);
		}
		return ((p - 1.0) * boost::math::beta(tf, p) * 1.0/C);
		*/
	}


	double scoreModel(double tf, double p){
		return (p*gsl_sf_beta(tf, p + 1));
		//return (1.0 / (pow(tf,p + 1)));
		//double nfac = sqrt(2*M_PI*tf)*pow(tf/exp(1),tf); // Stirlings approximation
		//return (sqrt(2*M_PI));


		//return p*(gsl_sf_lngamma(tf) * gsl_sf_lngamma(p+1.0))/gsl_sf_lngamma(tf + p + 1.0);

		/*
		 * OLD
		 * return ( p * tgamma(tf)*tgamma(p + 1)/tgamma(tf + p));
		 */
		/*
		double C = 1.0;
		if(tf > 1){
			C = (tf - 1) + boost::math::beta(tf-1, p);
		}
		return ((p - 1) * boost::math::beta(tf, p) * 1.0/C);
		*/
	}

public:
	void setParameters(std::vector<double> parms){
		if(parms.size() != 3){
			std::cout << "(ScoreModel.hpp) - Number of parameters given to YULEL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		p = parms.at(0);

		if( p <= 0.0 ){
			std::cout << "(ScoreModel.hpp) - Illegal parameter values given to YULEL2d!" << std::endl;
		}
		parms.pop_back();
		parms.pop_back();
		setScoreModelParameters(parms);
		setNumParameters(parms.size());

		std::vector<double> b1;
		b1.push_back(0.10); /* Lower bound for p */
		b1.push_back(10.0);  /* Upper bound for p - artificially fixed at 10*/
		bounds[0] = b1;
	}

	void updateParameters(std::vector<double> h){
		if(h.size() != 1){
			std::cerr << "(ScoreModel.hpp - updateParameters) - Number of parameters given to YULEL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		setScoreModelParameters(h);
		p = h.at(0);
	}

	double score(double tf){
		return -log2(scoreModel(tf));
	}

	double score(double tf, std::vector<double> parms){
		return -log2(scoreModel(tf, parms.at(0)));
	}
};

class GEVL2d: public ScoreModel
{
private:
	double k;
	double mu;
	double sigma;

	double scoreModel(double tf){
		if(k == 0.0){
			return ( (1/sigma) * exp(-exp( -(tf-mu)/sigma) - (tf-mu)/sigma) );
		}

		double z = (1 + k * (tf - mu)/sigma);

		if(z > 0){
			return ( 1/sigma * exp(-1*pow(z, -1/k)) * pow(z, -1 - 1/k)  );
		}
		return 0.0;
	}

	// The order of the model is correct!
	// See TestDistributions.cpp. It was verified against MATLAB's version.
	double scoreModel(double tf, double k, double sigma, double mu){
		if(k == 0.0){
			return ( (1.0/sigma) * exp(-exp( -(tf-mu)/sigma) - (tf-mu)/sigma) );
		}

		double z = (1.0 + k * (tf - mu)/sigma);

		if(z > 0){
			return ( 1.0/sigma * exp(-1*pow(z, -1.0/k)) * pow(z, -1.0 - 1.0/k)  );
		}
		return 0.0;
	}

public:
	void setParameters(std::vector<double> parms){
		if(parms.size() != 3){
			std::cout << "(ScoreModel.hpp) - Number of parameters given to GEVL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		// The order returned by MatLab's gevfit
		k     = parms.at(0);
		mu    = parms.at(1);
		sigma = parms.at(2);

		if(sigma <= 0.0){
			std::cout << "(ScoreModel.hpp) - Illegal parameter values given to GEVL2d!" << std::endl;
		}
		setScoreModelParameters(parms);
		setNumParameters(parms.size());

		std::vector<double> b1;
		b1.push_back(0.1);         /* Lower bound for k */
		b1.push_back(DOUBLE_INF);  /* Upper bound for k */
		bounds[0] = b1;

		std::vector<double> b2(b1);
		bounds[1] = b2;

		std::vector<double> b3(b1);
		bounds[2] = b3;
	}

	void updateParameters(std::vector<double> p){
		if(p.size() != 3){
			std::cerr << "(ScoreModel.hpp - updateParameters) - Number of parameters given to GEVL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		setScoreModelParameters(p);
		k     = p.at(0);
		mu    = p.at(1);
		sigma = p.at(2);
	}

	double score(double tf){
		return -log2(scoreModel(tf));
	}

	double score(double tf, std::vector<double> parms){
		return -log2(scoreModel(tf, parms.at(0), parms.at(1), parms.at(2)));
	}
};

/*
 * Add the original five basic DFR models.
 * Added 18-11-2015
 */

class PL2L2d: public ScoreModel
{
private:
	double lambda;

	double scoreModel(double tf){
		return scoreModel(tf, lambda);
	}

	double scoreModel(double tf, double lambda){
		return (tf * log2(tf/lambda) + (lambda + (1/(12*tf)) - tf) * log2(exp(1)) + 0.5*log2(2*M_PI*tf));
	}

public:
	void setParameters(std::vector<double> parms){
		if(parms.size() != 3){
			std::cout << "(ScoreModel.hpp) - Number of parameters given to PL2L2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		// The order returned by MatLab's gevfit
		lambda = parms.at(0);

		if(lambda <= 0.0){
			std::cout << "(ScoreModel.hpp) - Illegal parameter values given to PL2L2d!" << std::endl;
		}
		setScoreModelParameters(parms);
		setNumParameters(parms.size());

		std::vector<double> b1;
		b1.push_back(0.1);         /* Lower bound for alpha */
		b1.push_back(DOUBLE_INF);  /* Upper bound for alpha */
		bounds[0] = b1;
	}

	void updateParameters(std::vector<double> p){
		if(p.size() != 1){
			std::cerr << "(ScoreModel.hpp - updateParameters) - Number of parameters given to PL2L2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		setScoreModelParameters(p);
		lambda = p.at(0);
	}

	/*
	 * Inf_1
	 *
	 * Notice that -log2 is /not/ taken here. If you look at Eqn (6) p. 364 in Amati and Rijsbergen's paper, then
	 * inf_1(tf) ~ tf*log2(tf/lambda) + (lambda + (1/(12*tf)) - tf) * log2(exp) + 0.5*log2(2*PI*TF)
	 * i.e. -log2 is included in the calculation.
	 */
	double score(double tf){
		return (scoreModel(tf));
	}

	double score(double tf, std::vector<double> parms){
		return -log2(scoreModel(tf, parms.at(0)));
	}
};

/*
 * The original DFR geometric model
 */
class GL2L2d: public ScoreModel
{
private:
	double lambda;

	double scoreModel(double tf){
		return scoreModel(tf, lambda);
	}

	double scoreModel(double tf, double lambda){
		return ((1/(1 + lambda)) * pow(lambda/(1 + lambda),tf) ) ;
	}

public:
	void setParameters(std::vector<double> parms){
		if(parms.size() != 3){
			std::cout << "(ScoreModel.hpp) - Number of parameters given to GL2L2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		// The order returned by MatLab's gevfit
		lambda = parms.at(0);

		if(lambda <= 0.0){
			std::cout << "(ScoreModel.hpp) - Illegal parameter values given to GL2L2d!" << std::endl;
		}
		setScoreModelParameters(parms);
		setNumParameters(parms.size());

		std::vector<double> b1;
		b1.push_back(0.1);         /* Lower bound for alpha */
		b1.push_back(DOUBLE_INF);  /* Upper bound for alpha */
		bounds[0] = b1;
	}

	void updateParameters(std::vector<double> p){
		if(p.size() != 1){
			std::cerr << "(ScoreModel.hpp - updateParameters) - Number of parameters given to GL2L2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		setScoreModelParameters(p);
		lambda = p.at(0);
	}

	/*
	 * Inf_1
	 *
	 * Notice that -log2 is taken here. If you look at Eqn (17) p. 366 in Amati and Rijsbergen's paper, then
	 * inf_1(tf) ~ -log2( x ) where x = (1/(1 + lambda) * (lambda/(1 + lambda))^tf)
	 * i.e. -log2 is not included in the calculation.
	 */
	double score(double tf){
		return -log2(scoreModel(tf));
	}

	double score(double tf, std::vector<double> parms){
		return -log2(scoreModel(tf, parms.at(0)));
	}
};


/*
 * The original DFR I(n) (IDF) model given by Eqn. 19 in the Amati and Rijsbergen's paper
 * This is a special case model as it really has no parameters
 *
 * Defined by Eqn. 19.
 * inf_1 = tf * log2((N + 1)/(n + 0.5))
 * where N is the number of documents and n is the size of t's elite set.
 *
 * This is a SPECIAL CASE! Because it is parameter free we are better off checking for this model in the Score.cpp
 * class. We could do it using one of the score models, but this would not work if we are to use some form
 * of random search. To be continued....
 */
class IDFL2d: public ScoreModel
{
private:
	double dummy;

	double scoreModel(double tf){
		// Do not use for this model
		return 0.0;
	}

	double scoreModel(double tf, double N, double n){
		return 0.0;
	}

public:
	void setParameters(std::vector<double> parms){
		if(parms.size() != 3){
			std::cout << "(ScoreModel.hpp) - Number of parameters given to IDFL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		// The order returned by MatLab's gevfit
		dummy = parms.at(0);
		setScoreModelParameters(parms);
		setNumParameters(parms.size());

		std::vector<double> b1;
		b1.push_back(0.1);         /* Lower bound for alpha */
		b1.push_back(DOUBLE_INF);  /* Upper bound for alpha */
		bounds[0] = b1;
	}

	void updateParameters(std::vector<double> p){
		if(p.size() != 1){
			std::cerr << "(ScoreModel.hpp - updateParameters) - Number of parameters given to IDFL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		setScoreModelParameters(p);
		dummy = p.at(0);
	}

	double score(double tf){
		return 0.0;
	}

	double score(double tf, std::vector<double> parms){
		return -log2(scoreModel(tf, parms.at(0), parms.at(1)));
	}
};


/*
 * The original DFR I(n_e) (Poisson-Mixture-with-IDF) model given by Eqn. 20 in the Amati and Rijsbergen's paper
 * This is a special case model as it really has no parameters
 *
 * Defined by Eqn. 20.
 *
 * inf_1 = tf * log2((N + 1)/(n_e + 0.5))
 *
 * where N is the number of documents, n is the size of t's elite set and n_e is:
 *
 * n_e = N * ( 1 - ((N-1)/N)^F)
 *
 * and F is the total occurrences of t in the collection.
 *
 * This is a SPECIAL CASE! Because it is parameter free we are better off checking for this model in the Score.cpp
 * class. We could do it using one of the score models, but this would not work if we are to use some form
 * of random search. To be continued....
 */
class PIDFL2d: public ScoreModel
{
private:
	double dummy;

	double scoreModel(double tf){
		// Do not use for this model
		return 0.0;
	}

	double scoreModel(double tf, double N, double n){
		return 0.0;
	}

public:
	void setParameters(std::vector<double> parms){
		if(parms.size() != 3){
			std::cout << "(ScoreModel.hpp) - Number of parameters given to IDFL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		// The order returned by MatLab's gevfit
		dummy = parms.at(0);
		setScoreModelParameters(parms);
		setNumParameters(parms.size());

		std::vector<double> b1;
		b1.push_back(0.1);         /* Lower bound for alpha */
		b1.push_back(DOUBLE_INF);  /* Upper bound for alpha */
		bounds[0] = b1;
	}

	void updateParameters(std::vector<double> p){
		if(p.size() != 1){
			std::cerr << "(ScoreModel.hpp - updateParameters) - Number of parameters given to IDFL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		setScoreModelParameters(p);
		dummy = p.at(0);
	}

	double score(double tf){
		return 0.0;
	}

	double score(double tf, std::vector<double> parms){
		return -log2(scoreModel(tf, parms.at(0), parms.at(1)));
	}
};


/*
 * The original DFR I(F) (approximation to I(n_e) called the tf-itf) model given by Eqn. 21 in the Amati and Rijsbergen's paper
 * This is a special case model as it really has no parameters
 *
 * Defined by Eqn. 21.
 *
 * inf_1 = tf * log2((N + 1)/(F + 0.5) * F/N) : (doesnt say whether F/N is under the log2 but we assume so
 *
 * where N is the number of documents, n is the size of t's elite set and F is the total occurrences of t in the collection.
 *
 * This is a SPECIAL CASE! Because it is parameter free we are better off checking for this model in the Score.cpp
 * class. We could do it using one of the score models, but this would not work if we are to use some form
 * of random search. To be continued....
 */
class TFITFL2d: public ScoreModel
{
private:
	double dummy;

	double scoreModel(double tf){
		// Do not use for this model
		return 0.0;
	}

	double scoreModel(double tf, double N, double n){
		return 0.0;
	}

public:
	void setParameters(std::vector<double> parms){
		if(parms.size() != 3){
			std::cout << "(ScoreModel.hpp) - Number of parameters given to IDFL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		// The order returned by MatLab's gevfit
		dummy = parms.at(0);
		setScoreModelParameters(parms);
		setNumParameters(parms.size());

		std::vector<double> b1;
		b1.push_back(0.1);         /* Lower bound for alpha */
		b1.push_back(DOUBLE_INF);  /* Upper bound for alpha */
		bounds[0] = b1;
	}

	void updateParameters(std::vector<double> p){
		if(p.size() != 1){
			std::cerr << "(ScoreModel.hpp - updateParameters) - Number of parameters given to IDFL2d is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		setScoreModelParameters(p);
		dummy = p.at(0);
	}

	double score(double tf){
		return 0.0;
	}

	double score(double tf, std::vector<double> parms){
		return -log2(scoreModel(tf, parms.at(0), parms.at(1)));
	}
};

class LOGLOGISTIC: public ScoreModel
{
private:
	double dummy;

	double scoreModel(double tf){
		// Do not use for this model
		return 0.0;
	}

	double scoreModel(double tf, double N, double n){
		return 0.0;
	}

public:
	void setParameters(std::vector<double> parms){
		if(parms.size() != 3){
			std::cout << "(ScoreModel.hpp) - Number of parameters given to LOGLOGISTIC is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		// The order returned by MatLab's gevfit
		dummy = parms.at(0);
		setScoreModelParameters(parms);
		setNumParameters(parms.size());

		std::vector<double> b1;
		b1.push_back(0.1);         /* Lower bound for alpha */
		b1.push_back(DOUBLE_INF);  /* Upper bound for alpha */
		bounds[0] = b1;
	}

	void updateParameters(std::vector<double> p){
		if(p.size() != 1){
			std::cerr << "(ScoreModel.hpp - updateParameters) - Number of parameters given to LOGLOGISTIC is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		setScoreModelParameters(p);
		dummy = p.at(0);
	}

	double score(double tf){
		return 0.0;
	}

	double score(double tf, std::vector<double> parms){
		return -log2(scoreModel(tf, parms.at(0), parms.at(1)));
	}
};

class SMOOTHEDPL: public ScoreModel
{
private:
	double dummy;

	double scoreModel(double tf){
		// Do not use for this model
		return 0.0;
	}

	double scoreModel(double tf, double N, double n){
		return 0.0;
	}

public:
	void setParameters(std::vector<double> parms){
		if(parms.size() != 3){
			std::cout << "(ScoreModel.hpp) - Number of parameters given to LOGLOGISTIC is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		// The order returned by MatLab's gevfit
		dummy = parms.at(0);
		setScoreModelParameters(parms);
		setNumParameters(parms.size());

		std::vector<double> b1;
		b1.push_back(0.1);         /* Lower bound for alpha */
		b1.push_back(DOUBLE_INF);  /* Upper bound for alpha */
		bounds[0] = b1;
	}

	void updateParameters(std::vector<double> p){
		if(p.size() != 1){
			std::cerr << "(ScoreModel.hpp - updateParameters) - Number of parameters given to LOGLOGISTIC is wrong!" << std::endl;
			exit(EXIT_FAILURE);
		}
		setScoreModelParameters(p);
		dummy = p.at(0);
	}

	double score(double tf){
		return 0.0;
	}

	double score(double tf, std::vector<double> parms){
		return -log2(scoreModel(tf, parms.at(0), parms.at(1)));
	}
};

class ScoreModelsFactory
 {
private:
	ScoreModel * ptr;
 public:

	ScoreModel * getScoreModel(std::string description, std::vector<double> parms){
		 ScoreModel * model;
    	 int desc = 0;
    	 if(description.compare("WL2d") == 0){
    		 model = new WL2d;
        	 model->setModelName("WL2d");
        	 model->setModelID(0);
        	 std::cout << "****************************" << std::endl;
        	 std::cout << "*  SELECTED WEIBULL MODEL  *" << std::endl;
        	 std::cout << "****************************" << std::endl;
    	 }else if(description.compare("PL2d") == 0){
	 		 model = new PL2d;
	 		 model->setModelName("PL2d");
	 		 model->setModelID(1);
	 		std::cout << "****************************" << std::endl;
	 		std::cout << "*  SELECTED POISSON MODEL  *" << std::endl;
	 		std::cout << "****************************" << std::endl;
    	 }else if(description.compare("GL2d") == 0){
	 		 model = new GL2d;
	 		 model->setModelName("GL2d");
	 		 model->setModelID(2);
		 	 std::cout << "****************************" << std::endl;
		 	 std::cout << "* SELECTED GEOMETRIC MODEL *" << std::endl;
		 	 std::cout << "****************************" << std::endl;
    	 }else if(description.compare("EL2d") == 0){
	 		 model = new EL2d;
	 		 model->setModelName("EL2d");
	 		 model->setModelID(3);
    	 }else if(description.compare("RL2d") == 0){
	 		 model = new RL2d;
	 		 model->setModelName("RL2d");
	 		 model->setModelID(4);
    	 }else if(description.compare("CHIL2d") == 0){
	 		 model = new CHIL2d;
	 		 model->setModelName("CHIL2d");
	 		 model->setModelID(5);
    	 }else if(description.compare("LOGNL2d") == 0){
	 		 model = new LOGNL2d;
	 		 model->setModelName("LOGNL2d");
	 		 model->setModelID(6);
    	 }else if(description.compare("NORML2d") == 0){
	 		 model = new NORML2d;
	 		 model->setModelName("NORML2d");
	 		 model->setModelID(7);
    	 }else if(description.compare("GEOL2d") == 0){
	 		 model = new GEOL2d;
	 		 model->setModelName("GEOL2d");
	 		 model->setModelID(8);
    	 }else if(description.compare("GPL2d") == 0){
	 		 model = new GPL2d;
	 		 model->setModelName("GPL2d");
	 		 model->setModelID(9);
    	 }else if(description.compare("NBINL2d") == 0){
	 		 model = new NBINL2d;
	 		 model->setModelName("NBINL2d");
	 		 model->setModelID(10);
    	 }else if(description.compare("NAKAL2d") == 0){
    		 model = new NAKAL2d;
    		 model->setModelName("NAKAL2d");
    		 model->setModelID(11);
    	 }else if(description.compare("LOGL2d") == 0){
    		 model = new LOGL2d;
    		 model->setModelName("LOGL2d");
    		 model->setModelID(12);
    	 }else if(description.compare("INVGL2d") == 0){
    		 model = new INVGL2d;
    		 model->setModelName("INVGL2d");
    		 model->setModelID(13);
    	 }else if(description.compare("YULEL2d") == 0){
    		 model = new YULEL2d;
    		 model->setModelName("YULEL2d");
    		 model->setModelID(14);
 	 		std::cout << "****************************" << std::endl;
 	 		std::cout << "*   SELECTED YULE MODEL    *" << std::endl;
 	 		std::cout << "****************************" << std::endl;
    	 }else if(description.compare("GEVL2d") == 0){
    		model = new GEVL2d;
    		model->setModelName("GEVL2d");
    		model->setModelID(15);
 	 		std::cout << "****************************" << std::endl;
 	 		std::cout << "*    SELECTED GEV MODEL    *" << std::endl;
 	 		std::cout << "****************************" << std::endl;
    	 }else if(description.compare("PLAWL2d") == 0){
     		model = new PLAWL2d;
     		model->setModelName("PLAWL2d");
     		model->setModelID(16);
  	 		std::cout << "****************************" << std::endl;
  	 		std::cout << "* SELECTED POWER LAW MODEL *" << std::endl;
  	 		std::cout << "****************************" << std::endl;
    	 }else if(description.compare("PL2L2d") == 0){
    		 model = new PL2L2d;
    		 model->setModelName("PL2L2d");
    		 model->setModelID(101);
 	 		std::cout << "****************************" << std::endl;
 	 		std::cout << "*  SELECTED DFRPL2 MODEL   *" << std::endl;
 	 		std::cout << "****************************" << std::endl;
    	 }else if(description.compare("GL2L2d") == 0){
    		 model = new GL2L2d;
    		 model->setModelName("GL2L2d");
    		 model->setModelID(102);
 	 		std::cout << "****************************" << std::endl;
 	 		std::cout << "*   SELECTED GEOL2 MODEL   *" << std::endl;
 	 		std::cout << "****************************" << std::endl;
    	 }else if(description.compare("IDFL2d") == 0){
    		 model = new IDFL2d;
    		 model->setModelName("IDFL2d");
    		 model->setModelID(103);
 	 		std::cout << "****************************" << std::endl;
 	 		std::cout << "*   SELECTED IDFL2 MODEL   *" << std::endl;
 	 		std::cout << "****************************" << std::endl;
    	 }else if(description.compare("PIDFL2d") == 0){
    		 model = new PIDFL2d;
    		 model->setModelName("PIDFL2d");
    		 model->setModelID(104);
 	 		std::cout << "****************************" << std::endl;
 	 		std::cout << "*  SELECTED PIDFL2 MODEL   *" << std::endl;
 	 		std::cout << "****************************" << std::endl;
    	 }else if(description.compare("TFITFL2d") == 0){
    		 model = new TFITFL2d;
    		 model->setModelName("TFITFL2d");
    		 model->setModelID(105);
 	 		std::cout << "****************************" << std::endl;
 	 		std::cout << "*  SELECTED TFITFL2 MODEL  *" << std::endl;
 	 		std::cout << "****************************" << std::endl;
    	 }else if(description.compare("LOGLOGISTIC") == 0){
    		 model = new LOGLOGISTIC;
    		 model->setModelName("LOGLOGISTIC");
    		 model->setModelID(106);
 	 		std::cout << "****************************" << std::endl;
 	 		std::cout << "*  SELECTED LOGLOGL2 MODEL *" << std::endl;
 	 		std::cout << "****************************" << std::endl;
    	 }else if(description.compare("SMOOTHEDPL") == 0){
    		 model = new SMOOTHEDPL;
    		 model->setModelName("SMOOTHEDPL");
    		 model->setModelID(107);
 	 		std::cout << "****************************" << std::endl;
 	 		std::cout << "*   SELECTED SPLL2 MODEL   *" << std::endl;
 	 		std::cout << "****************************" << std::endl;
    	 }else{
    		 std::cout << "Model " << description << " not found!" << std::endl;
    		 exit(EXIT_FAILURE);
    	 }
    	 // Set the remaining parameters.
    	 model->setParameters(parms);
    	 model->setStepSize(0.1);

    	 LOG(INFO) << "Model selected: " << model->getModelName();
    	 return model;
     }
 };
#endif /* SCOREMODELS_HPP_ */
