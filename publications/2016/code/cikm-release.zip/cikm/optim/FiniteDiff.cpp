/*
 * FiniteDiff.cpp
 *
 *  Created on: Jul 3, 2015
 *      Author: casper
 */
#include "../include/ScoreModel.hpp"
#include "../include/aux.hpp"
#include "../include/Score.hpp"
#include "../include/PConfig.hpp"
#include "../include/Write.hpp"
#include "../include/easylogging++.h"
#include "../include/TrecEval.hpp"
#include "../include/ScoreModel.hpp"

const double h    		     = 0.1;
const double ONE_POINT_DENOM =  2*h;
const double TWO_POINT_DENOM = 12*h;
enum VAR {XVAR, YVAR, ZVAR};


double gradient_descent(){
	double old_optim_val  = 0.0;
	double new_target_val = 1.0;

	double newMAP, oldMAP;

	while( abs(newMAP > oldMAP) ){

	}
}

double onepointderivative(ScoreModel * f, const double qtf, const double doctf, double p1, double p2, double p3){
	VAR v = XVAR;
	switch(v){
	case XVAR:
		return ( f->score(qtf, doctf, p1 + h, p2, p3) -
				 f->score(qtf, doctf, p1 - h, p2, p3) )
				 /ONE_POINT_DENOM;
	case YVAR:
		return ( f->score(qtf, doctf, p1, p2 + h, p3) -
				 f->score(qtf, doctf, p1, p2 - h, p3) )
				 /ONE_POINT_DENOM;
	case ZVAR:
		return ( f->score(qtf, doctf, p1, p2, p3 + h) +
				 f->score(qtf, doctf, p1, p2, p3 - h) )
				 /ONE_POINT_DENOM;
	}
	return 0.0;
}

double twopointderivative(ScoreModel * f, const double qtf, const double doctf, double p1, double p2, double p3){
	VAR v = XVAR;
	switch(v){
	case XVAR:
		return (  -f->score(qtf, doctf, p1 + 2*h, p2, p3) +
				 8*f->score(qtf, doctf, p1 +   h, p2, p3) -
				 8*f->score(qtf, doctf, p1 -   h, p2, p3) +
				   f->score(qtf, doctf, p1 - 2*h, p2, p3) )
				 /TWO_POINT_DENOM;
	case YVAR:
		return (  -f->score(qtf, doctf, p1, p2 + 2*h, p3) +
				 8*f->score(qtf, doctf, p1, p2 +   h, p3) -
				 8*f->score(qtf, doctf, p1, p2 -   h, p3) +
				   f->score(qtf, doctf, p1, p2 - 2*h, p3) )
				 /TWO_POINT_DENOM;
	case ZVAR:
		return (  -f->score(qtf, doctf, p1, p2, p3 + 2*h) +
				 8*f->score(qtf, doctf, p1, p2, p3 +   h) -
				 8*f->score(qtf, doctf, p1, p2, p3 -   h) +
				   f->score(qtf, doctf, p1, p2, p3 - 2*h) )
				 /TWO_POINT_DENOM;
	}
	return 0.0;
}

void stuff(){

	std::vector<double> parms;
	parms.push_back(3.3);

	double h                   = 0.1;
	double static1             = 1.0;
	double static2             = 1.0;
	double parm1, parm2, parm3 = 0.0;

	ScoreModel * f;
	f = ScoreModelsFactory::getScoreModel("PL2d", parms);
	f->score(static1, static2, parm1, parm2, parm3); // This is our f(). First two values are statics and should not be optimized. Latter three are parameters
}

/*
 * The model to optimize
 * -> That model can have up to three parameters. Only optimize one parameter at a time
 * The derivative to calculate
 * -> Finite difference?
 * How precise to calculate the derivative
 * -> Point order
 *
 * Let f be the function, x the value and h the stepsize. Then a second-order approximation to a central difference scheme is:
 * -f(x + 2h) + 8f(x + h) - 8f(x - h) + f(x - 2h)
 * ----------------------------------------------
 * 						12h
 *
 * Taken from: http://www.boost.org/doc/libs/1_58_0/libs/multiprecision/doc/html/boost_multiprecision/tut/floats/fp_eg/nd.html
 *
 */
double eval(char ** argv){
	PConfig p;
	p.parse_configuration(argv[1]);

	Score s;

	// Get the model parameters
	vector<double> parms;
	if(p.getFirstParameter() > -1.0){
		parms.push_back(p.getFirstParameter());
	}
	if(p.getSecondParameter() > -1.0){
		parms.push_back(p.getSecondParameter());
	}
	if(p.getThirdParameter() > -1.0){
		parms.push_back(p.getThirdParameter());
	}

	// Set the model to use
	s.setScoreModel(p.getModel(), parms);

	// Load the queries from the query index
	s.loadQueries(p.getQueryIndex(), p.getDebugLevel());


	// Load the inverted lists from the document index
	s.loadInvertedIndex(p.getCollectionIndex(), p.getDebugLevel());


	/*
	 * Begin the optimisation procedure
	 */


	s.optimscore(p.getDebugLevel(), 0.0, 0.0, 0.0);

	// Write the results
	TRECResults w;
	w.write(s.getScoredQueries(), p.getRetrievalResults().c_str(), p.getCutoff(), p.getRunID());

	// Evaluate the results
	TrecEval te;
	te.evaluate(p.getQrelsLoc(), p.getRetrievalResults());
	double res = te.getEvaluationResult();
	std::cout << "Result was: " << res << std::endl;
	LOG(INFO) << "Result was: " << res;

	return 0.0;
}


