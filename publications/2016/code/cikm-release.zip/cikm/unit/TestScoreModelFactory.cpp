#include "../include/ScoreModel.hpp"
using namespace std;
int main(int argc, char ** argv){
	std::vector<double> parms;
	parms.push_back(12.0);
	ScoreModel * sm = ScoreModelsFactory::getScoreModel("PL2", parms);
	double res = sm->score(2, 4);
	std::cout << "Res was: " << res << std::endl;

}



