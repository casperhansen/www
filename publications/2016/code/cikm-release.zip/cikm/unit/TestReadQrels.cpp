#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <unordered_map>
#include <map>
#include <set>
#include <cmath>
#include <cstring>
#include <limits>
#include <iterator>
#include <iomanip>      // std::setprecision
#include <algorithm>
#include <utility>
#include <ctime>
#include <cctype>
#include "../include/QrelsObject.hpp"

std::vector<std::string> split(const std::string &s, char delim, std::vector<std::string> &elems) {
    std::stringstream ss(s);
    std::string item;
    while (std::getline(ss, item, delim)) {
        elems.push_back(item);
    }
    return elems;
}

void readResultsFile(const char * fptr, std::map<std::string, std::vector<std::string> > & queryToDocScore){
	  std::string line;
	  std::ifstream myfile (fptr);
	  int linecounter = 0;
	  std::set<std::string> seenQueries;
	  if (myfile.is_open()){
		  std::vector<std::string> documents;
		  std::string oldID = "";
		  std::vector<std::string> prev_documents;
		  while (getline (myfile,line)) {
			  std::vector<std::string> components;
			  split(line, ' ', components);
			  if(components.size() != 6){
				  std::cerr << "Line: " << line << " did not have 6 components (split on whitespace)" << std::endl;
				  exit(EXIT_FAILURE);
			  }
			  documents.push_back(components.at(2));

			  if(linecounter == 0){
				  seenQueries.insert(components.at(0));
				  linecounter++;
				  continue;
			  }

			  bool seen =  seenQueries.find(components.at(0)) != seenQueries.end();
			  if(!seen){
				  // New query, so save document_to_score in queryToDocScore
				  queryToDocScore[oldID] = prev_documents;
				  documents.clear();
				  documents.push_back(components.at(2));
				  seenQueries.insert(components.at(0));
			  }
			  oldID = components.at(0);
			  prev_documents = documents;
			  linecounter++;
		  }
		  queryToDocScore[oldID] = documents;
		  myfile.close();
	  }
	  std::cout << "Read " << linecounter << " lines" << std::endl;
/*
	  std::map<std::string, std::vector<std::string> >::iterator it;
	  for(it = queryToDocScore.begin(); it != queryToDocScore.end(); ++it){
		  std::cout << it->first << ", " << "Elements: " << it->second.size() << std::endl;
	  }
*/
}


void readQrelsFile(const char * fptr, std::map<std::string, Qrels::Object * >  & queryToDocScore){
	  std::string line;
	  std::ifstream myfile (fptr);
	  int linecounter = 0;
	  std::set<std::string> seenQueries;
	  if (myfile.is_open()){
		  std::map<std::string, int> document_to_score;
		  std::string oldID = "";
		  std::map<std::string, int> prev_document_to_score;
		  int rel_counter = 0;
		  int old_rel_counter = 0;
		  while (getline (myfile,line)) {
			  std::vector<std::string> components;
			  split(line, ' ', components);
			  if(components.size() != 4){
				  std::cerr << "Line: " << line << " did not have 4 components (split on whitespace)" << std::endl;
				  exit(EXIT_FAILURE);
			  }
			  std::string rel = components.at(3);
			  int docVal      = atoi(rel.c_str());
			  document_to_score[components.at(2)] = docVal;
			  if(docVal > 0){
				  rel_counter++;
			  }

			  if(linecounter == 0){
				  seenQueries.insert(components.at(0));
				  linecounter++;
			  }

			  bool seen =  seenQueries.find(components.at(0)) != seenQueries.end();
			  if(!seen){
				  // New query, so save document_to_score in queryToDocScore
				  Qrels::Object * qrel = new Qrels::Object(prev_document_to_score, old_rel_counter);
				  queryToDocScore[oldID] = qrel;

				  // Clean up
				  document_to_score.clear();

				  // Because we made it here by seeing a new query, we need to process it
				  std::string rel = components.at(3);
				  document_to_score[components.at(2)] = atoi(rel.c_str());
				  seenQueries.insert(components.at(0));

				  // Need to reset the relevant counter for this new query depending on whether it is relevant or not
				  if(docVal > 0){
					  rel_counter = 1;
				  }else{
					  rel_counter = 0;
				  }
			  }
			  // We need to save the information from the previous line in case we, on the next iteration, encounter a new query
			  oldID                  = components.at(0);
			  prev_document_to_score = document_to_score;
			  old_rel_counter        = rel_counter;

			  linecounter++;
		  }
		  Qrels::Object * qrel = new Qrels::Object(prev_document_to_score, rel_counter);
		  queryToDocScore[oldID] = qrel;
	  }
	  myfile.close();
	  std::cout << "Read " << linecounter << " lines" << std::endl;
}

void eval(std::map<std::string, Qrels::Object *> & qrels, std::map<std::string, std::vector<std::string> > & results){

	std::cout.setf(std::ios_base::fixed, std::ios_base::floatfield);
	std::cout.precision(4);
	std::map<std::string, std::vector<std::string> >::iterator query_iterator;

	double MRR_VALUE = 0.0;
	double MAP_VALUE = 0.0;
	const int K      = 5;
	//Loop over results
	for(query_iterator = results.begin(); query_iterator != results.end(); ++query_iterator){
		std::string query           = query_iterator->first;
		std::vector<std::string> rs = query_iterator->second;

		Qrels::Object * ptr                   = qrels[query];
		std::map<std::string, int> query_qrel = ptr->getQidToDocAndRelScore();

		int MRR_POSITION     = 1;

		bool recip_rankFound = false;
		bool PAKfound        = false;
		bool DCGfirstFound   = false;
		int runK             = 0;

		// Reciprocal rank
		double rr_value      = 0.0;
		// Average precision
		double q_AP          = 0.0;
		// Precision @ K
		double PAK           = 0.0;
		// Number of relevant documents retrieved
		double num_rel_found = 0.0;
		// Discounted cumulative gain
		std::vector<double> v;
		// Now we can loop over the vector of results
		std::vector<std::string>::iterator result_itr;
		for(result_itr = rs.begin(); result_itr != rs.end(); ++result_itr){
			std::string r = (*result_itr);
			bool is_in = query_qrel.find(r) != query_qrel.end();
			int val    = 0;
			if(is_in){
				val = query_qrel[r];
				if(val > 0){
					num_rel_found++;
					if(!recip_rankFound){
						rr_value   = (1/(double)MRR_POSITION);
						MRR_VALUE += rr_value;
						recip_rankFound = true;
					}
					if(MRR_POSITION <= K){
						runK++;
					}
					q_AP += (num_rel_found/MRR_POSITION);
				}
			}
			// nDCG calculations
			v.push_back(val);

			if(MRR_POSITION <= K){
				PAK = ((double)runK)/MRR_POSITION;
			}
			MRR_POSITION++;
		}

		// DCG calculations (https://en.wikipedia.org/wiki/Discounted_cumulative_gain)
		int N       = v.size();
		double rsum = v.at(0);
		for(int i = 1; i < N; i++){
			if(i < K){
				rsum += (v.at(i)/log2(i+1));
			}
		}
		std::vector<double> w(v);
		std::sort(w.begin(), w.end(), std::greater<int>());

		double normsum = w.at(0);
		for(int i = 1; i < N; i++){
			if(i < K){
				normsum += (w.at(i)/log2(i+1));
			}
		}

		int TOTAL_NUM_REL = ptr->getNumRelDocs();
		double AP         = (q_AP/TOTAL_NUM_REL);
		double nDCG       = rsum/normsum;
		MAP_VALUE        += AP;
		std::cout << std::endl;
		std::cout << "Query............: "       << query         << std::endl;
		std::cout << "Total rel docs...: "       << TOTAL_NUM_REL << std::endl;
		std::cout << "num_rel_found....: "       << num_rel_found << std::endl;
		std::cout << "P@"<<K<<".............: "  << PAK           << std::endl;
		std::cout << "AP...............: "       << AP            << std::endl;
		std::cout << "Reciprocal rank..: "       << rr_value      << std::endl;
		std::cout << "NDCG@"<<K<<"..........: "  << nDCG          << std::endl;
	}
	double NOF_QUERIES = results.size();

	double MRR = (1.0/NOF_QUERIES) * MRR_VALUE;
	double MAP = (1.0/NOF_QUERIES) * MAP_VALUE;
	std::cout << "MRR: " << MRR << std::endl;
	std::cout << "MAP: " << MAP << std::endl;
}

int main(int argc, char ** argv){
	std::map<std::string, Qrels::Object *> qrels;
	std::map<std::string, std::vector<std::string> > results;
	readQrelsFile(argv[1], qrels);
	readResultsFile(argv[2], results);

	eval(qrels, results);
}
