/*
 * TestSigir2016.cpp
 *
 * Purpose of this file is to test the Sigir2016 implementation on a small set of documents and
 * queries that allows me to trace whether it works.
 *
 * The queries are found at:
 * /home/casper/indexes/sigir2016-test-queries
 *
 * collection at:
 * /home/casper/indexes/sigir2016-test-collection
 *
 * and qrels at:
 * /home/casper/indexes/sigir2016-test/sigir2016-test.qrels
 *
 *
 *  Created on: Oct 30, 2015
 *      Author: Casper
 */

//#include "../include/ScoreModel.hpp"	// Models
//#include "../include/aux.hpp"			// Helper
//#include "../include/Score.hpp"			// Scoring
//#include "../include/Write.hpp"			// I/O
//#include "../include/TrecEval.hpp"		// Trec-eval (called outside)
#include "../include/CV.hpp"			// Cross-validation
#include "../include/CVModel.hpp"		// Optimise model through CV


int main(int argc, char ** argv){

	std::string querindex = "/home/casper/indexes/sigir2016-test-queries/";

	CV * cv       = new CV(querindex);
	CVFOLDS folds = cv->createfolds(3);

	map<Fold *, Fold *>::iterator it;

	for(it = folds.begin(); it != folds.end(); ++it){
		Fold * f1 = it->first;
		Fold * f2 = it->second;

		std::vector<std::string> testing  = f1->getFold();
		std::vector<std::string> training = f2->getFold();
		std::cout << std::endl;
		std::cout << "Printing testing fold" << std::endl;
		std::vector<std::string>::iterator testitr;
		for(testitr = testing.begin(); testitr != testing.end(); ++testitr){
			std::cout << (*testitr) << ",";
		}
		std::cout << std::endl;

		std::cout << "Printing training fold" << std::endl;
		std::vector<std::string>::iterator trainitr;
		for(trainitr = training.begin(); trainitr != training.end(); ++trainitr){
			std::cout << (*trainitr) << ",";
		}

	}

	return 1;
}
