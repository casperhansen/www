#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <unordered_map>
#include <map>
#include <time.h>
#include <set>
#include <cmath>
#include <cstring>
#include <limits>
#include <iterator>
#include <iomanip>      // std::setprecision
#include <algorithm>
#include <utility>
#include <ctime>
#include <cctype>
#include "omp.h"
#include <chrono>		// For timing

#define SSTR( x ) dynamic_cast< std::ostringstream & >( \
        ( std::ostringstream() << std::dec << x ) ).str()

std::string getTime(){
	time_t now = time(0);
	tm *ltm = localtime(&now);

	std::string str = "[2015/" + SSTR(ltm->tm_mon) + "/" + SSTR(ltm->tm_mday) + "] " + SSTR(1+ltm->tm_hour) + ":" + SSTR(1+ltm->tm_min) + ":" + SSTR(1+ltm->tm_sec);
	return str;
}
void termWeight(indri::collection::Repository & r){
	// Need a vocabulary iterator
	indri::collection::Repository::index_state state = r.indexes();
	indri::index::Index* index = (*state)[0];
	indri::index::VocabularyIterator* iter = index->vocabularyIterator();
	iter->startIteration();
	UINT64 totalTerms  = index->termCount();
	double totalDocs   = index->documentCount();

        std::cout << "termcount, idf, ridf, xi, burstiness, gain" << std::endl;
	while( !iter->finished() ) {
		indri::index::DiskTermData* entry = iter->currentEntry();
	    indri::index::TermData* termData = entry->termData;
		//std::string st     = r.processTerm(termData->term);
	    UINT64 termCount   = index->termCount(termData->term);
	    double docCount    = index->documentCount(termData->term);
	    double idf        = log2(totalDocs / docCount);
	    double ridf       = idf - (-log2(1.0 - exp(-1.0*termCount/totalDocs)));
	    double xi         = termCount - docCount;
	    double burstiness = termCount / docCount;
	    double tmp        = (docCount/totalDocs);
	    double gain       = tmp * (tmp - 1 - log2(tmp));
	    std::cout << termData->term << "," << termCount << "," << idf << "," << ridf << "," << xi << "," << burstiness << "," << gain << std::endl;
	    iter->nextEntry();
	}
}


int main(int argc, char **argv){
	indri::collection::Repository r;
	r.openRead( argv[1] );
	termWeight(r);
	r.close();
}
