/*
 * TestDistributions.cpp
 *
 *  Created on: Oct 6, 2015
 *      Author: casper
 */
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <unordered_map>
#include <map>
#include <time.h>
#include <set>
#include <cmath>
#include <cstring>
#include <limits>
#include <iterator>
#include <iomanip>      // std::setprecision
#include <algorithm>
#include <utility>
#include <ctime>
#include <cctype>
#include "boost/math/special_functions/zeta.hpp"
#include "boost/math/special_functions/beta.hpp"
#include <gsl/gsl_errno.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_sf_zeta.h>
# define M_PI_          3.141592653589793238462643383279502884L
/*
 * All score models' output is compared to MATLABs. VERIFIED means the model's output is the same as MATLAB's
 */

// VERIFIED
double WBL2dscoreModel(double docfreq, double k, double lambda){
		return ((k / lambda)  *  pow((docfreq / lambda), (k - 1.0))  *  exp(-1.0 * (pow( (docfreq / lambda), k))));
}

// FAILED
double PL2dscoreModel(double tf, double lambda){
	//return (tf * log2( tf / lambda) + (lambda + (1 / (12 * tf)) - tf) * log2(exp(1.0)) + 0.5 * log2(2*M_PI_*tf));
	return (pow(lambda, tf) * exp(-lambda) / tgamma(tf+1));
}

// VERIFIED
double GL2dscoreModel(double lambda, double alpha, double tf){
	return (1.0/(pow(alpha,lambda)*tgamma(lambda)) * pow(tf, (lambda - 1)) * exp(-tf/alpha));
}

// VERIFIED
double EL2dscoreModel(double tf, double lambda){
	return (1/lambda * exp(-tf / lambda));
}

// VERIFIED
double RL2dscoreModel(double tf, double sigma){
		return (tf / pow(sigma, 2.0)) * exp(-1.0 * (  pow(tf, 2.0) / (2*pow(sigma, 2.0))  ));
}

double myZeta(double a_hat, double x_min){
	gsl_sf_result result;
	if(gsl_sf_hzeta_e(a_hat, x_min, &result) == GSL_SUCCESS){
		return result.val;
	}
	//std::cout << "Result of a_hat: " << a_hat << ", and x_min: " << x_min << " was: " << result.val << std::endl;
	return GSL_NAN;
}

// VERIFIED
double PLAW2dscoreModel(double tf, double alpha, double xmin){
	//double zetaval = boost::math::zeta<double>(2.3);
	return ((1/myZeta(alpha, xmin)) * pow(tf, -alpha));
}

// VERIFIED
double CHIL2dscoreModel(double tf, double n){
	return ( (pow(0.5,n/2.0))  /  (tgamma(n/2.0)) * pow(tf, (n/2.0) - 1.0) * exp(-tf/2.0));
}

// VERIFIED
double LNL2dscoreModel(double tf, double mu, double sigma){
		return ( 1/(tf*sigma*sqrt(2*M_PI)) * exp(-1 * ( pow(log(tf) - mu,2.0)   / (2*pow(sigma,2.0))   ) ));
}

// VERIFIED
double NORML2dscoreModel(double tf, double mu, double sigma){
	return ( 1/(sigma*sqrt(2*M_PI)) * exp(-1 * ( pow(tf - mu,2.0)   / (2*pow(sigma,2.0))   ) ));
}

// VERIFIED
double GEOL2dscoreModel(double tf, double p){
	return ( pow(1 - p, tf) * p );
}

// VERIFIED
double GPL2dscoreModel(double tf, double k, double sigma, double theta){
	if(k != 0){
		if(k > 0){
			if(tf >= theta){
				return ( 1/sigma * pow(1 + k * ((tf - theta) / sigma), -1.0 - (1.0/k)));
			}
			return 0;
		}
		if(k < 0){
			if(theta <= tf && tf <= theta - (sigma/k)){
				return ( 1/sigma * pow(1 + k * ((tf - theta) / sigma), -1.0 - (1.0/k)));
			}
			return 0;
		}
	}
	if(tf >= theta){
		return (1/sigma * exp(-1 * ((tf - theta) / sigma )));
	}
	return 0;
}

// VERIFIED
double NBINL2dscoreModel(double tf, double r, double p){
	return ( tgamma(r + tf)/(tgamma(r)*tgamma(tf + 1)) * pow(p, r) * pow(1 - p, tf));
}

// VERIFIED (using MATLAB's pdf)
double NAKAL2dscoreModel(double tf, double mu, double w){
		return ( (2*pow(mu, mu))/(tgamma(mu)*pow(w, mu)) * pow(tf, 2*mu - 1) * exp(-1.0 * mu/w * pow(tf, 2.0) ) );
}

// VERIFIED (using MATLAB's pdf)
double LOGL2dscoreModel(double tf, double mu, double s){
	return ( (         exp((tf - mu) / s)   ) /
			 (s * pow(1.0 + exp((tf - mu) / s),2.0)) );
}

// VERIFIED (exchanged order of mu and lambda and did the same in ScoreModel.hpp)
double INVGL2dscoreModel(double tf, double mu, double lambda){
	//return ( sqrt(lambda / (2*M_PI*pow(tf, 3.0))) * exp( -lambda / (2*pow(mu,2.0)*tf) * pow((tf - mu), 2.0)) );
	return (sqrt(lambda/(2.0*M_PI_*pow(tf, 3.0))) * exp( -(lambda * pow(tf - mu, 2.0))  /  (2.0*pow(mu,2.0)* tf) ));
}

// VERIFIED
double YULEL2dscoreModel(double tf, double p){
	//return ( p * tgamma(tf)*tgamma(p + 1)/tgamma(tf + p));
	double C = 1.0;
	if(tf > 1){
		C = (tf - 1) + boost::math::beta(tf-1, p);
	}
	std::cout << "C: " << C << std::endl;
	return ((p - 1) * boost::math::beta(tf, p) * 1.0/C);
}

// VERIFIED
double GEVL2dscoreModel(double tf, double k, double sigma, double mu){

	if(k == 0.0){
		return ( (1/sigma) * exp(-exp( -(tf-mu)/sigma) - (tf-mu)/sigma) );
	}

	double z = (1 + k * (tf - mu)/sigma);

	if(z > 0){
		return ( 1/sigma * exp(-1*pow(z, -1/k)) * pow(z, -1 - 1/k)  );
	}
	return 0;
}

int main(int argc, char ** argv){

	std::vector<double> parms;

	parms.push_back(-0.2358); parms.push_back(10.0235); parms.push_back(2.1898);


	for(double tf = 1; tf <= 10; tf++){
		std::cout << "tf: " << tf << ", prob: " << GEVL2dscoreModel(tf, parms.at(0), parms.at(1), parms.at(2)) << std::endl;
	}

	return 1;
}



