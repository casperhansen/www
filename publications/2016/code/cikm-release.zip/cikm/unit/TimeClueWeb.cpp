/*
 * TimeClueWeb.cpp
 *
 * The purpose of this file is to time how long it will take to loop over the ClueWeb09 (or ClueWeb12 or any
 * large index) and time how long it will take to process a single query consisting of n terms over the index
 * by simply counting its frequency in each document.
 *
 *
 *  Created on: Jun 18, 2015
 *      Author: casper
 */

#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <map>
#include <time.h>
#include <set>
#include <cmath>
#include <cstring>
#include <limits>
#include <iterator>
#include "../include/aux.hpp"

std::string boolToString (bool b){
	std::string res = "";
    if(b){
    	res ="true";
    }else{
    	res = "false";
    }
    return res;
}

void loop(indri::collection::Repository & r){
    indri::server::LocalQueryServer local(r);
    indri::collection::Repository::index_state state = r.indexes();
    UINT64 docCount = local.documentCount();

    int op   = (int)floor(docCount/100.0);
    int pctr = 1;
    std::vector<lemur::api::DOCID_T> documentIDs;
    std::cout << "Looping over " << docCount << " documents" << std::endl;
	clock_t tStart = clock();
	double acc = 0.0;
	indri::server::QueryServerVectorsResponse* response;
    for(int i = 0; i < docCount; i++){
    	lemur::api::DOCID_T documentID = (i+1);
        documentIDs.push_back(documentID);
        response = local.documentVectors( documentIDs );
        if( response->getResults().size() ) {
        	map<std::string, int> hist;
            indri::api::DocumentVector* docVector = response->getResults()[0];
            for( size_t i=0; i<docVector->positions().size(); i++ ) {
              int position = docVector->positions()[i];
              const std::string& stem = docVector->stems()[position];
              if(hist.find(stem) == hist.end()){
            	  hist[stem] = 1;
              }else{
            	  hist[stem]++;
              }
            }
            delete docVector;
        }
        if((i+1) % op == 0){
        	double tEnd    = (double)(clock() - tStart)/CLOCKS_PER_SEC;
        	acc += tEnd;
        	std::cout << "Completed " << pctr << " percent in " << tEnd << " seconds" << std::endl;
        	pctr++;
        	tStart = clock();
        }

        //delete response;
    	documentIDs.clear();
    }
    delete response;
    std::cout << "Everything completed in " << acc << " seconds" << std::endl;
}


void loop_new(indri::collection::Repository & r){
    indri::server::LocalQueryServer local(r);
    indri::collection::Repository::index_state state = r.indexes();
    UINT64 docCount = local.documentCount();
    std::cout << "Looping over " << docCount << " documents" << std::endl;
    std::vector<lemur::api::DOCID_T> documentIDs;
    for(int i = 0; i < docCount; i++){
    	lemur::api::DOCID_T documentID = (i+1);
    	documentIDs.push_back(documentID);
    }
    std::cout << "Fetching documents from disk.... " << std::endl;
    clock_t tStart = clock();
    indri::server::QueryServerVectorsResponse * response = local.documentVectors( documentIDs );
    double tEnd    = (double)(clock() - tStart)/CLOCKS_PER_SEC;
    std::cout << "Done! (" << tEnd << " seconds)" << std::endl;
    int op     = (int)floor(docCount/100.0);
    int pctr   = 1;
    double acc = 0.0;
    acc += tEnd;
    tStart = clock();
    if( response->getResults().size() ) {
    	/* Use unordered_map for performance */
		map<std::string, int> hist;
    	for(size_t j = 0; j < docCount; j++){
			indri::api::DocumentVector* docVector = response->getResults()[j];
			for( size_t i=0; i<docVector->positions().size(); i++ ) {
			  const std::string& stem = docVector->stems()[ docVector->positions()[i] ];

			  if(hist.find(stem) == hist.end()){
				  hist[stem] = 1;
			  }else{
				  hist[stem]++;
			  }
			}
			delete docVector;

	        if((j+1) % op == 0){
	        	double tEnd    = (double)(clock() - tStart)/CLOCKS_PER_SEC;
	        	acc += tEnd;
	        	std::cout << "Completed " << pctr << " percent in " << tEnd << " seconds" << std::endl;
	        	pctr++;
	        	tStart = clock();
	        }
	        hist.clear();
    	}
    }
    delete response;
    std::cout << "Everything completed in " << acc << " seconds" << std::endl;
}


void loop_ret(indri::collection::Repository & r){

	std::set<std::string> vTerms;
	std::string t1 = "disciplines";//"is";
//	std::string t2 = "similarity";//"are";
	vTerms.insert(t1);
//	vTerms.insert(t2);

	indri::collection::Repository::index_state state = r.indexes();
	indri::server::LocalQueryServer local(r);
	UINT64 docCount = local.documentCount();
	indri::index::Index* index = (*state)[0];
	indri::index::DocListFileIterator* iter = index->docListFileIterator();


	vector<idx::IndexObject *> valid;


	iter->startIteration();
    double tStart = clock();
    int doccounter = 1;
	while( !iter->finished() ) {
		indri::index::DocListFileIterator::DocListData* entry = iter->currentEntry();
		indri::index::TermData* termData = entry->termData;
		/* Prepare to capture the stuff! */
		std::vector<idx::DocIDFreq *> entries;
		while(!entry->iterator->finished()){
			  indri::index::DocListIterator::DocumentData* doc = entry->iterator->currentEntry();
			  idx::DocIDFreq * ptr = new idx::DocIDFreq(doc->document, doc->positions.size());
			  entries.push_back(ptr);
			  entry->iterator->nextEntry();
		}
		std::string term(termData->term);
		bool is_in = vTerms.find(term) != vTerms.end();

	    if(is_in){
	    	idx::IndexObject * obj = new idx::IndexObject(term, entries);
	    	valid.push_back(obj);
	    }

	    iter->nextEntry();
	}

	std::vector<idx::IndexObject * >::iterator it;

	std::cout << "***************************************" << std::endl;
	for(it = valid.begin(); it != valid.end(); ++it){
/*
		std::cout << (*it)->getTerm() << std::endl;
		std::cout << (*it)->getVals().size() << std::endl;
		std::vector<idx::DocIDFreq *> entries = (*it)->getVals();
		std::vector<idx::DocIDFreq *>::iterator oo;
		for(oo = entries.begin(); oo != entries.end(); ++oo){
			std::cout << (*oo)->getDocID() << " :: " << (*oo)->getTermFreq() << std::endl;
		}
*/
		//std::cout << (*it)->getTerm() << " :: " << (*it)->toString() << std::endl;

	}

	double tEnd    = (double)(clock() - tStart)/CLOCKS_PER_SEC;
	std::cout << "Everything completed in " << tEnd << " seconds" << std::endl;
}

void tmp(){
	std::string term = "casper";
	int docid        = 4;
	std::vector<idx::DocIDFreq *> entries;

	for(int i = 0; i < 4; i++){
		idx::DocIDFreq * ptr = new idx::DocIDFreq(docid, i);
		entries.push_back(ptr);
	}

	idx::IndexObject * obj = new idx::IndexObject(term, entries);

	std::vector<idx::DocIDFreq * > es = obj->getVals();
	std::cout << obj->getTerm() << std::endl;
	std::vector<idx::DocIDFreq * >::iterator it;
	for(it = es.begin(); it != es.end(); ++it){
		std::cout << (*it)->getDocID() << "\t" << (*it)->getTermFreq() << std::endl;
	}
}

int main(int agrc, char ** argv){
    indri::collection::Repository r;
    r.openRead( argv[1] );
    //loop(r);
    //loop_new(r);
    loop_ret(r);
    //tmp();
    r.close();
}



