#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <unordered_map>
#include <map>
#include <time.h>
#include <set>
#include <cmath>
#include <cstring>
#include <limits>
#include <iterator>
#include <iomanip>      // std::setprecision
#include <algorithm>
#include <utility>
#include <ctime>
#include <cctype>
#include "omp.h"
#include <chrono>		// For timing

class QUERYOBJECT {
		private:
			std::string queryid;
			std::vector<std::string> qterms;
			std::string scoreModel;
			map<std::string, int> queryfreq;
			double score;
			~QUERYOBJECT(){};
		public:
			/* *_query contains the query terms of the specificed query */
			QUERYOBJECT();
			QUERYOBJECT(const std::vector<std::string> _qterms, std::string _queryid, std::string _scoreModel, map<std::string, int> _queryfreq){
				scoreModel = _scoreModel;
				queryid    = _queryid;
				qterms     = _qterms;
				queryfreq  = _queryfreq;
				score      = 0.0;
			}

			std::string toString(){
				std::string ret = "";
				std::vector<std::string>::iterator it;
				for(it = qterms.begin(); it != qterms.end(); ++it){
					ret = ret + (*it) + " ";
				}
				return ret;
			}

			std::vector<std::string> getQueryTerms(){
				return qterms;
			}

			void setScoreModel(std::string _scoreModel){
				scoreModel = _scoreModel;
			}

			std::string getScoreModel(){
				return scoreModel;
			}

			void setScore(double _score){
				score = _score;
			}

			double getScore(){
				return score;
			}

			std::string getQueryID(){
				return queryid;
			}

			int getQueryTermFrequency(std::string term){
				bool found = queryfreq.find(term) != queryfreq.end();
				if(found){
					return queryfreq[term];
				}
				return -1;
			}
};


map<std::string, QUERYOBJECT *> qIDtoQuery;
std::set< std::string >         POOLED_QUERYTERMS;

void loadQueries(std::string index, std::string fieldString){
	indri::collection::Repository r;
	r.openRead( index );
	indri::server::LocalQueryServer local(r);
	UINT64 docCount = local.documentCount();

	/* Load all the documents (queries if we are being honest) into memory */
	std::vector<lemur::api::DOCID_T> documentIDs;
	int i;
	for(i = 0; i < docCount; i++){
		lemur::api::DOCID_T documentID = i+1;
		documentIDs.push_back(documentID);
	}

	/* We need this to retrieve the document id i.e. the thing in the <DOCNO> </DOCNO> tags which we assume are set to the query id */
	indri::collection::CompressedCollection* collection = r.collection();

	/* Retrieve the content of the queries (i.e. their terms) */
    indri::server::QueryServerVectorsResponse* response = local.documentVectors( documentIDs );
	double tStart = clock();
	if( response->getResults().size() ) {

		/* Loop over the queries to reconstruct them and pool their query terms for inverted list retrieval */
		int j;
		for(j = 0; j < docCount; j++){
		    indri::api::DocumentVector* docVector = response->getResults()[j];
		    /* This corresponds to the query id from the TREC query files -- See Assumptions */
		    std::string queryid = collection->retrieveMetadatum( documentIDs.at(j), "docno" );

		    std::vector<std::string  > query;
		    std::set<std::string     > queryTermSeen;
		    std::map<std::string, int> queryfreq;

		    /*
		     * Fetch the start and end indices for the specified field
		     * If a field is not specified (or misspecified) we default to using everything
		     */
		    int fieldstart = 0;
		    int fieldend   = docVector->positions().size();
		    for( size_t i=0; i<docVector->fields().size(); i++ ) {
		      const indri::api::DocumentVector::Field& field = docVector->fields()[i];
		      if(field.name.compare(fieldString) == 0){
		    	  // We have a match
		    	  fieldstart = field.begin;
		    	  fieldend   = field.end;
		    	  break;
		      }
		    }

		    int k;
		    for(k=fieldstart; k<fieldend; k++ ) {
		    	int position = docVector->positions()[k];
		    	const std::string& stem = docVector->stems()[position];
		    	/* To ensure we do not include stop words */
		    	if(stem.compare("[OOV]") != 0){
					/* Now we have a stem. Add it to the pool... */
					POOLED_QUERYTERMS.insert(stem);

					bool seen = queryTermSeen.find(stem) != queryTermSeen.end();
					if(!seen){
						/*  And to its query - We are not interested in saving repeated terms */
						query.push_back(stem);
					}
					/* but we do want to increment its frequency */
					bool found = queryfreq.find(stem) != queryfreq.end();
					if(found){
					   queryfreq[stem]++;
					}else{
					   queryfreq[stem] = 1;
					}
					queryTermSeen.insert(stem);
		    	}
		    }
		    /* Save the query */
		    QUERYOBJECT * q = new QUERYOBJECT(query, queryid, "", queryfreq);

		    /* Indexed by its query id */
		    qIDtoQuery[queryid] = q;

		    delete docVector;
		}
	}
	delete response;
	r.close();
}

int main(int argc, char ** argv){
	std::string queryIndex = argv[1];

	loadQueries(queryIndex, "title");

	std::string collectionIndex = argv[2];

	indri::collection::Repository r;
	r.openRead( collectionIndex );
	indri::server::LocalQueryServer local(r);
	indri::collection::Repository::index_state state = r.indexes();
    indri::index::Index* index = (*state)[0];
    UINT64 uqTermCount = index->uniqueTermCount();
    UINT64 termCount   = index->termCount();
    INT64 totalF       = 0;
    INT64 totalN       = 0;
	std::set<std::string>::iterator query_itr;
	for(query_itr = POOLED_QUERYTERMS.begin(); query_itr != POOLED_QUERYTERMS.end(); ++query_itr){
		std::string term = *query_itr;
    	if(term.compare("[OOV]") != 0){
			INT64 F          = local.termCount(term);     //F /totalF)
			INT64 eliteset   = local.documentCount(term); //n (totalN)
			totalF          += F;
			totalN          += eliteset;
    	}
	}
	r.close();
	std::cout << "Total unique term count in " << argv[2] << " is " << uqTermCount << std::endl;
	std::cout << "Total unique query terms in " << argv[1] << " is " << POOLED_QUERYTERMS.size() << std::endl;
	std::cout << "Percentage: " << ((POOLED_QUERYTERMS.size()/(double)uqTermCount)*100) << "%" << std::endl;
	std::cout << "Total term count in " << argv[2] << " is " << termCount << std::endl;
	std::cout << "Total F: " << totalF << std::endl;
	std::cout << "Percentage: " << ((totalF/(double)termCount)*100) << "%" << std::endl;
	return 0;
}
