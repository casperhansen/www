
#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <unordered_map>
#include <map>
#include <time.h>
#include <set>
#include <cmath>
#include <cstring>
#include <limits>
#include <iterator>
#include <iomanip>      // std::setprecision
#include <algorithm>
#include <utility>
#include <ctime>
#include <cctype>
#include "omp.h"
#include <chrono>		// For timing

void getInvLists(indri::collection::Repository & r, std::set<std::string> qTerms){
	indri::collection::Repository::index_state state     = r.indexes();
	indri::index::Index* index                           = (*state)[0];
	indri::thread::ScopedLock( index->iteratorLock() );
	indri::collection::CompressedCollection * collection = r.collection();
	indri::server::LocalQueryServer local(r);

	set<std::string>::iterator it;
	for(it = qTerms.begin(); it != qTerms.end(); ++it){
		  std::string term  = *it;
		  std::string term2 = r.processTerm(term);
		  std::cout << "Original term: " << term << ", r.processTerm(term): " << term2 << std::endl;
	}
}

int main(int argc, char ** argv){
	indri::collection::Repository r;
	std::set<std::string> terms;
	terms.insert("companies");
	terms.insert("accusations");
	r.openRead( argv[1] );
	getInvLists(r, terms);
	r.close();
	return 1;
}
