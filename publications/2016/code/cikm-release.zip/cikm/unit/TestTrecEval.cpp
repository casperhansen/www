#include "../include/TrecEval.hpp"
#include <string>
#include <iostream>

int main(int argc, char ** argv){
	std::string res   = "/home/casper/wt10.result";
	std::string qrels = "/home/casper/10.adhoc-qrels.final";

	TrecEval t;
	t.evaluate(qrels, res);

}
