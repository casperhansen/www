/*
 * TestTemplate.cpp
 *
 *  Created on: Jul 3, 2015
 *      Author: casper
 */
#include <iostream>
#include <cmath>
#include <cerrno>
#include <cfenv>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <stdio.h>
#include <limits>

enum DEV_TYPE {DX,DY,DZ};

template<typename value_type, typename function_type>
   value_type derivative(const DEV_TYPE d, const value_type dx, const value_type x, const value_type y, const value_type z, function_type func)
{
   const value_type dx1 = dx;
   const value_type dx2 = dx1 * 2;
   const value_type dx3 = dx1 * 3;

   value_type m1,m2,m3;
   switch(d){
   	   case DX:
   		   m1 = (func(x + dx1, y, z ) - func(x - dx1, y, z )) / 2;
   		   m2 = (func(x + dx2, y, z ) - func(x - dx2, y, z )) / 4;
   		   m3 = (func(x + dx3, y, z ) - func(x - dx3, y, z )) / 6;
   		   break;
   	   case DY:
   		   m1 = (func(x, y + dx1, z ) - func(x, y - dx1, z )) / 2;
   		   m2 = (func(x, y + dx2, z ) - func(x, y - dx2, z )) / 4;
   		   m3 = (func(x, y + dx3, z ) - func(x, y - dx3, z )) / 6;
   		   break;
   	   case DZ:
   		   m1 = (func(x, y, z + dx1 ) - func(x, y, z - dx1 )) / 2;
   		   m2 = (func(x, y, z + dx2 ) - func(x, y, z - dx2 )) / 4;
   		   m3 = (func(x, y, z + dx3 ) - func(x, y, z - dx3 )) / 6;
   		   break;
   	   default: std::cout << "Error in specified derivative type " << d << std::endl;
   	   	   	    exit(-1);
   }

   const value_type fifteen_m1 = 15 * m1;
   const value_type six_m2     =  6 * m2;
   const value_type ten_dx1    = 10 * dx1;

   return ((fifteen_m1 - six_m2) + m3) / ten_dx1;
}

double ff(double a, double b, double c){
	return std::sin(a);
}

int main(int argc, char ** argv){
	double (*eval)(const DEV_TYPE, const double, const double, const double, const double, double (*f)(double,double,double));

	eval = &derivative;

	const double df = eval(DX, 0.001, M_PI/3.0, 0.0, 0.0, ff);

	std::cout << "Value: " << std::setprecision(std::numeric_limits<double>::digits10) << df << std::endl;

	return 0;
}
