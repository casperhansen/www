//#include "../include/TrecEval.hpp"
//#include "../include/aux.hpp"
//#include <random>
#include <iostream>
#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <map>
#include <string>
#include <vector>
#include <stdlib.h>
#include <cmath>
#include <cstring>
#include <limits>
#include <iterator>
#include <iomanip>      // std::setprecision
#include <algorithm>
#include <utility>
#include <ctime>
#include <cctype>


using std::cout;
using std::endl;

#define SSTR( x ) dynamic_cast< std::ostringstream & >( \
        ( std::ostringstream() << std::dec << x ) ).str()

std::string printTime(){
	time_t now = time(0);
	tm *ltm = localtime(&now);

	std::string str = "[2015/" + SSTR(ltm->tm_mon) + "/" + SSTR(ltm->tm_mday) + "] " + SSTR(1+ltm->tm_hour) + ":" + SSTR(1+ltm->tm_min) + ":" + SSTR(1+ltm->tm_sec);
	return str;
}

int main(int argc, char ** argv){


	indri::collection::Repository r;
	r.openRead( argv[1] );

	indri::collection::Repository::index_state state     = r.indexes();
	indri::index::Index* index                           = (*state)[0];
	indri::thread::ScopedLock( index->iteratorLock() );
	indri::collection::CompressedCollection * collection = r.collection();

	indri::server::LocalQueryServer local(r);

	/*
	 * If the collection was indexed then the below average is skewed as it will count stop words.
	 * To avoid counting stop words loop over the vocabulary (see print_vocabulary in dumpindex.cpp)
	 */

	INT64  documentCount = index->documentCount();
	UINT64 colLen 		 = index->termCount();

    double avgDocLength  = colLen / double(documentCount);
    std::cout << "Average document length (biased): " << avgDocLength << std::endl;


	UINT64 docCount = local.documentCount();

	std::vector<lemur::api::DOCID_T> documentIDs;
	int i;
	for(i = 0; i < docCount; i++){
		lemur::api::DOCID_T documentID = i+1;
		documentIDs.push_back(documentID);
	}

	map<std::string, int> realDocLengths;

	std::cout << printTime() << " - Fetching " << documentCount << " documents...." << std::endl;

    indri::server::QueryServerVectorsResponse* response = local.documentVectors( documentIDs );
    std::cout << printTime() << " - Fetched all documents!" << std::endl;
	int final_counter = 0;
	if( response->getResults().size() ) {

		/* Loop over the queries to reconstruct them and pool their query terms for inverted list retrieval */
		int j;
		for(j = 0; j < docCount; j++){
		    indri::api::DocumentVector* docVector = response->getResults()[j];
		    /* This corresponds to the query id from the TREC query files -- See Assumptions */
		    std::string docid = collection->retrieveMetadatum( j+1, "docno" );

		    int termcounter = 0;
		    size_t total = docVector->positions().size();
		    for(int k = 0; k < total; k++){
		    	int position = docVector->positions()[k];
		    	const std::string& stem = docVector->stems()[position];
		    	if(stem.compare("[OOV]") != 0){
		    		termcounter++;
		    	}
		    }
		    final_counter += termcounter;
		    realDocLengths[docid] = termcounter;
		}
	}
    r.close();

    double ll = final_counter/ double(documentCount);
    std::cout << "Average document length (unbiased): " << ll << std::endl;
/*
    map<std::string, int>::iterator cc;
    for(cc = realDocLengths.begin(); cc != realDocLengths.end(); ++cc){
    	std::cout << "Document: " << cc->first << ", Number of terms: " << cc->second << std::endl;
    }
*/
    return 1;

}
