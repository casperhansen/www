#include "../include/QExp.hpp"
using namespace std;

int main(int argc, char ** argv){
	QExp qe;
	std::string index = "/home/casper/indexes/qtfdf/nyt/";
	std::string query = "world trade center";
	std::string expandedQuery = qe.expand(index, query);

	std::cout << "Original query: " << query         << std::endl;
	std::cout << "Expanded query: " << expandedQuery << std::endl;

	return EXIT_SUCCESS;
}
