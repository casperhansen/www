#include "../include/CV.hpp"
using namespace std;

int main(int argc, char ** argv){
	CV * co = new CV("/home/casper/indexes/TREC/TREC-8-adhoc/index/trec8-queries-description-nostop-nostem/");

	map<Fold *,Fold *> mm = co->createfolds(5);

	map<Fold *,Fold *>::iterator it;
	int round = 1;
	for(it = mm.begin(); it != mm.end(); ++it){

		std::cout << "*************************************" << std::endl;
		std::cout << "*              ROUND " << round << "              *" << std::endl;
		std::cout << "*************************************" << std::endl;
		round++;
		vector<std::string> test  = it->first->getFold();
		vector<std::string> train = it->second->getFold();

		vector<std::string>::iterator testIT;
		std::cout << "Test fold: " << std::endl;
		for(testIT = test.begin(); testIT != test.end(); ++testIT){
			std::cout << *testIT << " ";
		}
		std::cout << std::endl;

		vector<std::string>::iterator trainIT;
		std::cout << "Train fold: " << std::endl;
		for(trainIT = train.begin(); trainIT != train.end(); ++trainIT){
			std::cout << *trainIT << " ";
		}
		std::cout << std::endl;

	}

	return EXIT_SUCCESS;
}
