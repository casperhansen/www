//#include "../include/TrecEval.hpp"
//#include "../include/aux.hpp"
//#include <random>
#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <unordered_map>
#include <map>
#include <set>
#include <cmath>
#include <cstring>
#include <limits>
#include <iterator>
#include <iomanip>      // std::setprecision
#include <algorithm>
#include <utility>
#include <ctime>
#include <cctype>
#include "splinter/datatable.h"
#include "splinter/bsplineapproximant.h"
#include "splinter/psplineapproximant.h"
#include "splinter/rbfapproximant.h"
#include "splinter/polynomialapproximant.h"

/*
std::vector<std::string> split(const std::string &s, char delim, std::vector<std::string> &elems) {
    std::stringstream ss(s);
    std::string item;
    while (std::getline(ss, item, delim)) {
        elems.push_back(item);
    }
    return elems;
}
*/

//using namespace SPLINTER;
/*
 * To install the SPLINTER library:
 * 1 - Download the package form https://github.com/bgrimstad/splinter/blob/master/docs/compile.md#options-both-platforms
 * 2 - Copy the include to /usr/local/include (put it in a SPLINTER directory)
 * 3 - Copy the lib to /usr/local/lib
 * 4 - sudo apt-get install libeigen3-dev
 * 5 - Go to /usr/local/include
 * 6 - sudo ln -s /usr/include/eigen3/Eigen /usr/local/include/Eigen
 * 7 -  Change the makefile to include: -lsplinter-static-2-0
 */

/*
double f(DenseVector x)
{
 //   assert(x.rows() == 2);
    return (4 - 2.1*x(0)*x(0)
           + (1/3.)*x(0)*x(0)*x(0)*x(0))*x(0)*x(0)
           + x(0)*x(1)
           + (-4 + 4*x(1)*x(1))*x(1)*x(1);
}
*/

#define SSTR( x ) dynamic_cast< std::ostringstream & >( \
        ( std::ostringstream() << std::dec << x ) ).str()

constexpr unsigned int str2int(const char* str, int h = 0)
		{
		    return !str[h] ? 5381 : (str2int(str, h+1)*33) ^ str[h];
		}

int main(int argc, char ** argv){
	  indri::collection::Repository r;
	  r.open(argv[1]);
	  indri::collection::Repository::index_state state = r.indexes();

	  indri::index::Index* index = (*state)[0];
	  indri::index::DocListFileIterator* iter = index->docListFileIterator();
	  iter->startIteration();
	  int max = 0;
	  const char * term;
	  while( !iter->finished() ) {
	    indri::index::DocListFileIterator::DocListData* entry = iter->currentEntry();
	    indri::index::TermData* termData = entry->termData;
	    entry->iterator->startIteration();

	    while( !entry->iterator->finished() ) {
	      indri::index::DocListIterator::DocumentData* doc = entry->iterator->currentEntry();
	      //std::cout << doc->positions.size() << std::endl;
	      if(doc->positions.size() > max){
	    	  max = doc->positions.size();
	    	  term = termData->term;
	      }
	      entry->iterator->nextEntry();
	    }

	    iter->nextEntry();
	  }
	  std::cout << "Term: " << term << ", Single document frequency: " << max << std::endl;
	  delete iter;
	  r.close();

/*
	indri::collection::Repository r;
	r.open("/home/casper/indexes/sigir2016-test-documents/");
	indri::server::LocalQueryServer local(r);
	int F         = local.termCount(argv[1]);
	int eliteset  = local.documentCount(argv[1]);
	std::cout << "Size of elite set: " << eliteset << std::endl;
	std::cout << "Total occurrences of " << argv[1] << " is: " << F << std::endl;
	r.close();
*/
/*

	DataTable samples;

	// Sample the function
	DenseVector x(2);
	double y;
	for(int i = 0; i < 20; i++) {
	    for(int j = 0; j < 20; j++) {
	       // Sample function at x
	       x(0) = i*0.1;
	       x(1) = j*0.1;
	       y = f(x);

	       // Store sample
	       samples.addSample(x,y);
	    }
	}
*/
/*
	BSplineApproximant bspline1(samples, BSplineType::LINEAR);
	BSplineApproximant bspline3(samples, BSplineType::CUBIC);

	    // Build penalized B-spline (P-spline) that smooths the samples
	    PSplineApproximant pspline(samples, 0.03);

	    // Build radial basis function spline that interpolate the samples
	    RBFApproximant rbfspline(samples, RBFType::THIN_PLATE_SPLINE);

	    /* The six-hump camelback is a function of degree 6 in x(0) and degree 4 in x(1),
	     * therefore a polynomial of degree 6 in the first variable and 4 in the second
	     * will be sufficient to interpolate the function
	     */
/*
	    auto degrees = std::vector<unsigned int>(2);
	    degrees.at(0) = 6;
	    degrees.at(1) = 4;
	    PolynomialApproximant polyfit(samples, degrees);

	    x(0) = 1; x(1) = 1;
	        cout << "-------------------------------------------------"        << endl;
	        cout << "Function at x: \t\t\t"            << f(x)                 << endl;
	        cout << "Linear B-spline at x: \t\t"       << bspline1.eval(x)     << endl;
	        cout << "Cubic B-spline at x: \t\t"        << bspline3.eval(x)     << endl;
	        cout << "P-spline at x: \t\t\t"            << pspline.eval(x)      << endl;
	        cout << "Thin-plate spline at x:\t\t"      << rbfspline.eval(x)    << endl;
	        cout << "Polynomial of degree 6 at x:\t"   << polyfit.eval(x)      << endl;
	        cout << "-------------------------------------------------"        << endl;

	return 0;
*/
/*
	std::random_device rd;
	std::mt19937 e2(rd());
	std::uniform_real_distribution<> dist(0.0, 1.0);

	for(int i = 0; i < 20; i++){
		std::cout << "Dist: " << dist(e2) << ", Dist: " << dist(e2) << std::endl;
	}
	decltype(dist.param()) new_range (0, 30.0);
	dist.param(new_range);

	for(int i = 0; i < 20; i++){
		std::cout << "Dist: " << dist(e2) << ", Dist: " << dist(e2) << std::endl;
	}
*/
/*
	  std::string qrels       = "/home/casper/indexes/TREC/TREC-123-adhoc/qrels/qrels.51-100.disk1.disk2.part1";
	  std::string resultspath = "/home/casper/test_score.out";

	  std::set<std::string> MEASURES;
	  MEASURES.insert("map");         MEASURES.insert("bpref");
	  MEASURES.insert("ndcg");        MEASURES.insert("P_10");
	  MEASURES.insert("ndcg_cut_10");

	  const std::string command = "/usr/bin/trec_eval -m map -m bpref -m ndcg -m P -m ndcg_cut " + qrels + " " + resultspath + " | awk '{print $1\",\"$3}' > /home/casper/tmp.out";
	  const char * exec   = command.c_str();
	  FILE *fp;
	  char path[2048];

	  double tStart = clock();
	  fp = popen(exec, "r");
	  double tEnd   = (double)(clock() - tStart)/CLOCKS_PER_SEC;
	  if (fp == NULL) {
	    std::cout  << "Failed to execute command: " << command << std::endl;
	    exit(EXIT_FAILURE);
	  }
	  pclose(fp);

	  std::vector<double> vals;
	  std::ifstream myReadFile;
	  myReadFile.open("/home/casper/tmp.out");
	  std::string value;
  	  std::vector<std::string> parts;
	  if (myReadFile.is_open()) {
		  while (myReadFile >> value) {
			  	  split(value, ',', parts);
			  	  const bool is_in = MEASURES.find(parts.at(0)) != MEASURES.end();
			  	  if(is_in){
			  		  vals.push_back(atof(parts.at(1).c_str()));
			  	  }
			  	  parts.clear();
		  }
	  }

	  std::vector<double>::iterator it;
	  for(it = vals.begin(); it != vals.end(); ++it){
	  	  std::cout << (*it) << std::endl;
	  }
	  myReadFile.close();

*/
}
