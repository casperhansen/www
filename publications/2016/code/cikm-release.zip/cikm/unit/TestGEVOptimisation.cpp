// The contents of this file are in the public domain. See LICENSE_FOR_EXAMPLE_PROGRAMS.txt
/*

    This is an example illustrating the use the general purpose non-linear
    optimization routines from the dlib C++ Library.

    The library provides implementations of the conjugate gradient,  BFGS,
    L-BFGS, and BOBYQA optimization algorithms.  These algorithms allow you to
    find the minimum of a function of many input variables.  This example walks
    though a few of the ways you might put these routines to use.

*/


#include <dlib/dlib/optimization.h>
#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <iterator>

std::vector<int> values;
int N;
const double eps = 2.2204e-16;
using namespace std;
using namespace dlib;



// ----------------------------------------------------------------------------------------

// In dlib, the general purpose solvers optimize functions that take a column
// vector as input and return a double.  So here we make a typedef for a
// variable length column vector of doubles.  This is the type we will use to
// represent the input to our objective functions which we will be minimizing.
typedef matrix<double,0,1> column_vector;

// ----------------------------------------------------------------------------------------
// Below we create a few functions.  When you get down into main() you will see that
// we can use the optimization algorithms to find the minimums of these functions.
// ----------------------------------------------------------------------------------------

double rosen (const column_vector& m)
/*
    This function computes what is known as Rosenbrock's function.  It is
    a function of two input variables and has a global minimum at (1,1).
    So when we use this function to test out the optimization algorithms
    we will see that the minimum found is indeed at the point (1,1).
*/
{
    const double x = m(0);
    const double y = m(1);

    // compute Rosenbrock's function and return the result
    return 100.0*pow(y - x*x,2) + pow(1 - x,2);
}

double gevnll(const column_vector& m){

	const double k       = m(0);
	const double lnsigma = m(1);
	const double sigma   = exp(lnsigma);
	const double mu      = m(2);

	std::vector<double> z(N);
	std::vector<double> lnu(N);
	std::vector<double> t(N);
	std::vector<double> u(N);


	double tval   = 0.0;
	double lnuval = 0.0;
	double minu   = 10000000.0;
	for(int i = 0; i < N; i++){
		z.at(i) = (values.at(i) - mu) / sigma;
		u.at(i) = 1 + k*z.at(i);
		if(u[i] < minu){
			minu = u.at(i);
		}
		lnu[i] = log1p(k*z.at(i));
		lnuval += lnu[i];
		t[i]   = exp(-(1/k) * lnu.at(i));
		tval += t.at(i);
	}
	double dz;
	if(abs(k) > eps){
		if(minu > 0){
			dz = N*lnsigma + tval + (1 + 1/k)*lnuval;
			std::cout << "dz: " << dz << std::endl;
			return dz;
		}else{
			return 0.0;
		}
	}
	double zval = 0.0;
	for(int j = 0; j < N; j++){
		zval += (exp(-z.at(j)) + z.at(j));
	}
	dz = N*lnsigma + zval;
	std::cout << "dz: " << dz << std::endl;
	return dz;
/*
	if abs(k) > eps
	    u = 1 + k.*z;
	    if min(u) > 0
	        lnu = log1p(k.*z); % log(1 + k.*z)
	        t = exp(-(1/k)*lnu); % (1 + k.*z).^(-1/k)
	        nll = n*lnsigma + sumfast(t) + (1+1/k)*sumfast(lnu);
	    else
	        % The support of the GEV is 1+k*z > 0, or x > mu - sigma/k.
	        nll = Inf;
	    end
	else % limiting extreme value dist'n as k->0
	    nll = n*lnsigma + sumfast(exp(-z) + z);
*/
}

double fpoly(const column_vector& m){
	const double v1 = m(0);
	const double v2 = m(1);

	return 3*pow(v1,2.0) + 2*v1*v2 + pow(v2,2.0) - 4*v1 + 5*v2;
}

void loadValues(char * file){
	  std::string line;
	  std::ifstream myfile (file);
	  int linecounter = 0;
	  if (myfile.is_open()){
		  while (getline (myfile,line)) {
			  int value = atoi(line.c_str());
			  values.push_back(value);
			  linecounter++;
		  }
	  }else{
		  myfile.close();
		  cout << "Unable to open file" << endl;
		  exit(EXIT_FAILURE);
	  }
	  N = values.size();
	  std::cout << "Read " << linecounter << " lines from " << file << std::endl;
}


int main(int argc, char ** argv)
{
/*
	column_vector spoint(2);
	spoint = 1,1;

	find_min_using_approximate_derivatives(bfgs_search_strategy(),
										   objective_delta_stop_strategy(1e-7),
										   fpoly, spoint, -1000);

	std::cout << "F solution: \n" << spoint << std::endl;

	return 1;
*/
	loadValues(argv[1]);
    try
    {
        // make a column vector of length 2
        column_vector starting_point(3);

        column_vector lower_bound(3);
        column_vector upper_bound(3);
        //k, sigma, mu
        lower_bound = -9999,eps,  -9999;
        upper_bound = 10000,10000,10000;
        starting_point = 0.0, 1.0, 0.0;
        // target 0.800589847464438       0.00532882747942095        0.0006891029113068
/*
        find_min_using_approximate_derivatives(lbfgs_search_strategy(100),
                                               objective_delta_stop_strategy(1e-7),
                                               gevnll, starting_point, -1000000);
*/

        find_min_box_constrained(lbfgs_search_strategy(100),
        						 objective_delta_stop_strategy(1e-8),
        		                 gevnll, derivative(gevnll), starting_point, lower_bound, upper_bound);

        // Again the correct minimum point is found and stored in starting_point
        cout << "rosen solution using approximate derivatives:\n" << starting_point << endl;


    }
    catch (std::exception& e)
    {
        cout << e.what() << endl;
    }
}

