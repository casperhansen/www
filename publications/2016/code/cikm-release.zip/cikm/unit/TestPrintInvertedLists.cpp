#include "indri/Repository.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/QueryEnvironment.hpp"
#include <iostream>
#include <set>
#include <string>

int main(int argc, char ** argv){
	  indri::collection::Repository r;
	  r.open("/home/casper/indexes/TREC/TREC-8-adhoc/index/fr94");
	  std::set<std::string> words;
	  words.insert("casper");words.insert("monkey");
	  indri::collection::Repository::index_state state = r.indexes();
	  indri::index::Index* index = (*state)[0];
	  indri::thread::ScopedLock( index->iteratorLock() );

	  set<std::string>::iterator iter;
	  for(iter = words.begin(); iter != words.end(); ++iter){
		  std::string term = *iter;
		  std::string stem = r.processTerm(term);

		  indri::index::DocListIterator* iter = index->docListIterator( stem );
		  if (iter == NULL) continue;

		  iter->startIteration();

		  int doc = 0;
		  indri::index::DocListIterator::DocumentData* entry;

		  std::cout << "Stem: " << stem << std::endl;
		  std::cout << "****************************************" << std::endl;
		  for( iter->startIteration(); iter->finished() == false; iter->nextEntry() ) {
		    entry = (indri::index::DocListIterator::DocumentData*) iter->currentEntry();

		    std::cout << entry->document << " "
		              << entry->positions.size() << std::endl;

		  }
		  std::cout << std::endl;
		  delete iter;
	  }
}


void bla(){
	  indri::collection::Repository r;
	  r.open("/home/casper/indexes/TREC/TREC-8-adhoc/index/fr94");
	  std::set<std::string> words;
	  words.insert("if");words.insert("casper");words.insert("monkey");
	  indri::collection::Repository::index_state state = r.indexes();

	  indri::index::Index* index = (*state)[0];
	  indri::index::DocListFileIterator* iter = index->docListFileIterator();
	  iter->startIteration();
	  int counter = 0;
	  while( !iter->finished() ) {
	    indri::index::DocListFileIterator::DocListData* entry = iter->currentEntry();
	    indri::index::TermData* termData = entry->termData;

	    std::cout << "Before string!" << std::endl;
	    std::cout << "String: " << termData->term << std::endl;
	    std::string str(termData->term);
	    bool is_in = words.find(str) != words.end();

	    if(is_in){
		    std::cout << "Iteration nr: " << counter << ", term " << str << std::endl;
		    entry->iterator->startIteration();

		    while( !entry->iterator->finished() ) {
		      entry->iterator->nextEntry();
		    }
	    	counter++;
	    }else{
	    	std::cout << "No match for iteration " << counter << ", term " << str << std::endl;
	    	counter++;
	    }
	    iter->nextEntry();

/*
	    entry->iterator->startIteration();

	    while( !entry->iterator->finished() ) {
	      entry->iterator->nextEntry();
	    }
	    std::cout << "Iteration nr: " << counter << ", term " << str << std::endl;
  	counter++;
	    iter->nextEntry();
*/
	  }
	  delete iter;
	  r.close();
	  std::cout << "Finished..." << std::endl;
}
