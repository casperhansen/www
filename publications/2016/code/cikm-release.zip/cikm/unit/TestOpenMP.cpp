#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <unordered_map>
#include <map>
#include <time.h>
#include <set>
#include <cmath>
#include <cstring>
#include <limits>
#include <iterator>
#include <iomanip>      // std::setprecision
#include <algorithm>
#include <utility>
#include <ctime>
#include <cctype>
#include "omp.h"

		class DocIDFreq{
		private:
			int DOCID = 0;
			int FREQ  = 0;
			std::string EXT_ID;
		public:
			DocIDFreq();
			DocIDFreq(int docid, int freq, std::string ext_id){
				DOCID  = docid;
				FREQ   = freq;
				EXT_ID = ext_id;
			}
			~DocIDFreq(){};

			int getDocID(){
				return DOCID;
			}

			int getTermFreq(){
				return FREQ;
			}

			std::string getExternalDocID(){
				return EXT_ID;
			}
		};

		class IndexObject {
		private:
			std::string TERM;
			std::vector<DocIDFreq *> VALS;
		public:
			IndexObject();
			IndexObject(const std::string& term, std::vector<DocIDFreq *>& v){
				 TERM = term;
				 VALS = v;
			}
			~IndexObject(){};

			std::string getTerm(){
				return TERM;
			}

			std::vector<DocIDFreq *> getVals(){
				return VALS;
			}
		};

		class QUERYOBJECT {
		private:
			std::string queryid;
			std::vector<std::string> qterms;
			std::string scoreModel;
			unordered_map<std::string, int> queryfreq;
			double score;
			~QUERYOBJECT(){};
		public:
			/* *_query contains the query terms of the specificed query */
			QUERYOBJECT();
			QUERYOBJECT(const std::vector<std::string> _qterms, std::string _queryid, std::string _scoreModel, unordered_map<std::string, int> _queryfreq){
				scoreModel = _scoreModel;
				queryid    = _queryid;
				qterms     = _qterms;
				queryfreq  = _queryfreq;
				score      = 0.0;
			}

			std::string toString(){
				std::string ret = "";
				std::vector<std::string>::iterator it;
				for(it = qterms.begin(); it != qterms.end(); ++it){
					ret = ret + (*it) + " ";
				}
				return ret;
			}

			std::vector<std::string> getQueryTerms(){
				return qterms;
			}

			void setScoreModel(std::string _scoreModel){
				scoreModel = _scoreModel;
			}

			std::string getScoreModel(){
				return scoreModel;
			}

			void setScore(double _score){
				score = _score;
			}

			double getScore(){
				return score;
			}

			std::string getQueryID(){
				return queryid;
			}

			int getQueryTermFrequency(std::string term){
				bool found = queryfreq.find(term) != queryfreq.end();
				if(found){
					return queryfreq[term];
				}
				return -1;
			}
		};

map<std::string, QUERYOBJECT *>               qIDtoQuery;


int main(int argc, char ** argv){

	indri::collection::Repository r;
	//r.openRead( "/data/indexes/nyt_eng/");
	//r.openRead( "/home/casper/indexes/TREC/TREC-8-adhoc/index/latimes" );
	r.openRead( "/home/casper/indexes/TREC/fr88" );

	indri::server::LocalQueryServer local(r);
	UINT64 docCount = local.documentCount();

	vector< QUERYOBJECT * > qIDvec(docCount);

	bool sequential = false;


	/* Load all the documents (queries if we are being honest) into memory */
	std::cout << "Fetching all documents from disk" << std::endl;
	double tStart = clock();
	std::vector<lemur::api::DOCID_T> documentIDs;
	int i;
	for(i = 0; i < docCount; i++){
		lemur::api::DOCID_T documentID = i+1;
		documentIDs.push_back(documentID);
	}

	/* We need this to retrieve the document id i.e. the thing in the <DOCNO> </DOCNO> tags which we assume are set to the query id */
	indri::collection::CompressedCollection* collection = r.collection();


	/* Retrieve the content of the queries (i.e. their terms) */
    indri::server::QueryServerVectorsResponse* response = local.documentVectors( documentIDs );

	double tEnd    = (double)(clock() - tStart)/CLOCKS_PER_SEC;
	std::cout << "Done! (" << tEnd << " seconds)" << std::endl;
	tStart			= clock();


	if(sequential){
		std::cout << "Using sequential approach" << std::endl;
		tStart			= clock();
		std::cout << "Calculating stuff...." << std::endl;
		std::set< std::string > POOLED_QUERYTERMS;
		if( response->getResults().size() ) {
			/* Loop over the queries to reconstruct them and pool their query terms for inverted list retrieval */
			int j;
			for(j = 0; j < docCount; j++){
			    indri::api::DocumentVector* docVector = response->getResults()[j];
			    /* This corresponds to the query id from the TREC query files -- See Assumptions */
			    std::string queryid = collection->retrieveMetadatum( j+1, "docno" );
			    std::vector<std::string  > query;
			    std::set<std::string     > queryTermSeen;
			    std::unordered_map<std::string, int> queryfreq;
			    int k; int ksize = docVector->positions().size();
			    for(k=0; k<ksize; k++ ) {
			    	int position = docVector->positions()[k];
			    	const std::string& stem = docVector->stems()[position];

			    	/* Now we have a stem. Add it to the pool... */
		    		POOLED_QUERYTERMS.insert(stem);
		    		bool seen = queryTermSeen.find(stem) != queryTermSeen.end();
			    	if(!seen){
					  	/*  and to its query - We are not interested in saving repeated terms */
					  	query.push_back(stem);
			    	}
				  	/* but we do want to increment its frequency */
				  	bool found = queryfreq.find(stem) != queryfreq.end();
				  	if(found){
					   queryfreq[stem]++;
				  	}else{
					   queryfreq[stem] = 1;
				  	}
		    		queryTermSeen.insert(stem);
			    }

			    /* Save the query */
			    QUERYOBJECT * q = new QUERYOBJECT(query, queryid, "", queryfreq);

			    /* Indexed by its query id */
			    qIDtoQuery[queryid] = q;

			    delete docVector;
			}

		}
		tEnd    = (double)(clock() - tStart)/CLOCKS_PER_SEC;
		std::cout << "Done! (" << tEnd << " seconds)" << std::endl;
	}else{
		std::cout << "Using concurrent approach" << std::endl;
		tStart			= clock();
		std::cout << "Calculating stuff...." << std::endl;

		std::set< std::string> POOLED_QUERYTERMS;

		if( response->getResults().size() ) {

			/* Loop over the queries to reconstruct them and pool their query terms for inverted list retrieval */
			int j;
			#pragma omp parallel for shared(response, POOLED_QUERYTERMS, collection, qIDvec)
			for(j = 0; j < docCount; j++){
			    indri::api::DocumentVector* docVector = response->getResults()[j];
			    //std::cout << "Retrieved docVector for document " << (j+1) << std::endl;
			    /* This corresponds to the query id from the TREC query files -- See Assumptions */
			    std::string queryid = collection->retrieveMetadatum( j+1, "docno" );
			    //std::cout << "Retrieved Metadatum for document " << (j+1) << std::endl;
			    int k; int ksize    = docVector->positions().size();
			    //std::cout << "Set k and k.size() for document " << (j+1) << std::endl;
			    std::vector< std::string > query(ksize);
			    std::unordered_map<std::string, int> queryfreq;

			    for(k=0; k<ksize; k++ ) {
			    	int position = docVector->positions()[k];
			    	const std::string& stem = docVector->stems()[position];
		    		bool seen = queryfreq.find(stem) != queryfreq.end();
			    	if(!seen){
					  	query.push_back(stem);
			    	}
			    	// Should be ok as it is local
			    	queryfreq[stem]++;
			    }

			    //std::cout << "Before constructing QUERYOBJECT for document " << (j+1) << std::endl;
			    /* Save the query */
			    QUERYOBJECT * q = new QUERYOBJECT(query, queryid, "", queryfreq);
			    //std::cout << "Constructed QUERYOBJECT for document " << (j+1) << std::endl;
			    /* Indexed by its query id */
				//#pragma omp critical
			    //qIDtoQuery[queryid] = q;
			    qIDvec[j] = q;

			    //std::cout << "Inserted QUERYOBJECT into qIDtoQuery for document " << (j+1) << std::endl;
			    delete docVector;
			    //std::cout << "Deleted docVector" << std::endl;
			}
			//std::cout << "Waiting at barrier" << std::endl;
			#pragma omp barrier
		}
		tEnd    = (double)(clock() - tStart)/CLOCKS_PER_SEC;
		std::cout << "qIDvec size: " << qIDvec.size() << std::endl;
		std::cout << "Done! (" << tEnd << " seconds)" << std::endl;

		/*
		double tStart = clock();
		std::vector<indri::server::QueryServerVectorsResponse* > response(docCount);
		#pragma omp parallel for shared(response)
			for(int i=0;i<docCount;i++){
				std::vector<lemur::api::DOCID_T> documentIDs(1);
				documentIDs[0] = i+1;
				response[i] = local.documentVectors(documentIDs);
			}
		double tEnd    = (double)(clock() - tStart)/CLOCKS_PER_SEC;
		std::cout << "Done! (" << tEnd << " seconds)" << std::endl;
		*/

		/* Now pool the query terms (most easily done with a vocabulary iterator)
		 * This is not prohibitly expensive as the query language vocabulary is MUCH smaller
		 * than the collection vocabulary
		 */
		tStart = clock();
		std::cout << "Reading vocabulary..." << std::endl;
		indri::collection::Repository::index_state state = r.indexes();

		indri::index::Index* index = (*state)[0];
		indri::index::VocabularyIterator* iter = index->vocabularyIterator();

		iter->startIteration();
		while( !iter->finished() ) {
		  indri::index::DiskTermData* entry = iter->currentEntry();
		  indri::index::TermData* termData = entry->termData;
		  std::string str(termData->term);
		  POOLED_QUERYTERMS.insert(str);
		  iter->nextEntry();
		}
		tEnd    = (double)(clock() - tStart)/CLOCKS_PER_SEC;
		std::cout << "Done! (" << tEnd << " seconds)" << std::endl;
		delete iter;
	}

	r.close();
	std::cout << "Index closed.... returning" << std::endl;
	return 1;
}
