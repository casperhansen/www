#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <unordered_map>
#include <map>
#include <time.h>
#include <set>
#include <cmath>
#include <cstring>
#include <limits>
#include <iterator>
#include <iomanip>      // std::setprecision
#include <algorithm>
#include <utility>
#include <ctime>
#include <cctype>


int main(int argc, char ** argv){
	indri::collection::Repository r;
	//r.open("/home/casper/indexes/TREC/TREC-8-adhoc/index/trec8-collection-stop-porter");
	r.open(argv[1]);
	indri::collection::Repository::index_state state = r.indexes();
	indri::index::Index* index = (*state)[0];
	indri::thread::ScopedLock( index->iteratorLock() );
	indri::collection::CompressedCollection * collection = r.collection();

	INT64  documentCount = index->documentCount();
	UINT64 colLen 		 = index->termCount();
    double avgDocLength  = colLen / (double)documentCount;
    std::cout << "Avg document length was: " << avgDocLength << std::endl;




      indri::index::VocabularyIterator* iter = index->vocabularyIterator();

      iter->startIteration();
      std::cout << "TOTAL" << " " << index->termCount() << " " << index->documentCount() << std::endl;

      double count = 0.0;
      while( !iter->finished() ) {
        indri::index::DiskTermData* entry = iter->currentEntry();
        indri::index::TermData* termData = entry->termData;
        count += termData->corpus.totalCount;
        iter->nextEntry();
      }
      delete iter;

      double newAvgDocLength = count / (double)documentCount;
      std::cout << "New avg document length was: " << newAvgDocLength << std::endl;
	/*
	  indri::server::LocalQueryServer local(r);
	  lemur::api::DOCID_T documentID = 4;

	  std::vector<lemur::api::DOCID_T> documentIDs;
	  documentIDs.push_back(documentID);

	  indri::server::QueryServerVectorsResponse* response = local.documentVectors( documentIDs );

	  if( response->getResults().size() ) {
	    indri::api::DocumentVector* docVector = response->getResults()[0];

	    std::cout << "--- Fields ---" << std::endl;

	    for( size_t i=0; i<docVector->fields().size(); i++ ) {
	      const indri::api::DocumentVector::Field& field = docVector->fields()[i];
	      std::cout << field.name << " " << field.begin << " " << field.end << " " << field.number << std::endl;
	    }

	    std::cout << "--- Terms ---" << std::endl;

	    for( size_t i=0; i<docVector->positions().size(); i++ ) {
	      int position = docVector->positions()[i];
	      const std::string& stem = docVector->stems()[position];

	      std::cout << i << " " << position << " " << stem << std::endl;
	    }

	    delete docVector;
	  }

	  delete response;
	*/
	r.close();
}
