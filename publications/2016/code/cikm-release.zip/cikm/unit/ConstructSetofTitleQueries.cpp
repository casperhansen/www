/*
 * CreateTitleQueriesFromIndex.cpp
 *
 *  Created on: Dec 20, 2015
 *      Author: casper
 */

#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include "indri/Index.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/Repository.hpp"
#include "indri/Collection.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <stdlib.h>
#include <time.h>
#include <set>
#include <cmath>
#include <cstring>
#include <limits>
#include <iterator>
#include <iomanip>      // std::setprecision
#include <algorithm>
#include <utility>
#include <ctime>
#include <cctype>


void loadQueries(std::string index, std::string fieldString){
	std::set<std::string> qterms;
	indri::collection::Repository r;
	r.openRead( index );

	indri::server::LocalQueryServer local(r);
	UINT64 docCount = local.documentCount();

	/*
	 * Load the queries identified by CVqueries into documentIDs, fetch them and process
	 * them as normal.
	 *
	 * This is not needed if all queries are numbered sequentially i.e. 1,2,3,....,n, but if there
	 * are gaps this is needed.
	 */

	std::vector<lemur::api::DOCID_T> documentIDs;
	int i;
	for(i = 0; i < docCount; i++){
		lemur::api::DOCID_T documentID = i+1;
		documentIDs.push_back(documentID);
	}

	/* We need this to retrieve the document id i.e. the thing in the <DOCNO> </DOCNO> tags which we assume are set to the query id */
	indri::collection::CompressedCollection* collection = r.collection();

	/* Retrieve the content of the queries (i.e. their terms) */
    indri::server::QueryServerVectorsResponse* response = local.documentVectors( documentIDs );
	if( response->getResults().size() ) {
		//std::cout << "getResults.size(): " << response->getResults().size() << std::endl;
		int loopLimit = response->getResults().size();
		/* Loop over the queries to reconstruct them and pool their query terms for inverted list retrieval */
		int j;
		for(j = 0; j < loopLimit; j++){
		    indri::api::DocumentVector* docVector = response->getResults()[j];
		    /* This corresponds to the query id from the TREC query files -- See Assumptions */
		    //std::string queryid = collection->retrieveMetadatum( j+1, "docno" );
		    std::string queryid = collection->retrieveMetadatum( documentIDs.at(j), "docno" );
		    std::vector<std::string  > query;
		    std::set<std::string     > queryTermSeen;
		    std::map<std::string, int> queryfreq;

		    /*
		     * Fetch the start and end indices for the specified field
		     * If a field is not specified (or misspecified) we default to using everything
		     */
		    int fieldstart = 0;
		    int fieldend   = docVector->positions().size();
		    for( size_t i=0; i<docVector->fields().size(); i++ ) {
		      const indri::api::DocumentVector::Field& field = docVector->fields()[i];
		      if(field.name.compare(fieldString) == 0){
		    	  // We have a match
		    	  fieldstart = field.begin;
		    	  fieldend   = field.end;
		    	  break;
		      }
		    }

		    // Loop over query terms
		    int k;
		    std::cout << queryid << ":";
		    for(k=fieldstart; k<fieldend; k++ ) {
		    	int position = docVector->positions()[k];
		    	const std::string& stem = docVector->stems()[position];
		    	if(stem.compare("[OOV]") != 0){
		    		qterms.insert(stem);
		    	}
		    }
		    std::cout << std::endl;

		    delete docVector;
		}
	}
	delete response;
	r.close();

	std::set<std::string>::iterator it;
	for(it = qterms.begin(); it != qterms.end(); ++it){
		std::cout << *it << std::endl;
	}
	std::cout << "Number of query terms: " << qterms.size() << std::endl;
}


int main(int argc, char ** argv){
	loadQueries(argv[1], "title");
	return 1;
}
