/*
 * Write.cpp
 *
 * CHANGELOG:
 * 23-06-2015: Created
 * 05-09-2015: Added code to remove leading 0's from query IDs (see example further down the code)
 *
 * Casper Petersen
 */
#include "../include/aux.hpp"
#include "../include/Write.hpp"
#include "../include/PConfig.hpp"
#include "../include/easylogging++.h"


void TRECResults::write(std::map<std::string, std::multimap<float, std::string> > results, const char * loc, int cutoff, std::string runid){
/*
	// Check for cutoff
	bool with_cutoff = false;
	if(cutoff >= 1){
		with_cutoff = true;
	}

	ofstream wfile;
	wfile.open(loc);

	// Begin writing
	std::cout << "Writing scored results to " << loc << std::endl;
	LOG(INFO) << "Writing scored results to " << loc;
	double tStart = clock();
	std::map< std::string, std::multimap<double, std::string> >::iterator it;
	for(it = results.begin(); it != results.end(); ++it){
		// Use reverse iterator to print the results in the correct order (from high probability to low)
		std::multimap<double, std::string>::reverse_iterator iter;
		int place = 1;
		for(iter = it->second.rbegin(); iter != it->second.rend(); ++iter){
			if(with_cutoff){
			   if(place > cutoff){break;}
			}
			wfile << it->first << " " << "Q0" << " " << iter->second << " " << place << " " << iter->first << " " << runid << std::endl;
			place++;
		}
	}
	wfile.flush();
	double tEnd    = (double)(clock() - tStart)/CLOCKS_PER_SEC;
	std::cout << "Done! (" << tEnd << " seconds)" << std::endl;
	LOG(INFO) << "Done! (" << tEnd << " seconds)";
	// End writing
	wfile.close();
*/
}



bool TRECResults::write(std::vector<std::pair<std::string, std::multimap<float, std::string> > > * results, const char * loc, int cutoff, std::string runid){
	/* Check for cutoff */
	bool with_cutoff = false;
	if(cutoff >= 1){
		with_cutoff = true;
	}

	bool wrote = false;
	ofstream wfile;
	wfile.open(loc);

	/* Begin writing */
	std::cout << "Writing scored results to " << loc << std::endl;
	LOG(INFO) << "Writing scored results to " << loc;
	double tStart = clock();
	std::vector<std::pair<std::string, std::multimap<float, std::string> > >::iterator it;

	// Some testing
	std::multimap<float, std::string>::reverse_iterator iter;
	for(it = results->begin(); it != results->end(); ++it){
		/* Use reverse iterator to print the results in the correct order (from high probability to low) */

		/*
		 * We need to check if the query id is -1 and filter it out. A query id is -1 if none of the terms in the query could be scored.
		 * See Score::parscore
		 *
		 * This is ONLY necessary for the vector version coming from the parallel code. The other uses a map that, by default, only inserts what
		 * it has not seen and thus there is no "empty" holes in the initialized data structure
		 */

		std::string query = (*it).first;
		if(query.compare("-1") == 0){continue;}

		int place = 1;
		for(iter = (*it).second.rbegin(); iter != (*it).second.rend(); ++iter){
			if(with_cutoff){
			   if(place > cutoff){break;}
			}
			wrote = true;
			/*
			 * There IS  an issue
			 * Consider the file: /home/casper/indexes/TREC/TREC-123-adhoc/queries/topics.51-100
			 * Notice that the query ID is given as 051
			 *
			 * Now consider the qrels file: /home/casper/indexes/TREC/TREC-123-adhoc/qrels/qrels.51-100.disk1.disk2.part1
			 * where the query ID is /not/ prefixed by 0.
			 *
			 * EXPERIMENTS CONFIRM THIS IS NOT CORRECTED BY TREC_EVAL! and hence will return a wrong score.
			 * We correct this by removing leading 0's from a query ID string before writing to disk.
			 *
			 *
			 */
 			// THIS IS UNCOMMENTED FOR ISEARCH!!!
//			if(query.compare(0, 1, "0") == 0){
//				query = query.erase(0,1);
//			}
			wfile << query << " " << "Q0" << " " << iter->second << " " << place << " " << iter->first << " " << runid << std::endl;
			place++;
		}
	}
	double tEnd    = (double)(clock() - tStart)/CLOCKS_PER_SEC;

	/* End writing */
	wfile.flush();
	wfile.close();
	std::cout << "Done! (" << tEnd << " seconds)" << std::endl;
	LOG(INFO) << "Done! (" << tEnd << " seconds)";
	return wrote;
}
