/*
 * The purpose of this class is to expand each query using a tf-idf
 *
 *  Created on: Jun 29, 2015
 *      Author: Casper Petersen
 */

#include "../include/QExp.hpp"
#include "../include/aux.hpp"



std::string QExp::expand(std::string& index, std::string query){
	// Retrieve the top-k documents
	std::vector<int> docids = retrieve(index, query);

	// Pass to the expander and return
	return tfidf(index,query,docids);
}

std::unordered_map<std::string, int> documentFrequency(std::string& index, std::vector<int> docids){
	// Need access to the QueryEnvironment
	indri::api::QueryEnvironment qe;
	qe.addIndex(index);

	// Need access to the collection as well
	indri::collection::Repository r;
    r.open(index);

    // Retrieve the documents
    indri::server::LocalQueryServer local(r);
    indri::server::QueryServerVectorsResponse* response = local.documentVectors( docids );

    std::unordered_map<std::string,int> hist;
    size_t resSize = response->getResults().size();

    // Treat all documents as one big document
   	for(size_t j = 0; j < resSize; j++){
		indri::api::DocumentVector* docVector = response->getResults()[j];
		size_t dvSize = docVector->positions().size();
		for( size_t i=0; i<dvSize; i++ ) {
			int position = docVector->positions()[i];
			const std::string& stem = docVector->stems()[position];
			bool seen = hist.find(stem) != hist.end();
			bool badTerm = stem.compare("[OOV]") == 0;
			if(!badTerm){
				if(seen){
					hist[stem]++;
				}else{
					hist[stem] = 1;
				}
			}
		}
		delete docVector;
   	}
   r.close();
   delete response;
   return hist;
}


std::string QExp::tfidf(std::string& index, std::string query, std::vector<int> docids){
	std::cout << "Expanding..." << std::endl;
	std::unordered_map<std::string,int> hist = documentFrequency(index, docids);
	double tStart = clock();
	indri::api::QueryEnvironment qe;
	qe.addIndex(index);
	double docCount = (double)qe.documentCount();
	std::unordered_map<std::string,int>::iterator it;
	std::map<double, std::string> scores;
	for(it = hist.begin(); it != hist.end(); ++it){
		double stemcount = (double)qe.documentCount( it->first );
		double tfidf     = it->second * log(docCount/(1 + stemcount)); // 1+ to avoid division by 0
		scores[tfidf]    = it->first;
	}

	// Maps are sorted by keys in ascending order so need to use reverse iterator
	int counter = 1;
	std::map<double, std::string>::reverse_iterator rit;
	for(rit = scores.rbegin(); rit != scores.rend(); ++rit){
		if(counter > 10){
			break;
		}
		query.append(" ").append(rit->second);
		counter++;
	}
	double tEnd    = (double)(clock() - tStart)/CLOCKS_PER_SEC;
	std::cout << "Done! (" << tEnd << " seconds)" << std::endl;
	std::cout << std::endl;
	return query;
}


std::vector<int> QExp::retrieve(std::string& index, std::string query){
	std::cout << "Retrieving..." << std::endl;
	double tStart = clock();
	indri::api::QueryEnvironment qe;
	// Add the indexes that we retrieve from. This will almost certain be a one-sized vector
	qe.addIndex(index);
	// Run and retrieve documents. We use standard Indri query language model
	std::vector<indri::api::ScoredExtentResult> results = qe.runQuery(query, 10, "indri");
	std::vector<int> docids;
	for( size_t i=0; i<results.size(); i++ ) {
		docids.push_back(results[i].document);
	}
	double tEnd    = (double)(clock() - tStart)/CLOCKS_PER_SEC;
	std::cout << "Done! (" << tEnd << " seconds)" << std::endl;
	std::cout << std::endl;
	return docids;
}




