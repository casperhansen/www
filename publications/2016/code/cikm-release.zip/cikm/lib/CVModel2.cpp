/*
 * CVModel.cpp
 *
 *  Created on: Aug 28, 2015
 *      Author: Casper
 */
#include "../include/CVModel2.hpp"
#include "../include/CV.hpp"
#include <random>
std::string PERFORMANCE_MEASURE2;


map<std::string, double> doscore2(Score * s, PConfig & c, FOLD f){
	TRECResults * r;
	TrecEval    * t;

	s->parscore(c);
	/* Write the results */
	bool res = r->write(s->getScoredVecQueriesPointer(), c.getRetrievalResults().c_str(), c.getCutoff(), "description");

	/* Evaluate the results */
	std::map<std::string, double> vvv;

	if(res){
		return (t->evaluate(c.getQrelsLoc(), c.getRetrievalResults()));
	}

	vvv[MAP]     = 0.0;
	vvv[MRR]     = 0.0;
	vvv[PATTEN]  = 0.0;
	vvv[NDCG]    = 0.0;
	vvv[NDCGTEN] = 0.0;
	std::cerr << "*************************************'" << std::endl;
	std::cerr << "* Some iteration was not successful *'" << std::endl;
	std::cerr << "*************************************'" << std::endl;
	return ( vvv );
}

void optim2(Score * s, const CVFOLDS folds, PConfig & c, CVFOLDS f, const int NOFFOLDS){

	vector<double> parms;
	parms.push_back(  c.getFirstParameter()  );
	parms.push_back(  c.getSecondParameter() );
	parms.push_back(  c.getThirdParameter()  );


	s->setScoreModel(c.getModel(), parms);
	//std::cout << "Number of parameters: " << s->getNofScoreModelParameters() << std::endl;
	RESULT r;
	int foldcounter = 1;
	CVFOLDS::iterator it;
	for(it = f.begin(); it != f.end(); ++it){

		/* Get training fold */
		std::vector<std::string> trainfold = it->second->getFold();

		/* Load queries and their inverted lists for training */
		s->loadCVQueries(c.getQueryIndex(), c.getQueryField(), trainfold);
		s->loadInvertedIndex(c.getCollectionIndex(), c.getLaplaceNorm(), c.getBm25Norm(), c.getModelToEstimate());

		/* Get the parameters of the highest-performing training is used for testing */
		std::cout << "************************************************" << std::endl;
		std::cout << "*             Starting training fold " << foldcounter       << "         *" << std::endl;
		std::cout << "************************************************" << std::endl;
		map<std::string, double> ptrain  = doscore2(s, c, trainfold);
		std::cerr << "************************************************" << std::endl;
		std::cerr << "* " << idx::printTime() <<"       Completed training fold " << foldcounter      << "        *" << std::endl;
		std::cerr << "************************************************" << std::endl;

		/* Update model parameters to the best ones */
		s->updateScoreModelParameters(parms);

		/* Evaluate on test fold */
		std::vector<std::string> testfold = it->first->getFold();
		s->cleanup();
		/* Load test fold queries and their inverted lists */
		s->loadCVQueries(c.getQueryIndex(), c.getQueryField(), testfold);
		s->loadInvertedIndex(c.getCollectionIndex(), c.getLaplaceNorm(), c.getBm25Norm(), c.getModelToEstimate());

		std::cout << "************************************************" << std::endl;
		std::cout << "*             Starting testing fold " << foldcounter       << "          *" << std::endl;
		std::cout << "************************************************" << std::endl;
		std::cout << "Starting testing fold using parameter: "          << std::endl;
		std::cout << std::endl;
		map<std::string, double> pbest  = doscore2(s, c, testfold);
		r.push_back( pbest[PERFORMANCE_MEASURE2] );

		std::cout << "************************************************" << std::endl;
		std::cout << "*             Completed testing fold " << foldcounter       << "         *" << std::endl;
		std::cout << "************************************************" << std::endl;
		std::cout << "*             Best MAP....: " << pbest[MAP]       << std::endl;
		std::cout << "*             Best MRR....: " << pbest[MRR]       << std::endl;
		std::cout << "*             Best P@10...: " << pbest[PATTEN]    << std::endl;
		std::cout << "*             Best NDCG...: " << pbest[NDCG]      << std::endl;
		std::cout << "*             Best NDCG@10: " << pbest[NDCGTEN]   << std::endl;
		std::cout << "************************************************" << std::endl;
		std::cout << std::endl;
		std::cout << std::endl;
		s->cleanup();
		foldcounter++;
	}
	std::cout << "************************************************" << std::endl;
	std::cout << "*          COMPLETED ALL TRAINING FOLDS        *" << std::endl;
	std::cout << "*                PRINTING RESULTS              *" << std::endl;
	std::cout << "************************************************" << std::endl;
	std::vector<double>::iterator itr;
	int testfoldcounter = 1;
	for(itr = r.begin(); itr != r.end(); ++itr){
		std::cout << "Value of " << PERFORMANCE_MEASURE2 << " for test-fold " << testfoldcounter << " was: " << (*itr) << std::endl;
		testfoldcounter++;
	}
	double avgPerformance = std::accumulate(r.begin(), r.end(), 0.0) / r.size();
	std::cout << "Average "<< PERFORMANCE_MEASURE2 << " value across " << (testfoldcounter-1) << " folds: " << avgPerformance << std::endl;
	std::cout << std::endl;
}


void CVModel2::doCV(Score * s, PConfig c, int NOFFOLDS){
	/* Get the performance measure to optimize for */
	PERFORMANCE_MEASURE2 = c.getPerformanceMeasure();
	std::set<std::string> PMEASURES = {MAP,MRR,PATTEN,NDCG,NDCGTEN};
	bool no_in = PMEASURES.find(PERFORMANCE_MEASURE2) == PMEASURES.end();
	if(no_in){
		std::cerr << "CVModel2 :: Performance measure " << PERFORMANCE_MEASURE2 << " not valid. Exiting..." << std::endl;
		exit(EXIT_FAILURE);
	}
	vector<double> parms;
	parms.push_back(  c.getFirstParameter()  );
	parms.push_back(  c.getSecondParameter() );
	parms.push_back(  c.getThirdParameter()  );

	s->setScoreModel(c.getModel(), parms);
	s->loadQueries(c.getQueryIndex(), c.getQueryField());
	s->loadInvertedIndex(c.getCollectionIndex(), c.getLaplaceNorm(), c.getBm25Norm(), c.getModelToEstimate());


	TRECResults * r;
	TrecEval    * t;

	s->parscore(c);
	/* Write the results */
	bool res = r->write(s->getScoredVecQueriesPointer(), c.getRetrievalResults().c_str(), c.getCutoff(), "description");

	/* Evaluate the results */
	std::map<std::string, double> vvv;

	vvv = t->evaluate(c.getQrelsLoc(), c.getRetrievalResults());

	std::map<std::string, double>::iterator itr;
	for(itr = vvv.begin(); itr != vvv.end(); ++itr){
		std::cout << itr->first << ", " << itr->second << std::endl;
	}
}
