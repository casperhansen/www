/*
 * Score.cpp
 *
 *
 * Assumptions:
 * 1 - We have INDEXED the queries. This has the advantage that as long as we index them identical to the documents,
 * we do not need to process them further in the program.
 * The <DOCNO></DOCNO> tag MUST contain the queryid and we assume strictly TREC formatted indexed documents/queries.
 *
 * Example:
 * <DOC>
 * <DOCNO>123</DOCNO>
 * <fieldA>
 * qt_1,...,qt_n
 * </fieldA>
 * <fieldB>
 * qt_1,...,qt_m
 * </fieldB>
 * <fieldC>
 * * qt_1,...,qt_k
 * </fieldC>
 * </DOC>
 *
 * The field corresponds to e.g. title, description and narrative. If no field are specified (i.e. the empty string
 * is given), we default to using everything e.g.\ qt_1,...,qt_n,qt_1,...,qt_m,qt_1,...qt_k
 *
 * This means that when indexing the queries you must specify, in the Indri parameter file, the fields.
 *
 * Purpose:
 * 1 - Retrieve the inverted lists of the queries
 *   -> (1) Create set of all query terms and retrieve using idx::getInvLists
 * 2 - Score each query by accumulating partial scores for each query term for a specific query
 *
 *
  * Changelog:
 * 02-07-2015: Added the omp.h header for OpenMP parallelization. Trying to parallelize for-loops for score
 *
 *  Created on: June 19, 2015
 *      Author: Casper Petersen, Ph.D Student
 *
 */
#include "../include/ScoreModel.hpp"
#include "../include/aux.hpp"
#include "../include/Score.hpp"
#include "../include/easylogging++.h"
#include "../include/PConfig.hpp"
#include "omp.h"
#include <tuple>


std::set< std::string > 						                          POOLED_QUERYTERMS;
std::vector< std::string > 						                          POOLED_QUERYTERMS_VEC;
map<std::string, idx::QUERYOBJECT *>                                      qIDtoQuery;
std::unordered_map<std::string, vector<idx::DocIDFreq * >>                INVINDEX;
std::unordered_map<std::string, std::tuple<unsigned int, unsigned int, std::vector<double> > > TERM_ELITE_SET_STATS;
std::unordered_map<std::string, std::string > INTERNAL_TO_EXTERNAL_QUERY_ID;
std::map<std::string, std::vector<double> > PARAMETERS;
std::map<std::string, std::multimap<float, std::string> >                SCORED_QUERIES;
std::vector<std::pair<std::string, std::multimap<float, std::string> > > SCORED_QUERIES_PAR;
std::vector<std::pair<std::string, std::multimap<float, std::string> > > * SCORED_QUERIES_PAR_POINTER;
std::map<double,double>                                                   rr;
std::set<std::string>                                                     NON_INFORMATIVE_TERMS;
std::set<std::string> STOP_WORDS;
ScoreModelsFactory smf;
std::string SCOREMODELNAME;
ScoreModel * SCOREMODEL;
double DOCUMENTS_IN_COLLECTION; // Number of documents in index
typedef std::vector<std::string> QUERYTERMS;
typedef std::string QUERYTERM;

/*
 * Loads the queries from index.
 *
 * All queries are located in an Indri index. This is a "slow" way of doing it but the TREC query files are
 * small so there is no performance impact.
 *
 * Input:
 * index - The INDRI index of the queries
 * fieldString - The field of the indexed queries to use for retrieval. Do not use <>. The name will do.
 * 				 To get the name use dumpindex on the index and look for fields.
 * DEBUG_LEVEL - The level of debugging to use. Default off (0).
 *
 */

bool invalidChar (char c){
    return !(c >= 0 && c < 128);
}

std::string trim(const std::string& str,
                 const std::string& whitespace = " \t"){
    const unsigned long int strBegin = str.find_first_not_of(whitespace);
    if (strBegin == std::string::npos)
        return ""; // no content

    const unsigned long int strEnd = str.find_last_not_of(whitespace);
    const unsigned long int strRange = strEnd - strBegin + 1;

    return str.substr(strBegin, strRange);
}


std::string reduce(const std::string& str){
	const std::string& fill = " ";
	const std::string& whitespace = " \t";
    // trim first
    std::string result = trim(str, whitespace);

    // replace sub ranges
    unsigned long int beginSpace = result.find_first_of(whitespace);
    while (beginSpace != std::string::npos)
    {
    	const unsigned long int endSpace = result.find_first_not_of(whitespace, beginSpace);
    	const unsigned long int range = endSpace - beginSpace;

        result.replace(beginSpace, range, fill);

        const unsigned long int newStart = beginSpace + fill.length();
        beginSpace = result.find_first_of(whitespace, newStart);
    }
    return result;
}

void fixString(std::string& str){
	str.erase(std::remove(str.begin(), str.end(), '\n'), str.end());
	str.erase(std::remove(str.begin(), str.end(), '\r'), str.end());
	std::transform(str.begin(), str.end(), str.begin(), ::tolower);
	str.erase(std::remove_if(str.begin(),str.end(), invalidChar), str.end());
	str = reduce(str);
}


void Score::loadListOfNonInformativeWords(const char * filename){
	  std::string line;
	  std::ifstream myfile (filename);
	  int our_querycounter,r_querycounter,linecounter = 0;
	  if (myfile.is_open()){
		  while (getline (myfile,line)) {
			  fixString(line);
			  NON_INFORMATIVE_TERMS.insert(line);
			  linecounter++;
		  }
		  myfile.close();
	  }else{
		  cout << "Unable to open file" << endl;
		  exit(EXIT_FAILURE);
	  }
	  std::cout << "Read " << linecounter << " non-informative words from " << filename << std::endl;
}

void loadStopWords(std::string stopwordlist){
		  std::string line;
		  std::ifstream myfile (stopwordlist.c_str());
		  int linecounter = 0;
		  if (myfile.is_open()){
			  while (getline (myfile,line)) {
				  STOP_WORDS.insert(line);
				  linecounter++;
			  }
			  myfile.close();
		  }else{
			  cout << "Unable to open file" << endl;
			  exit(EXIT_FAILURE);
		  }
		  std::cout << "Loaded stopwords from " << stopwordlist << " (" << linecounter << ")" << std::endl;
}

void Score::loadQueries(std::string index, std::string fieldString){
	qIDtoQuery.clear();
	POOLED_QUERYTERMS.clear();

	indri::collection::Repository r;
	r.openRead( index );

	indri::server::LocalQueryServer local(r);
	UINT64 docCount = local.documentCount();

	/*
	 * Load the queries identified by CVqueries into documentIDs, fetch them and process
	 * them as normal.
	 *
	 * This is not needed if all queries are numbered sequentially i.e. 1,2,3,....,n, but if there
	 * are gaps this is needed.
	 */

	std::vector<lemur::api::DOCID_T> documentIDs;
	int i;
	for(i = 0; i < docCount; i++){
		lemur::api::DOCID_T documentID = i+1;
		documentIDs.push_back(documentID);
	}

	/* We need this to retrieve the document id i.e. the thing in the <DOCNO> </DOCNO> tags which we assume are set to the query id */
	indri::collection::CompressedCollection* collection = r.collection();

	/* Retrieve the content of the queries (i.e. their terms) */
    indri::server::QueryServerVectorsResponse* response = local.documentVectors( documentIDs );
	double tStart = clock();
	if( response->getResults().size() ) {
		//std::cout << "getResults.size(): " << response->getResults().size() << std::endl;
		int loopLimit = response->getResults().size();
		/* Loop over the queries to reconstruct them and pool their query terms for inverted list retrieval */
		int j;
		for(j = 0; j < loopLimit; j++){
		    indri::api::DocumentVector* docVector = response->getResults()[j];
		    /* This corresponds to the query id from the TREC query files -- See Assumptions */
		    //std::string queryid = collection->retrieveMetadatum( j+1, "docno" );
		    std::string queryid = collection->retrieveMetadatum( documentIDs.at(j), "docno" );
		    INTERNAL_TO_EXTERNAL_QUERY_ID[std::to_string(j+1)] = queryid;

		    std::vector<std::string  > query;
		    std::set<std::string     > queryTermSeen;
		    std::map<std::string, int> queryfreq;

		    /*
		     * Fetch the start and end indices for the specified field
		     * If a field is not specified (or misspecified) we default to using everything
		     */
		    int fieldstart = 0;
		    int fieldend   = docVector->positions().size();
		    for( size_t i=0; i<docVector->fields().size(); i++ ) {
		      const indri::api::DocumentVector::Field& field = docVector->fields()[i];
		      if(field.name.compare(fieldString) == 0){
		    	  // We have a match
		    	  fieldstart = field.begin;
		    	  fieldend   = field.end;
		    	  break;
		      }
		    }

		    // Loop over query terms
		    int k;
		    for(k=fieldstart; k<fieldend; k++ ) {
		    	int position = docVector->positions()[k];
		    	const std::string& stem = docVector->stems()[position];
		    	//std::cout << "Stem: " << stem << std::endl;
		    	if(stem.compare("[OOV]") != 0){
/*
		    		if(!NON_INFORMATIVE_TERMS.empty()){
		    			if(NON_INFORMATIVE_TERMS.find(stem) != NON_INFORMATIVE_TERMS.end()){
		    				// The query term is a non-informative term
		    				continue;
		    			}
		    		}
*/
					/* Now we have a stem. Add it to the pool... */
					POOLED_QUERYTERMS.insert(stem);

					bool seen = queryTermSeen.find(stem) != queryTermSeen.end();
					if(!seen){
						/*  And to its query - We are not interested in saving repeated terms */
						query.push_back(stem);
					}
					/* but we do want to increment its frequency */
					bool found = queryfreq.find(stem) != queryfreq.end();
					if(found){
					   queryfreq[stem]++;
					}else{
					   queryfreq[stem] = 1;
					}
					/* And insert it into the set of terms seen for this query */
					queryTermSeen.insert(stem);
		    	}
		    }
		    /* Save the query */
		    idx::QUERYOBJECT * q = new idx::QUERYOBJECT(query, queryid, SCOREMODELNAME, queryfreq);
		    /* Indexed by its query id */
		    qIDtoQuery[queryid] = q;

		    delete docVector;
		}
	}
	delete response;
	r.close();
	double tEnd    = (double)(clock() - tStart)/CLOCKS_PER_SEC;
	std::cout << "Done! (" << tEnd << " seconds)" << std::endl;
}

void Score::loadQueriesWStopwords(std::string index, std::string fieldString, std::string stopwordfile){
	qIDtoQuery.clear();
	POOLED_QUERYTERMS.clear();

	indri::collection::Repository r;
	r.openRead( index );

	indri::server::LocalQueryServer local(r);
	UINT64 docCount = local.documentCount();

	/*
	 * Load the queries identified by CVqueries into documentIDs, fetch them and process
	 * them as normal.
	 *
	 * This is not needed if all queries are numbered sequentially i.e. 1,2,3,....,n, but if there
	 * are gaps this is needed.
	 */
	loadStopWords(stopwordfile);
	std::vector<lemur::api::DOCID_T> documentIDs;
	int i;
	for(i = 0; i < docCount; i++){
		lemur::api::DOCID_T documentID = i+1;
		documentIDs.push_back(documentID);
	}

	/* We need this to retrieve the document id i.e. the thing in the <DOCNO> </DOCNO> tags which we assume are set to the query id */
	indri::collection::CompressedCollection* collection = r.collection();
	int badwords = 0;
	/* Retrieve the content of the queries (i.e. their terms) */
    indri::server::QueryServerVectorsResponse* response = local.documentVectors( documentIDs );
	double tStart = clock();
	if( response->getResults().size() ) {
		//std::cout << "getResults.size(): " << response->getResults().size() << std::endl;
		int loopLimit = response->getResults().size();
		/* Loop over the queries to reconstruct them and pool their query terms for inverted list retrieval */
		int j;
		for(j = 0; j < loopLimit; j++){
		    indri::api::DocumentVector* docVector = response->getResults()[j];
		    /* This corresponds to the query id from the TREC query files -- See Assumptions */
		    //std::string queryid = collection->retrieveMetadatum( j+1, "docno" );
		    std::string queryid = collection->retrieveMetadatum( documentIDs.at(j), "docno" );
		    INTERNAL_TO_EXTERNAL_QUERY_ID[std::to_string(j+1)] = queryid;
		    std::vector<std::string  > query;
		    std::set<std::string     > queryTermSeen;
		    std::map<std::string, int> queryfreq;

		    /*
		     * Fetch the start and end indices for the specified field
		     * If a field is not specified (or misspecified) we default to using everything
		     */
		    int fieldstart = 0;
		    int fieldend   = docVector->positions().size();
		    for( size_t i=0; i<docVector->fields().size(); i++ ) {
		      const indri::api::DocumentVector::Field& field = docVector->fields()[i];
		      if(field.name.compare(fieldString) == 0){
		    	  // We have a match
		    	  fieldstart = field.begin;
		    	  fieldend   = field.end;
		    	  break;
		      }
		    }

		    // Loop over query terms
		    int k;
		    for(k=fieldstart; k<fieldend; k++ ) {
		    	int position = docVector->positions()[k];
		    	const std::string& stem = docVector->stems()[position];
		    	//std::cout << "Stem: " << stem << std::endl;
		    	bool is_not_stopword = STOP_WORDS.find(stem) == STOP_WORDS.end();
		    	if(stem.compare("[OOV]") != 0 && is_not_stopword){
/*
		    		if(!NON_INFORMATIVE_TERMS.empty()){
		    			if(NON_INFORMATIVE_TERMS.find(stem) != NON_INFORMATIVE_TERMS.end()){
		    				// The query term is a non-informative term
		    				continue;
		    			}
		    		}
*/
					/* Now we have a stem. Add it to the pool... */
					POOLED_QUERYTERMS.insert(stem);

					bool seen = queryTermSeen.find(stem) != queryTermSeen.end();
					if(!seen){
						/*  And to its query - We are not interested in saving repeated terms */
						query.push_back(stem);
					}
					/* but we do want to increment its frequency */
					bool found = queryfreq.find(stem) != queryfreq.end();
					if(found){
					   queryfreq[stem]++;
					}else{
					   queryfreq[stem] = 1;
					}
					/* And insert it into the set of terms seen for this query */
					queryTermSeen.insert(stem);
		    	}else{
		    		badwords++;
		    	}
		    }
		    /* Save the query */
		    idx::QUERYOBJECT * q = new idx::QUERYOBJECT(query, queryid, SCOREMODELNAME, queryfreq);
		    /* Indexed by its query id */
		    qIDtoQuery[queryid] = q;

		    delete docVector;
		}
	}
	delete response;
	r.close();
	double tEnd    = (double)(clock() - tStart)/CLOCKS_PER_SEC;
	std::cout << "Loaded " << POOLED_QUERYTERMS.size() << " query terms" << std::endl;
	std::cout << badwords << " stop words were removed!" << std::endl;
	std::cout << "Done! (" << tEnd << " seconds)" << std::endl;
}


void Score::init(std::string coll){
	idx::calcDocLengths(coll);
}

void Score::loadCVQueries(std::string index, std::string fieldString, std::vector<std::string> CVqueries){
	// Start by clearing out qIDtoQuery and POOLED_QUERYTERMS (as we are looping over folds)
	qIDtoQuery.clear();
	POOLED_QUERYTERMS.clear();

	indri::collection::Repository r;
	r.openRead( index );

	indri::server::LocalQueryServer local(r);
	UINT64 docCount = local.documentCount();

	std::cout << "Loading " << CVqueries.size() << " " << fieldString << " queries" << std::endl;
/*
	std::vector<std::string>::iterator il;
	for(il = CVqueries.begin(); il != CVqueries.end(); ++il){
		std::cout << (*il) << std::endl;
	}
*/
	/*
	 * Load the queries identified by CVqueries into documentIDs, fetch them and process
	 * them as normal.
	 *
	 * This is not needed if all queries are numbered sequentially i.e. 1,2,3,....,n, but if there
	 * are gaps this is needed.
	 */
	std::vector<lemur::api::DOCID_T> documentIDs;
	int i;
	for(i = 0; i < docCount; i++){
		std::string _id = std::to_string((i+1));

		if(std::find(CVqueries.begin(), CVqueries.end(), _id) != CVqueries.end()){
			lemur::api::DOCID_T documentID = i+1;
			documentIDs.push_back(documentID);
			//std::cout << "Pushing back query " << documentID << " id" << std::endl;
		}
	}

	/* We need this to retrieve the document id i.e. the thing in the <DOCNO> </DOCNO> tags which we assume are set to the query id */
	indri::collection::CompressedCollection* collection = r.collection();

	/* Retrieve the content of the queries (i.e. their terms) */
    indri::server::QueryServerVectorsResponse* response = local.documentVectors( documentIDs );
	double tStart = clock();
	if( response->getResults().size() ) {
		//std::cout << "getResults.size(): " << response->getResults().size() << std::endl;
		int loopLimit = response->getResults().size();
		/* Loop over the queries to reconstruct them and pool their query terms for inverted list retrieval */
		int j;
		for(j = 0; j < loopLimit; j++){
		    indri::api::DocumentVector* docVector = response->getResults()[j];
		    /* This corresponds to the query id from the TREC query files -- See Assumptions */
		    //std::string queryid = collection->retrieveMetadatum( j+1, "docno" );
		    std::string queryid = collection->retrieveMetadatum( documentIDs.at(j), "docno" );
		    std::vector<std::string  > query;
		    std::set<std::string     > queryTermSeen;
		    std::map<std::string, int> queryfreq;

		    /*
		     * Fetch the start and end indices for the specified field
		     * If a field is not specified (or misspecified) we default to using everything
		     */
		    int fieldstart = 0;
		    int fieldend   = docVector->positions().size();
		    for( size_t i=0; i<docVector->fields().size(); i++ ) {
		      const indri::api::DocumentVector::Field& field = docVector->fields()[i];
		      if(field.name.compare(fieldString) == 0){
		    	  // We have a match
		    	  fieldstart = field.begin;
		    	  fieldend   = field.end;
		    	  break;
		      }
		    }

		    // Loop over query terms
		    int k;
		    for(k=fieldstart; k<fieldend; k++ ) {
		    	int position = docVector->positions()[k];
		    	const std::string& stem = docVector->stems()[position];
		    	if(stem.compare("[OOV]") != 0){

					/* Now we have a stem. Add it to the pool... */
					POOLED_QUERYTERMS.insert(stem);

					bool seen = queryTermSeen.find(stem) != queryTermSeen.end();
					if(!seen){
						/*  And to its query - We are not interested in saving repeated terms */
						query.push_back(stem);
					}
					/* but we do want to increment its frequency */
					bool found = queryfreq.find(stem) != queryfreq.end();
					if(found){
					   queryfreq[stem]++;
					}else{
					   queryfreq[stem] = 1;
					}
					/* And insert it into the set of terms seen for this query */
					queryTermSeen.insert(stem);
		    	}
		    }
		    /* Save the query */
		    idx::QUERYOBJECT * q = new idx::QUERYOBJECT(query, queryid, SCOREMODELNAME, queryfreq);
		    /* Indexed by its query id */
		    //std::cout << "Query saved: " << queryid << std::endl;
		    qIDtoQuery[queryid] = q;

		    delete docVector;
		}
		std::cout << "Parsed all queries" << std::endl;
	}
	delete response;
	r.close();
	double tEnd    = (double)(clock() - tStart)/CLOCKS_PER_SEC;
	std::cout << "Done! (" << tEnd << " seconds)" << std::endl;
}

/*
 * Retrieves the inverted lists of the query terms.
 * Each inverted list is vector<idx::DocIDFreq *> indexed by the query term.
 * Each idx::DocIDFreq contains the document id and the frequency of the query term in that document id
 *
 * This is faster than retrieving the documents first
 */
void Score::loadInvertedIndex(std::string index, double c, double b, std::string modelest){
	indri::collection::Repository r;
	r.openRead( index );
	indri::server::LocalQueryServer local(r);
	DOCUMENTS_IN_COLLECTION = (double)local.documentCount();
	//idx::getInvLists(r, POOLED_QUERYTERMS, c, b, INVINDEX, TERM_ELITE_SET_STATS, modelest);
	idx::getInvLists2(r, POOLED_QUERYTERMS, INVINDEX, TERM_ELITE_SET_STATS, modelest);
	r.close();
}

/*
 * This function calls the ScoreModelFactory to create the score model used.
 *
 * Call this before loadQueries
 */
void Score::setScoreModel(std::string smname, std::vector<double> parms){
	SCOREMODEL     = smf.getScoreModel(smname, parms);
	SCOREMODELNAME = smname;
}

void Score::parscore(PConfig & c){

}

void Score::cleanup(){
	POOLED_QUERYTERMS.clear();
	qIDtoQuery.clear();
	INVINDEX.clear();
	SCORED_QUERIES_PAR.clear();
}

std::map<std::string, std::multimap<float, std::string> > Score::getScoredQueries(){
	return SCORED_QUERIES;
}

std::vector<std::pair<std::string, std::multimap<float, std::string> > > Score::getScoredVecQueries(){
	return SCORED_QUERIES_PAR;
}

std::vector<std::pair<std::string, std::multimap<float, std::string> > > * Score::getScoredVecQueriesPointer(){
	return SCORED_QUERIES_PAR_POINTER;
}


std::set< std::string > Score::getPooledQueryTerms(){
	return POOLED_QUERYTERMS;
}

map<std::string, idx::QUERYOBJECT *> Score::getQueryRep(){
	return qIDtoQuery;
}

/*
std::unordered_map<std::string, vector<idx::DocIDFreq *> > Score::getQTermsInvLists(){
	return INVINDEX;
}
*/
/*
 * Print the scores in TREC_EVAL format
 * Format is:
 * QueryID		Q0		DocID					Rank		Score		RunID
 * 10			Q0	clueweb09-enwp03-35-1378	1			16			run-1
 *
 * The QueryID should correspond to the query ID of the query you are evaluating.
 * Q0 is a required constant.
 * The DocID should be the external document ID.
 * The scores should be in descending order, to indicate that your results are ranked.
 * The Run ID is an experiment identifier which can be set to anything.
 */
void Score::printScoredQueries(){
/*
	std::map< std::string, std::multimap<float, std::string> >::iterator it;
	for(it = SCORED_QUERIES.begin(); it != SCORED_QUERIES.end(); ++it){
		// Use reverse iterator to print the results in the correct order (from high probabiliy to low)
		std::multimap<float, std::string>::reverse_iterator iter;
		int place = 1;
		for(iter = it->second.rbegin(); iter != it->second.rend(); ++iter){
			std::cout << it->first << "\t" << "Q0" << "\t" << iter->second << " \t" << place << "\t" << iter->first << "\t" << "run-1" << std::endl;
			place++;
		}
	}
*/
}

void Score::printParScoredQueries(){
/*
	std::vector<std::pair<std::string, std::multimap<float, std::string> > >::iterator it;
	for(it = SCORED_QUERIES_PAR.begin(); it != SCORED_QUERIES_PAR.end(); ++it){
		std::pair<std::string, std::multimap<float, std::string> > ss = *it;

		std::cout << "Printing scores for query " << ss.first << std::endl;

		std::multimap<float, std::string>::reverse_iterator iter;
		int place = 1;
		for(iter = ss.second.rbegin(); iter != ss.second.rend(); ++iter){
			std::cout << it->first << "\t" << "Q0" << "\t" << iter->second << " \t" << place << "\t" << iter->first << "\t" << "run-1" << std::endl;
			place++;
		}

	}
*/
}

std::string Score::getRandomPooledQueryTerim(){
	srand (time(0));
	int MAX_VAL = POOLED_QUERYTERMS.size();
	int iSecret = rand() % MAX_VAL;
	int counter = 0;
	std::set< std::string >::iterator it;
	for(it = POOLED_QUERYTERMS.begin(); it != POOLED_QUERYTERMS.end(); ++it){
		if(counter == iSecret){
			std::string str = (*it);
			return str;
		}
		counter++;
	}
	return "";
}

void Score::printPooledQueryTerms(){
	std::set< std::string >::iterator it;
	for(it = POOLED_QUERYTERMS.begin(); it != POOLED_QUERYTERMS.end(); ++it){
		std::cout << "Query term: " << (*it) << std::endl;
	}
	std::cout << std::endl;
}

void Score::printGetQueryRep(){
	map<std::string, idx::QUERYOBJECT *>::iterator it;
	for(it = qIDtoQuery.begin(); it != qIDtoQuery.end(); ++it){
		std::cout << "Query id: " << it->first << std::endl;
		std::vector<std::string> qterms = it->second->getQueryTerms();
		std::vector<std::string>::iterator iter;
		for(iter = qterms.begin(); iter != qterms.end(); ++iter){
			std::string qterm = *iter;
			int freq          = it->second->getQueryTermFrequency(qterm);
			std::cout << "Query term: " << qterm <<" -> Frequency: " << freq << std::endl;
		}
		std::cout << std::endl;
	}
}

void Score::printQTermsInvLists(){
/*
	std::unordered_map<std::string, vector<idx::DocIDFreq * >>::iterator it;
	std::cout << "Size of inverted index " << INVINDEX.size() << std::endl;
	for(it = INVINDEX.begin(); it != INVINDEX.end(); ++it){
		std::string stem 	  		 = it->first;
		vector<idx::DocIDFreq *> ptr = it->second;
		std::cout << "Query term: " << stem << std::endl;
		vector<idx::DocIDFreq *>::iterator iter;
		for(iter = ptr.begin(); iter != ptr.end(); ++iter){
			idx::DocIDFreq * p = *iter;
			std::cout << "\tDocid: " << p->getDocID() << "\tTerm freq: " << p->getTermFreq() << std::endl;
		}
		std::cout << std::endl;
	}
*/
}

void Score::printQTermsInvLists(std::string str){
/*
	std::unordered_map<std::string, vector<idx::DocIDFreq *> >::iterator it;
	std::cout << "Printing inverted list for query term: " << str << std::endl;
	for(it = INVINDEX.begin(); it != INVINDEX.end(); ++it){
		std::string stem 	  		 = it->first;
		if(stem.compare(str) == 0){
			vector<idx::DocIDFreq *> ptr = it->second;
			vector<idx::DocIDFreq *>::iterator iter;
			for(iter = ptr.begin(); iter != ptr.end(); ++iter){
				idx::DocIDFreq * p = *iter;
				std::cout << "\tDocid: " << p->getDocID() << "\tTerm freq: " << p->getTermFreq() << "\tExternal id: " << p->getExternalDocID() << std::endl;
			}
			std::cout << std::endl;
		}
	}
*/
}

std::vector<double> Score::getScoreModelParameterBounds(int index){
	return SCOREMODEL->getParameterBounds(index);
}

int Score::getNofScoreModelParameters(){
	return SCOREMODEL->getNumParameters();
}

std::vector<double> Score::getScoreModelParameters(){
	return SCOREMODEL->getParameters();
}

std::string Score::getScoreModelName(){
	return SCOREMODEL->getModelName();
}

void Score::updateScoreModelParameters(std::vector<double> vs){
	SCOREMODEL->updateParameters(vs);
}





void Score::parscore2(PConfig & c,std::vector<std::string> qids, double cval){

	/* What happens if a query does not get anything scored? We have an empty space?
	 * To avoid that we resize the vector so we don't point into empty space
	 */
	SCORED_QUERIES_PAR.clear();
	size_t mapSize = qids.size();
	SCORED_QUERIES_PAR.resize(mapSize);

	LOG(INFO) << "Scoring queries to documents.....";
	std::cout << idx::printTime() << " - Scoring queries to documents....." << std::endl;
	auto start = std::chrono::high_resolution_clock::now();

	/* Loop over queries */
	int index,progress = 0;
	bool useLaplace    = c.useLaplace();
	bool useftlambda   = c.getLambdaType();

	if(c.getNofThreads() == -1){
		int numthreads = omp_get_max_threads();
		std::cout << "Using all " << numthreads << " threads" << std::endl;
		omp_set_num_threads(numthreads);
	}else if(c.getNofThreads() >= 1){
		std::cout << "Number of threads specified: " << c.getNofThreads() << std::endl;
		omp_set_num_threads(c.getNofThreads());
	}else{
		// Must be a wrong set variable.
		std::cerr << "Number of threads " << c.getNofThreads() << " not allowed. Must be integer > 1 or -1" << std::endl;
		exit(EXIT_FAILURE);
	}

	omp_set_num_threads(12);

	#pragma omp parallel for shared(qids, qIDtoQuery, SCORED_QUERIES_PAR, INVINDEX, SCOREMODEL, useLaplace, useftlambda, TERM_ELITE_SET_STATS,DOCUMENTS_IN_COLLECTION,INTERNAL_TO_EXTERNAL_QUERY_ID, cval)
	for(index = 0; index < mapSize; index++){
		//std::cout << "Before fetching query: size of INTERNAL_TO_EXTERNAL: " << INTERNAL_TO_EXTERNAL_QUERY_ID.size() << std::endl;
		if(INTERNAL_TO_EXTERNAL_QUERY_ID.find(qids.at(index)) == INTERNAL_TO_EXTERNAL_QUERY_ID.end()){
			std::cerr << "Could not fetch query " << qids.at(index) << std::endl;
		}
		std::string q_ = INTERNAL_TO_EXTERNAL_QUERY_ID[qids.at(index)];
		idx::QUERYOBJECT * currentQuery = NULL;
		currentQuery = qIDtoQuery[q_];
		std::vector<std::string> cq     = currentQuery->getQueryTerms();
		/* External-document-id to partial-score map */
		std::map<std::string, float> accMap;
		/* Loop over query terms */
		int i;
		for(i = 0; i < cq.size(); i++){
		   /* Check if the query term was even found in the collection.
			* It can be the case that a query term does not exist in the collection
			* given the vocabulary mismatch problem.
			*/
			std::string queryterm = cq.at(i);
			bool        exist 	  = INVINDEX.find(queryterm) != INVINDEX.end();
			if(exist){
				/* Get the inverted list and query frequency of the query term */
				vector<idx::DocIDFreq *> qstats = INVINDEX[queryterm];
				int						 qtfreq = currentQuery->getQueryTermFrequency(queryterm);

				for(unsigned int j = 0; j < qstats.size(); j++){

					// Get the current document and the query term's term frequency in that document
					idx::DocIDFreq * pt       = qstats.at(j);

					/*
					 * See Eqn 5 in the original paper
					 * pt->getTermFreq() is the term frequency
					 * pt->getNormTerm() is the normalization (in this case normalization 2 - LaPlace)
					 * According to Eqn. 5
					 * tfn = term frequency * term normalization
					 *
					 * However, this is... mysterious. tfn is a float and cannot be used for discrete distribution....
					 *
					 * According to the paper:
					 * "We substitute uniformly tfn of Equations (41) or (42) for tf in weight (t, d ) of
					 * Equations (24) and (27)."
					 * See also Eqn 43. We must normalise tfn.
					 */
					double tfn    = pt->getTermFreq() * log2(1 + cval*pt->getNormTerm());
					/*
					 * Cases 103, 104 and 105 conforms to Equations 19, 20 and 21 in Amati & Rijsbergen's paper
					 * Each Equation corresponds to INF_1
					 */
					double tmp    = 0.0;
					double ne     = 0.0;

					unsigned int size_of_elite_set = std::get<0>(TERM_ELITE_SET_STATS[queryterm]);
					unsigned int term_elite_occ    = std::get<1>(TERM_ELITE_SET_STATS[queryterm]);

					// Default lambda
					float lambda   = term_elite_occ / DOCUMENTS_IN_COLLECTION;
					if(!useftlambda){
						lambda     = size_of_elite_set / DOCUMENTS_IN_COLLECTION;
					}
					std::vector<double> estparms;
					estparms.push_back( lambda );
					//double lambda = lambda = pt->getSizeOfEliteSet()/pt->getNumberOfCollectionDocs();
					switch(SCOREMODEL->getModelID()){
						case 101: // Baseline
								  tmp = tfn * log2(tfn/lambda) + (lambda + (1/(12*tfn)) - tfn) * log2(exp(1)) + 0.5*log2(2*M_PI*tfn);
								  break;
						case 102: // Baseline
								  tmp = -log2((1.0/(1.0 + lambda)) * pow(lambda/(1.0 + lambda), tfn));
								  break;
						case 103: //Baseline
								  tmp = tfn * log2((DOCUMENTS_IN_COLLECTION + 1.0)/(size_of_elite_set + 0.5)); // IDFL2d
								  break;
						case 104: //Baseline
								  ne  = DOCUMENTS_IN_COLLECTION * (1.0 - pow((DOCUMENTS_IN_COLLECTION - 1.0)/DOCUMENTS_IN_COLLECTION, tfn));
								  tmp = tfn * log2( (DOCUMENTS_IN_COLLECTION + 1.0) / (ne + 0.5) );// PIDFL2d
								  break;
						case 105: //Baseline
							      tmp = tfn * log2( ( (DOCUMENTS_IN_COLLECTION + 1.0) / (term_elite_occ + 0.5) ) ) * term_elite_occ/DOCUMENTS_IN_COLLECTION;// TFITFL2d
								  break;

						/* Begin baseline information models for ad hoc IR by Clinchant and Gaussier
						 * According to the paper lambda_2 = n_w/N and c \in (0.5, 0.75, 1,2,3,4,5,6,7,8,9)
						 */
						case 106: //Log-logistic Eqn. 4 in "Information models for ad hoc IR"
							      tmp = log2(lambda/(tfn + lambda));
 							      break;

						case 107: // Smoothed power law Eqn 5.
								  tmp = log2( (pow(lambda,tfn/(tfn+1.0))-lambda )/(1 - lambda));
								  break;

						default:  tmp = SCOREMODEL->score(tfn,estparms);// Usual
								  break;
					}

					float accscore = 0.0;

					if(SCOREMODEL->getModelID() < 106){
						accscore =  qtfreq  * tmp;

						if(useLaplace){
							accscore  = accscore * (1.0 - tfn/(tfn + 1.0));
						}else{
							accscore  = accscore * (term_elite_occ + 1.0)/(size_of_elite_set*(tfn + 1.0));
						}

					}else{
						accscore = -qtfreq * tmp;
					}

					if(!std::isinf(accscore)){
						accMap[pt->getExternalDocID()] += accscore;
					}
				}
			}else{
				// No contribution - continue with next query term
			}
		 }

		/* Now accMap contains scores for all documents w.r.t the current query
		 * These scores must now be sorted
		 */

		 if(!accMap.empty()){
			 // Sort map by value in increasing order of score, external document id
			 std::multimap<float, std::string> dst = idx::flipAndSortmap(accMap);
			 // All documents below the cutoff should be removed here. This should save a bit of memory

			 std::multimap<float, std::string> dst_red;
			 std::multimap<float, std::string>::reverse_iterator i;
			 int counter = 1;
			 for(i = dst.rbegin(); i != dst.rend(); ++i){
				 dst_red.insert( std::pair<float, std::string>(i->first, i->second));
				 if(counter == 1000){
					 break;
				 }
				 counter++;
			 }
			 dst.clear();
			 accMap.clear();
			 // Now store the result of the query
			 pair <string, std::multimap<float, std::string> > val (currentQuery->getQueryID(),dst_red);
			 SCORED_QUERIES_PAR[index] = val;
		 }else{
			 /* Special case: No terms in the query can be matched in the vocabulary of the index.
			  * We insert a dummy value and let it propagate until we write the results.
			  * See io/Write.cpp
			  */

			 std::multimap<float, std::string> dst;
			 pair <string, std::multimap<float, std::string> > val ("-1",dst);
			 SCORED_QUERIES_PAR[index] = val;
		 }
		#pragma omp critical
		 progress++;
		 if( (progress % 10) == 0)
			 std::cout << idx::printTime() << " :: Finished " << progress << " queries" << std::endl;
	}
	SCORED_QUERIES_PAR_POINTER = &SCORED_QUERIES_PAR;
	std::cout << idx::printTime() << " - Completed " << SCORED_QUERIES_PAR.size() << " queries scored (100%)" << std::endl;
	auto end = std::chrono::high_resolution_clock::now();
	double tEnd = (double)std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
	std::cout << "Done! (" << (tEnd/1000) << " seconds)" << std::endl;
	LOG(INFO) << "Done! (" << (tEnd/1000) << " seconds)";
}


void Score::loadFile(std::string parameter_file){
	string queryterm;
	ifstream myfile (parameter_file);
	if (myfile.is_open()){
	    while ( getline (myfile,queryterm) ) {
	      std::vector<string> parts;
	      std::vector<double> parameters;
	      idx::split(queryterm, ',', parts);
	      int N = parts.size();
	      for(int i = 1; i < N; i++){
	    	  parameters.push_back(atof(parts.at(i).c_str())+0.001);
	      }
	      PARAMETERS[parts.at(0)] = parameters;
	    }
	    myfile.close();
	  }

	map<std::string, std::vector<double> >::iterator it;
	for(it = PARAMETERS.begin(); it != PARAMETERS.end(); ++it){
		std::cout << it->first << " : [";
		std::vector<double>::iterator valitr;
		for(valitr = it->second.begin(); valitr != it->second.end(); ++valitr){
			std::cout << *valitr << " ";
		}
		std::cout << "]" << std::endl;
	}

	std::cout << "******************************" << std::endl;
	std::cout << "*   Loaded all query terms   *" << std::endl;
	std::cout << "******************************" << std::endl;
}

void Score::parscore3(PConfig & c,std::vector<std::string> qids, double cval){


	//Load the file containing the parameter values for each query term.


	/* What happens if a query does not get anything scored? We have an empty space?
	 * To avoid that we resize the vector so we don't point into empty space
	 */
	SCORED_QUERIES_PAR.clear();
	size_t mapSize = qids.size();
	std::cout << "qids.size(): " << qids.size() << std::endl;
	std::cout << "qIDtoQuery.size(): " << qIDtoQuery.size() << std::endl;
	SCORED_QUERIES_PAR.resize(mapSize);

	LOG(INFO) << "Scoring queries to documents.....";
	std::cout << idx::printTime() << " - Scoring queries to documents....." << std::endl;
	auto start = std::chrono::high_resolution_clock::now();

	/* Loop over queries */
	int index,progress = 0;
	bool useLaplace    = c.useLaplace();
	bool useftlambda   = c.getLambdaType();

	if(c.getNofThreads() == -1){
		int numthreads = omp_get_max_threads();
		std::cout << "Using all " << numthreads << " threads" << std::endl;
		omp_set_num_threads(numthreads);
	}else if(c.getNofThreads() >= 1){
		std::cout << "Number of threads specified: " << c.getNofThreads() << std::endl;
		omp_set_num_threads(c.getNofThreads());
	}else{
		// Must be a wrong set variable.
		std::cerr << "Number of threads " << c.getNofThreads() << " not allowed. Must be integer > 1 or -1" << std::endl;
		exit(EXIT_FAILURE);
	}

	omp_set_num_threads(12);

	#pragma omp parallel for shared(qids, qIDtoQuery, SCORED_QUERIES_PAR, INVINDEX, SCOREMODEL, useLaplace, useftlambda, TERM_ELITE_SET_STATS,DOCUMENTS_IN_COLLECTION,INTERNAL_TO_EXTERNAL_QUERY_ID, cval, PARAMETERS)
	for(index = 0; index < mapSize; index++){
		//std::cout << "Before fetching query: size of INTERNAL_TO_EXTERNAL: " << INTERNAL_TO_EXTERNAL_QUERY_ID.size() << std::endl;
		if(INTERNAL_TO_EXTERNAL_QUERY_ID.find(qids.at(index)) == INTERNAL_TO_EXTERNAL_QUERY_ID.end()){
			std::cerr << "Could not fetch query " << qids.at(index) << std::endl;
		}
		std::string q_ = INTERNAL_TO_EXTERNAL_QUERY_ID[qids.at(index)];
		idx::QUERYOBJECT * currentQuery = NULL;
		currentQuery = qIDtoQuery[q_];
		std::vector<std::string> cq     = currentQuery->getQueryTerms();
		/* External-document-id to partial-score map */
		std::map<std::string, float> accMap;
		/* Loop over query terms */
		int i;
		for(i = 0; i < cq.size(); i++){
		   /* Check if the query term was even found in the collection.
			* It can be the case that a query term does not exist in the collection
			* given the vocabulary mismatch problem.
			*/
			std::string queryterm = cq.at(i);
/*
// COMMENTED OUT FOR THE iSEARCH COLLECTION
			if(PARAMETERS.find(queryterm) == PARAMETERS.end()){
				std::cerr << "Could not find query term: " << queryterm << " in PARAMETERS (containing query terms loaded from external file)" << std::endl;
				exit(EXIT_FAILURE);
			}
			std::vector<double> estparms = PARAMETERS[queryterm];
*/
			//std::cout << "query term: " << queryterm << std::endl;
			std::vector<double> estparms;
			bool        exist 	  = INVINDEX.find(queryterm) != INVINDEX.end();
			if(exist){
				/* Get the inverted list and query frequency of the query term */
				vector<idx::DocIDFreq *> qstats = INVINDEX[queryterm];
				int						 qtfreq = currentQuery->getQueryTermFrequency(queryterm);

				/* Loop over the inverted list (<doc id, qterm_freq, external_doc_id>) of the current query term */
				for(unsigned int j = 0; j < qstats.size(); j++){

					// Get the current document and the query term's term frequency in that document
					idx::DocIDFreq * pt       = qstats.at(j);

					/*
					 * See Eqn 5 in the original paper
					 * pt->getTermFreq() is the term frequency
					 * pt->getNormTerm() is the normalization (in this case normalization 2 - LaPlace)
					 * According to Eqn. 5
					 * tfn = term frequency * term normalization
					 *
					 * However, this is... mysterious. tfn is a float and cannot be used for discrete distribution....
					 *
					 * According to the paper:
					 * "We substitute uniformly tfn of Equations (41) or (42) for tf in weight (t, d ) of
					 * Equations (24) and (27)."
					 * See also Eqn 43. We must normalise tfn.
					 */
					//std::cout << "Internal doc id: " << pt->getDocID() << ", External doc if: " << pt->getExternalDocID() << std::endl;
					//std::cout << "Term freq: " << pt->getTermFreq() << ", pt->getNormTerm(): " << pt->getNormTerm() << std::endl;
					double tfn    = pt->getTermFreq() * log2(1 + cval*pt->getNormTerm());
					/*
					 * Cases 103, 104 and 105 conforms to Equations 19, 20 and 21 in Amati & Rijsbergen's paper
					 * Each Equation corresponds to INF_1
					 */
					double tmp    = 0.0;
					double ne     = 0.0;

					unsigned int size_of_elite_set = std::get<0>(TERM_ELITE_SET_STATS[queryterm]);
					unsigned int term_elite_occ    = std::get<1>(TERM_ELITE_SET_STATS[queryterm]);

					// Default lambda
					float lambda   = term_elite_occ / DOCUMENTS_IN_COLLECTION;
					if(!useftlambda){
						lambda     = size_of_elite_set / DOCUMENTS_IN_COLLECTION;
					}
					estparms.clear();
					estparms.push_back(lambda);

					//double lambda = lambda = pt->getSizeOfEliteSet()/pt->getNumberOfCollectionDocs();
					switch(SCOREMODEL->getModelID()){
						case 101: // Baseline
								  tmp = tfn * log2(tfn/lambda) + (lambda + (1/(12*tfn)) - tfn) * log2(exp(1)) + 0.5*log2(2*M_PI*tfn);
								  break;
						case 102: // Baseline
							      tmp = -log2((1.0/(1.0 + lambda)) * pow(lambda/(1.0 + lambda), tfn));
								  break;
						case 103: //Baseline
								  tmp = tfn * log2((DOCUMENTS_IN_COLLECTION + 1.0)/(size_of_elite_set + 0.5)); // IDFL2d
								  break;
						case 104: //Baseline
								  ne  = DOCUMENTS_IN_COLLECTION * (1.0 - pow((DOCUMENTS_IN_COLLECTION - 1.0)/DOCUMENTS_IN_COLLECTION, tfn));
								  tmp = tfn * log2( (DOCUMENTS_IN_COLLECTION + 1.0) / (ne + 0.5) );// PIDFL2d
								  break;
						case 105: //Baseline
							      tmp = tfn * log2( ( (DOCUMENTS_IN_COLLECTION + 1.0) / (term_elite_occ + 0.5) ) ) * term_elite_occ/DOCUMENTS_IN_COLLECTION;// TFITFL2d
								  break;

						/* Begin baseline information models for ad hoc IR by Clinchant and Gaussier
						 * According to the paper lambda_2 = n_w/N and c \in (0.5, 0.75, 1,2,3,4,5,6,7,8,9)
						 */
						case 106: //Log-logistic Eqn. 4 in "Information models for ad hoc IR"
							      tmp = log2(lambda/(tfn + lambda));
 							      break;

						case 107: // Smoothed power law Eqn 5.
								  tmp = log2( (pow(lambda,tfn/(tfn+1.0))-lambda )/(1 - lambda));
								  break;

						default:  tmp = SCOREMODEL->score(tfn,estparms);// Usual
								  break;
					}

					float accscore = 0.0;

					if(SCOREMODEL->getModelID() < 106){
						accscore =  qtfreq  * tmp;

						if(useLaplace){
							accscore  = accscore * tfn/(tfn + 1.0);
						}else{
							accscore  = accscore * (term_elite_occ + 1.0)/(size_of_elite_set*(tfn + 1.0));
						}

					}else{
						accscore = -qtfreq * tmp;
					}

					if(!std::isinf(accscore)){
						accMap[pt->getExternalDocID()] += accscore;
					}
				}
			}else{
				// No contribution - continue with next query term
			}
		 }

		/* Now accMap contains scores for all documents w.r.t the current query
		 * These scores must now be sorted
		 */

		 if(!accMap.empty()){
			 // Sort map by value in increasing order of score, external document id
			 std::multimap<float, std::string> dst = idx::flipAndSortmap(accMap);
			 // All documents below the cutoff should be removed here. This should save a bit of memory

			 std::multimap<float, std::string> dst_red;
			 std::multimap<float, std::string>::reverse_iterator i;
			 int counter = 1;
			 for(i = dst.rbegin(); i != dst.rend(); ++i){
				 dst_red.insert( std::pair<float, std::string>(i->first, i->second));
				 if(counter == 1000){
					 break;
				 }
				 counter++;
			 }
			 dst.clear();
			 accMap.clear();
			 // Now store the result of the query
			 pair <string, std::multimap<float, std::string> > val (currentQuery->getQueryID(),dst_red);
			 SCORED_QUERIES_PAR[index] = val;
		 }else{
			 /* Special case: No terms in the query can be matched in the vocabulary of the index.
			  * We insert a dummy value and let it propagate until we write the results.
			  * See io/Write.cpp
			  */

			 std::multimap<float, std::string> dst;
			 pair <string, std::multimap<float, std::string> > val ("-1",dst);
			 SCORED_QUERIES_PAR[index] = val;
		 }
		#pragma omp critical
		 progress++;
		 if( (progress % 10) == 0)
			 std::cout << idx::printTime() << " :: Finished " << progress << " queries" << std::endl;
	}
	SCORED_QUERIES_PAR_POINTER = &SCORED_QUERIES_PAR;
	std::cout << idx::printTime() << " - Completed " << SCORED_QUERIES_PAR.size() << " queries scored (100%)" << std::endl;
	auto end = std::chrono::high_resolution_clock::now();
	double tEnd = (double)std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
	std::cout << "Done! (" << (tEnd/1000) << " seconds)" << std::endl;
	LOG(INFO) << "Done! (" << (tEnd/1000) << " seconds)";
}
