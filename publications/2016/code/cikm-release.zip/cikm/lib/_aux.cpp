/*
 * aux.cpp
 * TODO:
 * 08-10-2015: Modify getInvLists to NOT include c and b as scalars but as vectors, holding the possible values of each.
 *             C is in the range of 1 <= C <= 7. B is in the range 0 <= B <= 1.
 *             C is discretised into intervals of 1. B is discretised into intervals of 0.2
 * 28-10-2015: When creating DocIDFreq I calculate the normalised frequencies as per the paper. However, this converts the integer term frequencies
 * 			   to floating points, and the discrete statistical models are not defined on these.
 * 			   Thus we are calculating the value of tf from the score model and "normalising" it with a normalised version of tf.
 *
 * CHANGELOG:
 * 19-06-2015: Created
 * 29-10-2015: Added stuff necessary to filter out stop words. To NOT do this:
 * 			   1 - Comment IN the line double avgDocLength  = colLen / double(documentCount);
 * 			   2 - Change double cavgDocLength = c*COLLECTION_AVGDOCLENGTH; to double cavgDocLength = c*avgDocLength
 * 			   3 - Comment IN the line double doclen = index->documentLength(entry->document);
 * 			   4 - Comment OUT the 5-6 lines related to the line const bool is_in = COLLECTION_DOCLENGTHS.find(documentName) != COLLECTION_DOCLENGTHS.end();
 * 			   5 - Change 1 / ((1 - b) + b * doclen/COLLECTION_AVGDOCLENGTH) to 1 / ((1 - b) + b * doclen/avgDocLength)
 *
 *  Created on: Jun 19, 2015
 *      Author: casper
 */
#include "../include/aux.hpp"
#include "../include/easylogging++.h"
#include "../include/ScoreModel.hpp"
#include "../include/Estimation.hpp"

std::unordered_map<lemur::api::DOCID_T, std::string> ID_TO_EXT;
//std::unordered_map<std::string, vector<idx::DocIDFreq *>  >   termIlist;
std::unordered_map<std::string, vector<idx::DocIDFreq * > > * IIDX;
std::set<double>   	  TFN_TO_SCORE_SET;
std::set<double> 	* TFN_TO_SCORE_SET_PTR;
std::vector<double>   TFN_TO_SCORE_VECTOR;
std::vector<double> * TFN_TO_SCORE_VECTOR_PTR;
EstimationFactory est;
Estimation * dist;

void idx::getInvLists(indri::collection::Repository & r, std::set<std::string> qTerms, double c, double b, std::unordered_map<std::string, vector<idx::DocIDFreq * > > &termListOut, std::unordered_map<std::string, std::tuple<unsigned int, unsigned int, std::vector<double> > > &eliteset, std::string modelest){
	//termIlist.clear();
	TFN_TO_SCORE_SET.clear();
	indri::collection::Repository::index_state state     = r.indexes();
	indri::index::Index* index                           = (*state)[0];
	indri::thread::ScopedLock( index->iteratorLock() );
	indri::collection::CompressedCollection * collection = r.collection();
	indri::server::LocalQueryServer local(r);


	  // Estimate model-parameters using MLE
	  switch(idx::str2int(modelest.c_str())){
	  	  case idx::str2int("powerlaw"):
 			  dist = est.getEstimator("powerlaw");
	 		  break;
	   case idx::str2int("yule"):
 		 	  dist = est.getEstimator("yule");
	 		  break;
	   case idx::str2int("gev"):
 		 	  dist = est.getEstimator("gev");
	 		  break;
	   default: std::cerr << "Model " << modelest << " not specified" << std::endl;
	 	       exit(EXIT_FAILURE);
	 }


	/*
	 * If the collection was indexed then the below average is skewed as it will count stop words.
	 * To avoid counting stop words loop over the vocabulary (see print_vocabulary in dumpindex.cpp)
	 */

	INT64  documentCount = index->documentCount();
	UINT64 colLen 		 = index->termCount();
    float avgDocLength  = colLen / double(documentCount);
    //std::cout << "Average document length: " << avgDocLength << std::endl;
        //double cavgDocLength = c*COLLECTION_AVGDOCLENGTH;
	float cavgDocLength = c*avgDocLength;
	set<std::string>::iterator it;
	LOG(INFO) << "Fetching inverted lists for " << qTerms.size() << " query terms....";
	std::cout << "Fetching inverted lists for " << qTerms.size() << " query terms...." << std::endl;
	auto start = std::chrono::high_resolution_clock::now();
	int counter, counter2 = 0;
	std::vector<unsigned short int> datapoints;
	std::vector<double> misc;
	int minval = 10000000;
	for(it = qTerms.begin(); it != qTerms.end(); ++it){
		  std::string term = *it;
		  term             = r.processTerm(term);
		  indri::index::DocListIterator* iter = index->docListIterator( term );
		  if (iter == NULL){
			  counter++;
			  continue;
		  }

		  iter->startIteration();
		  std::vector<idx::DocIDFreq *> entries;

		  indri::index::DocListIterator::DocumentData* entry;

		  unsigned int F  = local.termCount(term);
		  unsigned int n  = local.documentCount(term);

		  for( iter->startIteration(); iter->finished() == false; iter->nextEntry() ) {

			entry                    = (indri::index::DocListIterator::DocumentData*) iter->currentEntry();

//		    std::cout << "Document: " << entry->document << ", Document length: " << doclen << std::endl;
		    std::string documentName;
		    if(ID_TO_EXT.find(entry->document) != ID_TO_EXT.end()){
		    	// We have found a match and do not need to retrieve it
		    	documentName = ID_TO_EXT[entry->document];

		    }else{
		    	// Otherwise we have to do this (which is HUGELY expensive because of the scoped lock)
			    documentName = collection->retrieveMetadatum( entry->document, "docno" );
			    ID_TO_EXT[entry->document] = documentName;
		    }
		    double doclen = index->documentLength(entry->document);
/*
		    double doclen = 0.0;
			const bool is_in = COLLECTION_DOCLENGTHS.find(documentName) != COLLECTION_DOCLENGTHS.end();
			if(is_in){
				doclen = COLLECTION_DOCLENGTHS[documentName];
			}else{
				std::cout << "This should never happen!" << std::endl;
			}
			// Should never happen
*/
		    //entry->document,							// Internal document id
			idx::DocIDFreq * ptr     = new idx::DocIDFreq(entry->positions.size(),					// Term frequency
														  documentName,								// External document name
														  c < 0 ? -1 : log2(1.0 + cavgDocLength/doclen));         // Laplace term normalisation
														  //b < 0 ? -1 : 1 / ((1 - b) + b * doclen/avgDocLength));  // BM25 term normalisation
														  //n,                                        // n : Size of query term's elite set (defined by Amati to be all documents where t occurs)
														  //F);                                       // F : total number of occurrences of query term
			if(entry->positions.size() < minval){
				minval = entry->positions.size();
			}
			datapoints.push_back(entry->positions.size());
			//std::cout << "query term: " << term << ", internal docid: " << entry->document << ", f_{t,d}: " << entry->positions.size() << ", doclen: " << doclen << ", laplace: " << (c < 0 ? -1 : log2(1.0 + cavgDocLength/doclen)) << ", bm25: " << (b < 0 ? -1 : 1 / ((1 - b) + b * doclen/avgDocLength)) << ", n: " << n << ", F: " << F << ", total docs: " << documentCount << std::endl;
			entries.push_back(ptr);
 		  }
		  misc.push_back( (double) minval );
		  termListOut[term]            = entries;
		  std::vector<double> estparms = dist->estimate(datapoints, misc);

		  eliteset[term]               = std::tuple<unsigned int, unsigned int, std::vector<double> >(n,F,estparms);
		  counter2++;
		  delete iter;
		  if((counter2 % 50) == 0){
			  std::cout << printTime() << " :: Loaded " << counter2 << " inverted lists" << std::endl;
		  }
		  minval = 10000000;
		  datapoints.clear();
	}
	datapoints.clear();
	std::cout << "Loaded " << counter2 << " inverted lists" << std::endl;
	auto end = std::chrono::high_resolution_clock::now();
	double tEnd = (double)std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
	std::cout << "Done! (" << tEnd/1000 << " seconds)" << std::endl;
	LOG(INFO) << "Done! (" << tEnd/1000 << " seconds)";
}

std::vector<std::string> idx::split(const std::string &s, char delim, std::vector<std::string> &elems) {
    std::stringstream ss(s);
    std::string item;
    while (std::getline(ss, item, delim)) {
        elems.push_back(item);
    }
    return elems;
}

std::set<double> * idx::getTFNPointer(){
	return TFN_TO_SCORE_SET_PTR;
}


std::string idx::printTime(){
	time_t now = time(0);
	tm *ltm = localtime(&now);

	std::string str = "[2015/" + SSTR(ltm->tm_mon) + "/" + SSTR(ltm->tm_mday) + "] " + SSTR(1+ltm->tm_hour) + ":" + SSTR(1+ltm->tm_min) + ":" + SSTR(1+ltm->tm_sec);
	return str;
}

void idx::calcDocLengths(std::string collectionindex){}



void idx::getInvLists2(indri::collection::Repository & r, std::set<std::string> qTerms, std::unordered_map<std::string, vector<idx::DocIDFreq * > > &termListOut, std::unordered_map<std::string, std::tuple<unsigned int, unsigned int, std::vector<double> > > &eliteset, std::string modelest){
	//termIlist.clear();
	TFN_TO_SCORE_SET.clear();
	indri::collection::Repository::index_state state     = r.indexes();
	indri::index::Index* index                           = (*state)[0];
	indri::thread::ScopedLock( index->iteratorLock() );
	indri::collection::CompressedCollection * collection = r.collection();
	indri::server::LocalQueryServer local(r);


	  // Estimate model-parameters using MLE
/*
	  switch(idx::str2int(modelest.c_str())){
	  	  case idx::str2int("powerlaw"):
 			  dist = est.getEstimator("powerlaw");
	 		  break;
	   case idx::str2int("yule"):
 		 	  dist = est.getEstimator("yule");
	 		  break;
	   case idx::str2int("gev"):
 		 	  dist = est.getEstimator("gev");
	 		  break;
	   default: std::cerr << "Model " << modelest << " not specified" << std::endl;
	 	       exit(EXIT_FAILURE);
	 }
*/

	/*
	 * If the collection was indexed then the below average is skewed as it will count stop words.
	 * To avoid counting stop words loop over the vocabulary (see print_vocabulary in dumpindex.cpp)
	 */

	INT64  documentCount = index->documentCount();
	UINT64 colLen 		 = index->termCount();
    float avgDocLength  = colLen / double(documentCount);
    //std::cout << "Average document length: " << avgDocLength << std::endl;
        //double cavgDocLength = c*COLLECTION_AVGDOCLENGTH;
	float cavgDocLength = avgDocLength;
	set<std::string>::iterator it;
	LOG(INFO) << "Fetching inverted lists for " << qTerms.size() << " query terms....";
	std::cout << "Fetching inverted lists for " << qTerms.size() << " query terms...." << std::endl;
	auto start = std::chrono::high_resolution_clock::now();
	int counter, counter2 = 0;
/*
	std::vector<unsigned short int> datapoints;
	std::vector<double> misc;
	int minval = 10000000;
*/
	for(it = qTerms.begin(); it != qTerms.end(); ++it){
		  std::string term = *it;
		  term             = r.processTerm(term);
		  indri::index::DocListIterator* iter = index->docListIterator( term );
		  if (iter == NULL){
			  counter++;
			  continue;
		  }

		  iter->startIteration();
		  std::vector<idx::DocIDFreq *> entries;

		  indri::index::DocListIterator::DocumentData* entry;

		  unsigned int F  = local.termCount(term);
		  unsigned int n  = local.documentCount(term);

		  for( iter->startIteration(); iter->finished() == false; iter->nextEntry() ) {

			entry                    = (indri::index::DocListIterator::DocumentData*) iter->currentEntry();

//		    std::cout << "Document: " << entry->document << ", Document length: " << doclen << std::endl;
		    std::string documentName;
		    if(ID_TO_EXT.find(entry->document) != ID_TO_EXT.end()){
		    	// We have found a match and do not need to retrieve it
		    	documentName = ID_TO_EXT[entry->document];

		    }else{
		    	// Otherwise we have to do this (which is HUGELY expensive because of the scoped lock)
			    documentName = collection->retrieveMetadatum( entry->document, "docno" );
			    ID_TO_EXT[entry->document] = documentName;
		    }
		    double doclen = index->documentLength(entry->document);

		    //entry->document,							// Internal document id
			idx::DocIDFreq * ptr     = new idx::DocIDFreq(entry->positions.size(),	// Term frequency
														  documentName,				// External document name
														  cavgDocLength/doclen);     // Laplace term normalisation
/*
			if(entry->positions.size() < minval){
				minval = entry->positions.size();
			}
*/
			//datapoints.push_back(entry->positions.size());
			//std::cout << "query term: " << term << ", internal docid: " << entry->document << ", f_{t,d}: " << entry->positions.size() << ", doclen: " << doclen << ", laplace: " << (c < 0 ? -1 : log2(1.0 + cavgDocLength/doclen)) << ", bm25: " << (b < 0 ? -1 : 1 / ((1 - b) + b * doclen/avgDocLength)) << ", n: " << n << ", F: " << F << ", total docs: " << documentCount << std::endl;
			entries.push_back(ptr);
 		  }
		  //misc.push_back( (double) minval );
		  termListOut[term]            = entries;
		  //std::vector<double> estparms = dist->estimate(datapoints, misc);
		  std::vector<double> estparms;
		  eliteset[term]               = std::tuple<unsigned int, unsigned int, std::vector<double> >(n,F,estparms);
		  counter2++;
		  delete iter;
		  if((counter2 % 50) == 0){
			  std::cout << printTime() << " :: Loaded " << counter2 << " inverted lists" << std::endl;
		  }
/*
		  minval = 10000000;
		  datapoints.clear();
*/
	}
	//datapoints.clear();
	std::cout << "Loaded " << counter2 << " inverted lists" << std::endl;
	auto end = std::chrono::high_resolution_clock::now();
	double tEnd = (double)std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
	std::cout << "Done! (" << tEnd/1000 << " seconds)" << std::endl;
	LOG(INFO) << "Done! (" << tEnd/1000 << " seconds)";
}
