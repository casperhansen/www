/*
 * Kriging.cpp
 *
 *  Created on: Oct 24, 2015
 *      Author: casper
 */

#include "../include/Kriging.hpp"

using namespace SPLINTER;
void Kriging::train(int N_TRIALS, int N_MODEL_PARAMETERS){

	DataTable samples;

	// Sample the function
	DenseVector x(N_MODEL_PARAMETERS);
	double y;

	for(int i = 0; i < N_TRIALS; i++){
		// Generate random parameter vector

		// Evaluate random parameter vector

		// Add the to samples
		samples.addSample(x, y);
	}
}

void Kriging::eval(int SPLINE_TYPE){

}
