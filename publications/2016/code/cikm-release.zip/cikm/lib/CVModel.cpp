/*
 * CVModel.cpp
 *
 *  Created on: Aug 28, 2015
 *      Author: Casper
 */
#include "../include/CVModel.hpp"
#include "../include/CV.hpp"
#include <random>
int         NTRIALS;
std::string PERFORMANCE_MEASURE;


map<std::string, double> doscore(Score * s, PConfig & c, FOLD f){
	TRECResults * r;
	TrecEval    * t;
/*
	// Load the fold queries from the query index
	s->loadCVQueries(c.getQueryIndex(), c.getQueryField(), f, c.getDebugLevel());
	//
	// Load the inverted lists from the document index (last argument is whether to use sequential or parallel).
	// For this task the sequential method is substantially quicker due to the scoped lock.
	//
	s->loadInvertedIndex(c.getCollectionIndex(), c.getLaplaceNorm(), c.getBm25Norm(), c.getDebugLevel(), false);
*/

	s->parscore(c);
	/* Write the results */
	bool res = r->write(s->getScoredVecQueriesPointer(), c.getRetrievalResults().c_str(), c.getCutoff(), "description");

	/* Evaluate the results */
	std::map<std::string, double> vvv;

	if(res){
		return (t->evaluate(c.getQrelsLoc(), c.getRetrievalResults()));
	}

	vvv[MAP]     = 0.0;
	vvv[MRR]     = 0.0;
	vvv[PATTEN]  = 0.0;
	vvv[NDCG]    = 0.0;
	vvv[NDCGTEN] = 0.0;
	std::cerr << "*************************************'" << std::endl;
	std::cerr << "* Some iteration was not successful *'" << std::endl;
	std::cerr << "*************************************'" << std::endl;
	return ( vvv );
}


map<std::string, double> mydoscore(Score * s, PConfig & c, FOLD f, double cval){
	TRECResults * r;
	TrecEval    * t;
/*
	// Load the fold queries from the query index
	s->loadCVQueries(c.getQueryIndex(), c.getQueryField(), f, c.getDebugLevel());
	//
	// Load the inverted lists from the document index (last argument is whether to use sequential or parallel).
	// For this task the sequential method is substantially quicker due to the scoped lock.
	//
	s->loadInvertedIndex(c.getCollectionIndex(), c.getLaplaceNorm(), c.getBm25Norm(), c.getDebugLevel(), false);
*/

	s->parscore2(c, f, cval);

//	s->parscore3(c, f, cval);
	/* Write the results */
	bool res = r->write(s->getScoredVecQueriesPointer(), c.getRetrievalResults().c_str(), c.getCutoff(), "description");

	/* Evaluate the results */
	std::map<std::string, double> vvv;

	if(res){
		return (t->evaluate(c.getQrelsLoc(), c.getRetrievalResults()));
	}

	vvv[MAP]     = 0.0;
	vvv[MRR]     = 0.0;
	vvv[PATTEN]  = 0.0;
	vvv[NDCG]    = 0.0;
	vvv[NDCGTEN] = 0.0;
	std::cerr << "*************************************'" << std::endl;
	std::cerr << "* Some iteration was not successful *'" << std::endl;
	std::cerr << "*************************************'" << std::endl;
	return ( vvv );
}

RESULT generateParameterVector(Score * s){
	std::random_device rd;
	std::mt19937 e2(rd());
	const int NPARMS = s->getNofScoreModelParameters();
	RESULT r;

	if(s->getScoreModelName().compare("CHIL2d") == 0){
		for(int i = 0; i < NPARMS; i++){
			BOUNDS limits = s->getScoreModelParameterBounds(i);
			std::uniform_int_distribution<> rng(limits.at(0), limits.at(1));
			r.push_back( rng(e2) );
		}
	   	return r;
	}

	for(int i = 0; i < NPARMS; i++){
		BOUNDS limits = s->getScoreModelParameterBounds(i); // Starting from parameter 1
		std::uniform_real_distribution<> rng(limits.at(0), limits.at(1));
		r.push_back( rng(e2) );
	}
	return r;
}

PARAMETER randomSearch(Score * s, PConfig & c, FOLD f){

 /*
  * Performs random search.
  * At each step we generate a random (but valid in terms of the range of each parameter) guess and use that for evaluation
  *
  * Random search fixates the response surface methodology by Cox and Wilson.
  *
  * Imagine the 5% interval around the true maximum. Now imagine that we sample points from this space and
  * see if any of it lands within that maximum. Each random draw has a 5% chance of landing in that interval,
  * if we draw n points independently, then the probability that all of them miss the desired interval is (1−0.05)^n.
  * So the probability that at least one of them succeeds in hitting the interval is 1 minus that quantity.
  * We want at least a .95 probability of success so we need:
  * 0.95 = 1 - (1 - 0.05)^n => n = 60
  * iterations to ensure that our best guess is within the 5% interval.
  */


	/* Optimise */

	double MAX_MAP = -1.0;
	PARAMETER BEST_PARMS;
	map<std::string, double> best;
	for(int i = 0; i < NTRIALS; i++){
		 std::cout << std::endl;
		 std::cout << "************************************************" << std::endl;
		 std::cout << "Starting trial " << i << " of random search"     << std::endl;
		 std::cout << "************************************************" << std::endl;
		 map<std::string, double> r = doscore(s, c, f);
		 //bool is_in = r.find(PERFORMANCE_MEASURE) != r.end();
		 //double val = -1;
		 //if(is_in){
		 double val = r[PERFORMANCE_MEASURE];
		 //}

		 if(val > MAX_MAP){
			 MAX_MAP    = val;
			 BEST_PARMS = s->getScoreModelParameters();
			 best       = r;
		 }
/*
		 std::vector<double> vg = s->getScoreModelParameters();
		 for(int b = 0; b < vg.size(); b++){
			 std::cout << "Parameter: " << (b+1) << ": " << vg.at(b)   << std::endl;
		 }
*/
		 std::cout << "MAP......: " << r[MAP]  	  << std::endl;
		 std::cout << "MRR......: " << r[MRR]     << std::endl;
		 std::cout << "P@10.....: " << r[PATTEN]  << std::endl;
		 std::cout << "NDCG.....: " << r[NDCG]    << std::endl;
		 std::cout << "NDCG@10..: " << r[NDCGTEN] << std::endl;

		 // Generate new random parameter vector vector
		 //std::vector<double> parms = generateParameterVector(s);
		 //std::cout << "New parameter generated was: " << parms.at(0) << std::endl;
		 s->updateScoreModelParameters( generateParameterVector(s) );
		 //std::cout  << "Fetched parameter: " << (s->getScoreModelParameters()).at(0) << std::endl;
	}
	std::cout << std::endl;
	std::cout << "*********** COMPLETED ALL " << NTRIALS << " TRIALS ***********" << std::endl;
	std::cout << "*       Best MAP....: " << best[MAP]     << std::endl;
	std::cout << "*       Best MRR....: " << best[MRR]     << std::endl;
	std::cout << "*       Best P@10...: " << best[PATTEN]  << std::endl;
	std::cout << "*       Best NDCG...: " << best[NDCG]    << std::endl;
	std::cout << "*       Best NDCG@10: " << best[NDCGTEN] << std::endl;
	std::cout << "************************************************"               << std::endl;

	return BEST_PARMS;
}

void optim(Score * s, const CVFOLDS folds, PConfig & c, CVFOLDS f, const int NOFFOLDS){

	vector<double> parms;
	parms.push_back(  c.getFirstParameter()  );
	parms.push_back(  c.getSecondParameter() );
	parms.push_back(  c.getThirdParameter()  );


	s->setScoreModel(c.getModel(), parms);
	//std::cout << "Number of parameters: " << s->getNofScoreModelParameters() << std::endl;
	RESULT r;
	int foldcounter = 1;
	CVFOLDS::iterator it;
	for(it = f.begin(); it != f.end(); ++it){

		/* Get training fold */
		std::vector<std::string> trainfold = it->second->getFold();

		/* Load queries and their inverted lists for training */
		s->loadCVQueries(c.getQueryIndex(), c.getQueryField(), trainfold);
		s->loadInvertedIndex(c.getCollectionIndex(), c.getLaplaceNorm(), c.getBm25Norm(), c.getModelToEstimate());

		/* Get the parameters of the highest-performing training is used for testing */
		std::cout << "************************************************" << std::endl;
		std::cout << "*             Starting training fold " << foldcounter       << "         *" << std::endl;
		std::cout << "************************************************" << std::endl;
		PARAMETER p = randomSearch(s, c, trainfold);
		std::cerr << "************************************************" << std::endl;
		std::cerr << "* " << idx::printTime() <<"       Completed training fold " << foldcounter      << "        *" << std::endl;
		std::cerr << "************************************************" << std::endl;

		/* Update model parameters to the best ones */
		s->updateScoreModelParameters(p);


		/* Evaluate on test fold */
		std::vector<std::string> testfold = it->first->getFold();
		s->cleanup();
		/* Load test fold queries and their inverted lists */
		s->loadCVQueries(c.getQueryIndex(), c.getQueryField(), testfold);
		s->loadInvertedIndex(c.getCollectionIndex(), c.getLaplaceNorm(), c.getBm25Norm(), c.getModelToEstimate());

		std::cout << "************************************************" << std::endl;
		std::cout << "*             Starting testing fold " << foldcounter       << "          *" << std::endl;
		std::cout << "************************************************" << std::endl;
/*
		std::cout << "Starting testing fold using parameter: "          << std::endl;
		for(int b = 0; b < p.size(); b++){
		   std::cout << "Parameter: " << (b+1) << ": " << p.at(b)   << std::endl;
		}
*/
		std::cout << std::endl;
		map<std::string, double> pbest  = doscore(s, c, testfold);
		r.push_back( pbest[PERFORMANCE_MEASURE] );

		std::cout << "************************************************" << std::endl;
		std::cout << "*             Completed testing fold " << foldcounter       << "         *" << std::endl;
		std::cout << "************************************************" << std::endl;
		std::cout << "*             Best MAP....: " << pbest[MAP]       << std::endl;
		std::cout << "*             Best MRR....: " << pbest[MRR]       << std::endl;
		std::cout << "*             Best P@10...: " << pbest[PATTEN]    << std::endl;
		std::cout << "*             Best NDCG...: " << pbest[NDCG]      << std::endl;
		std::cout << "*             Best NDCG@10: " << pbest[NDCGTEN]   << std::endl;
		std::cout << "************************************************" << std::endl;
		std::cout << std::endl;
		std::cout << std::endl;
		s->cleanup();
		foldcounter++;
	}
	std::cout << "************************************************" << std::endl;
	std::cout << "*          COMPLETED ALL TRAINING FOLDS        *" << std::endl;
	std::cout << "*                PRINTING RESULTS              *" << std::endl;
	std::cout << "************************************************" << std::endl;
	std::vector<double>::iterator itr;
	int testfoldcounter = 1;
	for(itr = r.begin(); itr != r.end(); ++itr){
		std::cout << "Value of " << PERFORMANCE_MEASURE << " for test-fold " << testfoldcounter << " was: " << (*itr) << std::endl;
		testfoldcounter++;
	}
	double avgPerformance = std::accumulate(r.begin(), r.end(), 0.0) / r.size();
	std::cout << "Average "<< PERFORMANCE_MEASURE << " value across " << (testfoldcounter-1) << " folds: " << avgPerformance << std::endl;
	std::cout << std::endl;
}


/*
 * The purpose of this function is to optimise hyperparameters and NOT the parameters of each model.
 * Hyperparameters are e.g. the c-value, the b and/or k_1 value of BM25.
 * Optimisation is done using k-fold cross-validation
 *
 * Hyperparameter values should be specified in the config file.
 * The DFR it self should be run from a bash file that calls this code, get the results, changes a
 * hyperparameter value and repeats. This is easier that doing it in C++.
 */
void optimmeta(Score * s, CVFOLDS folds, PConfig & c, const int NOFFOLDS){

	vector<double> parms;
	parms.push_back(  c.getFirstParameter()  );
	parms.push_back(  c.getSecondParameter() );
	parms.push_back(  c.getThirdParameter()  );


	s->setScoreModel(c.getModel(), parms);
	//MAP,MRR,PATTEN,NDCG,NDCGTEN
	RESULT P_MAP;
	RESULT P_MRR;
	RESULT P_PATTEN;
	RESULT P_NDCG;
	RESULT P_NDCGTEN;
	RESULT r;
	int foldcounter = 1;
	CVFOLDS::iterator it;
	for(it = folds.begin(); it != folds.end(); ++it){

		/* Get training fold */
		std::vector<std::string> trainfold = it->second->getFold();

		/* Load queries and their inverted lists for training */
		s->loadCVQueries(c.getQueryIndex(), c.getQueryField(), trainfold);
		s->loadInvertedIndex(c.getCollectionIndex(), c.getLaplaceNorm(), c.getBm25Norm(), c.getModelToEstimate());

		/* Get the parameters of the highest-performing training is used for testing */
		std::cout << "************************************************" << std::endl;
		std::cout << "*             Starting training fold " << foldcounter       << "         *" << std::endl;
		std::cout << "************************************************" << std::endl;
		map<std::string, double> pbest  = doscore(s, c, trainfold);
		std::cerr << "****************************************************************" << std::endl;
		std::cerr << "* " << idx::printTime() <<"       Completed training fold " << foldcounter      << "        *" << std::endl;
		std::cerr << "****************************************************************" << std::endl;

		/* Evaluate on test fold */
		std::vector<std::string> testfold = it->first->getFold();
		s->cleanup();
		/* Load test fold queries and their inverted lists */
		s->loadCVQueries(c.getQueryIndex(), c.getQueryField(), testfold);
		s->loadInvertedIndex(c.getCollectionIndex(), c.getLaplaceNorm(), c.getBm25Norm(), c.getModelToEstimate());

		std::cout << "****************************************************************" << std::endl;
		std::cout << "*             Starting testing fold " << foldcounter       << "          *" << std::endl;
		std::cout << "****************************************************************" << std::endl;
		std::cout << std::endl;

		pbest  = doscore(s, c, testfold);
		r.push_back( pbest[PERFORMANCE_MEASURE] );

		P_MAP.push_back(    pbest[MAP    ] );
		P_MRR.push_back(    pbest[MRR    ] );
		P_PATTEN.push_back( pbest[PATTEN ] );
		P_NDCG.push_back(   pbest[NDCG   ] );
		P_NDCGTEN.push_back(pbest[NDCGTEN] );

		std::cout << "************************************************" << std::endl;
		std::cout << "*             Completed testing fold " << foldcounter       << "         *" << std::endl;
		std::cout << "************************************************" << std::endl;
		std::cout << "*             Best MAP....: " << pbest[MAP]       << std::endl;
		std::cout << "*             Best MRR....: " << pbest[MRR]       << std::endl;
		std::cout << "*             Best P@10...: " << pbest[PATTEN]    << std::endl;
		std::cout << "*             Best NDCG...: " << pbest[NDCG]      << std::endl;
		std::cout << "*             Best NDCG@10: " << pbest[NDCGTEN]   << std::endl;
		std::cout << "************************************************" << std::endl;
		std::cout << std::endl;
		std::cout << std::endl;
		s->cleanup();
		foldcounter++;
	}
	std::cout << "************************************************" << std::endl;
	std::cout << "*             COMPLETED ALL FOLDS              *" << std::endl;
	std::cout << "*               PRINTING RESULTS               *" << std::endl;
	std::cout << "************************************************" << std::endl;
	std::vector<double>::iterator itr;
	int testfoldcounter = 1;
	for(itr = r.begin(); itr != r.end(); ++itr){
		std::cout << "Value of " << PERFORMANCE_MEASURE << " for test-fold " << testfoldcounter << " was: " << (*itr) << std::endl;
		testfoldcounter++;
	}
	std::cout << std::endl;
	double avgPerformance        = std::accumulate(r.begin(), r.end(), 0.0) / r.size();
	std::cout << "Average "<< PERFORMANCE_MEASURE << " across " << (testfoldcounter-1) << " folds: " << avgPerformance << std::endl;
	std::cout << std::endl;
	std::cout << std::endl;
	std::cout << std::endl;
	std::cout << "Printing averages for all specified performance measures..." << std::endl;
	double avgMAPPerformance     = std::accumulate(P_MAP.begin(), P_MAP.end(), 0.0) / P_MAP.size();
	std::cout << "Average MAP across " << (testfoldcounter-1) << " folds: " << avgMAPPerformance << std::endl;
	double avgMRRPerformance     = std::accumulate(P_MRR.begin(), P_MRR.end(), 0.0) / P_MRR.size();
	std::cout << "Average MRR across " << (testfoldcounter-1) << " folds: " << avgMRRPerformance << std::endl;
	double avgPTENPerformance    = std::accumulate(P_PATTEN.begin(), P_PATTEN.end(), 0.0) / P_PATTEN.size();
	std::cout << "Average P@10 across " << (testfoldcounter-1) << " folds: " << avgPTENPerformance << std::endl;
	double avgNDCGPerformance    = std::accumulate(P_NDCG.begin(), P_NDCG.end(), 0.0) / P_NDCG.size();
	std::cout << "Average NDCG across " << (testfoldcounter-1) << " folds: " << avgNDCGPerformance << std::endl;
	double avgNDCGTENPerformance = std::accumulate(P_NDCGTEN.begin(), P_NDCGTEN.end(), 0.0) / P_NDCGTEN.size();
	std::cout << "Average NDCG@10 across " << (testfoldcounter-1) << " folds: " << avgNDCGTENPerformance << std::endl;
}

void optimmeta2(Score * s, CVFOLDS folds, PConfig & c, const int NOFFOLDS){

	vector<double> parms;
	parms.push_back(  c.getFirstParameter()  );
	parms.push_back(  c.getSecondParameter() );
	parms.push_back(  c.getThirdParameter()  );


	s->setScoreModel(c.getModel(), parms);
	//MAP,MRR,PATTEN,NDCG,NDCGTEN
	RESULT P_MAP;
	RESULT P_MRR;
	RESULT P_PATTEN;
	RESULT P_NDCG;
	RESULT P_NDCGTEN;
	RESULT r;
	int foldcounter = 1;

	/* Load queries and their inverted lists */
	//s->loadQueries(c.getQueryIndex(), c.getQueryField());
	double localcnorm = c.getLaplaceNorm();
        std::cout << "Using c: " << localcnorm << std::endl;
	s->loadQueriesWStopwords(c.getQueryIndex(), c.getQueryField(), "/home/casper/sigir2016/code/DFR/stopwords.txt");
	s->loadInvertedIndex(c.getCollectionIndex(), c.getLaplaceNorm(), c.getBm25Norm(), c.getModelToEstimate());
	CVFOLDS::iterator it;
	for(it = folds.begin(); it != folds.end(); ++it){

/*
		// Get training fold
		std::vector<std::string> trainfold = it->second->getFold();

		// Get the parameters of the highest-performing training is used for testing
		std::cout << "************************************************" << std::endl;
		std::cout << "*             Starting training fold " << foldcounter       << "         *" << std::endl;
		std::cout << "************************************************" << std::endl;
		map<std::string, double> pbest  = mydoscore(s, c, trainfold, 0.0);
		std::cerr << "****************************************************************" << std::endl;
		std::cerr << "* " << idx::printTime() <<"       Completed training fold " << foldcounter      << "        *" << std::endl;
		std::cerr << "****************************************************************" << std::endl;
*/
		/* Evaluate on test fold */
		std::vector<std::string> testfold = it->first->getFold();

		map<std::string, double> pbest  = mydoscore(s, c, testfold, localcnorm);
		r.push_back( pbest[PERFORMANCE_MEASURE] );

		P_MAP.push_back(    pbest[MAP    ] );
		P_MRR.push_back(    pbest[MRR    ] );
		P_PATTEN.push_back( pbest[PATTEN ] );
		P_NDCG.push_back(   pbest[NDCG   ] );
		P_NDCGTEN.push_back(pbest[NDCGTEN] );

		std::cout << "************************************************" << std::endl;
		std::cout << "*             Completed testing fold " << foldcounter       << "         *" << std::endl;
		std::cout << "************************************************" << std::endl;
		std::cout << "*             Best MAP....: " << pbest[MAP]       << std::endl;
		std::cout << "*             Best MRR....: " << pbest[MRR]       << std::endl;
		std::cout << "*             Best P@10...: " << pbest[PATTEN]    << std::endl;
		std::cout << "*             Best NDCG...: " << pbest[NDCG]      << std::endl;
		std::cout << "*             Best NDCG@10: " << pbest[NDCGTEN]   << std::endl;
		std::cout << "************************************************" << std::endl;
		std::cout << std::endl;
		std::cout << std::endl;
		foldcounter++;
	}
	std::cout << "************************************************" << std::endl;
	std::cout << "*             COMPLETED ALL FOLDS              *" << std::endl;
	std::cout << "*               PRINTING RESULTS               *" << std::endl;
	std::cout << "************************************************" << std::endl;
	std::vector<double>::iterator itr;
	int testfoldcounter = 1;
	for(itr = r.begin(); itr != r.end(); ++itr){
		std::cout << "Value of " << PERFORMANCE_MEASURE << " for test-fold " << testfoldcounter << " was: " << (*itr) << std::endl;
		testfoldcounter++;
	}
	std::cout << std::endl;
	double avgPerformance        = std::accumulate(r.begin(), r.end(), 0.0) / r.size();
	std::cout << "Average "<< PERFORMANCE_MEASURE << " across " << (testfoldcounter-1) << " folds: " << avgPerformance << std::endl;
	std::cout << std::endl;
	std::cout << std::endl;
	std::cout << std::endl;
	std::cout << "Printing averages for all specified performance measures..." << std::endl;
	double avgMAPPerformance     = std::accumulate(P_MAP.begin(), P_MAP.end(), 0.0) / P_MAP.size();
	std::cout << "Average MAP across " << (testfoldcounter-1) << " folds: " << avgMAPPerformance << std::endl;
	double avgMRRPerformance     = std::accumulate(P_MRR.begin(), P_MRR.end(), 0.0) / P_MRR.size();
	std::cout << "Average MRR across " << (testfoldcounter-1) << " folds: " << avgMRRPerformance << std::endl;
	double avgPTENPerformance    = std::accumulate(P_PATTEN.begin(), P_PATTEN.end(), 0.0) / P_PATTEN.size();
	std::cout << "Average P@10 across " << (testfoldcounter-1) << " folds: " << avgPTENPerformance << std::endl;
	double avgNDCGPerformance    = std::accumulate(P_NDCG.begin(), P_NDCG.end(), 0.0) / P_NDCG.size();
	std::cout << "Average NDCG across " << (testfoldcounter-1) << " folds: " << avgNDCGPerformance << std::endl;
	double avgNDCGTENPerformance = std::accumulate(P_NDCGTEN.begin(), P_NDCGTEN.end(), 0.0) / P_NDCGTEN.size();
	std::cout << "Average NDCG@10 across " << (testfoldcounter-1) << " folds: " << avgNDCGTENPerformance << std::endl;
}

void optimmeta3(Score * s, CVFOLDS folds, PConfig & c, const int NOFFOLDS){

	vector<double> parms;
	parms.push_back(  c.getFirstParameter()  );
	parms.push_back(  c.getSecondParameter() );
	parms.push_back(  c.getThirdParameter()  );

	std::string basefile = "/home/casper/cweb12-nostopwords-"+c.getRetrievalResults();

	s->setScoreModel(c.getModel(), parms);
	//MAP,MRR,PATTEN,NDCG,NDCGTEN
	RESULT P_MAP;
	RESULT P_MRR;
	RESULT P_PATTEN;
	RESULT P_NDCG;
	RESULT P_NDCGTEN;
	RESULT r;
	int foldcounter = 1;

	// Loads the MLE file
	//s->loadFile(c.getParameterFile());

	/* Load queries and their inverted lists */
	//s->loadQueries(c.getQueryIndex(), c.getQueryField());
	s->loadQueriesWStopwords(c.getQueryIndex(), c.getQueryField(), "/home/casper/sigir2016/code/DFR/stopwords.txt");
	s->loadInvertedIndex(c.getCollectionIndex(), c.getLaplaceNorm(), c.getBm25Norm(), c.getModelToEstimate());
	double cvals [6] = {0.5,1.0,2.0,4.0,6.0,8.0};
	//double cvals [11] = {0.5,0.75,1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0};
        //double cvals [2] = {0.1,0.2};
	CVFOLDS::iterator it;

	for(it = folds.begin(); it != folds.end(); ++it){

		/* Get training fold */
		std::vector<std::string> trainfold = it->second->getFold();

		/* Get the parameters of the highest-performing training is used for testing */
		double local_best_map = 0.0;
		double local_best_c   = cvals[0];
	        std::cerr << "Starting fold " << foldcounter << std::endl;
		map<std::string, double> pbest;

		for(int k = 0; k < 6; k++){
			std::string outputfile = basefile+"-"+std::to_string(cvals[k])+"-trainfold-"+SSTR(foldcounter);
			c.setRetrievalResults(outputfile);
			std::cout << "************************************************" << std::endl;
			std::cout << "*             Starting training fold " << foldcounter << " with c: " << cvals[k] << "          *" << std::endl;
			std::cout << "************************************************" << std::endl;
			pbest  = mydoscore(s, c, trainfold, cvals[k]);
			if(pbest[MAP] > local_best_map){
				local_best_map = pbest[MAP];
				local_best_c   = cvals[k];
			}
			std::cerr << "Finished c: " << cvals[k] << ", having MAP: " << pbest[MAP] << std::endl;
		}

		pbest.clear();
		std::cerr << "****************************************************************" << std::endl;
		std::cerr << "* " << idx::printTime() <<"       Completed training fold " << foldcounter      << "        *" << std::endl;
		std::cerr << "****************************************************************" << std::endl;
		std::cerr << "* Highest MAP was: " << local_best_map << " using c: " << local_best_c << std::endl;


		/* Evaluate on test fold */
		std::vector<std::string> testfold = it->first->getFold();

		//std::cerr << "*                 Running test-fold with optimal c                 *"<< std::endl;
	    std::cerr << "* " << idx::printTime() <<"       Running test-fold with optimal c for fold " << foldcounter      << "        *" << std::endl;
	    std::string outputfile = basefile+"-"+std::to_string(local_best_c)+"-testfold-"+SSTR(foldcounter);
	    c.setRetrievalResults(outputfile);
		pbest  = mydoscore(s, c, testfold, local_best_c);
		r.push_back( pbest[PERFORMANCE_MEASURE] );

		P_MAP.push_back(    pbest[MAP    ] );
		P_MRR.push_back(    pbest[MRR    ] );
		P_PATTEN.push_back( pbest[PATTEN ] );
		P_NDCG.push_back(   pbest[NDCG   ] );
		P_NDCGTEN.push_back(pbest[NDCGTEN] );

		std::cout << "************************************************" << std::endl;
		std::cout << "*             Completed testing fold " << foldcounter       << "         *" << std::endl;
		std::cout << "************************************************" << std::endl;
		std::cout << "*             Best MAP....: " << pbest[MAP]       << std::endl;
		std::cout << "*             Best MRR....: " << pbest[MRR]       << std::endl;
		std::cout << "*             Best P@10...: " << pbest[PATTEN]    << std::endl;
		std::cout << "*             Best NDCG...: " << pbest[NDCG]      << std::endl;
		std::cout << "*             Best NDCG@10: " << pbest[NDCGTEN]   << std::endl;
		std::cout << "************************************************" << std::endl;
		std::cout << std::endl;
		std::cout << std::endl;
		foldcounter++;
	}
	std::cout << "************************************************" << std::endl;
	std::cout << "*             COMPLETED ALL FOLDS              *" << std::endl;
	std::cout << "*               PRINTING RESULTS               *" << std::endl;
	std::cout << "************************************************" << std::endl;
	std::vector<double>::iterator itr;
	int testfoldcounter = 1;
	for(itr = r.begin(); itr != r.end(); ++itr){
		std::cout << "Value of " << PERFORMANCE_MEASURE << " for test-fold " << testfoldcounter << " was: " << (*itr) << std::endl;
		testfoldcounter++;
	}
	std::cout << std::endl;
	double avgPerformance        = std::accumulate(r.begin(), r.end(), 0.0) / r.size();
	std::cout << "Average "<< PERFORMANCE_MEASURE << " across " << (testfoldcounter-1) << " folds: " << avgPerformance << std::endl;
	std::cout << std::endl;
	std::cout << std::endl;
	std::cout << std::endl;
	std::cout << "Printing averages for all specified performance measures..." << std::endl;
	double avgMAPPerformance     = std::accumulate(P_MAP.begin(), P_MAP.end(), 0.0) / P_MAP.size();
	std::cout << "Average MAP across " << (testfoldcounter-1) << " folds: " << avgMAPPerformance << std::endl;
	double avgMRRPerformance     = std::accumulate(P_MRR.begin(), P_MRR.end(), 0.0) / P_MRR.size();
	std::cout << "Average MRR across " << (testfoldcounter-1) << " folds: " << avgMRRPerformance << std::endl;
	double avgPTENPerformance    = std::accumulate(P_PATTEN.begin(), P_PATTEN.end(), 0.0) / P_PATTEN.size();
	std::cout << "Average P@10 across " << (testfoldcounter-1) << " folds: " << avgPTENPerformance << std::endl;
	double avgNDCGPerformance    = std::accumulate(P_NDCG.begin(), P_NDCG.end(), 0.0) / P_NDCG.size();
	std::cout << "Average NDCG across " << (testfoldcounter-1) << " folds: " << avgNDCGPerformance << std::endl;
	double avgNDCGTENPerformance = std::accumulate(P_NDCGTEN.begin(), P_NDCGTEN.end(), 0.0) / P_NDCGTEN.size();
	std::cout << "Average NDCG@10 across " << (testfoldcounter-1) << " folds: " << avgNDCGTENPerformance << std::endl;
}


void CVModel::doCV(Score * s, PConfig c, int NOFFOLDS){
	/* Get the number of trials */
	NTRIALS             = c.getNofTrials();

	/* Get the performance measure to optimise for */
	PERFORMANCE_MEASURE = c.getPerformanceMeasure();
	std::set<std::string> PMEASURES = {MAP,MRR,PATTEN,NDCG,NDCGTEN};
	bool no_in = PMEASURES.find(PERFORMANCE_MEASURE) == PMEASURES.end();
	if(no_in){
		std::cerr << "CVModel :: Performance measure " << PERFORMANCE_MEASURE << " not valid. Exiting..." << std::endl;
		exit(EXIT_FAILURE);
	}

	/* Do CV train/test */
	CV * cv       = new CV(c.getQueryIndex());
	CVFOLDS folds = cv->createfolds(NOFFOLDS);
        //cv->printCrossFolds();
	// All I did (29-08-2016) was change from optimmeta3 to optimmeta2
	optimmeta3(s, folds, c, NOFFOLDS);
	delete cv;
}
