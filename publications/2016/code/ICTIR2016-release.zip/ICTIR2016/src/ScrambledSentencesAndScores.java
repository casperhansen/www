import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;
import java.util.TreeMap;

/**
 * The purpose of this class is:
 * To loop over all the files of either the Accidents or Earthquakes dataset. Each of the 100 files contain between
 * 1 and 20 permutations. Add the scores for BIP, ABIP and RED for each permutation and aggregate over them.
 */
public class ScrambledSentencesAndScores {
    private final int FILENAME_INDEX = 0;
    private final int BIP_INDEX      = 4;
    private final int ABIP_INDEX     = 5;
    private final int RED_INDEX      = 8;

    private TreeMap<Double, Double> agg_bip = new TreeMap<>();
    private TreeMap<Double, Double> agg_abip = new TreeMap<>();
    private TreeMap<Double, Double> agg_red = new TreeMap<>();

    public static void main(String[] args) throws IOException {
        // Argument is the folder containing either the accidents or earthquake dataset
        new ScrambledSentencesAndScores(args[0]);
    }

    public ScrambledSentencesAndScores(String dir) throws IOException {
        doProcess(dir);
    }

    private void doProcess(String dir) throws IOException {
        File content = new File(dir);
        File[] files = content.listFiles();
        for(File file : files){
            processFile(file.getAbsolutePath());
        }
        System.out.println();
        System.out.println();
        for(Map.Entry<Double, Double> entry : agg_red.entrySet()){
            System.out.println((int)Math.floor(entry.getKey()) + "\t" + entry.getValue()/(double)files.length);
        }
    }
/*
- field 1: name of the input document
- field 5: bipartite clustering coefficient
- field 6: asymmetric bipartite clustering coefficient
- field 9: redundancy coefficient
 */

    private void processFile(String filepath) throws IOException {
        System.out.println(filepath);
        TreeMap<Double, Double> POS_ACC = new TreeMap<>();
        FileReader fr = new FileReader(filepath);
        BufferedReader br = new BufferedReader(fr);
        String sCurrentLine;
        while((sCurrentLine = br.readLine()) != null){
            String[] parts = sCurrentLine.split(",");
            String[] permnr = parts[0].split("-");
            //System.out.println(parts[0] + ", permnr.length: " + permnr.length);
            if(permnr.length <= 2){
                POS_ACC.put(0.0,Double.parseDouble(parts[RED_INDEX]));
            }else {
                POS_ACC.put(Double.parseDouble(permnr[2]),Double.parseDouble(parts[RED_INDEX]));
            }
        }
        fr.close();
        br.close();

        // So now we have the <PERMUTATION, SCORE> map. Now, we can calculate the accuracy
        int N = POS_ACC.size();
        double[][] map = new double[N][2];
        int i = 0;
        for(Map.Entry<Double, Double> entry : POS_ACC.entrySet()){
            map[i][0] = entry.getKey();
            map[i][1] = entry.getValue();
            i++;
        }

        for(int j = 0; j < N; j++){
            System.out.println(map[j][0] + "," + map[j][1]);
        }
        System.out.println();
        System.out.println();


        for(int j = 0; j < map.length; j++){
            int val = 0;
            for(int k = 0; k < map.length; k++){
                if(j == k){continue;}
                if(map[k][1] <= map[j][1]){
                    val++;
                }
            }
            double acc = val/(double)map.length;

            if(agg_red.containsKey(map[j][0])){
                agg_red.put(map[j][0], agg_red.get(map[j][0])+acc);
            }else{
                agg_red.put(map[j][0], acc);
            }

            System.out.println("Acc for " + map[j][1] + " was: " + acc);
        }
        System.out.println("**************************************");
    }
}
