package accuracy;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class ProcessEarthQuakes {
    private final int BIP_INDEX        = 4;
    private final int ASSYM_BIP_INDEX  = 5;
    private final int REDUNDANCY_INDEX = 8;

    public static void main(String[] args) throws IOException{
        new ProcessEarthQuakes("/path/to/data/");
    }

    public ProcessEarthQuakes(String directory) throws IOException{
        File dir = new File(directory);
        File[] files = dir.listFiles();
        System.out.println("Found " + files.length + " files");

        double[][] results = new double[files.length][3];
        double acc_bip       = 0.0;
        double acc_assym_bip = 0.0;
        double acc_red       = 0.0;
        int filecounter = 0;
        for(File f : files){
            FileReader fr            = new FileReader(f.getAbsolutePath());
            BufferedReader br        = new BufferedReader(fr);
            String sCurrentLine      = br.readLine();
            int total_perms          = 0;
            int bip_good_perms       = 0; // A good perm is one with a score lower than the baseline
            int assym_bip_good_perms = 0; // A good perm is one with a score lower than the baseline
            int red_good_perms       = 0; // A good perm is one with a score lower than the baseline
            if(sCurrentLine != null) {
                String[] parts = sCurrentLine.split(",");
                double baseline_bip = Double.parseDouble(parts[BIP_INDEX]);
                double baseline_assym_bip = Double.parseDouble(parts[ASSYM_BIP_INDEX]);
                double baseline_red = Double.parseDouble(parts[REDUNDANCY_INDEX]);
                System.out.println(baseline_bip + "," + baseline_assym_bip + "," + baseline_red);
                while ((sCurrentLine = br.readLine()) != null) {
                    // Start processing of permuted files
                    parts = sCurrentLine.split(",");
                    double bip = Double.parseDouble(parts[BIP_INDEX]);
                    double assym_bip = Double.parseDouble(parts[ASSYM_BIP_INDEX]);
                    double red = Double.parseDouble(parts[REDUNDANCY_INDEX]);
                    if (bip <= baseline_bip) {
                        bip_good_perms++;
                    }
                    if (assym_bip <= baseline_assym_bip) {
                        assym_bip_good_perms++;
                    }
                    if (red <= baseline_red) {
                        red_good_perms++;
                    }
                    total_perms++;
                }
            }
            results[filecounter][0] = ((double)bip_good_perms)/total_perms;
            results[filecounter][1] = ((double)assym_bip_good_perms)/total_perms;
            results[filecounter][2] = ((double)red_good_perms)/total_perms;
            filecounter++;

            acc_bip += ((double)bip_good_perms)/total_perms;
            acc_assym_bip += ((double)assym_bip_good_perms)/total_perms;
            acc_red += ((double)red_good_perms)/total_perms;

            fr.close();
            br.close();
        }
        System.out.println("Average accuracy for BIP: " + (acc_bip/files.length));
        System.out.println("Average accuracy for assymetric BIP: " + (acc_assym_bip/files.length));
        System.out.println("Average accuracy for redundancy: " + (acc_red/files.length));
        System.out.println((acc_bip/files.length) + "," + (acc_assym_bip/files.length) + "," + (acc_red/files.length));
    }

}
