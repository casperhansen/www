import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class ReRankTestfile {
    private final int BIP_METRIC        = 0;
    private final int ASSYM_BIP_METRIC  = 1;
    private final int REDUNDANCY_METRIC = 2;

    private TreeMap<Integer, String> FOLD_TO_FILE      = new TreeMap<Integer, String>();
    private HashMap<Integer, Vector<ResultLine>> FOLDS = new HashMap<Integer, Vector<ResultLine>>();
    private HashMap<String, Document> lookup           = new HashMap<String, Document>();
    private final int MAP_INDEX = 0;
    private final int MRR_INDEX = 1;
    private final int P10_INDEX = 2;
    private final int NDCG10_INDEX = 3;
    private final int BPREF_INDEX = 4;

    /*
      First argument is the coherence scores
      Second argument is the output directory for the indri folds
      Third argument is the path to the qrels
      Fourth argument is the network metric (either 0,1 or 2);
     */
    public static void main(String[] args){
        if(args.length != 5){
            System.err.println("Error! Incorrect number of arguments");
            System.err.println("First argument.: Path to folder containing the coherence scores");
            System.err.println("Second argument: Path to folder containing the test-folds of cross-validation with RunXFoldDir.java (see /home/casper/sigir2016/code/java/ on angua");
            System.err.println("Third argument.: Path to the qrels file");
            System.err.println("Fourth argument: The network metric to use (must be either 0, 1 or 2)");
            System.err.println("Fifth argument.: The reranking procedure to use  (must be either 0 = original ictir paper, 1 = log, 2 = satu, 3 = sigm)");
        }
        new ReRankTestfile(args[0], args[1], args[2], args[3], args[4]);
    }

    public ReRankTestfile(String networkmetricfile, String indrioutputdir, String qrels, String metric, String rerankmethod){

        int networkmetric = Integer.parseInt(metric);
        int rerank        = Integer.parseInt(rerankmethod);
        if(!(networkmetric == 0 || networkmetric == 1 || networkmetric == 2)){
            System.err.println("Network metric must be either 0, 1 or 2");
            System.exit(-1);
        }

        populatelookup(networkmetricfile);
        locateTestFiles(indrioutputdir);
        System.out.println("Finished locating test files");
        readTestFiles();
        System.out.println("Finished reading test files");
        switch(rerank){
            case 0: reRank(qrels,     networkmetric);
                    break;
            case 1: reRanklog( qrels, networkmetric);
                    break;
            case 2: reRanksatu(qrels, networkmetric);
                    break;
            case 3: reRanksigm(qrels, networkmetric);
                    break;
            default: System.err.println("Illegal reranking method: " + rerankmethod);
                    break;
        }
        System.out.println("Finished!");
    }


    private void populatelookup(String directory){
        LoadFiles lf = null;
        try {
            lf = new LoadFiles();
            lf.doProcess(directory);
        } catch (IOException e) {
            e.printStackTrace();
        }
        assert lf != null;
        lookup = lf.getLookUp();
    }

    private void locateTestFiles(String directory){
        //System.out.println(directory);
        File dir = new File(directory);
        File[] files = dir.listFiles();
        for(File f : files){
            if(f.getAbsolutePath().contains("-test-")){
                String[] parts = f.getAbsolutePath().split("-");
                String tmp     = parts[parts.length-1];
                tmp            = tmp.replaceAll(".out.fixed", "");
                int foldnr = Integer.parseInt(tmp);
                FOLD_TO_FILE.put(foldnr, f.getAbsolutePath());
                System.out.println("Found " + f.getAbsolutePath() + " having fold number " + foldnr);
            }
        }
        System.out.println("Found " + FOLD_TO_FILE.size() + " test files in " + directory);
    }

    private void readTestFiles(){
        if(FOLD_TO_FILE.isEmpty()){
            System.err.println("Fold to file was empty");
            System.exit(-1);
        }

        for(Map.Entry<Integer, String> entry : FOLD_TO_FILE.entrySet()){
            FileReader fr = null;
            try {
                fr = new FileReader(entry.getValue());
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            assert fr != null;
            BufferedReader br = new BufferedReader(fr);
            String sCurrentLine;
            Vector<ResultLine> vs = new Vector<ResultLine>();
            try {
                while((sCurrentLine = br.readLine()) != null){
                    ResultLine rs = new ResultLine(sCurrentLine);
                    vs.add(rs);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            FOLDS.put(entry.getKey(), vs);
            try {
                fr.close();
                br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void reRank(String qrelsfile, int networkmetric){
        //String outpath      = "/home/casper/research/ictir2016/runs/decreasing/"+networkmetric+"/";
        String outpath      = "/home/casper/research/ictir2016/runs/increasing/"+networkmetric+"/";
        String summaryfile  = outpath+"summary";
        PrintWriter summary = null;
        try {
            summary = new PrintWriter(summaryfile);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        double[] alphas = {0.0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0};
        //double[] alphas = {0.3,0.5};

        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        for(Map.Entry<Integer, Vector<ResultLine>> entry : FOLDS.entrySet()){
            Vector<ResultLine> rs = entry.getValue();

            for(int i = 0; i < 10; i++){
                System.out.println(rs.get(i).getLine());
            }
            System.out.println();
            System.out.println();
            double BEST_MAP   = 0.0;
            double BEST_ALPHA = 0.0;
            for(double alpha : alphas){
                //TreeMap<Double, ResultLine> rerankeddocs = new TreeMap<Double, ResultLine>(Collections.reverseOrder());
                TreeMap<Double, ResultLine> rerankeddocs = new TreeMap<Double, ResultLine>();
                for(ResultLine r : rs){
                    if(lookup.containsKey(r.getFileName())){
                        Document d = lookup.get(r.getFileName());
                        rerankeddocs.put(score(r.getScore(), d.getMetric(networkmetric), alpha), r);
                    }
                    else{
                        rerankeddocs.put(score(r.getScore(), 0.0, alpha), r);
                    }
                }
                int ctr = 0;
                for(Map.Entry<Double, ResultLine> e : rerankeddocs.entrySet()){
                    System.out.println(e.getValue().getQueryID() + " Q0 " + e.getValue().getFileName() + " " + (ctr+1) + " " + e.getKey() + " ictir2016");
                    ctr++;
                    if(ctr == 10){
                        break;
                    }
                }

                System.exit(-1);
                /*
                 Now we need to sort the scores, reconstruct the entries and trec_eval it
                 Because we use a treemap, positive scores are ordered from highest to lowest.
                 i.e. 7 > 6 > 2

                 Negative scores are ordered similarly i.e
                 -0.2 > -1.4 > -9.0
                 */
                int position = 1;
                String out = outpath+"foldnr-"+entry.getKey()+"-alpha-"+alpha+".txt";
                PrintWriter pw = null;
                try {
                     pw = new PrintWriter(out);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                assert pw != null;
                for(Map.Entry<Double, ResultLine> e : rerankeddocs.entrySet()){
                    pw.println(e.getValue().getQueryID() + " Q0 " + e.getValue().getFileName() + " " + position + " " + e.getKey() + " ictir2016");
                    position++;
                }

                pw.flush();
                pw.close();


                double[] x = doTrecEval(qrelsfile,out);
                Date date = new Date();
                System.out.println(dateFormat.format(date) + " :: Finished evaluating fold " + entry.getKey() + " for alpha " + alpha);

                if(x[MAP_INDEX] > BEST_MAP){
                    BEST_MAP   = x[MAP_INDEX];
                    BEST_ALPHA = alpha;
                }
            }
            System.out.println();
            System.out.println("*******************************************************************************************************");
            System.out.println("*                             FINISHED FOLD NUMBER " + entry.getKey() + "                                                  *");
            System.out.println("*                             Best alpha value: " + BEST_ALPHA + "                                                   *");
            System.out.println("*                             Best MAP value..: " + BEST_MAP   + "                                                 *");
            System.out.println("*******************************************************************************************************");
            System.out.println();

            summary.println();
            summary.println("*******************************************************************************************************");
            summary.println("*                             FINISHED FOLD NUMBER " + entry.getKey() + "                                                  *");
            summary.println("*                             Best alpha value: " + BEST_ALPHA + "                                                   *");
            summary.println("*                             Best MAP value..: " + BEST_MAP   + "                                                 *");
            summary.println("*******************************************************************************************************");
            summary.println();
        }
        summary.flush();
        summary.close();
    }

    /*
    This method implements the log re-ranking from "Relevance Weighting for Query Independent Evidence"
    */
    private void reRanklog(String qrelsfile, int networkmetric){
        String outpath      = "/home/casper/research/ictir2016/runs/RWQIE/log/"+networkmetric+"/";
        System.out.println("Writing to " + outpath);
        String summaryfile  = outpath+"summary";

        PrintWriter summary = null;
        PrintWriter map     = null;
        try {
            summary = new PrintWriter(summaryfile);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        final int nof_weights = 600;
        double[] ws = new double[nof_weights];
        for(int i = 0; i < nof_weights; i++){
            ws[i] = -3+(i*0.01);
        }



        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        for(Map.Entry<Integer, Vector<ResultLine>> entry : FOLDS.entrySet()){
            Vector<ResultLine> rs = entry.getValue();

            String mapfile      = outpath+"foldnr-"+entry.getKey()+"-MAP";
            try {
                map     = new PrintWriter(mapfile);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }

            double BEST_MAP    = 0.0;
            double BEST_WEIGHT = 0.0;
            String BEST_FILE   = "";
            final double EPS   = 0.00000001;
            for(double w : ws){
                TreeMap<Double, ResultLine> rerankeddocs = new TreeMap<Double, ResultLine>(Collections.reverseOrder());
                //TreeMap<Double, ResultLine> rerankeddocs = new TreeMap<Double, ResultLine>();
                for(ResultLine r : rs){
                    if(lookup.containsKey(r.getFileName())){
                        Document d = lookup.get(r.getFileName());
                        rerankeddocs.put(score_log(r.getScore(), d.getMetric(networkmetric), w)+EPS, r);
                    }
                    else{
                        rerankeddocs.put(score_log(r.getScore(), 0.0, w)+EPS, r);
                    }
                }

                /*
                 Now we need to sort the scores, reconstruct the entries and trec_eval it
                 Because we use a treemap, positive scores are ordered from highest to lowest.
                 i.e. 7 > 6 > 2

                 Negative scores are ordered similarly i.e
                 -0.2 > -1.4 > -9.0
                 */
                int position = 1;
                String out = outpath+"foldnr-"+entry.getKey()+"-weight-"+w+".txt";
                PrintWriter pw = null;
                try {
                    pw = new PrintWriter(out);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                assert pw != null;
                for(Map.Entry<Double, ResultLine> e : rerankeddocs.entrySet()){
                    pw.println(e.getValue().getQueryID() + " Q0 " + e.getValue().getFileName() + " " + position + " " + e.getKey() + " ictir2016");
                    position++;
                }

                pw.flush();
                pw.close();


                double[] x = doTrecEval(qrelsfile,out);
                if(x[MAP_INDEX] > BEST_MAP){
                    BEST_MAP    = x[MAP_INDEX];
                    BEST_WEIGHT = w;
                    BEST_FILE   = outpath+"foldnr-"+entry.getKey()+"-weight-"+w+".txt";
                }

                map.println(w + "," + x[MAP_INDEX]);

                //Date date = new Date();
                //System.out.println(dateFormat.format(date) + " :: Finished evaluating fold " + entry.getKey() + " for alpha " + w);

            }
            map.flush();
            map.close();
            System.out.println();
            System.out.println("*******************************************************************************************************");
            System.out.println("*                             FINISHED FOLD NUMBER " + entry.getKey() + "                                                  *");
            System.out.println("*                             Best w value....: " + BEST_WEIGHT + "                                                   *");
            System.out.println("*                             Best MAP value..: " + BEST_MAP   + "                                                 *");
            System.out.println("*******************************************************************************************************");
            System.out.println();

            summary.println(BEST_FILE);
/*
            summary.println();
            summary.println("*******************************************************************************************************");
            summary.println("*                             FINISHED FOLD NUMBER " + entry.getKey() + "                                                  *");
            summary.println("*                             Best w value....: " + BEST_WEIGHT + "                                                   *");
            summary.println("*                             Best MAP value..: " + BEST_MAP   + "                                                 *");
            summary.println("*******************************************************************************************************");
            summary.println();
*/
        }
        summary.flush();
        summary.close();
    }

    /*
    This method implements the log re-ranking from "Relevance Weighting for Query Independent Evidence"
    */
    private void reRanksatu(String qrelsfile, int networkmetric){
        //String outpath      = "/home/casper/research/ictir2016/runs/decreasing/"+networkmetric+"/";
        String outpath      = "/home/casper/research/ictir2016/runs/RWQIE/satu/"+networkmetric+"/";
        String summaryfile  = outpath+"summary";

        PrintWriter summary = null;
        try {
            summary = new PrintWriter(summaryfile);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        final int nof_weights = 100;
        double[] ws = new double[nof_weights];
        for(int i = 0; i < nof_weights; i++){
            ws[i] = -1+(i*0.02);
        }

        final int nof_ks = 100;
        double[] ks = new double[nof_ks];
        for(int j = 0; j < nof_ks; j++){
            ks[j] = -1*(j*0.02);
        }

        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        for(Map.Entry<Integer, Vector<ResultLine>> entry : FOLDS.entrySet()){
            Vector<ResultLine> rs = entry.getValue();

            double BEST_MAP    = 0.0;
            double BEST_WEIGHT = 0.0;
            double BEST_K      = 0.0;
            String BEST_FILE   = "";
            for(double w : ws){
                for(double k : ks) {
                    TreeMap<Double, ResultLine> rerankeddocs = new TreeMap<Double, ResultLine>(Collections.reverseOrder());
                    for (ResultLine r : rs) {
                        if (lookup.containsKey(r.getFileName())) {
                            Document d = lookup.get(r.getFileName());
                            rerankeddocs.put(score_satu(r.getScore(), d.getMetric(networkmetric), k, w), r);
                        } else {
                            rerankeddocs.put(score_satu(r.getScore(), 0.0, k, w), r);
                        }
                    }

                    /*
                     Now we need to sort the scores, reconstruct the entries and trec_eval it
                     Because we use a treemap, positive scores are ordered from highest to lowest.
                     i.e. 7 > 6 > 2

                     Negative scores are ordered similarly i.e
                     -0.2 > -1.4 > -9.0
                     */
                    int position = 1;
                    String out = outpath + "foldnr-" + entry.getKey() + "-weight-" + w + "-k-"+k+".txt";
                    PrintWriter pw = null;
                    try {
                        pw = new PrintWriter(out);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                    assert pw != null;
                    for (Map.Entry<Double, ResultLine> e : rerankeddocs.entrySet()) {
                        pw.println(e.getValue().getQueryID() + " Q0 " + e.getValue().getFileName() + " " + position + " " + e.getKey() + " ictir2016");
                        position++;
                    }

                    pw.flush();
                    pw.close();


                    double[] x = doTrecEval(qrelsfile, out);

                    if (x[MAP_INDEX] > BEST_MAP) {
                        BEST_MAP    = x[MAP_INDEX];
                        BEST_WEIGHT = w;
                        BEST_K      = k;
                        BEST_FILE   = outpath + "foldnr-" + entry.getKey() + "-weight-" + w + "-k-"+k+".txt";
                    }
                }
            }
            summary.println(BEST_FILE);

            System.out.println();
            System.out.println("*******************************************************************************************************");
            System.out.println("*                             FINISHED FOLD NUMBER " + entry.getKey() + "                                                  *");
            System.out.println("*                             Best w value....: " + BEST_WEIGHT + "                                                   *");
            System.out.println("*                             Best k value....: " + BEST_K + "                                                   *");
            System.out.println("*                             Best MAP value..: " + BEST_MAP   + "                                                 *");
            System.out.println("*******************************************************************************************************");
            System.out.println();
        }
        summary.flush();
        summary.close();
    }


    private void reRanksigm(String qrelsfile, int networkmetric){
        //String outpath      = "/home/casper/research/ictir2016/runs/decreasing/"+networkmetric+"/";
        String outpath      = "/home/casper/research/ictir2016/runs/RWQIE/sigm/"+networkmetric+"/";
        String summaryfile  = outpath+"summary";

        PrintWriter summary = null;
        try {
            summary = new PrintWriter(summaryfile);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        final int nof_weights = 20;
        double[] ws = new double[nof_weights];
        for(int i = 0; i < nof_weights; i++){
            ws[i] = -1+(i*0.1);
        }

        final int nof_ks = 20;
        double[] ks = new double[nof_ks];
        for(int j = 0; j < nof_ks; j++){
            ks[j] = -1+(j*0.1);
        }

        final int nof_as = 10;
        double[] as = new double[nof_as];
        for(int t = 0; t < nof_as; t++){
            as[t] = -1+(t*0.2);
        }

        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        for(Map.Entry<Integer, Vector<ResultLine>> entry : FOLDS.entrySet()){
            Vector<ResultLine> rs = entry.getValue();

            double BEST_MAP    = 0.0;
            double BEST_WEIGHT = 0.0;
            double BEST_K      = 0.0;
            double BEST_A      = 0.0;
            String BEST_FILE   = "";
            for(double w : ws){
                for(double k : ks) {
                    for(double a : as) {
                        TreeMap<Double, ResultLine> rerankeddocs = new TreeMap<Double, ResultLine>(Collections.reverseOrder());
                        for (ResultLine r : rs) {
                            if (lookup.containsKey(r.getFileName())) {
                                Document d = lookup.get(r.getFileName());
                                rerankeddocs.put(score_satu(r.getScore(), d.getMetric(networkmetric), k, w), r);
                            } else {
                                rerankeddocs.put(score_satu(r.getScore(), 0.0, k, w), r);
                            }
                        }

                    /*
                     Now we need to sort the scores, reconstruct the entries and trec_eval it
                     Because we use a treemap, positive scores are ordered from highest to lowest.
                     i.e. 7 > 6 > 2

                     Negative scores are ordered similarly i.e
                     -0.2 > -1.4 > -9.0
                     */
                        int position = 1;
                        String out = outpath + "foldnr-" + entry.getKey() + "-weight-" + w + "-k-" + k + "-a-"+a+".txt";
                        PrintWriter pw = null;
                        try {
                            pw = new PrintWriter(out);
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }
                        assert pw != null;
                        for (Map.Entry<Double, ResultLine> e : rerankeddocs.entrySet()) {
                            pw.println(e.getValue().getQueryID() + " Q0 " + e.getValue().getFileName() + " " + position + " " + e.getKey() + " ictir2016");
                            position++;
                        }

                        pw.flush();
                        pw.close();


                        double[] x = doTrecEval(qrelsfile, out);

                        if (x[MAP_INDEX] > BEST_MAP) {
                            BEST_MAP = x[MAP_INDEX];
                            BEST_WEIGHT = w;
                            BEST_K = k;
                            BEST_A = a;
                            BEST_FILE = out;
                        }
                    }
                }
            }
            summary.println(BEST_FILE);

            System.out.println();
            System.out.println("*******************************************************************************************************");
            System.out.println("*                             FINISHED FOLD NUMBER " + entry.getKey() + "                                                  *");
            System.out.println("*                             Best w value....: " + BEST_WEIGHT + "                                                   *");
            System.out.println("*                             Best k value....: " + BEST_K + "                                                   *");
            System.out.println("*                             Best a value....: " + BEST_A + "                                                   *");
            System.out.println("*                             Best MAP value..: " + BEST_MAP   + "                                                 *");
            System.out.println("*******************************************************************************************************");
            System.out.println();
        }
        summary.flush();
        summary.close();
    }


    private double score(double rsv, double coh, double alpha_parameter){
        return (rsv * alpha_parameter + coh * (1 - alpha_parameter));
    }

    private double score_log(double rsv, double S, double w){
        return (rsv + (Math.exp(S) * w));
    }

    private double score_satu(double rsv, double S, double k, double w){
        return (rsv + (w * S/(k+S)));
    }

    private double score_sigm(double rsv, double S, double k, double alpha, double w){
        return (rsv + (w * Math.pow(S,alpha)/(Math.pow(k,alpha)+Math.pow(S,alpha))));
    }

    private double[] doTrecEval(String qrels_file, String file){
        //System.out.println(qrels_file + " :: " + file);
        //Vector<Double> x = new Vector<Double>(100);
        double[] x = new double[5];
        try {
            String[] command4 = {"trec_eval", "-m", "ndcg_cut", "-m", "map", "-m", "recip_rank", "-m", "bpref", "-m", "P" ,qrels_file, file};
            final Process proc = Runtime.getRuntime().exec(command4);

            try {
                proc.waitFor();
            } catch (final InterruptedException e) {
                e.printStackTrace();
            }

            final BufferedReader outputReader = new BufferedReader(new InputStreamReader(proc
                    .getInputStream()));
            final BufferedReader errorReader = new BufferedReader(new InputStreamReader(proc
                    .getErrorStream()));

            String line;
            while ((line = outputReader.readLine()) != null) {
                //System.out.println(line);
                double map_local    = 0.0;
                double mrr_local    = 0.0;
                double p10_local    = 0.0;
                double ndcg10_local = 0.0;
                double bpref_local  = 0.0;
                String[] parts = line.split("\\s+");
                if (parts[0].trim().equalsIgnoreCase("map")) {
                    //System.out.println("b: " + bval + ", MAP: " + parts[2]);
                    map_local = Double.valueOf(parts[2]);
                    //x.add(MAP_INDEX,map_local);
                    x[0] = map_local;
                }
                if(parts[0].trim().equalsIgnoreCase("recip_rank")){
                    //System.out.println("b: " + bval + ", MRR: " + parts[2]);
                    mrr_local      = Double.valueOf(parts[2]);
                    //x.add(MRR_INDEX,mrr_local);
                    x[1] = mrr_local;
                }
                if(parts[0].trim().equalsIgnoreCase("P_10")){
                    //System.out.println("b: " + bval + ", P@10: " + parts[2]);
                    p10_local      = Double.valueOf(parts[2]);
                    //x.add(P10_INDEX, p10_local);
                    x[2] = p10_local;
                }
/*
                if(parts[0].trim().equalsIgnoreCase("ndcg")){
                    //System.out.println("b: " + bval + ", nDCG: " + parts[2]);
                    ndcg_local     = Double.valueOf(parts[2]);
                    x.add(ndcg_local);
                }
*/
                if(parts[0].trim().equalsIgnoreCase("ndcg_cut_10")){
                    //System.out.println("b: " + bval + ", nDCG@10: " + parts[2]);
                    ndcg10_local   = Double.valueOf(parts[2]);
                    //x.add(NDCG10_INDEX, ndcg10_local);
                    x[3] = ndcg10_local;
                }

                if(parts[0].trim().equalsIgnoreCase("bpref")){
                    //System.out.println("b: " + bval + ", nDCG@10: " + parts[2]);
                    bpref_local   = Double.valueOf(parts[2]);
                    //x.add(BPREF_INDEX, bpref_local);
                    x[4] = bpref_local;
                }

            }
            outputReader.close();
            while ((line = errorReader.readLine()) != null) {
                System.err.println(line);
            }
            errorReader.close();
        } catch (final IOException e) {
            e.printStackTrace();
        }
        return x;
    }
}



