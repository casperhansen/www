import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.Map;
import java.util.Vector;

public class RunXFoldDirLemur {

    /*
       /home/casper/TREC-123-folds.txt \/home\/casper\/indexes\/TREC\/TREC-123-adhoc\/index\/trec-123-collection-adhoc-stop-porter /home/casper/indexes/TREC/TREC-123-adhoc/qrels/qrels-trec-123.all
       /home/casper/TREC-8-folds.txt \/home\/casper\/indexes\/TREC\/TREC-8-adhoc\/index\/trec8-collection-stop-porter /home/casper/indexes/TREC/TREC-8-adhoc/qrels/qrels.trec8.adhoc

       /home/casper/trec-123/trec-123-folds.txt \/home\/casper\/indexes\/TREC\/TREC-123-adhoc\/index\/trec-123-collection-nostop-nostem/ /home/casper/indexes/TREC/TREC-123-adhoc/qrels/qrels-trec-123.all
     */


    private Vector<String> PATHS              = new Vector<String>();
    private Vector<MTestTrainPair2> CVPAIRS    = new Vector<MTestTrainPair2>();
    private int NUM_FOLDS                     = 0;
    private double ACC_MAP_SCORE              = 0.0;
    private double ACC_MRR_SCORE              = 0.0;
    private double ACC_P10_SCORE              = 0.0;
    private double ACC_NDCG_SCORE             = 0.0;
    private double ACC_NDCG10_SCORE           = 0.0;
    private double ACC_BPREF_SCORE            = 0.0;
    private double ACC_ERR10_SCORE            = 0.0;
    private double ACC_ERR20_SCORE            = 0.0;
    private int BEST_MU                       = 0;
    private double BEST_MAP_VAL               = 0.0;

    public static void main(String[] args){
        /*
          Assume argument is a file containing the paths to the training and test sets
          Lines in the file must specify an Indri query file, and must be in the order:
          <testing-file-fold-0>
          <training-file-fold-0>
          <testing-file-fold-1>
          <training-file-fold-1>
          .
          .
          <testing-file-fold-n>
          <training-file-fold-n>
          The indri query file (assuming here only BM25) can be found examples of at:
          C:\Casper\Universitet\PhD\Queries\cweb09\baseline
          */
        // Argument: Above file, indexlocation, location of qrels and lemur index file (see the comment below)
        new RunXFoldDirLemur(args[0], args[1], args[2], args[3]);
    }

    /*

    <parameters>
    <index>/home/casper/indexes/trec-123-collection-nostop-nostem/</index>
    <textQuery>/home/casper/tmp/lemur.out</textQuery>
    <resultFile>/home/casper/results.txt</resultFile>
    <resultCount>1000</resultCount>
    <retModel>2</retModel>
    <adjustedScoreMethod>ql</adjustedScoreMethod>
    <DirichletPrior>1000</DirichletPrior>
    </parameters>

     */

    // The folds contain the actual queries. We keep this as is.....
    private void readfolds(String file){
        FileReader fr = null;
        try {
            fr = new FileReader(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        BufferedReader br   = new BufferedReader(fr);
        String sCurrentLine = "";
        int counter         = 0;
        try {
            while((sCurrentLine = br.readLine()) != null){
                counter++;
                PATHS.add(sCurrentLine);
            }
        } catch (IOException e) {
            System.err.println("Could not read line after " + sCurrentLine);
            e.printStackTrace();
            System.exit(-1);
        }
        try {
            fr.close();
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        int CVPAIRSADDED = 0;
        for(int j = 0; j < PATHS.size(); j += 2){
            MTestTrainPair2 tp = new MTestTrainPair2(PATHS.get(j), PATHS.get(j+1));
            CVPAIRS.add(tp);
            CVPAIRSADDED++;
        }
        System.out.println("Read " + counter + " paths from " + file + " and added " + CVPAIRSADDED + " x-fold pairs");
    }

    public RunXFoldDirLemur(String file, String indexlocation, String qrels_file, String lemurfile){
        readfolds(file);
        int[] mu        = {100, 500, 800, 1000, 2000, 3000, 4000, 5000, 8000, 10000};

        // How many folds
        NUM_FOLDS = (int)PATHS.size()/2;
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        for(int foldnr = 0; foldnr < NUM_FOLDS; foldnr++){
            MTestTrainPair2 fold = CVPAIRS.elementAt(foldnr);
            String train = fold.getTrainingFile();
            System.out.println("Starting training for fold: " + foldnr);
            //Train
            for(int j = 0; j < mu.length; j++) {
                Date date             = new Date();
                System.out.println(dateFormat.format(date) + " - Starting mu: " + mu[j]);
                run(train, indexlocation, qrels_file, mu[j], true, foldnr, lemurfile);
            }
            System.out.println("Finished all training folds");
            //System.out.println("Best mu: " + BEST_MU);
            // Test
            String test = fold.getTestingFile();
            System.out.println("Starting testing for fold: " + foldnr);
            Vector<Double> x = run(test, indexlocation, qrels_file, BEST_MU, false, foldnr, lemurfile);
            Date date = new Date();
            System.out.println(dateFormat.format(date) + " :: Finished testing for fold: " + foldnr);
            System.out.println("**************************");
            System.out.println("MAP....: " + x.elementAt(0));
            System.out.println("MRR....: " + x.elementAt(1));
            System.out.println("P@10...: " + x.elementAt(2));
            System.out.println("nDCG...: " + x.elementAt(3));
            System.out.println("nDCG@10: " + x.elementAt(4));
            System.out.println("bpref..: " + x.elementAt(5));
            System.out.println("ERR@10.: " + x.elementAt(6));
            System.out.println("ERR@20.: " + x.elementAt(7));
            System.out.println("**************************");
            ACC_MAP_SCORE    = ACC_MAP_SCORE + x.elementAt(0);
            ACC_MRR_SCORE    = ACC_MRR_SCORE + x.elementAt(1);
            ACC_P10_SCORE    = ACC_P10_SCORE + x.elementAt(2);
            ACC_NDCG_SCORE   = ACC_NDCG_SCORE + x.elementAt(3);
            ACC_NDCG10_SCORE = ACC_NDCG10_SCORE + x.elementAt(4);
            ACC_BPREF_SCORE  = ACC_BPREF_SCORE + x.elementAt(5);
            ACC_ERR10_SCORE  = ACC_ERR10_SCORE + x.elementAt(6);
            ACC_ERR20_SCORE  = ACC_ERR20_SCORE + x.elementAt(7);
            BEST_MU          = 0;
            BEST_MAP_VAL     = 0.0;
        }

        double AVG_MAP_SCORE    = ACC_MAP_SCORE/(double)NUM_FOLDS;
        double AVG_MRR_SCORE    = ACC_MRR_SCORE/(double)NUM_FOLDS;
        double AVG_P10_SCORE    = ACC_P10_SCORE/(double)NUM_FOLDS;
        double AVG_NDCG_SCORE   = ACC_NDCG_SCORE/(double)NUM_FOLDS;
        double AVG_NDCG10_SCORE = ACC_NDCG10_SCORE/(double)NUM_FOLDS;
        double AVG_ERR10_SCORE  = ACC_ERR10_SCORE/(double)NUM_FOLDS;
        double AVG_ERR20_SCORE  = ACC_ERR20_SCORE/(double)NUM_FOLDS;
        double AVG_BPREF_SCORE  = ACC_BPREF_SCORE/(double)NUM_FOLDS;
        System.out.println("Average MAP score across all folds....: " + AVG_MAP_SCORE);
        System.out.println("Average MRR score across all folds....: " + AVG_MRR_SCORE);
        System.out.println("Average P@10 score across all folds...: " + AVG_P10_SCORE);
        System.out.println("Average nDCG score across all folds...: " + AVG_NDCG_SCORE);
        System.out.println("Average nDCG@10 score across all folds: " + AVG_NDCG10_SCORE);
        System.out.println("Average BPREF score across all folds..: " + AVG_BPREF_SCORE);
        System.out.println("Average ERR@10 score across all folds.: " + AVG_ERR10_SCORE);
        System.out.println("Average ERR@20 score across all folds.: " + AVG_ERR20_SCORE);
    }

    private Vector<Double> run(String file, String indexlocation, String qrels_file, int muval, boolean isTrain, int foldnr, String lemurfile) {

        // Change the index
        String tmp = "2s/.*/<index>" + indexlocation + "<\\/index>/";
        String[] command = {"sed", "-i", tmp, lemurfile};

        Process runSedCommand = null;
        try {
            runSedCommand = Runtime.getRuntime().exec(command);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            runSedCommand.waitFor();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        runSedCommand.destroy();

        // Change the index
        tmp = "3s/.*/<textQuery>" + file + "<\\/textQuery>/";
        String[] command2 = {"sed", "-i", tmp, lemurfile};

        Process runSedCommand2 = null;
        try {
            runSedCommand2 = Runtime.getRuntime().exec(command2);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            runSedCommand2.waitFor();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        runSedCommand2.destroy();


        // Now we can run the IndriRunQuery
        String writefile = "";
        if(isTrain){
            writefile = "/home/casper/lmdir-baseline-train-mu:"+muval+"-foldnr-"+foldnr+".out";
        }else{
            writefile = "/home/casper/lmdir-baseline-test-mu:"+ muval+"-foldnr-"+foldnr+".out";
        }

        // Set the outputfile
        tmp = "4s/.*/<resultFile>"+writefile+"<\\/resultFile>/";
        String[] command3 = {"sed", "-i", tmp, lemurfile};
        Process runSedCommand3 = null;
        try {
            runSedCommand3 = Runtime.getRuntime().exec(command3);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            runSedCommand3.waitFor();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        runSedCommand3.destroy();


        tmp = "8s/.*/<DirichletPrior>"+muval+"<\\/DirichletPrior>/";
        System.out.println(tmp);
        String[] command4 = {"sed", "-i", tmp, lemurfile};
        Process runSedCommand4 = null;
        try {
            runSedCommand4 = Runtime.getRuntime().exec(command4);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            runSedCommand4.waitFor();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        runSedCommand4.destroy();


        try {

              String[] command5 = {"/home/casper/lemur/bin/RetEval", lemurfile};
              Process proc = null;
              try{
                proc = Runtime.getRuntime().exec(command5);
              }catch (IOException e) {
                e.printStackTrace();
              }
              try {
                   proc.waitFor();
              } catch (final InterruptedException e) {
                   e.printStackTrace();
              }


              final BufferedReader errorReader = new BufferedReader(new InputStreamReader(proc
                    .getErrorStream()));
              String line = "";
              while ((line = errorReader.readLine()) != null) {
                    System.err.println(line);
              }



        } catch (final IOException e) {
          e.printStackTrace();
        }

        // Now we can run trec_eval

        Vector<Double> x = new Vector<Double>();

        try {
            String[] command6 = {"trec_eval", "-m", "ndcg", "-m", "ndcg_cut", "-m", "map", "-m", "recip_rank", "-m", "bpref", "-m", "P" ,qrels_file, writefile};
            final Process proc = Runtime.getRuntime().exec(command6);

            try {
                proc.waitFor();
            } catch (final InterruptedException e) {
                e.printStackTrace();
            }

            final BufferedReader outputReader = new BufferedReader(new InputStreamReader(proc
                    .getInputStream()));
            final BufferedReader errorReader = new BufferedReader(new InputStreamReader(proc
                    .getErrorStream()));

            String line;
            while ((line = outputReader.readLine()) != null) {
                //System.out.println(line);
                double map_local    = 0.0;
                double mrr_local    = 0.0;
                double p10_local    = 0.0;
                double ndcg_local   = 0.0;
                double ndcg10_local = 0.0;
                double bpref_local  = 0.0;
                String[] parts = line.split("\\s+");
                if (parts[0].trim().equalsIgnoreCase("map")) {
                    //System.out.println("b: " + bval + ", MAP: " + parts[2]);
                    map_local = Double.valueOf(parts[2]);
                    if (map_local > BEST_MAP_VAL) {
                        BEST_MAP_VAL = map_local;
                        BEST_MU      = muval;
                    }
                    x.add(map_local);
                }
                if(parts[0].trim().equalsIgnoreCase("recip_rank")){
                    //System.out.println("b: " + bval + ", MRR: " + parts[2]);
                    mrr_local      = Double.valueOf(parts[2]);
                    x.add(mrr_local);
                }
                if(parts[0].trim().equalsIgnoreCase("P_10")){
                    //System.out.println("b: " + bval + ", P@10: " + parts[2]);
                    p10_local      = Double.valueOf(parts[2]);
                    x.add(p10_local);
                }
                if(parts[0].trim().equalsIgnoreCase("ndcg")){
                    //System.out.println("b: " + bval + ", nDCG: " + parts[2]);
                    ndcg_local     = Double.valueOf(parts[2]);
                    x.add(ndcg_local);
                }
                if(parts[0].trim().equalsIgnoreCase("ndcg_cut_10")){
                    //System.out.println("b: " + bval + ", nDCG@10: " + parts[2]);
                    ndcg10_local   = Double.valueOf(parts[2]);
                    x.add(ndcg10_local);
                }
                if(parts[0].trim().equalsIgnoreCase("bpref")){
                    //System.out.println("b: " + bval + ", nDCG@10: " + parts[2]);
                    bpref_local   = Double.valueOf(parts[2]);
                    x.add(bpref_local);
                }
            }
            x.add(1.0);
            x.add(1.0);

            while ((line = errorReader.readLine()) != null) {
                System.err.println(line);
            }
        } catch (final IOException e) {
            e.printStackTrace();
        }

        return x;
    }
}

class MTestTrainPair2{
    private String testFile;
    private String trainFile;
    public MTestTrainPair2(String test, String train){
        testFile  = test;
        trainFile = train;
    }

    public String getTrainingFile(){
        return trainFile;
    }

    public String getTestingFile(){
        return testFile;
    }
}
