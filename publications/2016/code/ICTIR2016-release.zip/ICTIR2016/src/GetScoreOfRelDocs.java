import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils;
import javafx.util.Pair;

import java.io.*;
import java.util.*;


public class GetScoreOfRelDocs {
    private TreeMap<Integer, String> FOLD_TO_FILE                       = new TreeMap<Integer, String>();
    private HashMap<Integer, TreeMap<String, Vector<ResultLine>>> FOLDS = new HashMap<Integer, TreeMap<String, Vector<ResultLine>>>();
    private HashMap<String, TreeMap<String, Integer>>             QRELS = new HashMap<>();

    public static void main(String[] args) throws IOException {
        new GetScoreOfRelDocs(args[0], args[1]);
    }

    public GetScoreOfRelDocs(String testfiledirectory, String qrelsfile) throws IOException {
        locateTestFiles(testfiledirectory);
        readTestFiles();
        loadQrelsFile(qrelsfile);
        loop();
    }

    private void locateTestFiles(String directory){
        //System.out.println(directory);
        File dir = new File(directory);
        File[] files = dir.listFiles();
        for(File f : files){
            if(f.getAbsolutePath().contains("-test-")){
                String[] parts = f.getAbsolutePath().split("-");
                String tmp     = parts[parts.length-1];
                tmp            = tmp.replaceAll(".out.fixed", "");
                int foldnr = Integer.parseInt(tmp);
                FOLD_TO_FILE.put(foldnr, f.getAbsolutePath());
                System.out.println("Found " + f.getAbsolutePath() + " having fold number " + foldnr);
            }
        }
        System.out.println("Found " + FOLD_TO_FILE.size() + " test files in " + directory);
    }

    private void loadQrelsFile(String qrelsfile) throws IOException {
        FileReader fr = new FileReader(qrelsfile);
        BufferedReader br = new BufferedReader(fr);
        String sCurrentLine = br.readLine();
        String[] parts      = sCurrentLine.split("\\s+");
        String prev_id      = parts[0];
        TreeMap<String, Integer> docs = new TreeMap<>();
        docs.put(parts[2], Integer.parseInt(parts[3]));
        while((sCurrentLine = br.readLine()) != null){
            parts = sCurrentLine.split("\\s+");
            if(parts[0].equalsIgnoreCase(prev_id)){
                //Same as what we've seen so far
                docs.put(parts[2], Integer.parseInt(parts[3]));
            }else{
                // We have encountered a new query id. Insert the old one, clear it and loop around
                QRELS.put(prev_id, docs);
                docs = new TreeMap<String, Integer>();
                prev_id = parts[0];
                docs.put(parts[2], Integer.parseInt(parts[3]));
            }
        }
        QRELS.put(prev_id, docs);
        fr.close();
        br.close();
    }

    private void readTestFiles(){
        if(FOLD_TO_FILE.isEmpty()){
            System.err.println("Fold to file was empty");
            System.exit(-1);
        }
        HashSet<String> ids = new HashSet<>();
        for(Map.Entry<Integer, String> entry : FOLD_TO_FILE.entrySet()){
            FileReader fr = null;
            try {
                fr = new FileReader(entry.getValue());
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            assert fr != null;
            BufferedReader br = new BufferedReader(fr);
            String sCurrentLine = null;
            try {
                sCurrentLine = br.readLine();
            } catch (IOException e) {
                e.printStackTrace();
            }

            TreeMap<String, Vector<ResultLine>> QUERYID_TO_RANKEDLIST = new TreeMap<>();
            String[] parts      = sCurrentLine.split("\\s+");
            String prev_id      = parts[0];
            ids.add(prev_id);
            ResultLine d        = new ResultLine(sCurrentLine);
            Vector<ResultLine> re = new Vector<ResultLine>();
            re.add(d);
            int linecounter = 0;
            try {
                while((sCurrentLine = br.readLine()) != null){
                    parts = sCurrentLine.split("\\s+");
                    if(parts[0].equalsIgnoreCase(prev_id)){
                        //Same as what we've seen so far
                        d = new ResultLine(sCurrentLine);
                        re.add(d);
                    }else{
/*
                        if(prev_id.equalsIgnoreCase("151")){
                            System.out.println("Found query 151! Size of vector is: " + re.size());
                        }
*/
                        // We have encountered a new query id. Insert the old one, clear it and loop around
                        QUERYID_TO_RANKEDLIST.put(prev_id, re);
                        re = new Vector<ResultLine>();
                        prev_id = parts[0];
                        ids.add(prev_id);
                        d = new ResultLine(sCurrentLine);
                        re.add(d);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            QUERYID_TO_RANKEDLIST.put(prev_id, re);
            System.out.println("Fold " + entry.getKey() + " - Size of QUERYID_TO_RANKEDLIST: " + QUERYID_TO_RANKEDLIST.size());
            FOLDS.put(entry.getKey(), QUERYID_TO_RANKEDLIST);
            try {
                fr.close();
                br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        System.out.println("Ids size: " + ids.size());
    }

    private void loop(){
        HashSet<String> ids = new HashSet<>();
        HashSet<String> badids = new HashSet<>();
        for(Map.Entry<Integer, TreeMap<String, Vector<ResultLine>>> entry : FOLDS.entrySet()){
            TreeMap<String, Vector<ResultLine>> rs = entry.getValue();
            for(Map.Entry<String, Vector<ResultLine>> query : rs.entrySet()){
                TreeMap<String, Integer> qrels4query = QRELS.get(query.getKey());
                for(ResultLine r : query.getValue()){
                    if(qrels4query.containsKey(r.getFileName())){
                        if(qrels4query.get(r.getFileName()) > 0){
                            //System.out.println(query.getKey() + ", " + r.getFileName() + ", " + r.getPosition() + ", " + r.getScore());
                            ids.add(query.getKey());
                        }else{
                            System.out.println(query.getKey() + ", " + r.getFileName() + ", " + r.getPosition() + ", " + r.getScore());
                        }
                    }
                }
            }
        }
        System.out.println("Ids size: " + ids.size());
    }
}
