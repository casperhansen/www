package workshop;

import java.io.File;
import java.util.SortedSet;
import java.util.TreeSet;

/**
 * Created by casper on 5/11/16.
 */
public class WriteSampleFile {

    public static void main(String[] args){
        new WriteSampleFile();
    }

    public WriteSampleFile(){

        // Directory
        String dir = "/home/casper/research/sigir2016-workshop/trained-rnns/TREC/two-layer/cv/";
        File dirpath = new File(dir);
        File[] content = dirpath.listFiles();
        int buuh = 0;
        for(File fl : content){
            //System.out.println();
            File f = new File(fl.getAbsolutePath()+"/");
            File[] files = f.listFiles();
            if(files.length != 0) {
                SortedSet<Integer> sortedNames = new TreeSet<>();
                for (File file : files) {
                    if (file.getAbsolutePath().endsWith(".t7")) {
                        sortedNames.add(Integer.parseInt(file.getName().replace(".t7", "").replace("checkpoint_", "")));
                    }
                }
                String myfile = "checkpoint_" + sortedNames.last() + ".t7";
                System.out.println("th sample.lua -checkpoint " + f.getAbsolutePath() + "/" + myfile + " -length 100000 > /home/casper/research/sigir2016-workshop/sampled-docs/TREC/TREC_OFFSET30/two-layer/"+fl.getName()+".sample100000");

                //System.out.println();
            }else{
                buuh++;
                //System.out.println("No files in " + fl.getAbsolutePath()+"/");
            }
        }
        System.out.println("No results found for " + buuh + " documents");
    }

    private void doWrite(){
        int low  = 301;
        int high = 450;
        System.out.println("#/bin/bash");
        System.out.println("cd /home/casper/torch-rnn/");
        for(int i = low; i <= high; i++){
            System.out.println("th sample.lua -checkpoint /home/casper/research/sigir2016-workshop/trained-rnns/TREC/cv/query-"+i+"/checkpoint_50000.t7 -length 300000 > /home/casper/research/sigir2016-workshop/sampled-docs/TREC/q"+i+".sample300000");
        }
    }
}
