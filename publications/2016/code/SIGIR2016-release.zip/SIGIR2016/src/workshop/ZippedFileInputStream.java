package workshop;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class ZippedFileInputStream {
    final static int bufferSize = 32 * 1024;
    public static void main(String[] args) throws IOException {
        ZipFile zipFile = new ZipFile("/home/casper/cweb09-kl-1m.zip");
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        Enumeration<? extends ZipEntry> entries = zipFile.entries();
        String line;
        int counter = 0;
/*
        final Pattern pattern = Pattern.compile("\\((.*?)\\)");
        final Matcher matcher = pattern.matcher("");
*/
        System.out.println(dateFormat.format(date) + " - Starting processing...");
        long startTime = System.nanoTime();
        while(entries.hasMoreElements()){
            ZipEntry entry = entries.nextElement();
            InputStream stream = zipFile.getInputStream(entry);
            BufferedReader reader = new BufferedReader(new InputStreamReader(stream), bufferSize);
            boolean readOpen = false;
            String str2      = "";
            while ((line = reader.readLine()) != null) {
                counter++;
                String[] parts = line.split(";");
//                String docname = parts[0];
                //parts = parts[1].split("[()]+");

                for(char c : parts[1].toCharArray()){

                    if(readOpen){
                        str2 += c;
                    }

                    if(c == '('){
                        readOpen = true;
                        continue;
                    }
                    if(c == ')'){
                        //str2 = str2.substring(0,str2.length()-1);
                        str2 = "";
                        readOpen = false;
                    }
                }


/*
                while(matcher.find()) {
                    parts = matcher.group(1).split(",");
                    //System.out.println(p[0] + "," + Integer.parseInt(p[1]));
                }
*/
            }
        }
        zipFile.close();
        long endTime = System.nanoTime();

        long duration = (endTime - startTime);
        System.out.println("Finished processing in " + (duration/1000000000) + " seconds");
        date = new Date();
        System.out.println(dateFormat.format(date) + " - Read " + counter + " lines"); //2014/08/06 15:59:48
    }
}