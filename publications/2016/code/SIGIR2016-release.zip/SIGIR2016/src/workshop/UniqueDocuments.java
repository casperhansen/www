package workshop;

import java.io.*;
import java.util.HashSet;
import java.util.zip.GZIPInputStream;

/**
 * This class creates the set of documents from e.g. /home/casper/research/sigir2016-workshop/queries/baseline-xfold-results/bpref/all
 */
public class UniqueDocuments {
    HashSet<String> documents = new HashSet<>();

    final String PERFORMANCE_MEASURE = "ndcg1000";

    public static void main(String[] args) throws IOException {
        new UniqueDocuments();
    }

    public UniqueDocuments() throws IOException {
        doProcess();
        parse();
    }

    private void doProcess() throws IOException {
        FileReader fr = new FileReader("/home/casper/research/sigir2016-workshop/queries/baseline-xfold-results/"+PERFORMANCE_MEASURE+"/all");
        BufferedReader br = new BufferedReader(fr);
        String sCurrentLine;
        int counter = 0;
        while((sCurrentLine = br.readLine()) != null){
            String[] parts = sCurrentLine.split("\\s+");
            documents.add(parts[2]);
            counter++;
        }
        fr.close();
        br.close();

        System.out.println("Read " + counter + " lines. Total documents: " + documents.size());
    }

    private void parse() throws IOException {
        InputStream fileStream = new FileInputStream("/home/casper/research/sigir2016-workshop/collection/experiment2/three-layer/trecdisks45-stopwords.txt.gz");
        InputStream gzipStream = new GZIPInputStream(fileStream);
        Reader decoder = new InputStreamReader(gzipStream);
        BufferedReader buffered = new BufferedReader(decoder);

        PrintWriter pw = new PrintWriter("/home/casper/research/sigir2016-workshop/collection/experiment2/three-layer/out/"+PERFORMANCE_MEASURE+"/"+PERFORMANCE_MEASURE+".txt");
        int matches = 0;
        String sCurrentLine;
        while((sCurrentLine = buffered.readLine()) != null){
                String[] parts = sCurrentLine.split(";");
                if(documents.contains(parts[0])){
                    pw.println(sCurrentLine);
                    matches++;
                }
        }
        pw.flush();
        pw.close();
        System.out.println("Found " + matches + " matches");
    }
}
