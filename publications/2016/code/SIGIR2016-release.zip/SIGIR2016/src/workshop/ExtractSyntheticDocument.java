package workshop;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.Random;
import java.util.TreeMap;
import java.util.Vector;

/**
 * The purpose of this class is to read a sampled file from e.g. /home/casper/research/sigir2016-workshop/sampled-docs/
 * and write out all "documents" found between '?' which is the EOF character
 */
public class ExtractSyntheticDocument {

    /*
     Contains all documents read from the input file in a <id, Vector<Characters> > TreeMap
     */
    private TreeMap<Integer, Integer> counts = new TreeMap<>();
    private TreeMap<Integer, Vector<Character>> documents = new TreeMap<>();

    public static void main(String[] args) throws IOException {
        new ExtractSyntheticDocument(args[0]);
    }

    public ExtractSyntheticDocument(String infile) throws IOException {
        doProcess(infile);
    }

    private void doProcess(String infile) throws IOException {
        //System.out.println(infile);
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(
                        new FileInputStream(infile),
                        Charset.forName("UTF-8")));
        int c;
        int docid = 1;
        Vector<Character> document = new Vector<>();
        Random rand = new Random();
        final int TOTAL_MAX_SIZE = 10000;
        final int TOTAL_MIN_SIZE = 5000;
        int randomNum = TOTAL_MIN_SIZE + rand.nextInt((TOTAL_MAX_SIZE - TOTAL_MIN_SIZE) + 1);

        int counter = 0;
        while((c = reader.read()) != -1) {
            char character = (char) c;
            if(character != '?' && counter < randomNum){
                document.add(character);
            }else{
                // Notice this counts characters - not words!
                counts.put(docid, document.size());
                documents.put(docid, document);
                document = new Vector<>();
                docid++;
                counter = 0;
            }
            counter++;
        }
        counts.put(docid, document.size());
        documents.put(docid, document);
        reader.close();

        System.out.println("Read " + documents.size() + " documents from " + infile);
    }

    TreeMap<Integer, Vector<Character>> getDocuments(){
        return documents;
    }

    TreeMap<Integer, Integer> getDocumentStatistics(){
        return counts;
    }
}
